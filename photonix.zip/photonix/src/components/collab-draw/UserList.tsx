'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Users, X } from 'lucide-react';
import type { RoomUser } from './types';

interface UserListProps {
  users: RoomUser[];
  currentUsername: string;
}

export default function UserList({ users, currentUsername }: UserListProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        variant="outline"
        size="sm"
        className="h-8 gap-1.5 text-slate-600 bg-white border-slate-200 hover:bg-slate-50"
      >
        <Users className="w-4 h-4" />
        <span className="text-xs font-medium">{users.length}</span>
      </Button>

      {isOpen && (
        <div className="absolute top-12 right-0 z-50 w-56 bg-white rounded-lg shadow-xl border border-slate-200 overflow-hidden animate-in slide-in-from-top-2 duration-150">
          <div className="px-3 py-2 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <h3 className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              Online ({users.length})
            </h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <ScrollArea className="max-h-60">
            <div className="p-2 space-y-1">
              {users.map((user) => {
                const isMe = user.username === currentUsername;
                return (
                  <div
                    key={user.id}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-slate-50 transition-colors"
                  >
                    <div
                      className="w-3 h-3 rounded-full shrink-0 ring-2 ring-white shadow-sm"
                      style={{ backgroundColor: user.color }}
                    />
                    <span className="text-sm text-slate-700 truncate">
                      {user.username}
                      {isMe && (
                        <span className="text-[10px] text-violet-500 font-medium ml-1">(you)</span>
                      )}
                    </span>
                    <div className="ml-auto w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </div>
      )}
    </>
  );
}
