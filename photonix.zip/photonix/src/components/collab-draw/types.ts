export type Tool = 'pen' | 'eraser' | 'line' | 'rectangle' | 'circle' | 'arrow';

export interface Point {
  x: number;
  y: number;
}

export interface DrawAction {
  type: 'stroke' | 'shape' | 'clear' | 'image';
  tool: Tool;
  points: Point[];
  color: string;
  size: number;

  startX?: number;
  startY?: number;
  endX?: number;
  endY?: number;

  imageData?: string;
  imageX?: number;
  imageY?: number;
  imageWidth?: number;
  imageHeight?: number;
}

export interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: number;
}

export interface RoomUser {
  id: string;
  username: string;
  color: string;
}

export interface CanvasState {
  actions: DrawAction[];
  redoStack: DrawAction[];
}
