'use client';

import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  Pen,
  Eraser,
  Minus,
  Square,
  Circle,
  MoveRight,
  Undo2,
  Redo2,
  Trash2,
  Download,
  FileImage,
  FileDown,
  ImagePlus,
} from 'lucide-react';
import type { Tool } from './types';

interface ToolbarProps {
  tool: Tool;
  onToolChange: (tool: Tool) => void;
  color: string;
  onColorChange: (color: string) => void;
  size: number;
  onSizeChange: (size: number) => void;
  onUndo: () => void;
  onRedo: () => void;
  onClear: () => void;
  onDownloadImage: () => void;
  onDownloadPDF: () => void;
  onUploadImage: () => void;
  canUndo: boolean;
  canRedo: boolean;
}

const PRESET_COLORS = [
  '#000000', '#ffffff', '#ef4444', '#f97316', '#eab308',
  '#22c55e', '#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899',
  '#78716c', '#6b7280', '#a3a3a3', '#d4d4d4',
];

const TOOLS: { id: Tool; icon: React.ReactNode; label: string }[] = [
  { id: 'pen', icon: <Pen className="w-4 h-4" />, label: 'Pen' },
  { id: 'eraser', icon: <Eraser className="w-4 h-4" />, label: 'Eraser' },
  { id: 'line', icon: <Minus className="w-4 h-4" />, label: 'Line' },
  { id: 'rectangle', icon: <Square className="w-4 h-4" />, label: 'Rectangle' },
  { id: 'circle', icon: <Circle className="w-4 h-4" />, label: 'Circle' },
  { id: 'arrow', icon: <MoveRight className="w-4 h-4" />, label: 'Arrow' },
];

export default function Toolbar({
  tool,
  onToolChange,
  color,
  onColorChange,
  size,
  onSizeChange,
  onUndo,
  onRedo,
  onClear,
  onDownloadImage,
  onDownloadPDF,
  onUploadImage,
  canUndo,
  canRedo,
}: ToolbarProps) {
  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex items-center gap-1 px-3 py-2 bg-white border-b border-slate-200 overflow-x-auto">
        <div className="flex items-center gap-1">
          {TOOLS.map(({ id, icon, label }) => (
            <Tooltip key={id}>
              <TooltipTrigger asChild>
                <Button
                  variant={tool === id ? 'default' : 'ghost'}
                  size="sm"
                  className={`h-8 w-8 p-0 ${
                    tool === id
                      ? 'bg-violet-600 hover:bg-violet-700 text-white shadow-sm'
                      : 'hover:bg-slate-100 text-slate-600'
                  }`}
                  onClick={() => onToolChange(id)}
                >
                  {icon}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">
                {label}
              </TooltipContent>
            </Tooltip>
          ))}
        </div>

        <Separator orientation="vertical" className="h-6 mx-1" />

        <div className="flex items-center gap-1.5">
          <div className="relative">
            <input
              type="color"
              value={color}
              onChange={(e) => onColorChange(e.target.value)}
              className="w-7 h-7 rounded-md border-2 border-slate-200 cursor-pointer appearance-none bg-transparent [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded-md [&::-webkit-color-swatch]:border-none"
            />
          </div>
          <div className="hidden sm:flex items-center gap-0.5">
            {PRESET_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => onColorChange(c)}
                className={`w-4 h-4 rounded-full border transition-all hover:scale-125 ${
                  color === c ? 'ring-1 ring-offset-1 ring-slate-400 scale-125' : 'border-slate-200'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>

        <Separator orientation="vertical" className="h-6 mx-1" />

        <div className="flex items-center gap-2 min-w-[100px]">
          <span className="text-xs text-slate-400 whitespace-nowrap">Size</span>
          <Slider
            value={[size]}
            onValueChange={([v]) => onSizeChange(v)}
            min={1}
            max={50}
            step={1}
            className="w-20"
          />
          <span className="text-xs text-slate-500 font-mono w-5 text-right">{size}</span>
        </div>

        <Separator orientation="vertical" className="h-6 mx-1" />

        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-slate-600 hover:bg-slate-100 disabled:opacity-30"
                onClick={onUndo}
                disabled={!canUndo}
              >
                <Undo2 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Undo</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-slate-600 hover:bg-slate-100 disabled:opacity-30"
                onClick={onRedo}
                disabled={!canRedo}
              >
                <Redo2 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Redo</TooltipContent>
          </Tooltip>
        </div>

        <Separator orientation="vertical" className="h-6 mx-1" />

        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-slate-600 hover:bg-slate-100"
                onClick={onUploadImage}
              >
                <ImagePlus className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Upload Image</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-slate-600 hover:bg-slate-100"
                onClick={onDownloadImage}
              >
                <FileImage className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Download PNG</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-slate-600 hover:bg-slate-100"
                onClick={onDownloadPDF}
              >
                <FileDown className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Download PDF</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-red-500 hover:bg-red-50"
                onClick={onClear}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">Clear Canvas</TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}
