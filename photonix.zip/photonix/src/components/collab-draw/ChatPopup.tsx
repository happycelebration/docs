'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MessageCircle, X, Send } from 'lucide-react';
import type { ChatMessage } from './types';

interface ChatPopupProps {
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
  currentUsername: string;
}

export default function ChatPopup({ messages, onSendMessage, currentUsername }: ChatPopupProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const prevMsgLengthRef = useRef(messages.length);

  useEffect(() => {
    const newMsgs = messages.length - prevMsgLengthRef.current;
    prevMsgLengthRef.current = messages.length;

    if (!isOpen && newMsgs > 0) {
      setUnreadCount((prev) => prev + newMsgs);
    }
  }, [messages.length, isOpen]);

  useEffect(() => {
    if (isOpen && scrollRef.current) {
      const el = scrollRef.current;
      el.scrollTop = el.scrollHeight;
    }
  }, [messages, isOpen]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleToggle = useCallback(() => {
    setIsOpen((prev) => {
      if (!prev) {
        setUnreadCount(0);
      }
      return !prev;
    });
  }, []);

  const handleSend = useCallback(() => {
    const trimmed = input.trim();
    if (!trimmed) return;
    setInput('');
    try {
      onSendMessage(trimmed);
    } catch {}
    setTimeout(() => inputRef.current?.focus(), 0);
  }, [input, onSendMessage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <>
      <Button
        onClick={handleToggle}
        className="fixed bottom-4 right-4 z-50 h-12 w-12 rounded-full shadow-lg bg-violet-600 hover:bg-violet-700 text-white transition-all duration-200 hover:scale-105"
        size="sm"
      >
        {isOpen ? <X className="w-5 h-5" /> : <MessageCircle className="w-5 h-5" />}
        {unreadCount > 0 && !isOpen && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-[10px] font-bold text-white flex items-center justify-center animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </Button>

      {isOpen && (
        <div className="fixed bottom-20 right-4 z-50 w-80 sm:w-96 h-[440px] bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-200">
          <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-r from-violet-500 to-purple-600">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              Room Chat
            </h3>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2 scroll-smooth">
            {messages.length === 0 && (
              <div className="text-center text-slate-400 text-xs py-8">
                No messages yet. Say hello!
              </div>
            )}
            {messages.map((msg) => {
              const isMe = msg.username === currentUsername;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-baseline gap-1.5 mb-0.5">
                    <span className="text-[10px] font-semibold text-violet-600 truncate max-w-[120px]">
                      {msg.username}
                    </span>
                    <span className="text-[9px] text-slate-400">{formatTime(msg.timestamp)}</span>
                  </div>
                  <div
                    className={`px-3 py-1.5 rounded-xl text-sm max-w-[85%] break-words ${
                      isMe
                        ? 'bg-violet-600 text-white rounded-br-sm'
                        : 'bg-slate-100 text-slate-700 rounded-bl-sm'
                    }`}
                  >
                    {msg.message}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 border-t border-slate-200 bg-slate-50/50">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                className="h-9 text-sm bg-white"
                maxLength={500}
              />
              <Button
                type="button"
                size="sm"
                className="h-9 px-3 bg-violet-600 hover:bg-violet-700 text-white"
                disabled={!input.trim()}
                onClick={handleSend}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
