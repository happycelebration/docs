'use client';

import { useEffect, useRef, useCallback, useState } from 'react';
import type { ChatMessage, DrawAction, RoomUser } from './types';

const SCALEDRONE_CHANNEL_ID = 'qYFx0t9HCbiJ47ue';
const SCALEDRONE_SCRIPT_URL = 'https://cdn.scaledrone.com/scaledrone.min.js';
const MAX_MESSAGE_SIZE = 9000;

type RoomMessage =
  | { type: 'draw'; action: DrawAction }
  | { type: 'draw-chunk'; chunkIndex: number; totalChunks: number; strokeId: string; tool: string; color: string; size: number; points: { x: number; y: number }[] }
  | { type: 'image-chunk'; chunkIndex: number; totalChunks: number; imageId: string; dataURLPiece: string }
  | { type: 'chat'; message: ChatMessage };

interface UseScaledroneOptions {
  roomId: string;
  username: string;
  userColor: string;
  onDrawAction?: (action: DrawAction) => void;
  onChatMessage?: (message: ChatMessage) => void;
  onUserJoin?: (user: RoomUser) => void;
  onUserLeave?: (user: RoomUser) => void;
  onUsersUpdate?: (users: RoomUser[]) => void;
}

function loadScaledroneScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if ((window as any).Scaledrone) {
      resolve();
      return;
    }
    const existing = document.querySelector(`script[src="${SCALEDRONE_SCRIPT_URL}"]`);
    if (existing) {
      const check = () => {
        if ((window as any).Scaledrone) resolve();
        else setTimeout(check, 50);
      };
      check();
      return;
    }
    const script = document.createElement('script');
    script.src = SCALEDRONE_SCRIPT_URL;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Scaledrone SDK'));
    document.head.appendChild(script);
  });
}

function getMessageSize(msg: any): number {
  return new TextEncoder().encode(JSON.stringify(msg)).length;
}

export function useScaledrone({
  roomId,
  username,
  userColor,
  onDrawAction,
  onChatMessage,
  onUserJoin,
  onUserLeave,
  onUsersUpdate,
}: UseScaledroneOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [debugInfo, setDebugInfo] = useState({
    status: 'disconnected',
    roomOpen: false,
    drawSent: 0,
    drawRecv: 0,
    chatSent: 0,
    chatRecv: 0,
    lastError: '',
    clientId: '',
  });

  const droneRef = useRef<any>(null);
  const roomRef = useRef<any>(null);
  const strokeChunkBufferRef = useRef<Map<string, { chunks: Map<number, { x: number; y: number }[]>; totalChunks: number; tool: string; color: string; size: number }>>(new Map());
  const imageChunkBufferRef = useRef<Map<string, { chunks: Map<number, string>; totalChunks: number }>>(new Map());

  const onDrawActionRef = useRef(onDrawAction);
  const onChatMessageRef = useRef(onChatMessage);
  const onUserJoinRef = useRef(onUserJoin);
  const onUserLeaveRef = useRef(onUserLeave);
  const onUsersUpdateRef = useRef(onUsersUpdate);

  useEffect(() => {
    onDrawActionRef.current = onDrawAction;
    onChatMessageRef.current = onChatMessage;
    onUserJoinRef.current = onUserJoin;
    onUserLeaveRef.current = onUserLeave;
    onUsersUpdateRef.current = onUsersUpdate;
  });

  useEffect(() => {
    if (!roomId || !username) return;

    let cancelled = false;
    const roomName = `observable-photonix-${roomId}`;

    const init = async () => {
      try {
        await loadScaledroneScript();
      } catch {
        setDebugInfo((p) => ({ ...p, status: 'script-failed', lastError: 'SDK load failed' }));
        return;
      }

      if (cancelled) return;

      const ScaledroneConstructor = (window as any).Scaledrone;
      const drone = new ScaledroneConstructor(SCALEDRONE_CHANNEL_ID, {
        data: { username, color: userColor },
      });

      droneRef.current = drone;
      setDebugInfo((p) => ({ ...p, status: 'connecting' }));

      drone.on('open', (error: any) => {
        if (error) {
          setDebugInfo((p) => ({ ...p, status: 'open-error', lastError: String(error?.message || error) }));
          return;
        }
        if (cancelled) return;

        const cid = drone.clientId || '';
        setIsConnected(true);
        setDebugInfo((p) => ({ ...p, status: 'connected', clientId: cid }));

        const room = drone.subscribe(roomName, { historyCount: 100 });
        roomRef.current = room;

        room.on('open', () => {
          if (!cancelled) {
            setDebugInfo((p) => ({ ...p, status: 'room-open', roomOpen: true }));
          }
        });

        room.on('data', (data: any, member: any) => {
          if (cancelled) return;
          if (member && member.id === drone.clientId) return;

          try {
            const msg = data as RoomMessage;

            if (msg.type === 'draw' && msg.action) {
              setDebugInfo((p) => ({ ...p, drawRecv: p.drawRecv + 1 }));
              onDrawActionRef.current?.(msg.action);

            } else if (msg.type === 'draw-chunk') {
              const chunk = msg as any;
              const { chunkIndex, totalChunks, strokeId, tool, color, size, points } = chunk;

              let buffer = strokeChunkBufferRef.current.get(strokeId);
              if (!buffer) {
                buffer = { chunks: new Map(), totalChunks, tool, color, size };
                strokeChunkBufferRef.current.set(strokeId, buffer);
              }
              buffer.chunks.set(chunkIndex, points);

              if (buffer.chunks.size === totalChunks) {
                strokeChunkBufferRef.current.delete(strokeId);
                const allPoints: { x: number; y: number }[] = [];
                for (let i = 0; i < totalChunks; i++) {
                  const chunkPoints = buffer.chunks.get(i);
                  if (chunkPoints) allPoints.push(...chunkPoints);
                }
                setDebugInfo((p) => ({ ...p, drawRecv: p.drawRecv + 1 }));
                onDrawActionRef.current?.({
                  type: 'stroke',
                  tool: tool as any,
                  points: allPoints,
                  color,
                  size,
                });
              }

            } else if (msg.type === 'image-chunk') {
              const chunk = msg as any;
              const { chunkIndex, totalChunks, imageId, dataURLPiece } = chunk;

              let buffer = imageChunkBufferRef.current.get(imageId);
              if (!buffer) {
                buffer = { chunks: new Map(), totalChunks };
                imageChunkBufferRef.current.set(imageId, buffer);
              }
              buffer.chunks.set(chunkIndex, dataURLPiece);

              if (buffer.chunks.size === totalChunks) {
                imageChunkBufferRef.current.delete(imageId);
                let fullDataURL = '';
                for (let i = 0; i < totalChunks; i++) {
                  const piece = buffer.chunks.get(i);
                  if (piece) fullDataURL += piece;
                }
                setDebugInfo((p) => ({ ...p, drawRecv: p.drawRecv + 1 }));
                onDrawActionRef.current?.({
                  type: 'image',
                  tool: 'pen',
                  points: [],
                  color: '#000000',
                  size: 0,
                  imageData: fullDataURL,
                  imageX: 0,
                  imageY: 0,
                });
              }

            } else if (msg.type === 'chat' && msg.message) {
              setDebugInfo((p) => ({ ...p, chatRecv: p.chatRecv + 1 }));
              onChatMessageRef.current?.(msg.message);
            }
          } catch (e: any) {
            setDebugInfo((p) => ({ ...p, lastError: `recv: ${e?.message || 'err'}` }));
          }
        });

        room.on('members', (members: any[]) => {
          if (cancelled) return;
          const users: RoomUser[] = members.map((m: any) => ({
            id: m.id,
            username: m.clientData?.username || 'Anonymous',
            color: m.clientData?.color || '#8b5cf6',
          }));
          onUsersUpdateRef.current?.(users);
        });

        room.on('member_join', (member: any) => {
          if (cancelled) return;
          onUserJoinRef.current?.({
            id: member.id,
            username: member.clientData?.username || 'Anonymous',
            color: member.clientData?.color || '#8b5cf6',
          });
        });

        room.on('member_leave', (member: any) => {
          if (cancelled) return;
          onUserLeaveRef.current?.({
            id: member.id,
            username: member.clientData?.username || 'Anonymous',
            color: member.clientData?.color || '#8b5cf6',
          });
        });

        room.on('error', (err: any) => {
          setDebugInfo((p) => ({ ...p, lastError: `room-err: ${String(err?.message || err)}` }));
        });
      });

      drone.on('error', (err: any) => {
        setDebugInfo((p) => ({ ...p, status: 'error', lastError: `drone: ${String(err?.message || err)}` }));
      });

      drone.on('close', () => {
        setIsConnected(false);
        setDebugInfo((p) => ({ ...p, status: 'closed', roomOpen: false }));
      });
    };

    init();

    return () => {
      cancelled = true;
      roomRef.current = null;
      strokeChunkBufferRef.current.clear();
      imageChunkBufferRef.current.clear();
      if (droneRef.current) {
        try { droneRef.current.close(); } catch {}
        droneRef.current = null;
      }
      setIsConnected(false);
      setDebugInfo({
        status: 'disconnected', roomOpen: false,
        drawSent: 0, drawRecv: 0, chatSent: 0, chatRecv: 0, lastError: '', clientId: '',
      });
    };
  }, [roomId, username, userColor]);

  const publishDrawAction = useCallback((action: DrawAction) => {
    const drone = droneRef.current;
    if (!drone) {
      setDebugInfo((p) => ({ ...p, lastError: 'pub-draw: no drone' }));
      return;
    }
    const roomName = `observable-photonix-${roomId}`;

    try {
      if (action.type === 'stroke' && action.points.length > 0) {
        const msg: RoomMessage = { type: 'draw', action };
        const size = getMessageSize({ room: roomName, message: msg });

        if (size <= MAX_MESSAGE_SIZE) {
          drone.publish({ room: roomName, message: msg });
          setDebugInfo((p) => ({ ...p, drawSent: p.drawSent + 1 }));
        } else {
          const pointsPerChunk = Math.max(Math.floor(action.points.length / Math.ceil(size / MAX_MESSAGE_SIZE)), 10);
          const strokeId = `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
          const chunks: { x: number; y: number }[][] = [];

          for (let i = 0; i < action.points.length; i += pointsPerChunk) {
            chunks.push(action.points.slice(i, i + pointsPerChunk));
          }

          for (let i = 0; i < chunks.length; i++) {
            const chunkMsg = {
              type: 'draw-chunk' as const,
              chunkIndex: i,
              totalChunks: chunks.length,
              strokeId,
              tool: action.tool,
              color: action.color,
              size: action.size,
              points: chunks[i],
            };
            drone.publish({ room: roomName, message: chunkMsg });
          }
          setDebugInfo((p) => ({ ...p, drawSent: p.drawSent + 1 }));
        }
      } else if (action.type === 'shape' || action.type === 'clear') {
        const msg: RoomMessage = { type: 'draw', action };
        drone.publish({ room: roomName, message: msg });
        setDebugInfo((p) => ({ ...p, drawSent: p.drawSent + 1 }));
      } else if (action.type === 'image' && action.imageData) {
        const imageId = `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
        const dataURL = action.imageData;
        const chunkSize = 6000;
        const totalChunks = Math.ceil(dataURL.length / chunkSize);

        for (let i = 0; i < totalChunks; i++) {
          const chunkMsg = {
            type: 'image-chunk' as const,
            chunkIndex: i,
            totalChunks,
            imageId,
            dataURLPiece: dataURL.substring(i * chunkSize, (i + 1) * chunkSize),
          };
          drone.publish({ room: roomName, message: chunkMsg });
        }
        setDebugInfo((p) => ({ ...p, drawSent: p.drawSent + 1 }));
      }
    } catch (e: any) {
      setDebugInfo((p) => ({ ...p, lastError: `pub-draw: ${e?.message || 'err'}` }));
    }
  }, [roomId]);

  const publishChatMessage = useCallback((message: ChatMessage) => {
    const drone = droneRef.current;
    if (!drone) {
      setDebugInfo((p) => ({ ...p, lastError: 'pub-chat: no drone' }));
      return;
    }
    const roomName = `observable-photonix-${roomId}`;
    const msg: RoomMessage = { type: 'chat', message };
    try {
      drone.publish({ room: roomName, message: msg });
      setDebugInfo((p) => ({ ...p, chatSent: p.chatSent + 1 }));
    } catch (e: any) {
      setDebugInfo((p) => ({ ...p, lastError: `pub-chat: ${e?.message || 'err'}` }));
    }
  }, [roomId]);

  return {
    isConnected,
    debugInfo,
    publishDrawAction,
    publishChatMessage,
  };
}
