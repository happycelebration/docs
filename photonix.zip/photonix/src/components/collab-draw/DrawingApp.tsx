'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { Copy, LogOut, Check } from 'lucide-react';
import type { Tool, DrawAction, Point, ChatMessage, RoomUser } from './types';
import { useScaledrone } from './useScaledrone';
import Toolbar from './Toolbar';
import ChatPopup from './ChatPopup';
import UserList from './UserList';

interface DrawingAppProps {
  roomId: string;
  username: string;
  userColor: string;
  onLeave: () => void;
}

export default function DrawingApp({ roomId, username, userColor, onLeave }: DrawingAppProps) {

  const [tool, setTool] = useState<Tool>('pen');
  const [color, setColor] = useState('#000000');
  const [size, setSize] = useState(3);
  const [actions, setActions] = useState<DrawAction[]>([]);
  const [redoStack, setRedoStack] = useState<DrawAction[]>([]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  const [users, setUsers] = useState<RoomUser[]>([]);

  const isDrawingRef = useRef(false);
  const lastXRef = useRef(0);
  const lastYRef = useRef(0);
  const shapeStartRef = useRef<Point | null>(null);
  const shapeEndRef = useRef<Point | null>(null);
  const currentStrokeRef = useRef<Point[]>([]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const cursorRef = useRef<HTMLDivElement>(null);

  const toolRef = useRef(tool);
  const colorRef = useRef(color);
  const sizeRef = useRef(size);
  toolRef.current = tool;
  colorRef.current = color;
  sizeRef.current = size;

  const actionsRef = useRef(actions);
  actionsRef.current = actions;

  const redrawNeededRef = useRef(false);

  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const roomUrl = typeof window !== 'undefined' ? `${window.location.origin}#${roomId}` : '';

  const getMainCtx = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return canvas.getContext('2d');
  }, []);

  const getOverlayCtx = useCallback(() => {
    const overlay = overlayCanvasRef.current;
    if (!overlay) return null;
    return overlay.getContext('2d');
  }, []);

  const drawActionOnCtx = useCallback((ctx: CanvasRenderingContext2D, action: DrawAction) => {
    ctx.save();

    if (action.type === 'clear') {
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      ctx.restore();
      return;
    }

    if (action.type === 'image' && action.imageData) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, ctx.canvas.width, ctx.canvas.height);
      };
      img.src = action.imageData;
      ctx.restore();
      return;
    }

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (action.type === 'stroke') {
      const isEraser = action.tool === 'eraser';
      ctx.globalCompositeOperation = isEraser ? 'destination-out' : 'source-over';
      ctx.strokeStyle = isEraser ? 'rgba(0,0,0,1)' : action.color;
      ctx.lineWidth = isEraser ? Math.max(action.size, 20) : action.size;

      if (action.points.length === 1) {
        ctx.beginPath();
        ctx.arc(action.points[0].x, action.points[0].y, action.size / 2, 0, Math.PI * 2);
        ctx.fillStyle = isEraser ? 'rgba(0,0,0,1)' : action.color;
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(action.points[0].x, action.points[0].y);
        for (let i = 1; i < action.points.length; i++) {
          ctx.lineTo(action.points[i].x, action.points[i].y);
        }
        ctx.stroke();
      }
    } else if (action.type === 'shape') {
      ctx.strokeStyle = action.color;
      ctx.lineWidth = action.size;
      const sx = action.startX || 0;
      const sy = action.startY || 0;
      const ex = action.endX || 0;
      const ey = action.endY || 0;

      if (action.tool === 'line') {
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(ex, ey);
        ctx.stroke();
      } else if (action.tool === 'rectangle') {
        ctx.beginPath();
        ctx.strokeRect(Math.min(sx, ex), Math.min(sy, ey), Math.abs(ex - sx), Math.abs(ey - sy));
      } else if (action.tool === 'circle') {
        const rx = Math.abs(ex - sx) / 2;
        const ry = Math.abs(ey - sy) / 2;
        const cx = Math.min(sx, ex) + rx;
        const cy = Math.min(sy, ey) + ry;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else if (action.tool === 'arrow') {
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(ex, ey);
        ctx.stroke();
        const angle = Math.atan2(ey - sy, ex - sx);
        const headLen = Math.max(15, action.size * 3);
        ctx.beginPath();
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex - headLen * Math.cos(angle - Math.PI / 6), ey - headLen * Math.sin(angle - Math.PI / 6));
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex - headLen * Math.cos(angle + Math.PI / 6), ey - headLen * Math.sin(angle + Math.PI / 6));
        ctx.stroke();
      }
    }

    ctx.restore();
  }, []);

  const redrawCanvas = useCallback((canvasActions: DrawAction[]) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (const action of canvasActions) {
      drawActionOnCtx(ctx, action);
    }
  }, [drawActionOnCtx]);

  const drawSingleAction = useCallback((action: DrawAction) => {
    const ctx = getMainCtx();
    if (!ctx) return;
    drawActionOnCtx(ctx, action);
  }, [getMainCtx, drawActionOnCtx]);

  const handleDrawAction = useCallback((action: DrawAction) => {
    setActions((prev) => {
      const next = [...prev, action];
      requestAnimationFrame(() => drawSingleAction(action));
      return next;
    });
  }, [drawSingleAction]);

  const handleChatMessage = useCallback((message: ChatMessage) => {
    setChatMessages((prev) => [...prev, message]);
  }, []);

  const handleUserJoin = useCallback((user: RoomUser) => {
    setUsers((prev) => {
      if (prev.find((u) => u.id === user.id)) return prev;
      return [...prev, user];
    });
    toast({ title: `${user.username} joined`, description: 'A new collaborator has joined the room', duration: 2000 });
  }, []);

  const handleUserLeave = useCallback((user: RoomUser) => {
    setUsers((prev) => prev.filter((u) => u.id !== user.id));
    toast({ title: `${user.username} left`, description: 'A collaborator has left the room', duration: 2000 });
  }, []);

  const handleUsersUpdate = useCallback((usersList: RoomUser[]) => {
    setUsers(usersList);
  }, []);

  const { isConnected, debugInfo, publishDrawAction, publishChatMessage } = useScaledrone({
    roomId, username, userColor,
    onDrawAction: handleDrawAction,
    onChatMessage: handleChatMessage,
    onUserJoin: handleUserJoin,
    onUserLeave: handleUserLeave,
    onUsersUpdate: handleUsersUpdate,
  });

  useEffect(() => {
    const resizeCanvas = () => {
      const canvas = canvasRef.current;
      const overlay = overlayCanvasRef.current;
      const container = containerRef.current;
      if (!canvas || !overlay || !container) return;

      const rect = container.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
      overlay.width = rect.width;
      overlay.height = rect.height;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
      }

      redrawNeededRef.current = true;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  useEffect(() => {
    if (redrawNeededRef.current) {
      redrawNeededRef.current = false;
      redrawCanvas(actionsRef.current);
    }
  });

  useEffect(() => {
    const cursor = cursorRef.current;
    if (!cursor) return;
    const s = Math.max(size, 4);
    cursor.style.width = `${s}px`;
    cursor.style.height = `${s}px`;
    cursor.style.borderColor = tool === 'eraser' ? '#94a3b8' : color;
    cursor.style.backgroundColor = tool === 'eraser' ? 'rgba(255,255,255,0.3)' : 'transparent';
  }, [tool, color, size]);

  const getPointFromEvent = useCallback((e: MouseEvent | Touch): Point => {
    const container = containerRef.current;
    if (!container) return { x: 0, y: 0 };
    const rect = container.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const startDrawing = (e: MouseEvent | Touch) => {
      const rawPoint = getPointFromEvent(e);
      const point = { x: Math.round(rawPoint.x), y: Math.round(rawPoint.y) };
      isDrawingRef.current = true;
      lastXRef.current = rawPoint.x;
      lastYRef.current = rawPoint.y;
      shapeStartRef.current = rawPoint;
      shapeEndRef.current = rawPoint;
      currentStrokeRef.current = [point];
    };

    const onMouseDown = (e: MouseEvent) => {
      e.preventDefault();
      startDrawing(e);
    };

    const onTouchStart = (e: TouchEvent) => {
      e.preventDefault();
      if (e.touches[0]) startDrawing(e.touches[0]);
    };

    const draw = (e: MouseEvent | Touch) => {
      const point = getPointFromEvent(e);
      const currentTool = toolRef.current;
      const currentColor = colorRef.current;
      const currentSize = sizeRef.current;

      const cursor = cursorRef.current;
      if (cursor && (currentTool === 'pen' || currentTool === 'eraser')) {
        cursor.style.left = `${point.x}px`;
        cursor.style.top = `${point.y}px`;
        cursor.style.display = 'block';
      } else if (cursor) {
        cursor.style.display = 'none';
      }

      if (!isDrawingRef.current) return;

      if (currentTool === 'pen' || currentTool === 'eraser') {

        const ctx = getMainCtx();
        if (ctx) {
          ctx.beginPath();
          ctx.moveTo(lastXRef.current, lastYRef.current);
          ctx.lineTo(point.x, point.y);
          if (currentTool === 'eraser') {
            ctx.strokeStyle = 'rgba(0,0,0,1)';
            ctx.lineWidth = Math.max(currentSize, 20);
            ctx.globalCompositeOperation = 'destination-out';
          } else {
            ctx.strokeStyle = currentColor;
            ctx.lineWidth = currentSize;
            ctx.globalCompositeOperation = 'source-over';
          }
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.stroke();
        }
        lastXRef.current = point.x;
        lastYRef.current = point.y;
        const lastStrokePoint = currentStrokeRef.current[currentStrokeRef.current.length - 1];
        if (!lastStrokePoint || Math.abs(point.x - lastStrokePoint.x) >= 2 || Math.abs(point.y - lastStrokePoint.y) >= 2) {
          currentStrokeRef.current.push({ x: Math.round(point.x), y: Math.round(point.y) });
        }
      } else {

        shapeEndRef.current = point;
        const overlay = overlayCanvasRef.current;
        const start = shapeStartRef.current;
        if (overlay && start) {
          const ctx = overlay.getContext('2d');
          if (ctx) {
            ctx.clearRect(0, 0, overlay.width, overlay.height);
            ctx.strokeStyle = currentColor;
            ctx.lineWidth = currentSize;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            if (currentTool === 'line') {
              ctx.beginPath();
              ctx.moveTo(start.x, start.y);
              ctx.lineTo(point.x, point.y);
              ctx.stroke();
            } else if (currentTool === 'rectangle') {
              ctx.beginPath();
              ctx.strokeRect(Math.min(start.x, point.x), Math.min(start.y, point.y), Math.abs(point.x - start.x), Math.abs(point.y - start.y));
            } else if (currentTool === 'circle') {
              const rx = Math.abs(point.x - start.x) / 2;
              const ry = Math.abs(point.y - start.y) / 2;
              const cx = Math.min(start.x, point.x) + rx;
              const cy = Math.min(start.y, point.y) + ry;
              ctx.beginPath();
              ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
              ctx.stroke();
            } else if (currentTool === 'arrow') {
              ctx.beginPath();
              ctx.moveTo(start.x, start.y);
              ctx.lineTo(point.x, point.y);
              ctx.stroke();
              const angle = Math.atan2(point.y - start.y, point.x - start.x);
              const headLen = Math.max(15, currentSize * 3);
              ctx.beginPath();
              ctx.moveTo(point.x, point.y);
              ctx.lineTo(point.x - headLen * Math.cos(angle - Math.PI / 6), point.y - headLen * Math.sin(angle - Math.PI / 6));
              ctx.moveTo(point.x, point.y);
              ctx.lineTo(point.x - headLen * Math.cos(angle + Math.PI / 6), point.y - headLen * Math.sin(angle + Math.PI / 6));
              ctx.stroke();
            }
          }
        }
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      draw(e);
    };

    const onTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      if (e.touches[0]) draw(e.touches[0]);
    };

    const stopDrawing = () => {
      if (!isDrawingRef.current) return;
      isDrawingRef.current = false;

      const currentTool = toolRef.current;
      const currentColor = colorRef.current;
      const currentSize = sizeRef.current;

      const overlay = overlayCanvasRef.current;
      if (overlay) {
        const ctx = overlay.getContext('2d');
        if (ctx) ctx.clearRect(0, 0, overlay.width, overlay.height);
      }

      let newAction: DrawAction;

      if (currentTool === 'pen' || currentTool === 'eraser') {
        newAction = {
          type: 'stroke',
          tool: currentTool,
          points: [...currentStrokeRef.current],
          color: currentTool === 'eraser' ? '#ffffff' : currentColor,
          size: currentSize,
        };

        setActions((prev) => [...prev, newAction]);
      } else {
        const start = shapeStartRef.current;
        const end = shapeEndRef.current;
        if (!start || !end) return;

        newAction = {
          type: 'shape',
          tool: currentTool,
          points: [],
          color: currentColor,
          size: currentSize,
          startX: Math.round(start.x),
          startY: Math.round(start.y),
          endX: Math.round(end.x),
          endY: Math.round(end.y),
        };

        const ctx = getMainCtx();
        if (ctx) drawActionOnCtx(ctx, newAction);
        setActions((prev) => [...prev, newAction]);
      }

      setRedoStack([]);
      if (newAction.type !== 'image') {
        publishDrawAction(newAction);
      }

      currentStrokeRef.current = [];
      shapeStartRef.current = null;
      shapeEndRef.current = null;
    };

    const onMouseUp = () => stopDrawing();
    const onMouseLeave = () => {
      const cursor = cursorRef.current;
      if (cursor) cursor.style.display = 'none';
      stopDrawing();
    };
    const onTouchEnd = () => stopDrawing();

    const interactionLayer = container.querySelector('[data-interaction-layer]') as HTMLElement;
    if (!interactionLayer) return;

    interactionLayer.addEventListener('mousedown', onMouseDown);
    interactionLayer.addEventListener('mousemove', onMouseMove);
    interactionLayer.addEventListener('mouseup', onMouseUp);
    interactionLayer.addEventListener('mouseleave', onMouseLeave);
    interactionLayer.addEventListener('touchstart', onTouchStart, { passive: false });
    interactionLayer.addEventListener('touchmove', onTouchMove, { passive: false });
    interactionLayer.addEventListener('touchend', onTouchEnd);

    return () => {
      interactionLayer.removeEventListener('mousedown', onMouseDown);
      interactionLayer.removeEventListener('mousemove', onMouseMove);
      interactionLayer.removeEventListener('mouseup', onMouseUp);
      interactionLayer.removeEventListener('mouseleave', onMouseLeave);
      interactionLayer.removeEventListener('touchstart', onTouchStart);
      interactionLayer.removeEventListener('touchmove', onTouchMove);
      interactionLayer.removeEventListener('touchend', onTouchEnd);
    };
  }, [getPointFromEvent, getMainCtx, getOverlayCtx, drawActionOnCtx, publishDrawAction]);

  const handleUndo = useCallback(() => {
    setActions((prev) => {
      if (prev.length === 0) return prev;
      const lastAction = prev[prev.length - 1];
      setRedoStack((rs) => [...rs, lastAction]);
      const next = prev.slice(0, -1);
      actionsRef.current = next;
      redrawNeededRef.current = true;
      return next;
    });
  }, []);

  const handleRedo = useCallback(() => {
    setRedoStack((prev) => {
      if (prev.length === 0) return prev;
      const action = prev[prev.length - 1];
      setActions((a) => {
        const next = [...a, action];
        actionsRef.current = next;
        redrawNeededRef.current = true;
        return next;
      });
      publishDrawAction(action);
      return prev.slice(0, -1);
    });
  }, [publishDrawAction]);

  const handleClear = useCallback(() => {
    const clearAction: DrawAction = {
      type: 'clear', tool: 'pen', points: [], color: '#ffffff', size: 0,
    };
    setActions([clearAction]);
    setRedoStack([]);
    actionsRef.current = [clearAction];
    publishDrawAction(clearAction);
    redrawNeededRef.current = true;
  }, [publishDrawAction]);

  const handleDownloadImage = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `photonix-${roomId}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }, [roomId]);

  const handleDownloadPDF = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const { jsPDF } = await import('jspdf');
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: canvas.width > canvas.height ? 'landscape' : 'portrait',
        unit: 'px',
        format: [canvas.width, canvas.height],
      });
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`photonix-${roomId}.pdf`);
    } catch {
      toast({ title: 'Error', description: 'Failed to generate PDF', variant: 'destructive' });
    }
  }, [roomId]);

  const handleUploadImage = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleImageUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const imgData = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = getMainCtx();
        if (!ctx) return;

        let imgWidth = img.width;
        let imgHeight = img.height;
        const maxW = canvas.width * 0.8;
        const maxH = canvas.height * 0.8;

        if (imgWidth > maxW || imgHeight > maxH) {
          const ratio = Math.min(maxW / imgWidth, maxH / imgHeight);
          imgWidth *= ratio;
          imgHeight *= ratio;
        }

        const x = (canvas.width - imgWidth) / 2;
        const y = (canvas.height - imgHeight) / 2;

        ctx.drawImage(img, x, y, imgWidth, imgHeight);

        setTimeout(() => {
          let quality = 0.6;
          let fullCanvasDataURL = canvas.toDataURL('image/jpeg', quality);
          while (fullCanvasDataURL.length > 200000 && quality > 0.1) {
            quality -= 0.1;
            fullCanvasDataURL = canvas.toDataURL('image/jpeg', quality);
          }
          const imageAction: DrawAction = {
            type: 'image', tool: 'pen', points: [], color: '#000000', size: 0,
            imageData: fullCanvasDataURL, imageX: 0, imageY: 0,
          };
          setActions((prev) => {
            const next = [...prev, imageAction];
            actionsRef.current = next;
            return next;
          });
          setRedoStack([]);
          publishDrawAction(imageAction);
        }, 100);
      };
      img.src = imgData;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  }, [getMainCtx, publishDrawAction]);

  const handleSendMessage = useCallback((message: string) => {
    const chatMsg: ChatMessage = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      username, message, timestamp: Date.now(),
    };
    setChatMessages((prev) => [...prev, chatMsg]);
    publishChatMessage(chatMsg);
  }, [username, publishChatMessage]);

  const handleCopyLink = useCallback(() => {
    navigator.clipboard.writeText(roomUrl).then(() => {
      setCopied(true);
      toast({ title: 'Link copied!', description: 'Share this link with others to join your room', duration: 2000 });
      setTimeout(() => setCopied(false), 2000);
    });
  }, [roomUrl]);

  return (
    <div className="h-screen flex flex-col bg-slate-200">
      <header className="flex items-center justify-between px-3 py-2 bg-white border-b border-slate-200 shadow-sm shrink-0 z-10">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-sm">
              <span className="text-white text-xs font-bold">P</span>
            </div>
            <h1 className="text-sm font-bold text-slate-800 hidden sm:block">Photonix</h1>
          </div>
          <div className="h-5 w-px bg-slate-200" />
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400 hidden sm:inline">Room:</span>
            <code className="text-xs font-mono bg-violet-50 px-2 py-0.5 rounded text-violet-600 border border-violet-100">
              {roomId}
            </code>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 gap-1.5 text-xs hover:bg-violet-50 hover:text-violet-600"
            onClick={handleCopyLink}
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy Link'}</span>
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <div className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full ${
            isConnected ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-500'
          }`}>
            <div className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-emerald-500' : 'bg-amber-400 animate-pulse'}`} />
            <span className="hidden sm:inline text-[11px] font-medium">{isConnected ? 'Live' : 'Connecting'}</span>
          </div>

          <div className="text-[9px] text-slate-400 font-mono hidden md:block max-w-[280px] truncate" title="Debug: connection info">
            {debugInfo.status} | D:{debugInfo.drawSent}/{debugInfo.drawRecv} C:{debugInfo.chatSent}/{debugInfo.chatRecv}
            {debugInfo.lastError && <span className="text-red-400"> | {debugInfo.lastError}</span>}
          </div>

          <div className="relative">
            <UserList users={users} currentUsername={username} />
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200">
            <div className="w-2.5 h-2.5 rounded-full ring-2 ring-white" style={{ backgroundColor: userColor }} />
            <span className="text-[11px] font-medium text-slate-600 max-w-[80px] truncate">{username}</span>
          </div>

          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-400 hover:text-red-500 hover:bg-red-50" onClick={onLeave} title="Leave room">
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <Toolbar
        tool={tool} onToolChange={setTool}
        color={color} onColorChange={setColor}
        size={size} onSizeChange={setSize}
        onUndo={handleUndo} onRedo={handleRedo} onClear={handleClear}
        onDownloadImage={handleDownloadImage} onDownloadPDF={handleDownloadPDF}
        onUploadImage={handleUploadImage}
        canUndo={actions.length > 0} canRedo={redoStack.length > 0}
      />

      <div
        ref={containerRef}
        className="flex-1 relative overflow-hidden"
        style={{ cursor: (tool === 'pen' || tool === 'eraser') ? 'none' : 'crosshair' }}
      >
        <canvas
          ref={canvasRef}
          className="absolute inset-0 bg-white"
          style={{ touchAction: 'none' }}
        />
        <canvas
          ref={overlayCanvasRef}
          className="absolute inset-0 pointer-events-none"
          style={{ touchAction: 'none' }}
        />

        <div
          ref={cursorRef}
          className="pointer-events-none absolute rounded-full border-2 hidden"
          style={{
            width: Math.max(size, 4),
            height: Math.max(size, 4),
            transform: 'translate(-50%, -50%)',
            borderColor: tool === 'eraser' ? '#94a3b8' : color,
            backgroundColor: tool === 'eraser' ? 'rgba(255,255,255,0.3)' : 'transparent',
          }}
        />

        <div
          data-interaction-layer
          className="absolute inset-0"
          style={{ touchAction: 'none' }}
        />
      </div>

      <ChatPopup messages={chatMessages} onSendMessage={handleSendMessage} currentUsername={username} />

      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />

      <div className="md:hidden px-3 py-1 bg-slate-800 text-slate-300 text-[10px] font-mono flex items-center gap-2 overflow-x-auto shrink-0">
        <span className={isConnected ? 'text-emerald-400' : 'text-amber-400'}>{debugInfo.status}</span>
        <span>D:{debugInfo.drawSent}/{debugInfo.drawRecv}</span>
        <span>C:{debugInfo.chatSent}/{debugInfo.chatRecv}</span>
        {debugInfo.lastError && <span className="text-red-400">{debugInfo.lastError}</span>}
      </div>
    </div>
  );
}
