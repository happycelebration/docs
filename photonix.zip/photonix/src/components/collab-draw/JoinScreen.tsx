'use client';

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Pen, Users, Link, ArrowRight, Palette, MessageSquare, Zap } from 'lucide-react';

interface JoinScreenProps {
  onJoin: (username: string, roomId: string, userColor: string) => void;
  initialRoomId?: string;
}

const COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4',
  '#3b82f6', '#8b5cf6', '#ec4899', '#f43f5e', '#14b8a6',
];

function generateRoomId(): string {
  return Math.random().toString(36).substring(2, 8);
}

export default function JoinScreen({ onJoin, initialRoomId }: JoinScreenProps) {
  const [username, setUsername] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLORS[6]);
  const isJoining = !!initialRoomId;

  const handleCreateRoom = useCallback(() => {
    if (!username.trim()) return;
    const roomId = generateRoomId();
    onJoin(username.trim(), roomId, selectedColor);
  }, [username, selectedColor, onJoin]);

  const handleJoinRoom = useCallback(() => {
    if (!username.trim() || !initialRoomId) return;
    onJoin(username.trim(), initialRoomId, selectedColor);
  }, [username, initialRoomId, selectedColor, onJoin]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-violet-50 via-white to-purple-50">
      <div className="w-full max-w-lg space-y-6 flex-1 flex flex-col justify-center">
        <div className="text-center space-y-4">
          <div className="relative w-32 h-32 mx-auto">
            <img
              src="/photonix-hero.png"
              alt="Collaborative Drawing"
              className="w-full h-full object-contain drop-shadow-xl"
            />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-extrabold tracking-tight">
              <span className="bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                Photonix
              </span>
            </h1>
            <p className="text-slate-500 text-sm max-w-xs mx-auto">
              Draw together in real-time. Create a private room, share the link, and start creating.
            </p>
          </div>
        </div>

        <Card className="shadow-2xl shadow-violet-100/50 border-violet-100/50 overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500" />
          <CardHeader className="pb-4 pt-5">
            <CardTitle className="text-lg flex items-center gap-2">
              {isJoining ? (
                <>
                  <Users className="w-5 h-5 text-violet-500" />
                  Join Drawing Room
                </>
              ) : (
                <>
                  <Pen className="w-5 h-5 text-violet-500" />
                  Create a Room
                </>
              )}
            </CardTitle>
            <CardDescription>
              {isJoining
                ? 'Enter your name to join the drawing session'
                : 'Set up your profile and start drawing with others'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5 pb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Your Name</label>
              <Input
                placeholder="Enter your name..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    if (isJoining) {
                      handleJoinRoom();
                    } else {
                      handleCreateRoom();
                    }
                  }
                }}
                className="h-11 border-slate-200 focus:border-violet-400 focus:ring-violet-400"
                maxLength={20}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Pick Your Color</label>
              <div className="flex flex-wrap gap-2.5">
                {COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-9 h-9 rounded-full transition-all duration-200 hover:scale-110 shadow-sm ${
                      selectedColor === color
                        ? 'ring-3 ring-offset-2 ring-violet-400 scale-110 shadow-md'
                        : 'hover:shadow-md'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <Button
              onClick={isJoining ? handleJoinRoom : handleCreateRoom}
              disabled={!username.trim()}
              className="w-full h-12 text-sm font-semibold bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-lg shadow-violet-200 transition-all duration-200 hover:shadow-xl hover:shadow-violet-300 disabled:opacity-50 disabled:shadow-none"
              size="default"
            >
              {isJoining ? (
                <>
                  <Users className="w-4 h-4 mr-2" />
                  Join Room
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  <Link className="w-4 h-4 mr-2" />
                  Create Room & Get Shareable Link
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="grid grid-cols-3 gap-3 text-center">
          {[
            { icon: Palette, label: 'Drawing Tools', desc: 'Pen, shapes & more' },
            { icon: MessageSquare, label: 'Live Chat', desc: 'Real-time messaging' },
            { icon: Zap, label: 'Real-time', desc: 'Instant sync' },
          ].map(({ icon: Icon, label, desc }) => (
            <div
              key={label}
              className="rounded-xl bg-white/70 backdrop-blur border border-violet-100/50 p-3 hover:bg-white transition-colors"
            >
              <Icon className="w-5 h-5 mx-auto mb-1.5 text-violet-500" />
              <div className="text-xs font-semibold text-slate-700">{label}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">{desc}</div>
            </div>
          ))}
        </div>
      </div>

      <footer className="mt-auto pt-6 pb-4 text-center">
        <div className="flex items-center justify-center gap-1.5 text-slate-400 text-xs">
          <span>&copy; {new Date().getFullYear()}</span>
          <span className="font-semibold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">Photonix by Pallavi Thakur</span>
          <span>&mdash; All rights reserved.</span>
        </div>
        <p className="text-[10px] text-slate-300 mt-1">Real-time collaborative drawing, made with ♥</p>
      </footer>
    </div>
  );
}
