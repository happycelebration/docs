import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Photonix - Real-time Collaborative Drawing",
  description: "Draw together in real-time with Photonix. Create private rooms, invite friends, and collaborate on a shared canvas with live chat and user presence.",
  keywords: ["collaborative", "drawing", "real-time", "canvas", "whiteboard", "Scaledrone"],
  authors: [{ name: "Photonix" }],
  icons: {
    icon: "https://raw.githubusercontent.com/happycelebration/docs/refs/heads/main/photonix.png",
  },
  openGraph: {
    title: "Photonix - Real-time Collaborative Drawing",
    description: "Draw together in real-time. Create a room and invite your friends.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Photonix - Real-time Collaborative Drawing",
    description: "Draw together in real-time. Create a room and invite your friends.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
