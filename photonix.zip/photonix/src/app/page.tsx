'use client';

import { useState, useCallback, useSyncExternalStore } from 'react';
import JoinScreen from '@/components/collab-draw/JoinScreen';
import DrawingApp from '@/components/collab-draw/DrawingApp';


function useHash() {
  return useSyncExternalStore(
    (callback) => {
      window.addEventListener('hashchange', callback);
      return () => window.removeEventListener('hashchange', callback);
    },
    () => window.location.hash.slice(1),
    () => ''
  );
}

export default function Home() {
  const [username, setUsername] = useState<string | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [userColor, setUserColor] = useState<string>('#8b5cf6');
  const hash = useHash();

  const handleJoin = useCallback((name: string, room: string, color: string) => {
    setUsername(name);
    setRoomId(room);
    setUserColor(color);
    window.location.hash = room;
  }, []);

  const handleLeave = useCallback(() => {
    setUsername(null);
    setRoomId(null);
    window.location.hash = '';
    window.location.reload();
  }, []);

  if (!username || !roomId) {
    return (
      <JoinScreen
        onJoin={handleJoin}
        initialRoomId={hash || undefined}
      />
    );
  }

  return (
    <DrawingApp
      roomId={roomId}
      username={username}
      userColor={userColor}
      onLeave={handleLeave}
    />
  );
}
