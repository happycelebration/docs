# Photonix

Photonix is a real-time collaborative drawing canvas where multiple users can create and share artwork together instantly. Simply start a room, send the link, and begin sketching with others in sync. It’s fast, interactive, and designed for seamless creative collaboration from anywhere.

## Features

- **Live Drawing** — Pen, eraser, and shape tools (line, rectangle, circle, arrow) with instant sync across all connected users
- **Image Upload** — Upload images to the canvas; they sync to every participant in real-time
- **Undo / Redo** — Full stroke-level undo and redo support
- **Live Chat** — Floating chat panel with unread message badges
- **User Presence** — See who's online, get notified when collaborators join or leave
- **Shareable Room Links** — Create a room, copy the link, and anyone with it can join
- **Export** — Download your canvas as PNG or PDF
- **Responsive** — Works on desktop and mobile with touch support

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui |
| Icons | Lucide React |
| Real-time | Scaledrone (observable rooms, auto-chunking) |
| PDF Export | jsPDF |
| Runtime | Bun |

## Getting Started

### Prerequisites

- [Bun](https://bun.sh/) (recommended) or Node.js 18+
- A free [Scaledrone](https://www.scaledrone.com/) account and channel ID

### Installation

```bash
git clone https://github.com/cloudxplorer/Photonix
cd Photonix
bun install
```

### Configuration

Open `src/components/collab-draw/useScaledrone.ts` and replace the channel ID with your own:

```ts
const SCALEDRONE_CHANNEL_ID = 'YOUR_CHANNEL_ID';
```

You can get a free channel ID by signing up at [scaledrone.com](https://www.scaledrone.com/).

### Run

```bash
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Lint

```bash
bun run lint
```

## How It Works

1. A user creates a room and gets a shareable link (room ID in the URL hash)
2. Other users open the link, enter their name, and join the room
3. All drawing actions, chat messages, and image uploads are published to a Scaledrone observable room
4. Messages that exceed Scaledrone's 10 KB limit are automatically split into chunks and reassembled on the receiving end
5. Each user maintains their own action history for undo/redo; the canvas redraws from the action log when needed

## Project Structure

```
src/
├── app/
│   ├── layout.tsx          Root layout, metadata, fonts
│   ├── page.tsx            Home — routes to JoinScreen or DrawingApp
│   └── globals.css         Tailwind + CSS variables
├── components/
│   ├── collab-draw/
│   │   ├── DrawingApp.tsx  Main canvas component, drawing logic
│   │   ├── JoinScreen.tsx  Landing page — create/join a room
│   │   ├── ChatPopup.tsx   Floating chat panel
│   │   ├── Toolbar.tsx     Drawing tools, colors, size, actions
│   │   ├── UserList.tsx    Online users dropdown
│   │   ├── useScaledrone.ts Real-time sync hook (chunking, presence)
│   │   └── types.ts        TypeScript types
│   └── ui/                 shadcn/ui components
├── hooks/
│   └── use-toast.ts        Toast notification hook
└── lib/
    └── utils.ts            cn() utility
```

## Deployment

### Vercel (recommended)

1. Push your repo to GitHub
2. Import it on [vercel.com](https://vercel.com)
3. Vercel auto-detects Next.js — no extra config needed

### Self-hosted

```bash
bun run build
bun run start
```

The build produces a standalone output in `.next/standalone/`.

## License

MIT License

Copyright (c) 2026 Photonix

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the “Software”), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
