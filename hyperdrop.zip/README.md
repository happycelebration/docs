# HyperDrop

**Peer-to-peer file sharing in your browser. No servers. No signups. No limits.**

HyperDrop lets you share files instantly between two browsers using WebRTC DataChannels. Just create a room, share the link or QR code, and drop your files — they go directly to the other peer. Nothing ever touches a server.

---

## Features

- **Direct P2P Transfer** — Files travel browser-to-browser via WebRTC DataChannels. No server storage, no middleman.
- **Room System** — Create a timed room, share the link or QR code, and your peer joins instantly.
- **QR Code Sharing** — Auto-generated QR code with one-click copy link and download as PNG.
- **Multi-File Support** — Drag & drop or pick multiple files at once.
- **Progress Tracking** — Real-time upload/download progress bars per file.
- **Countdown Timer** — Rooms auto-expire after 5 min, 15 min, 30 min, 1 hr, 24 hr, or a custom duration.
- **Toast Notifications** — Instant feedback for peer connected, file sent, file received, errors, and expiry.
- **Dark Purple/Pink UI** — Glassmorphism cards, gradient accents, smooth transitions.
- **Fully Responsive** — Works on mobile, tablet, and desktop.
- **Zero Backend** — No database, no WebSocket server, no persistence. Fully serverless-compatible.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui |
| P2P Signaling | PeerJS (cloud server) |
| File Transfer | WebRTC DataChannels |
| Room IDs | nanoid |
| QR Codes | qrcode |
| Notifications | Sonner |
| Icons | Lucide React |

---

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) 20+ or [Bun](https://bun.sh/) 1.0+
- A modern browser (Chrome, Firefox, Edge, Safari)

### Install

```bash
git clone https://github.com/cloudxplorer/HyperDrop
cd HyperDrop
bun install
```

### Run Locally

```bash
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Lint

```bash
bun run lint
```

---

## How It Works

### 1. Create a Room

Visit the homepage, pick a duration, and hit **Create Room**. A unique room ID is generated using nanoid.

### 2. Share the Link

A QR code and shareable URL are displayed. Copy the link or download the QR code image and send it to your peer.

### 3. Peer Joins

When the second user opens the link, PeerJS establishes a WebRTC connection. Both users transition to the file sharing UI.

### 4. Transfer Files

Drag & drop or pick files. They are chunked and sent directly over WebRTC DataChannels — no server ever sees your data. Progress bars update in real time.

### 5. Download

Received files appear with a download button. Click to save locally.

### 6. Session Expires

When the countdown hits zero, the peer connection is destroyed, the UI shows "Session Expired," and all sharing is disabled.

---

## Project Structure

```
src/
├── app/
│   ├── globals.css          # Theme, gradients, scrollbar
│   ├── layout.tsx           # Root layout with metadata & toaster
│   ├── page.tsx             # Homepage — room creation
│   └── r/[id]/page.tsx      # Room page — P2P connection & file sharing
├── components/
│   ├── ui/                  # shadcn/ui primitives (button, card, progress, sonner)
│   ├── header.tsx           # App header with logo
│   ├── footer.tsx           # App footer
│   ├── room-creator.tsx     # Timer selector + create room form
│   ├── qr-display.tsx       # QR code, copy link, download QR
│   ├── file-drop-zone.tsx   # Drag & drop / file picker
│   ├── file-list.tsx        # Outgoing, incoming, received file cards
│   ├── file-sharer.tsx      # Drop zone + file list wrapper
│   ├── connection-status.tsx # Connection state + countdown badge
│   ├── expired-screen.tsx   # Session expired UI
│   └── loading-screen.tsx   # Connecting spinner
├── hooks/
│   ├── use-peer.ts          # PeerJS connection lifecycle
│   ├── use-file-transfer.ts # File chunking, sending, receiving
│   ├── use-countdown.ts     # Room expiry timer
│   └── use-qrcode.ts        # QR generation & download
├── lib/
│   ├── peer.ts              # PeerJS host/join helpers
│   ├── file-transfer.ts     # Chunking, formatting, ID generation
│   ├── safe-storage.ts      # sessionStorage with in-memory fallback
│   └── utils.ts             # Tailwind merge utility
└── types/
    └── index.ts             # All TypeScript types & constants
```

---

## Security

- Files transfer **directly between browsers** — no server ever receives or stores file data.
- PeerJS cloud server is used **only for signaling** (exchanging connection metadata).
- All data channels use WebRTC's built-in encryption (DTLS/SRTP).
- No user data is persisted anywhere after the session ends.

---

## Deployment

HyperDrop is fully serverless and deploys to **Vercel** with zero configuration:

1. Push the repo to GitHub
2. Import the repo on [vercel.com](https://vercel.com)
3. Click **Deploy**

That's it. No environment variables, no database, no server setup needed.

---

## License

Copyright (c) 2026 HyperDrop

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
