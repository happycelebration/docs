export type ConnectionStatus =
  | "idle"
  | "connecting"
  | "waiting"
  | "connected"
  | "transferring"
  | "disconnected"
  | "expired"

export type TimerPreset = 5 | 15 | 30 | 60 | 1440

export interface RoomConfig {
  id: string
  durationMinutes: number
  createdAt: number
  expiresAt: number
}

export interface FileMeta {
  id: string
  name: string
  size: number
  type: string
  totalChunks: number
}

export interface FileChunk {
  fileId: string
  index: number
  data: ArrayBuffer
}

export interface FileEnd {
  fileId: string
}

export interface IncomingFile {
  meta: FileMeta
  chunks: ArrayBuffer[]
  receivedChunks: number
  blob?: Blob
  completed: boolean
}

export interface OutgoingFile {
  meta: FileMeta
  file: File
  progress: number
  status: "pending" | "uploading" | "sent" | "error"
}

export interface ReceivedFile {
  id: string
  name: string
  size: number
  type: string
  blob: Blob
  receivedAt: number
}

export type PeerMessage =
  | { type: "file-meta"; payload: FileMeta }
  | { type: "file-chunk"; payload: { fileId: string; index: number; data: ArrayBuffer } }
  | { type: "file-end"; payload: FileEnd }
  | { type: "room-info"; payload: { expiresAt: number } }

export const CHUNK_SIZE = 16 * 1024

export const TIMER_PRESETS: { label: string; value: TimerPreset }[] = [
  { label: "5 min", value: 5 },
  { label: "15 min", value: 15 },
  { label: "30 min", value: 30 },
  { label: "1 hr", value: 60 },
  { label: "24 hr", value: 1440 },
]
