"use client"

import { Card, CardContent } from "@/components/ui/card"
import { FileDropZone } from "@/components/file-drop-zone"
import { FileList } from "@/components/file-list"
import type { OutgoingFile, ReceivedFile, IncomingFile } from "@/types"

interface FileSharerProps {
  outgoingFiles: OutgoingFile[]
  receivedFiles: ReceivedFile[]
  incomingFiles: IncomingFile[]
  onFilesSelected: (files: FileList) => void
  onDownload: (file: ReceivedFile) => void
  disabled?: boolean
}

export function FileSharer({
  outgoingFiles,
  receivedFiles,
  incomingFiles,
  onFilesSelected,
  onDownload,
  disabled = false,
}: FileSharerProps) {
  return (
    <div className="w-full max-w-lg mx-auto space-y-4">
      <Card className="border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl shadow-purple-500/10">
        <CardContent className="p-6 sm:p-8 space-y-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-white">
              Share Files
            </h3>
            <p className="text-sm text-white/40 mt-1">
              Drop files to send instantly
            </p>
          </div>

          <FileDropZone onFilesSelected={onFilesSelected} disabled={disabled} />

          <FileList
            outgoingFiles={outgoingFiles}
            receivedFiles={receivedFiles}
            incomingFiles={incomingFiles}
            onDownload={onDownload}
          />
        </CardContent>
      </Card>
    </div>
  )
}
