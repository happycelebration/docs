"use client"

import { Loader2, Wifi } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function LoadingScreen() {
  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl shadow-purple-500/10">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col items-center gap-6">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full blur-xl opacity-30 animate-pulse" />
              <div className="relative p-4 rounded-full bg-purple-500/20">
                <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold text-white">
                Connecting to Room
              </h3>
              <p className="text-sm text-white/50">
                Establishing peer connection...
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
