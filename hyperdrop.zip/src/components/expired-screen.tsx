"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShieldAlert, RotateCcw } from "lucide-react"
import { useRouter } from "next/navigation"

export function ExpiredScreen() {
  const router = useRouter()

  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl shadow-purple-500/10">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col items-center gap-6">
            <div className="p-4 rounded-2xl bg-red-500/10">
              <ShieldAlert className="w-12 h-12 text-red-400" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-semibold text-white">
                Session Expired
              </h3>
              <p className="text-sm text-white/50">
                This room has expired. File transfer is no longer available.
              </p>
            </div>
            <Button
              onClick={() => router.push("/")}
              className="w-full h-11 bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-500 hover:to-pink-400 text-white border-0 shadow-lg shadow-purple-500/25"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Create New Room
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
