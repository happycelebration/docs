"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Copy, Download, QrCode, Link } from "lucide-react"
import { useQRCode } from "@/hooks/use-qrcode"
import { toast } from "sonner"

interface QRDisplayProps {
  roomUrl: string
}

export function QRDisplay({ roomUrl }: QRDisplayProps) {
  const { qrDataUrl, generate, download } = useQRCode()

  useEffect(() => {
    if (roomUrl) {
      generate(roomUrl)
    }
  }, [roomUrl, generate])

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(roomUrl)
      toast.success("Link copied successfully")
    } catch {
      toast.error("Failed to copy link")
    }
  }

  const handleDownloadQR = () => {
    download()
    toast.success("QR code downloaded")
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl shadow-purple-500/10">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-2 text-white/70">
              <QrCode className="w-5 h-5" />
              <h3 className="text-lg font-semibold text-white">Share Room</h3>
            </div>

            <div className="relative p-4 rounded-2xl bg-white shadow-2xl shadow-purple-500/20">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 blur-xl -z-10" />
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="Room QR Code"
                  className="w-56 h-56 sm:w-64 sm:h-64 rounded-lg"
                />
              ) : (
                <div className="w-56 h-56 sm:w-64 sm:h-64 rounded-lg bg-gray-100 animate-pulse flex items-center justify-center">
                  <QrCode className="w-12 h-12 text-gray-300" />
                </div>
              )}
            </div>

            <div className="w-full space-y-3">
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-2">
                <Link className="w-4 h-4 text-purple-400 shrink-0" />
                <p className="text-sm text-white/70 truncate flex-1 select-all">
                  {roomUrl}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={handleCopyLink}
                  variant="outline"
                  className="h-10 bg-white/5 border-white/10 text-white hover:bg-white/10 hover:text-white"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Link
                </Button>
                <Button
                  onClick={handleDownloadQR}
                  variant="outline"
                  className="h-10 bg-white/5 border-white/10 text-white hover:bg-white/10 hover:text-white"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download QR
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
