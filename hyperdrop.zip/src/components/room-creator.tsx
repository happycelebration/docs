"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { nanoid } from "nanoid"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Clock, Plus } from "lucide-react"
import { TIMER_PRESETS, type TimerPreset } from "@/types"

interface RoomCreatorProps {
  onCreateRoom: (roomId: string, durationMinutes: number) => void
}

export function RoomCreator({ onCreateRoom }: RoomCreatorProps) {
  const router = useRouter()
  const [selectedPreset, setSelectedPreset] = useState<TimerPreset>(15)
  const [customMinutes, setCustomMinutes] = useState<string>("")
  const [isCustom, setIsCustom] = useState(false)
  const [isCreating, setIsCreating] = useState(false)

  const handleCreateRoom = () => {
    if (isCreating) return
    setIsCreating(true)
    const roomId = nanoid(10)
    const duration = isCustom ? parseInt(customMinutes) || 15 : selectedPreset
    onCreateRoom(roomId, duration)
    router.push(`/r/${roomId}?mode=host&duration=${duration}`)
  }

  return (
    <div className="w-full max-w-lg mx-auto">
      <Card className="border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl shadow-purple-500/10">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col items-center gap-6">
            <div className="text-center space-y-2">
              <h2 className="text-xl sm:text-2xl font-semibold text-white">
                Create a Room
              </h2>
              <p className="text-sm text-white/50">
                Set a timer and share files peer-to-peer
              </p>
            </div>

            <div className="w-full space-y-4">
              <div className="flex items-center gap-2 text-sm text-white/70">
                <Clock className="w-4 h-4" />
                <span>Room Duration</span>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {TIMER_PRESETS.map((preset) => (
                  <button
                    key={preset.value}
                    onClick={() => {
                      setSelectedPreset(preset.value)
                      setIsCustom(false)
                    }}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      !isCustom && selectedPreset === preset.value
                        ? "bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg shadow-purple-500/25"
                        : "bg-white/5 text-white/60 hover:bg-white/10 hover:text-white/80 border border-white/10"
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
                <button
                  onClick={() => setIsCustom(!isCustom)}
                  className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isCustom
                      ? "bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg shadow-purple-500/25"
                      : "bg-white/5 text-white/60 hover:bg-white/10 hover:text-white/80 border border-white/10"
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  Custom
                </button>
              </div>

              {isCustom && (
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="1440"
                    value={customMinutes}
                    onChange={(e) => setCustomMinutes(e.target.value)}
                    placeholder="Enter minutes"
                    className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50"
                  />
                  <span className="text-sm text-white/50">min</span>
                </div>
              )}
            </div>

            <Button
              onClick={handleCreateRoom}
              disabled={isCreating || (isCustom && !customMinutes)}
              className="w-full h-12 text-base font-semibold bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-500 hover:to-pink-400 text-white shadow-lg shadow-purple-500/25 transition-all duration-300 hover:shadow-purple-500/40 hover:scale-[1.02] active:scale-[0.98] border-0"
              size="lg"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create Room
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
