"use client"

import { Wifi, WifiOff, Loader2, Clock, ShieldAlert } from "lucide-react"
import type { ConnectionStatus } from "@/types"
import { formatTime } from "@/lib/file-transfer"

interface ConnectionStatusBarProps {
  status: ConnectionStatus
  remaining: number
  isExpired: boolean
}

export function ConnectionStatusBar({
  status,
  remaining,
  isExpired,
}: ConnectionStatusBarProps) {
  const getStatusConfig = () => {
    if (isExpired) {
      return {
        icon: <ShieldAlert className="w-4 h-4" />,
        label: "Session Expired",
        color: "text-red-400",
        bg: "bg-red-500/10 border-red-500/20",
      }
    }
    switch (status) {
      case "waiting":
        return {
          icon: <Clock className="w-4 h-4 animate-pulse" />,
          label: "Waiting for peer",
          color: "text-amber-400",
          bg: "bg-amber-500/10 border-amber-500/20",
        }
      case "connecting":
        return {
          icon: <Loader2 className="w-4 h-4 animate-spin" />,
          label: "Connecting",
          color: "text-purple-400",
          bg: "bg-purple-500/10 border-purple-500/20",
        }
      case "connected":
        return {
          icon: <Wifi className="w-4 h-4" />,
          label: "Connected",
          color: "text-emerald-400",
          bg: "bg-emerald-500/10 border-emerald-500/20",
        }
      case "transferring":
        return {
          icon: <Loader2 className="w-4 h-4 animate-spin" />,
          label: "Transferring",
          color: "text-pink-400",
          bg: "bg-pink-500/10 border-pink-500/20",
        }
      case "disconnected":
        return {
          icon: <WifiOff className="w-4 h-4" />,
          label: "Disconnected",
          color: "text-red-400",
          bg: "bg-red-500/10 border-red-500/20",
        }
      default:
        return {
          icon: <Wifi className="w-4 h-4" />,
          label: "Ready",
          color: "text-white/50",
          bg: "bg-white/5 border-white/10",
        }
    }
  }

  const config = getStatusConfig()

  return (
    <div
      className={`flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl border ${config.bg} backdrop-blur-sm`}
    >
      <div className="flex items-center gap-2">
        <span className={config.color}>{config.icon}</span>
        <span className={`text-sm font-medium ${config.color}`}>
          {config.label}
        </span>
      </div>
      {remaining > 0 && !isExpired && (
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-white/40" />
          <span className="text-sm font-mono text-white/50">
            {formatTime(remaining)}
          </span>
        </div>
      )}
    </div>
  )
}
