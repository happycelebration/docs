"use client"

import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Download, File, Check, AlertCircle, Loader2 } from "lucide-react"
import { formatFileSize } from "@/lib/file-transfer"
import type { OutgoingFile, ReceivedFile, IncomingFile } from "@/types"

interface FileListProps {
  outgoingFiles: OutgoingFile[]
  receivedFiles: ReceivedFile[]
  incomingFiles: IncomingFile[]
  onDownload: (file: ReceivedFile) => void
}

export function FileList({
  outgoingFiles,
  receivedFiles,
  incomingFiles,
  onDownload,
}: FileListProps) {
  const allFiles = [
    ...outgoingFiles.map((f) => ({ ...f, direction: "outgoing" as const })),
    ...incomingFiles.map((f) => ({ ...f, direction: "incoming" as const })),
    ...receivedFiles.map((f) => ({ ...f, direction: "received" as const })),
  ]

  if (allFiles.length === 0) return null

  return (
    <div className="w-full space-y-2 max-h-72 overflow-y-auto custom-scrollbar pr-1">
      {outgoingFiles.map((file) => (
        <div
          key={file.meta.id}
          className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10"
        >
          <div className="shrink-0 p-2 rounded-lg bg-purple-500/20">
            <File className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {file.meta.name}
            </p>
            <p className="text-xs text-white/40">
              {formatFileSize(file.meta.size)}
            </p>
            {file.status === "uploading" && (
              <div className="mt-1.5">
                <Progress value={file.progress} className="h-1.5 bg-white/10" />
              </div>
            )}
          </div>
          <div className="shrink-0">
            {file.status === "uploading" && (
              <div className="flex items-center gap-1.5 text-purple-400">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-xs">{Math.round(file.progress)}%</span>
              </div>
            )}
            {file.status === "sent" && (
              <div className="flex items-center gap-1 text-emerald-400">
                <Check className="w-4 h-4" />
                <span className="text-xs">Sent</span>
              </div>
            )}
            {file.status === "error" && (
              <div className="flex items-center gap-1 text-red-400">
                <AlertCircle className="w-4 h-4" />
                <span className="text-xs">Error</span>
              </div>
            )}
          </div>
        </div>
      ))}

      {incomingFiles.map((file) => (
        <div
          key={file.meta.id}
          className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10"
        >
          <div className="shrink-0 p-2 rounded-lg bg-pink-500/20">
            <Loader2 className="w-4 h-4 text-pink-400 animate-spin" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {file.meta.name}
            </p>
            <p className="text-xs text-white/40">
              {formatFileSize(file.meta.size)} • Receiving...
            </p>
            <div className="mt-1.5">
              <Progress
                value={(file.receivedChunks / file.meta.totalChunks) * 100}
                className="h-1.5 bg-white/10"
              />
            </div>
          </div>
        </div>
      ))}

      {receivedFiles.map((file) => (
        <div
          key={file.id}
          className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10"
        >
          <div className="shrink-0 p-2 rounded-lg bg-emerald-500/20">
            <File className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {file.name}
            </p>
            <p className="text-xs text-white/40">
              {formatFileSize(file.size)}
            </p>
          </div>
          <Button
            onClick={() => onDownload(file)}
            size="sm"
            className="bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-500 hover:to-pink-400 text-white border-0 shadow-lg shadow-purple-500/20 h-8 px-3"
          >
            <Download className="w-3.5 h-3.5 mr-1" />
            Save
          </Button>
        </div>
      ))}
    </div>
  )
}
