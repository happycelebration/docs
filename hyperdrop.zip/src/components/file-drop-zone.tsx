"use client"

import { useCallback, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, FileUp } from "lucide-react"

interface FileDropZoneProps {
  onFilesSelected: (files: FileList) => void
  disabled?: boolean
}

export function FileDropZone({ onFilesSelected, disabled = false }: FileDropZoneProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      if (!disabled) setIsDragging(true)
    },
    [disabled]
  )

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      setIsDragging(false)
      if (!disabled && e.dataTransfer.files.length > 0) {
        onFilesSelected(e.dataTransfer.files)
      }
    },
    [onFilesSelected, disabled]
  )

  const handleClick = () => {
    if (disabled) return
    const input = document.createElement("input")
    input.type = "file"
    input.multiple = true
    input.onchange = (e) => {
      const files = (e.target as HTMLInputElement).files
      if (files && files.length > 0) {
        onFilesSelected(files)
      }
    }
    input.click()
  }

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={handleClick}
      className={`relative cursor-pointer rounded-xl border-2 border-dashed transition-all duration-300 ${
        disabled
          ? "border-white/5 bg-white/[0.02] cursor-not-allowed opacity-50"
          : isDragging
            ? "border-purple-400 bg-purple-500/10 scale-[1.02]"
            : "border-white/15 bg-white/5 hover:border-purple-400/50 hover:bg-white/[0.07]"
      }`}
    >
      <div className="flex flex-col items-center justify-center gap-4 py-10 px-6">
        <div
          className={`p-4 rounded-2xl transition-all duration-300 ${
            isDragging
              ? "bg-purple-500/20 scale-110"
              : "bg-white/5"
          }`}
        >
          {isDragging ? (
            <FileUp className="w-8 h-8 text-purple-400" />
          ) : (
            <Upload className="w-8 h-8 text-white/40" />
          )}
        </div>
        <div className="text-center">
          <p className={`text-sm font-medium ${isDragging ? "text-purple-300" : "text-white/60"}`}>
            {isDragging ? "Drop files here" : "Drag & drop files here"}
          </p>
          <p className="text-xs text-white/30 mt-1">
            or click to browse • multiple files supported
          </p>
        </div>
      </div>
    </div>
  )
}
