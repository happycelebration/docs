"use client"

import { Zap } from "lucide-react"

export function Header() {
  return (
    <header className="w-full py-6 px-4">
      <div className="max-w-4xl mx-auto flex items-center justify-center gap-3">
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg blur-md opacity-50" />
          <div className="relative bg-gradient-to-r from-purple-600 to-pink-500 p-2 rounded-lg">
            <Zap className="w-6 h-6 text-white" />
          </div>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          HyperDrop
        </h1>
      </div>
    </header>
  )
}
