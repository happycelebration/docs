"use client"

export function Footer() {
  return (
    <footer className="w-full py-4 px-4 mt-auto">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-sm text-white/30">
          &copy; {new Date().getFullYear()} HyperDrop by Pallavi Thakur. Peer-to-peer file sharing.
        </p>
      </div>
    </footer>
  )
}
