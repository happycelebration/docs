"use client"

import { Suspense, useCallback, useEffect, useRef } from "react"
import { useParams, useSearchParams } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { QRDisplay } from "@/components/qr-display"
import { FileSharer } from "@/components/file-sharer"
import { ConnectionStatusBar } from "@/components/connection-status"
import { ExpiredScreen } from "@/components/expired-screen"
import { LoadingScreen } from "@/components/loading-screen"
import { usePeer } from "@/hooks/use-peer"
import { useFileTransfer } from "@/hooks/use-file-transfer"
import { useCountdown } from "@/hooks/use-countdown"
import { safeStorage } from "@/lib/safe-storage"
import { toast } from "sonner"

function RoomContent() {
  const params = useParams()
  const searchParams = useSearchParams()
  const roomId = params.id as string
  const mode = searchParams.get("mode")
  const durationParam = searchParams.get("duration")
  const isHost = mode === "host"

  const prevStatusRef = useRef("idle")
  const startedRef = useRef(false)

  const { connection, status, createRoom, joinRoom, disconnect } = usePeer()
  const {
    outgoingFiles,
    receivedFiles,
    incomingFiles,
    uploadFiles,
    downloadFile,
    isTransferring,
  } = useFileTransfer(connection, status === "connected")

  const { remaining, isExpired, start } = useCountdown()

  useEffect(() => {
    if (startedRef.current) return
    startedRef.current = true

    if (isHost && durationParam) {
      const data = {
        id: roomId,
        durationMinutes: parseInt(durationParam),
        createdAt: Date.now(),
        isHost: true,
      }
      safeStorage.setItem(
        `hyperdrop-room-${roomId}`,
        JSON.stringify(data)
      )
      const durationMs = data.durationMinutes * 60 * 1000
      start(durationMs)
      createRoom(roomId)
    } else {
      const stored = safeStorage.getItem(`hyperdrop-room-${roomId}`)
      if (stored) {
        const data = JSON.parse(stored)
        const elapsed = Date.now() - data.createdAt
        const durationMs = data.durationMinutes * 60 * 1000
        const left = Math.max(0, durationMs - elapsed)
        start(left)
      } else {
        start(24 * 60 * 60 * 1000)
      }
      joinRoom(roomId)
    }
  }, [roomId, isHost, durationParam, createRoom, joinRoom, start])

  useEffect(() => {
    if (status !== prevStatusRef.current) {
      if (status === "connected" && prevStatusRef.current !== "connected") {
        toast.success("Peer connected")
      } else if (
        status === "disconnected" &&
        prevStatusRef.current === "connected"
      ) {
        toast.error("Peer disconnected")
      }
      prevStatusRef.current = status
    }
  }, [status])

  useEffect(() => {
    if (isExpired) {
      disconnect()
      toast.error("Room expired")
    }
  }, [isExpired, disconnect])

  const prevReceivedCountRef = useRef(0)
  useEffect(() => {
    if (receivedFiles.length > prevReceivedCountRef.current) {
      const latest = receivedFiles[receivedFiles.length - 1]
      toast.success(`New file received: ${latest.name}`)
    }
    prevReceivedCountRef.current = receivedFiles.length
  }, [receivedFiles])

  const handleDownload = useCallback(
    (file: {
      id: string
      name: string
      size: number
      type: string
      blob: Blob
      receivedAt: number
    }) => {
      const url = URL.createObjectURL(file.blob)
      const a = document.createElement("a")
      a.href = url
      a.download = file.name
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast.success(`Downloaded: ${file.name}`)
    },
    []
  )

  const handleFilesSelected = useCallback(
    (files: FileList) => {
      uploadFiles(files)
      toast.success(`${files.length} file${files.length > 1 ? "s" : ""} added`)
    },
    [uploadFiles]
  )

  if (isExpired) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-8">
          <ExpiredScreen />
        </main>
        <Footer />
      </div>
    )
  }

  const roomUrl =
    typeof window !== "undefined"
      ? `${window.location.origin}/r/${roomId}`
      : ""

  const showQR = isHost && status === "waiting"
  const showFileSharer = status === "connected" || status === "transferring"

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-6 gap-4">
        <ConnectionStatusBar
          status={isTransferring ? "transferring" : status}
          remaining={remaining}
          isExpired={isExpired}
        />

        {showQR && <QRDisplay roomUrl={roomUrl} />}

        {showFileSharer && (
          <FileSharer
            outgoingFiles={outgoingFiles}
            receivedFiles={receivedFiles}
            incomingFiles={incomingFiles}
            onFilesSelected={handleFilesSelected}
            onDownload={handleDownload}
          />
        )}

        {status === "connecting" && <LoadingScreen />}

        {status === "disconnected" && (
          <div className="w-full max-w-md mx-auto text-center space-y-4">
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl">
              <p className="text-white/50 text-sm">
                Peer disconnected. Waiting for reconnection...
              </p>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}

export default function RoomPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1 flex items-center justify-center px-4 py-8">
            <LoadingScreen />
          </main>
          <Footer />
        </div>
      }
    >
      <RoomContent />
    </Suspense>
  )
}
