import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/sonner"

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
})

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
})

export const metadata: Metadata = {
  title: "HyperDrop - Peer-to-Peer File Sharing",
  description:
    "Share files instantly between browsers. No servers, no signups, no limits. Pure peer-to-peer file transfer powered by WebRTC.",
  keywords: [
    "HyperDrop",
    "P2P",
    "file sharing",
    "WebRTC",
    "peer-to-peer",
    "secure file transfer",
    "browser file sharing",
  ],
  authors: [{ name: "HyperDrop" }],
  icons: {
    icon: "/favicon.png",
  },
  openGraph: {
    title: "HyperDrop - Peer-to-Peer File Sharing",
    description:
      "Share files instantly between browsers. No servers, no signups, no limits.",
    type: "website",
    siteName: "HyperDrop",
  },
  twitter: {
    card: "summary_large_image",
    title: "HyperDrop - Peer-to-Peer File Sharing",
    description:
      "Share files instantly between browsers. No servers, no signups, no limits.",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: "rgba(30, 15, 50, 0.95)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#fff",
              backdropFilter: "blur(12px)",
            },
          }}
        />
      </body>
    </html>
  )
}
