"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { RoomCreator } from "@/components/room-creator"
import { safeStorage } from "@/lib/safe-storage"

export default function Home() {
  const handleCreateRoom = (roomId: string, durationMinutes: number) => {
    safeStorage.setItem(
      `hyperdrop-room-${roomId}`,
      JSON.stringify({
        id: roomId,
        durationMinutes,
        createdAt: Date.now(),
        isHost: true,
      })
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center px-4 py-8">
        <RoomCreator onCreateRoom={handleCreateRoom} />
      </main>
      <Footer />
    </div>
  )
}
