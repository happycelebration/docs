"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import type { DataConnection } from "peerjs"
import type { IncomingFile, OutgoingFile, PeerMessage, ReceivedFile } from "@/types"
import { sendFile, generateFileId, createFileMeta } from "@/lib/file-transfer"

interface UseFileTransferResult {
  outgoingFiles: OutgoingFile[]
  receivedFiles: ReceivedFile[]
  incomingFiles: IncomingFile[]
  uploadFiles: (files: FileList) => void
  downloadFile: (file: ReceivedFile) => void
  isTransferring: boolean
}

export function useFileTransfer(
  connection: DataConnection | null,
  isConnected: boolean
): UseFileTransferResult {
  const [outgoingFiles, setOutgoingFiles] = useState<OutgoingFile[]>([])
  const [receivedFiles, setReceivedFiles] = useState<ReceivedFile[]>([])
  const [incomingFiles, setIncomingFiles] = useState<IncomingFile[]>([])
  const [isTransferring, setIsTransferring] = useState(false)
  const connectionRef = useRef<DataConnection | null>(null)

  useEffect(() => {
    connectionRef.current = connection
  }, [connection])

  const handleMeta = useCallback((meta: PeerMessage) => {
    if (meta.type !== "file-meta") return
    const incoming: IncomingFile = {
      meta: meta.payload,
      chunks: new Array(meta.payload.totalChunks),
      receivedChunks: 0,
      completed: false,
    }
    setIncomingFiles((prev) => [...prev, incoming])
    setIsTransferring(true)
  }, [])

  const handleChunk = useCallback((msg: PeerMessage) => {
    if (msg.type !== "file-chunk") return
    const { fileId, index, data } = msg.payload
    setIncomingFiles((prev) =>
      prev.map((f) => {
        if (f.meta.id !== fileId || f.completed) return f
        const chunks = [...f.chunks]
        chunks[index] = data
        const receivedChunks = f.receivedChunks + 1
        const completed = receivedChunks === f.meta.totalChunks
        const blob = completed
          ? new Blob(chunks as BlobPart[], { type: f.meta.type })
          : undefined
        return { ...f, chunks, receivedChunks, completed, blob }
      })
    )
  }, [])

  const handleEnd = useCallback((msg: PeerMessage) => {
    if (msg.type !== "file-end") return
    const { fileId } = msg.payload
    setIncomingFiles((prev) => {
      const file = prev.find((f) => f.meta.id === fileId)
      if (!file) return prev
      if (file.blob) {
        const received: ReceivedFile = {
          id: file.meta.id,
          name: file.meta.name,
          size: file.meta.size,
          type: file.meta.type,
          blob: file.blob,
          receivedAt: Date.now(),
        }
        setReceivedFiles((r) => [...r, received])
      }
      setIsTransferring(false)
      return prev.filter((f) => f.meta.id !== fileId)
    })
  }, [])

  useEffect(() => {
    if (!connection) return

    const handleMessage = (data: unknown) => {
      const msg = data as PeerMessage
      if (msg.type === "file-meta") handleMeta(msg)
      else if (msg.type === "file-chunk") handleChunk(msg)
      else if (msg.type === "file-end") handleEnd(msg)
    }

    connection.on("data", handleMessage)
    return () => {
      connection.off("data", handleMessage)
    }
  }, [connection, handleMeta, handleChunk, handleEnd])

  const uploadFiles = useCallback(
    (files: FileList) => {
      const conn = connectionRef.current
      if (!conn || !isConnected) return

      Array.from(files).forEach((file) => {
        const fileId = generateFileId()
        const meta = createFileMeta(file, fileId)
        const outgoing: OutgoingFile = {
          meta,
          file,
          progress: 0,
          status: "uploading",
        }
        setOutgoingFiles((prev) => [...prev, outgoing])
        setIsTransferring(true)

        sendFile(file, fileId, conn, (progress) => {
          setOutgoingFiles((prev) =>
            prev.map((f) =>
              f.meta.id === fileId
                ? {
                    ...f,
                    progress,
                    status: progress >= 100 ? ("sent" as const) : ("uploading" as const),
                  }
                : f
            )
          )
        })
          .then(() => {
            setOutgoingFiles((prev) =>
              prev.map((f) =>
                f.meta.id === fileId
                  ? { ...f, progress: 100, status: "sent" as const }
                  : f
              )
            )
            setIsTransferring(false)
          })
          .catch(() => {
            setOutgoingFiles((prev) =>
              prev.map((f) =>
                f.meta.id === fileId ? { ...f, status: "error" as const } : f
              )
            )
            setIsTransferring(false)
          })
      })
    },
    [isConnected]
  )

  const downloadFile = useCallback((file: ReceivedFile) => {
    const url = URL.createObjectURL(file.blob)
    const a = document.createElement("a")
    a.href = url
    a.download = file.name
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [])

  return {
    outgoingFiles,
    receivedFiles,
    incomingFiles,
    uploadFiles,
    downloadFile,
    isTransferring,
  }
}
