"use client"

import { useCallback, useEffect, useRef, useState } from "react"

interface UseCountdownResult {
  remaining: number
  isExpired: boolean
  start: (durationMs: number) => void
  stop: () => void
}

export function useCountdown(): UseCountdownResult {
  const [remaining, setRemaining] = useState(0)
  const [isExpired, setIsExpired] = useState(false)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const expiresAtRef = useRef<number>(0)

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
  }, [])

  const start = useCallback(
    (durationMs: number) => {
      stop()
      const expiresAt = Date.now() + durationMs
      expiresAtRef.current = expiresAt
      setIsExpired(false)

      const tick = () => {
        const left = Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000))
        setRemaining(left)
        if (left <= 0) {
          setIsExpired(true)
          stop()
        }
      }

      tick()
      intervalRef.current = setInterval(tick, 1000)
    },
    [stop]
  )

  useEffect(() => {
    return () => {
      stop()
    }
  }, [stop])

  return { remaining, isExpired, start, stop }
}
