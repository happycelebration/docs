"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import Peer, { type DataConnection } from "peerjs"
import type { ConnectionStatus } from "@/types"

interface UsePeerResult {
  peer: Peer | null
  connection: DataConnection | null
  status: ConnectionStatus
  createRoom: (roomId: string) => void
  joinRoom: (roomId: string) => void
  disconnect: () => void
}

export function usePeer(): UsePeerResult {
  const [peer, setPeer] = useState<Peer | null>(null)
  const [connection, setConnection] = useState<DataConnection | null>(null)
  const [status, setStatus] = useState<ConnectionStatus>("idle")
  const peerRef = useRef<Peer | null>(null)
  const connectionRef = useRef<DataConnection | null>(null)

  const cleanup = useCallback(() => {
    if (connectionRef.current) {
      connectionRef.current.close()
      connectionRef.current = null
      setConnection(null)
    }
    if (peerRef.current && !peerRef.current.destroyed) {
      peerRef.current.destroy()
      peerRef.current = null
      setPeer(null)
    }
  }, [])

  const createRoom = useCallback((roomId: string) => {
    cleanup()
    setStatus("connecting")

    const p = new Peer(roomId)
    peerRef.current = p
    setPeer(p)

    p.on("error", () => {
      setStatus("disconnected")
    })

    p.on("open", () => {
      setStatus("waiting")

      p.on("connection", (conn) => {
        conn.on("open", () => {
          connectionRef.current = conn
          setConnection(conn)
          setStatus("connected")
        })

        conn.on("close", () => {
          setStatus("disconnected")
          connectionRef.current = null
          setConnection(null)
        })

        conn.on("error", () => {
          setStatus("disconnected")
        })
      })
    })
  }, [cleanup])

  const joinRoom = useCallback((roomId: string) => {
    cleanup()
    setStatus("connecting")

    const p = new Peer()
    peerRef.current = p
    setPeer(p)

    p.on("error", () => {
      setStatus("disconnected")
    })

    p.on("open", () => {
      const conn = p.connect(roomId, { reliable: true })

      conn.on("open", () => {
        connectionRef.current = conn
        setConnection(conn)
        setStatus("connected")
      })

      conn.on("close", () => {
        setStatus("disconnected")
        connectionRef.current = null
        setConnection(null)
      })

      conn.on("error", () => {
        setStatus("disconnected")
      })
    })
  }, [cleanup])

  const disconnect = useCallback(() => {
    cleanup()
    setStatus("idle")
  }, [cleanup])

  useEffect(() => {
    return () => {
      cleanup()
    }
  }, [cleanup])

  useEffect(() => {
    if (connection) {
      const handleClose = () => {
        setStatus("disconnected")
        connectionRef.current = null
        setConnection(null)
      }
      connection.on("close", handleClose)
      connection.on("error", handleClose)

      return () => {
        connection.off("close", handleClose)
        connection.off("error", handleClose)
      }
    }
  }, [connection])

  return { peer, connection, status, createRoom, joinRoom, disconnect }
}
