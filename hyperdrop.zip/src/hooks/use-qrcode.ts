"use client"

import { useCallback, useRef, useState } from "react"
import QRCode from "qrcode"

interface UseQRCodeResult {
  qrDataUrl: string
  generate: (text: string) => Promise<void>
  download: (filename?: string) => void
}

export function useQRCode(): UseQRCodeResult {
  const [qrDataUrl, setQrDataUrl] = useState("")
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  const generate = useCallback(async (text: string) => {
    try {
      const canvas = document.createElement("canvas")
      canvasRef.current = canvas
      await QRCode.toCanvas(canvas, text, {
        width: 280,
        margin: 2,
        color: { dark: "#1a0a2e", light: "#ffffff" },
      })
      setQrDataUrl(canvas.toDataURL("image/png"))
    } catch {
      setQrDataUrl("")
    }
  }, [])

  const download = useCallback((filename = "hyperdrop-qr.png") => {
    if (!qrDataUrl) return
    const a = document.createElement("a")
    a.href = qrDataUrl
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }, [qrDataUrl])

  return { qrDataUrl, generate, download }
}
