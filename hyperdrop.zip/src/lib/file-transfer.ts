import { CHUNK_SIZE, type FileMeta, type PeerMessage } from "@/types"
import type { DataConnection } from "peerjs"

export function createFileMeta(file: File, id: string): FileMeta {
  return {
    id,
    name: file.name,
    size: file.size,
    type: file.type || "application/octet-stream",
    totalChunks: Math.ceil(file.size / CHUNK_SIZE),
  }
}

export async function sendFile(
  file: File,
  fileId: string,
  connection: DataConnection,
  onProgress: (progress: number) => void
): Promise<void> {
  const meta = createFileMeta(file, fileId)

  const metaMessage: PeerMessage = { type: "file-meta", payload: meta }
  connection.send(metaMessage)

  await new Promise((resolve) => setTimeout(resolve, 100))

  let offset = 0
  let chunkIndex = 0

  while (offset < file.size) {
    const end = Math.min(offset + CHUNK_SIZE, file.size)
    const blob = file.slice(offset, end)
    const buffer = await blob.arrayBuffer()

    const chunkMessage: PeerMessage = {
      type: "file-chunk",
      payload: { fileId, index: chunkIndex, data: buffer },
    }
    connection.send(chunkMessage)

    offset = end
    chunkIndex++
    onProgress(Math.min((offset / file.size) * 100, 100))

    if (chunkIndex % 8 === 0) {
      await new Promise((resolve) => setTimeout(resolve, 10))
    }
  }

  const endMessage: PeerMessage = { type: "file-end", payload: { fileId } }
  connection.send(endMessage)
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 B"
  const units = ["B", "KB", "MB", "GB"]
  const k = 1024
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  const size = bytes / Math.pow(k, i)
  return `${size.toFixed(i === 0 ? 0 : 1)} ${units[i]}`
}

export function formatTime(seconds: number): string {
  if (seconds <= 0) return "00:00"
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) {
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`
  }
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`
}

export function generateFileId(): string {
  return `f-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
}
