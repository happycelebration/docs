const memoryStore = new Map<string, string>()

function isSessionStorageAvailable(): boolean {
  try {
    const testKey = "__hyperdrop_test__"
    sessionStorage.setItem(testKey, "1")
    sessionStorage.removeItem(testKey)
    return true
  } catch {
    return false
  }
}

const storageAvailable = typeof window !== "undefined" && isSessionStorageAvailable()

export const safeStorage = {
  setItem(key: string, value: string): void {
    if (storageAvailable) {
      try {
        sessionStorage.setItem(key, value)
      } catch {
        memoryStore.set(key, value)
      }
    } else {
      memoryStore.set(key, value)
    }
  },

  getItem(key: string): string | null {
    if (storageAvailable) {
      try {
        return sessionStorage.getItem(key)
      } catch {
        return memoryStore.get(key) ?? null
      }
    }
    return memoryStore.get(key) ?? null
  },

  removeItem(key: string): void {
    if (storageAvailable) {
      try {
        sessionStorage.removeItem(key)
      } catch {
        memoryStore.delete(key)
      }
    } else {
      memoryStore.delete(key)
    }
  },
}
