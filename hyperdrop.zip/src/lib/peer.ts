import Peer, { type DataConnection } from "peerjs"

export function createHostPeer(roomId: string): Promise<{ peer: Peer; connection: DataConnection }> {
  return new Promise((resolve, reject) => {
    const peer = new Peer(roomId)

    peer.on("error", (err) => {
      reject(err)
    })

    peer.on("open", () => {
      peer.on("connection", (conn) => {
        conn.on("open", () => {
          resolve({ peer, connection: conn })
        })
      })
    })
  })
}

export function createJoinerPeer(
  roomId: string
): Promise<{ peer: Peer; connection: DataConnection }> {
  return new Promise((resolve, reject) => {
    const peer = new Peer()

    peer.on("error", (err) => {
      reject(err)
    })

    peer.on("open", () => {
      const conn = peer.connect(roomId, { reliable: true })

      conn.on("open", () => {
        resolve({ peer, connection: conn })
      })

      conn.on("error", (err) => {
        reject(err)
      })
    })
  })
}

export function destroyPeer(peer: Peer | null): void {
  if (peer && !peer.destroyed) {
    peer.destroy()
  }
}
