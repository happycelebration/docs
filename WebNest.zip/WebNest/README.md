# WebNest

**WebNest** is a sleek, modern, and highly responsive Android application designed to convert your favorite mobile websites into seamless, native-feeling applications. Built around a dynamic Multi-WebView Dashboard, it offers a beautifully structured interface that organizes custom web links into a production-ready, 3D card layout complete with local data persistence, automatic icon fetching, and a real-time dark theme toggle.

Distinctively optimized for standalone development environments, this application contains zero dependencies on heavy third-party UI libraries or annotation processors, enabling it to compile instantly within both mobile IDE systems like AIDE and standard desktop environments like Android Studio.

---

## Tech Stack

The architecture of **WebNest** relies entirely on native, robust, and lightning-fast Android core elements to remain exceptionally lightweight and widely compatible:

- **Language:** Pure Java (Compiled with full Java 6/7 syntax tree compatibility to eliminate reliance on modern runtime desugaring or Java 8+ features).

- **UI Engine:** Android Native XML Views (`RelativeLayout`, `LinearLayout`, `GridView`, `FrameLayout`) ensuring fast layout measurements.

- **Web Engine:** `android.webkit.WebView` powered by optimized native JavaScript (`WebSettings`) and specialized, dynamic navigation intercepts (`WebViewClient`).

- **Data Persistence:** Android `SharedPreferences` managing customized local storage setups via lightweight key-value string serialization.

- **Asynchronous Processing:** Standard Android `AsyncTask` threads handling independent network requests to pull custom images in the background without dropping frame rates.

- **Graphics Renderer:** High-definition Vector Drawables (`<vector>`) compiled natively down to low-level canvas paths.

- **Build Automation System:** Gradle (Configured with structural repository fallbacks to bridge local assets smoothly across target machines).

---

## Features

- **Native App Feel:** Wraps standard web addresses into high-performance, edge-to-edge WebView sandboxes.

- **AIDE Ready Out-of-the-Box:** Fully authored using strictly backward-compatible Java 7 syntax, completely avoiding modern compiler features like lambdas, method references, or diamond operators.

- **Beautiful 3D Card Dashboard:** Arranges shortcuts into a two-column, 3-millimeter spaced fluid scroll grid styled with custom depth drawables.

- **Dynamic Metadata & Favicon Fetching:** Automatically generates, loads, and squares web app icons on the fly by resolving URLs against secure CDN endpoints.

- **Real-time Dark & Light Themes:** Toggle visual states directly within the app toolbar. Includes runtime color filtering of vector drawables (`.xml` SVGs).

- **Persistent Storage:** Uses flattened data architectures stored inside `SharedPreferences` to ensure websites survive device restarts and orientation resets.

- **Dynamic Title Switching:** The sticky action toolbar tracks network navigation dynamically, instantly displaying the true header title of the active webpage.

- **Intuitive Navigation & Management:** Supports localized in-app page backstack handling via the system back button and instant list purging via standard long-press interactions.

---

## Project Structure

The codebase is organized cleanly to match rigid Android compilation models:

```text
├── AndroidManifest.xml          # Configures system permissions and intents
├── build.gradle                 # Handles build variants and SDK targets
├── res/
│   ├── drawable/                # Modern vector asset SVGs & 3D background maps
│   │   ├── card_background_dark.xml
│   │   ├── card_background_light.xml
│   │   ├── ic_moon.xml
│   │   ├── ic_plus.xml
│   │   └── ic_sun.xml
│   └── layout/                  # Strict standard Android UI layout views
│       ├── activity_main.xml    # Top sticky toolbar and primary GridView
│       ├── dialog_add_app.xml   # Entry inputs for custom URLs
│       └── grid_item.xml        # Card frame definition for grid entries
└── src/com/smart/webnest/
    ├── MainActivity.java        # Central application state and window drivers
    ├── SquareImageView.java     # Bound layout widget enforcing aspect-ratios
    ├── WebAdapter.java          # Custom item renderer handling background image threads
    └── WebApp.java              # Immutable object data model representing websites
```

**Application Name:** `WebNest`

**Package Name:** `com.smart.webnest`

---

## Compilation & Environment Targets

The app targets modern Android performance requirements while retaining strong backward compatibility profiles:

- **Compilation SDK:** `compileSdk 36` (Android 16)

- **Target SDK:** `targetSdk 36` (Android 16 compatibility ensuring Edge-to-Edge architecture conformance)

- **Minimum SDK:** `minSdk 24` (Android 7.0 Nougat)

- **Gradle Variant:** Gradle 9.0.1 / AGP compatibility configurations

---

## Installation & Setup

### Building via AIDE (Mobile Environment)

1. Create a blank project inside AIDE matching the root application layout structure.

2. Clone or copy the source components into their corresponding folders inside your local workspace (`app/src/main/...`).

3. Configure the root-level repositories and Gradle paths as defined in the project.

4. Run **Clean Project** from the AIDE menu.

5. Tap **Run** to compile, package, and install the application on your Android device.

### Building via Android Studio (Desktop Environment)

1. Open Android Studio and select **Import Project (Gradle)**.

2. Choose the project's root directory.

3. Allow Gradle to synchronize dependencies automatically.

4. Build the release APK using:

```bash
./gradlew assembleRelease
```

---

## Usage Guide

### Accessing a Website

Tap any card on the dashboard to launch the selected website in a full-screen native WebView.

### Adding a New Website

Tap the **+** icon in the toolbar, enter the website title and URL (for example, `github.com`), then tap **Add**.

### Removing a Website

Long-press any dashboard card and confirm the deletion to remove it permanently.

### Switching Themes

Tap the theme icon in the toolbar to instantly switch between **Light Mode** and **Dark Mode**.

### Navigation

The Android system **Back** button navigates backward through the current website before exiting the application.

---

## License

This repository is licensed under the **MIT License**. You are free to use, modify, distribute, and deploy the project for both personal and commercial purposes.
