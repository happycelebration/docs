package com.smart.webnest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private RelativeLayout mainRootLayout;
    private LinearLayout topToolbar;
    private TextView toolbarTitle;
    private ImageButton btnToggleTheme;
    private ImageButton btnAddWebsite;
    private GridView gridView;
    private FrameLayout webViewContainer;
    private WebView webView;

    private ArrayList<WebApp> webAppList;
    private WebAdapter adapter;

    private boolean isDarkMode = false;

    private static final String PREFS_NAME = "WebAppsPrefs";
    private static final String KEY_DATA_STRING = "serialized_apps";
    private static final String KEY_DARK_MODE = "dark_mode_state";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        isDarkMode = prefs.getBoolean(KEY_DARK_MODE, false);

        if (isDarkMode) {
            setTheme(android.R.style.Theme_Holo_NoActionBar);
        } else {
            setTheme(android.R.style.Theme_Holo_Light_NoActionBar);
        }

        setContentView(R.layout.activity_main);

        mainRootLayout = (RelativeLayout) findViewById(R.id.main_root_layout);
        topToolbar = (LinearLayout) findViewById(R.id.top_toolbar);
        toolbarTitle = (TextView) findViewById(R.id.toolbar_title);
        btnToggleTheme = (ImageButton) findViewById(R.id.btn_toggle_theme);
        btnAddWebsite = (ImageButton) findViewById(R.id.btn_add_website);
        gridView = (GridView) findViewById(R.id.dashboard_grid);
        webViewContainer = (FrameLayout) findViewById(R.id.webview_container);

        webAppList = new ArrayList<WebApp>();
        loadSavedApps();

        adapter = new WebAdapter(this, webAppList, isDarkMode);
        gridView.setAdapter(adapter);
        updateUiColors();

        btnWebViewSetup();

        btnAddWebsite.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showAddAppDialog();
				}
			});

        btnToggleTheme.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					isDarkMode = !isDarkMode;
					SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
					SharedPreferences.Editor editor = prefs.edit();
					editor.putBoolean(KEY_DARK_MODE, isDarkMode);
					editor.commit();

					updateUiColors();
				}
			});
    }

    private void btnWebViewSetup() {
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					WebApp selectedApp = webAppList.get(position);
					openWebViewApp(selectedApp);
				}
			});

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
				@Override
				public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
					showDeleteConfirmDialog(position);
					return true;
				}
			});
    }

    private void updateUiColors() {
        if (isDarkMode) {
            mainRootLayout.setBackgroundColor(Color.parseColor("#121212"));
            topToolbar.setBackgroundColor(Color.parseColor("#1E1E1E"));
            toolbarTitle.setTextColor(Color.parseColor("#FFFFFF"));

            btnToggleTheme.setImageResource(R.drawable.ic_sun);
            btnToggleTheme.setColorFilter(Color.parseColor("#FFFFFF"));
            btnAddWebsite.setColorFilter(Color.parseColor("#FFFFFF"));
        } else {
            mainRootLayout.setBackgroundColor(Color.parseColor("#F5F5F7"));
            topToolbar.setBackgroundColor(Color.parseColor("#FFFFFF"));
            toolbarTitle.setTextColor(Color.parseColor("#1C1C1E"));

            btnToggleTheme.setImageResource(R.drawable.ic_moon);
            btnToggleTheme.setColorFilter(Color.parseColor("#1C1C1E"));
            btnAddWebsite.setColorFilter(Color.parseColor("#1C1C1E"));
        }
        adapter.setDarkMode(isDarkMode);
        adapter.notifyDataSetChanged();
    }

    private void showDeleteConfirmDialog(final int position) {
        WebApp appToDelete = webAppList.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Remove Website");
        builder.setMessage("Are you sure you want to remove " + appToDelete.getName() + "?");

        builder.setPositiveButton("Remove", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					webAppList.remove(position);
					adapter.notifyDataSetChanged();
					saveApps();
					Toast.makeText(MainActivity.this, "Website removed", Toast.LENGTH_SHORT).show();
				}
			});

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

        builder.create().show();
    }

    private void openWebViewApp(final WebApp app) {
        toolbarTitle.setText(app.getName());
        btnAddWebsite.setVisibility(View.GONE);

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
									FrameLayout.LayoutParams.MATCH_PARENT,
									FrameLayout.LayoutParams.MATCH_PARENT));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        webView.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					view.loadUrl(url);
					return true;
				}

				@Override
				public void onPageFinished(WebView view, String url) {
					String webTitle = view.getTitle();
					if (webTitle != null && webTitle.length() > 0) {
						toolbarTitle.setText(webTitle);
					}
				}
			});

        webViewContainer.removeAllViews();
        webViewContainer.addView(webView);

        webView.loadUrl(app.getUrl());

        gridView.setVisibility(View.GONE);
        webViewContainer.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (webViewContainer.getVisibility() == View.VISIBLE && webView != null) {
            if (webView.canGoBack()) {
                webView.goBack();
            } else {
                webViewContainer.setVisibility(View.GONE);
                gridView.setVisibility(View.VISIBLE);
                webViewContainer.removeAllViews();
                webView = null;

                toolbarTitle.setText("WebNest");
                btnAddWebsite.setVisibility(View.VISIBLE);
            }
        } else {
            super.onBackPressed();
        }
    }

    private void showAddAppDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Website App");

        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_app, null);
        builder.setView(dialogView);

        final EditText editTitle = (EditText) dialogView.findViewById(R.id.edit_title);
        final EditText editUrl = (EditText) dialogView.findViewById(R.id.edit_url);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					String title = editTitle.getText().toString().trim();
					String url = editUrl.getText().toString().trim();

					if (title.length() == 0 || url.length() == 0) {
						Toast.makeText(MainActivity.this, "Fields cannot be blank", Toast.LENGTH_SHORT).show();
						return;
					}

					if (!url.startsWith("http://") && !url.startsWith("https://")) {
						url = "https://" + url;
					}

					webAppList.add(new WebApp(title, url));
					adapter.notifyDataSetChanged();
					saveApps();
				}
			});

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

        builder.create().show();
    }

    private void saveApps() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < webAppList.size(); i++) {
            WebApp app = webAppList.get(i);
            sb.append(app.getName()).append("<<<>>>").append(app.getUrl());
            if (i < webAppList.size() - 1) {
                sb.append("|||");
            }
        }

        editor.putString(KEY_DATA_STRING, sb.toString());
        editor.commit();
    }

    private void loadSavedApps() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String data = prefs.getString(KEY_DATA_STRING, "");

        webAppList.clear();
        if (data.length() == 0) {
            webAppList.add(new WebApp("Google", "https://www.google.com"));
            webAppList.add(new WebApp("Wikipedia", "https://www.wikipedia.org"));
            return;
        }

        String[] apps = data.split("\\|\\|\\|");
        for (int i = 0; i < apps.length; i++) {
            String[] parts = apps[i].split("<<<>>>");
            if (parts.length == 2) {
                webAppList.add(new WebApp(parts[0], parts[1]));
            }
        }
    }
}

