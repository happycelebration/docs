package com.smart.webnest;

public class WebApp {
    private String name;
    private String url;

    public WebApp(String name, String url) {
        this.name = name;
        this.url = url;
    }

    public String getName() {
        return this.name;
    }

    public String getUrl() {
        return this.url;
    }
}

