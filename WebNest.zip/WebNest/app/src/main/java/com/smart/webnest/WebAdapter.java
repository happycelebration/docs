package com.smart.webnest;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class WebAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<WebApp> appList;
    private boolean isDarkMode;

    public WebAdapter(Context context, ArrayList<WebApp> appList, boolean isDarkMode) {
        this.context = context;
        this.appList = appList;
        this.isDarkMode = isDarkMode;
    }

    public void setDarkMode(boolean isDarkMode) {
        this.isDarkMode = isDarkMode;
    }

    @Override
    public int getCount() {
        return appList.size();
    }

    @Override
    public Object getItem(int position) {
        return appList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.grid_item, parent, false);
        }

        LinearLayout rootLayout = (LinearLayout) convertView.findViewById(R.id.item_root_layout);
        SquareImageView iconView = (SquareImageView) convertView.findViewById(R.id.item_icon);
        TextView titleView = (TextView) convertView.findViewById(R.id.item_title);
        TextView subtitleView = (TextView) convertView.findViewById(R.id.item_subtitle);

        if (isDarkMode) {
            rootLayout.setBackgroundResource(R.drawable.card_background_dark);
            titleView.setTextColor(Color.parseColor("#FFFFFF"));
            subtitleView.setTextColor(Color.parseColor("#A9A9A9"));
        } else {
            rootLayout.setBackgroundResource(R.drawable.card_background_light);
            titleView.setTextColor(Color.parseColor("#1C1C1E"));
            subtitleView.setTextColor(Color.parseColor("#8E8E93"));
        }

        WebApp currentApp = appList.get(position);
        titleView.setText(currentApp.getName());

        String cleanDisplayUrl = currentApp.getUrl().replace("https://", "").replace("http://", "");
        subtitleView.setText(cleanDisplayUrl);

        iconView.setImageResource(android.R.drawable.sym_def_app_icon);

        String faviconUrl = "https://www.google.com/s2/favicons?sz=128&domain=" + cleanDisplayUrl;
        new ImageLoadTask(faviconUrl, iconView).execute();

        return convertView;
    }

    private static class ImageLoadTask extends AsyncTask<Void, Void, Bitmap> {
        private String url;
        private SquareImageView imageView;

        public ImageLoadTask(String url, SquareImageView imageView) {
            this.url = url;
            this.imageView = imageView;
        }

        @Override
        protected Bitmap doInBackground(Void... params) {
            try {
                URL urlConnection = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) urlConnection.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                return BitmapFactory.decodeStream(input);
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            if (result != null && imageView != null) {
                imageView.setImageBitmap(result);
            }
        }
    }
}

