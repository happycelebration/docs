# 🪐 Planetopedia: 3D Solar System Explorer

An interactive 3D solar system simulation built with Next.js, Three.js, and TypeScript. Explore all planets in our solar system with realistic textures, orbital animations, educational information, and text-to-speech narration.

![Next.js](https://img.shields.io/badge/Next.js-16-black?logo=next.js)
![Three.js](https://img.shields.io/badge/Three.js-R3F-orange?logo=three.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)
![Vercel](https://img.shields.io/badge/Deploy-Vercel-black?logo=vercel)

---

## ✨ Features

- **Realistic 3D Solar System**: All 9 planets (Mercury through Pluto) with real texture maps, proper orbital paths, and axial tilts
- **Interactive Sun**: Click the Sun to view its detailed information
- **Orbital Animation**: Planets revolve around the Sun and rotate on their axes with adjustable speed controls
- **Interactive Exploration**: Click any planet to zoom in, view detailed information, and hear it spoken aloud via text-to-speech
- **Auto Narration**: Planet info is automatically spoken 1 second after the info panel appears
- **Asteroid Belts**: Main asteroid belt between Mars and Jupiter, plus the Kuiper Belt beyond Neptune
- **Saturn & Uranus Rings**: Textured ring systems with proper UV mapping
- **Earth's Moon**: Orbiting moon with realistic texture
- **Atmospheres**: Earth and Venus feature transparent atmosphere layers
- **Bloom Effects**: Sun glow with post-processing bloom for realistic lighting
- **Sun Glow & Light**: Adjustable sun intensity with point light illumination
- **Controls Panel**: Orbit speed, rotation speed, and sun glow sliders
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Keyboard Shortcuts**: Press `Escape` to close info panel and return to overview

---

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) 18+ or [Bun](https://bun.sh/)

### Installation

```bash
# Clone the repository
git clone https://github.com/cloudxplorer/Planetopedia
cd Planetopedia

# Install dependencies
npm install

# Start the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🎮 How to Use

| Action | Control |
|---|---|
| **Select a planet/Sun** | Click on any planet or the Sun |
| **Rotate the view** | Left-click + drag |
| **Zoom in/out** | Scroll wheel / pinch |
| **Pan the view** | Right-click + drag |
| **Close info panel** | Click ✕ or press `Escape` |
| **Resume orbits** | Close the planet info panel |
| **Adjust orbit speed** | Use the Orbit Speed slider |
| **Adjust rotation speed** | Use the Rotation Speed slider |
| **Adjust sun glow** | Use the Sun Glow slider |
| **Reset view** | Click the "Reset View" button |
| **Read planet info aloud** | Click "Read Aloud" in the info panel |

---

## 📁 Project Structure

```
Planetopedia/
├── public/
│   └── textures/          # Planet texture maps
│       ├── sun.jpg
│       ├── mercury.jpg
│       ├── venus.jpg
│       ├── earth_daymap.jpg
│       ├── earth_normal.jpg
│       ├── earth_clouds.png
│       ├── moon.jpg
│       ├── mars.jpg
│       ├── jupiter.jpg
│       ├── saturn.jpg
│       ├── saturn_ring_color.jpg
│       ├── uranus_map.jpg
│       ├── uranus_ring.jpg
│       ├── neptune_map.jpg
│       └── pluto.jpg
├── src/
│   ├── app/
│   │   ├── globals.css            # Global styles & animations
│   │   ├── layout.tsx             # Root layout with metadata
│   │   └── page.tsx               # Main page with state management
│   ├── components/
│   │   ├── solar-system/
│   │   │   ├── SolarSystem.tsx    # 3D scene (Sun, Planets, Asteroids, Camera)
│   │   │   ├── PlanetInfoPanel.tsx # Planet info overlay panel
│   │   │   └── ControlsPanel.tsx  # Speed/glow controls
│   │   └── ui/                    # Reusable UI components (shadcn/ui)
│   │       ├── badge.tsx
│   │       ├── button.tsx
│   │       ├── card.tsx
│   │       ├── label.tsx
│   │       └── slider.tsx
│   └── lib/
│       ├── planet-data.ts         # Planet data & types
│       └── utils.ts               # Utility functions
├── next.config.ts                 # Next.js configuration
├── package.json
├── tsconfig.json
└── README.md
```

---

## 🛠️ Tech Stack

| Technology | Purpose |
|---|---|
| **Next.js 16** | React framework with App Router |
| **TypeScript** | Type-safe development |
| **Three.js** | 3D rendering engine |
| **@react-three/fiber** | React renderer for Three.js |
| **@react-three/drei** | Useful helpers for R3F (OrbitControls, Stars, etc.) |
| **@react-three/postprocessing** | Bloom post-processing effects |
| **Tailwind CSS 4** | Utility-first styling |
| **shadcn/ui** | Accessible UI component library |
| **Lucide React** | Icon library |

---

## 🪐 Planet Data

Each planet (and the Sun) includes:

- Radius, Diameter, Distance from Sun
- Axial Tilt, Rotation Period, Orbital Period
- Temperature, Gravity, Number of Moons
- Atmospheric Composition
- Mass
- Fun Facts
- Discovery Information

---

## License

© 2026 Planetopedia by Pallavi Thakur. All Rights Reserved.

Built with Next.js, Three.js & TypeScript** | Useful helpers for R3F (OrbitControls, Stars, etc.) |
| **@react-three/postprocessing** | Bloom post-processing effects |
| **Tailwind CSS 4** | Utility-first styling |
| **shadcn/ui** | Accessible UI component library |
| **Lucide React** | Icon library |

---

## 🪐 Planet Data

Each planet (and the Sun) includes:

- Radius, Diameter, Distance from Sun
- Axial Tilt, Rotation Period, Orbital Period
- Temperature, Gravity, Number of Moons
- Atmospheric Composition
- Mass
- Fun Facts
- Discovery Information

---

## 📄 License

© 2025 3D Solar System Explorer. All Rights Reserved.

Built with Next.js, Three.js & TypeScript
