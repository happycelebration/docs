"use client";

import { useState, useCallback, useRef, useEffect } from "react";
import dynamic from "next/dynamic";
import { PlanetInfo, SUN_INFO } from "@/lib/planet-data";
import PlanetInfoPanel from "@/components/solar-system/PlanetInfoPanel";
import ControlsPanel from "@/components/solar-system/ControlsPanel";
import { Badge } from "@/components/ui/badge";
import {
  Volume2,
  MousePointerClick,
  Move,
  ZoomIn,
  RotateCw,
} from "lucide-react";

const SolarSystem = dynamic(
  () => import("@/components/solar-system/SolarSystem"),
  { ssr: false }
);

export default function Home() {
  const [selectedPlanet, setSelectedPlanet] = useState<PlanetInfo | null>(null);
  const [hoveredPlanet, setHoveredPlanet] = useState<PlanetInfo | null>(null);
  const [orbitSpeed, setOrbitSpeed] = useState(1);
  const [rotationSpeed, setRotationSpeed] = useState(1);
  const [sunIntensity, setSunIntensity] = useState(1.9);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [isOrbitPaused, setIsOrbitPaused] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const autoSpeakRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const stopSpeaking = useCallback(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  const handleSpeak = useCallback((text: string) => {
    stopSpeaking();
    if (!("speechSynthesis" in window)) return;
    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }, [stopSpeaking]);

  const handleBodyClick = useCallback(
    (body: PlanetInfo) => {
      if (isSpeaking) stopSpeaking();
      if (autoSpeakRef.current) {
        clearTimeout(autoSpeakRef.current);
        autoSpeakRef.current = null;
      }
      setSelectedPlanet(body);
      setShowInfo(false);
      setIsOrbitPaused(true);
    },
    [isSpeaking, stopSpeaking]
  );

  const handlePlanetClick = useCallback(
    (planet: PlanetInfo) => handleBodyClick(planet),
    [handleBodyClick]
  );

  const handleSunClick = useCallback(
    (sun: PlanetInfo) => handleBodyClick(sun),
    [handleBodyClick]
  );

  const handleCameraArrival = useCallback(() => {
    setShowInfo(true);
  }, []);

  const handlePlanetHover = useCallback((planet: PlanetInfo | null) => {
    setHoveredPlanet(planet);
  }, []);

  const handleSunHover = useCallback((body: PlanetInfo | null) => {
    setHoveredPlanet(body);
  }, []);

  const handleCloseInfo = useCallback(() => {
    if (isSpeaking) stopSpeaking();
    if (autoSpeakRef.current) {
      clearTimeout(autoSpeakRef.current);
      autoSpeakRef.current = null;
    }
    setSelectedPlanet(null);
    setShowInfo(false);
    setIsOrbitPaused(false);
  }, [isSpeaking, stopSpeaking]);

  const handleReset = useCallback(() => {
    handleCloseInfo();
    setOrbitSpeed(1);
    setRotationSpeed(1);
    setSunIntensity(1.9);
  }, [handleCloseInfo]);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (showInfo && selectedPlanet) {
      if (autoSpeakRef.current) {
        clearTimeout(autoSpeakRef.current);
      }
      autoSpeakRef.current = setTimeout(() => {
        const fullText = `${selectedPlanet.name}. ${selectedPlanet.description} ${selectedPlanet.funFact ? `Fun fact: ${selectedPlanet.funFact}` : ""}`;
        handleSpeak(fullText);
      }, 1000);
      return () => {
        if (autoSpeakRef.current) {
          clearTimeout(autoSpeakRef.current);
          autoSpeakRef.current = null;
        }
      };
    }
  }, [showInfo, selectedPlanet, handleSpeak]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        handleCloseInfo();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleCloseInfo]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-black">
      {isLoading && (
        <div className="absolute inset-0 z-[100] flex flex-col items-center justify-center bg-black">
          <div className="relative">
            <div className="w-20 h-20 rounded-full border-4 border-yellow-400/20 border-t-yellow-400 animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-300 to-orange-500 animate-pulse" />
            </div>
          </div>
          <p className="mt-6 text-white/70 text-sm font-medium tracking-wider animate-pulse">
            Loading Solar System...
          </p>
        </div>
      )}

      <SolarSystem
        onPlanetClick={handlePlanetClick}
        onPlanetHover={handlePlanetHover}
        onSunClick={handleSunClick}
        onSunHover={handleSunHover}
        selectedPlanet={selectedPlanet}
        onCameraArrival={handleCameraArrival}
        orbitSpeed={orbitSpeed}
        rotationSpeed={rotationSpeed}
        sunIntensity={sunIntensity}
        isOrbitPaused={isOrbitPaused}
      />

      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-40 pointer-events-none">
        <div className="text-center">
          <h1
            className="text-lg sm:text-xl md:text-2xl font-bold tracking-widest"
            style={{
              background:
                "linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FF6347 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              filter: "drop-shadow(0 0 20px rgba(255,165,0,0.3))",
            }}
          >
            PLANETOPEDIA
          </h1>
          <p className="text-white/40 text-[10px] sm:text-xs tracking-wider mt-0.5">
            Interactive Space Exploration
          </p>
        </div>
      </div>

      {isOrbitPaused && (
        <div className="absolute top-14 sm:top-16 left-1/2 -translate-x-1/2 z-40 pointer-events-none">
          <Badge
            variant="outline"
            className="gap-1.5 border-amber-500/50 bg-amber-500/10 text-amber-400 px-3 py-1 text-[10px] sm:text-xs"
          >
            <RotateCw size={12} className="opacity-50" />
            Orbit Paused — Click &quot;Close&quot; to resume
          </Badge>
        </div>
      )}

      {showInfo && selectedPlanet && (
        <PlanetInfoPanel
          planet={selectedPlanet}
          onClose={handleCloseInfo}
          isSpeaking={isSpeaking}
          onSpeak={handleSpeak}
          onStopSpeaking={stopSpeaking}
        />
      )}

      <ControlsPanel
        orbitSpeed={orbitSpeed}
        rotationSpeed={rotationSpeed}
        sunIntensity={sunIntensity}
        onOrbitSpeedChange={setOrbitSpeed}
        onRotationSpeedChange={setRotationSpeed}
        onSunIntensityChange={setSunIntensity}
        onReset={handleReset}
      />

      <div className="absolute bottom-14 sm:bottom-16 left-2 sm:left-4 z-40 pointer-events-none">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs">
            <MousePointerClick size={12} />
            <span>Click any planet or Sun to explore</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs">
            <Move size={12} />
            <span>Drag to rotate view</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs">
            <ZoomIn size={12} />
            <span>Scroll to zoom in/out</span>
          </div>
        </div>
      </div>

      {isSpeaking && (
        <div className="absolute bottom-14 sm:bottom-16 left-1/2 -translate-x-1/2 z-50">
          <Badge
            variant="outline"
            className="gap-2 border-yellow-500/50 bg-yellow-500/10 text-yellow-400 px-3 py-1"
          >
            <Volume2 size={14} className="animate-pulse" />
            <span className="text-xs">Speaking...</span>
          </Badge>
        </div>
      )}

      <footer className="absolute bottom-0 left-0 right-0 z-40 bg-black/40 backdrop-blur-sm border-t border-white/5">
        <div className="flex items-center justify-center py-2 px-4">
          <p className="text-white/30 text-[10px] sm:text-xs text-center">
            © {new Date().getFullYear()} Planetopedia by Pallavi Thakur. All Rights
            Reserved. | Built with Next.js, Three.js & TypeScript
          </p>
        </div>
      </footer>
    </main>
  );
}
