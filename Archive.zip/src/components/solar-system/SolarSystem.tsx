"use client";

import { useRef, useState, useCallback, useEffect, useMemo } from "react";
import { Canvas, useFrame, useThree, ThreeEvent } from "@react-three/fiber";
import {
  OrbitControls,
  Stars,
  Html,
  useTexture,
  Line,
} from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import { PLANETS, PlanetInfo, SUN_INFO } from "@/lib/planet-data";

interface PlanetProps {
  planet: PlanetInfo;
  orbitSpeedMultiplier: number;
  rotationSpeedMultiplier: number;
  isOrbitPaused: boolean;
  onClick: (planet: PlanetInfo) => void;
  onHover: (planet: PlanetInfo | null) => void;
}

function Sun({
  sunIntensity,
  onClick,
  onHover,
}: {
  sunIntensity: number;
  onClick: (sun: PlanetInfo) => void;
  onHover: (body: PlanetInfo | null) => void;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const texture = useTexture("/textures/sun.jpg");

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.001;
    }
    if (glowRef.current) {
      const scale = 1.0 + Math.sin(performance.now() * 0.002) * 0.015;
      glowRef.current.scale.set(scale, scale, scale);
    }
  });

  useEffect(() => {
    document.body.style.cursor = hovered ? "pointer" : "auto";
    return () => {
      document.body.style.cursor = "auto";
    };
  }, [hovered]);

  const handleClick = useCallback(
    (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation();
      onClick(SUN_INFO);
    },
    [onClick]
  );

  const handlePointerOver = useCallback(
    (e: ThreeEvent<PointerEvent>) => {
      e.stopPropagation();
      setHovered(true);
      onHover(SUN_INFO);
    },
    [onHover]
  );

  const handlePointerOut = useCallback(() => {
    setHovered(false);
    onHover(null);
  }, [onHover]);

  const sunSize = 697 / 40;

  return (
    <group>
      <mesh
        ref={meshRef}
        onClick={handleClick}
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
      >
        <sphereGeometry args={[sunSize, 64, 32]} />
        <meshStandardMaterial
          emissive={new THREE.Color(0xfff88f)}
          emissiveMap={texture}
          emissiveIntensity={sunIntensity}
          toneMapped={false}
        />
      </mesh>
      <mesh>
        <sphereGeometry args={[sunSize + 0.8, 32, 16]} />
        <meshBasicMaterial
          color="#FFA500"
          transparent
          opacity={0.06}
          side={THREE.BackSide}
          depthWrite={false}
        />
      </mesh>
      <mesh ref={glowRef}>
        <sphereGeometry args={[sunSize + 2.5, 32, 16]} />
        <meshBasicMaterial
          color="#FF8C00"
          transparent
          opacity={0.03}
          side={THREE.BackSide}
          depthWrite={false}
        />
      </mesh>
      <pointLight
        color={0xfdffd3}
        intensity={2500}
        distance={500}
        decay={1.4}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />

      {hovered && (
        <Html
          center
          position={[0, sunSize + 4, 0]}
          distanceFactor={60}
          style={{ pointerEvents: "none" }}
        >
          <div
            style={{
              background: "rgba(0,0,0,0.8)",
              color: "white",
              padding: "5px 14px",
              borderRadius: "8px",
              fontSize: "13px",
              fontWeight: 600,
              whiteSpace: "nowrap",
              border: "1.5px solid #FFD700",
              backdropFilter: "blur(8px)",
              letterSpacing: "0.5px",
              textShadow: "0 0 8px #FFD70066",
            }}
          >
            The Sun
          </div>
        </Html>
      )}
    </group>
  );
}

function PlanetAtmosphere({
  texturePath,
  size,
}: {
  texturePath: string;
  size: number;
}) {
  const atmosphereRef = useRef<THREE.Mesh>(null);
  const atmoTexture = useTexture(texturePath);

  useFrame(() => {
    if (atmosphereRef.current) {
      atmosphereRef.current.rotation.y += 0.0005;
    }
  });

  return (
    <mesh ref={atmosphereRef} rotation={[0, 0, 0.41]}>
      <sphereGeometry args={[size + 0.2, 64, 32]} />
      <meshPhongMaterial
        map={atmoTexture}
        transparent
        opacity={0.3}
        depthTest={true}
        depthWrite={false}
      />
    </mesh>
  );
}

function PlanetRing({
  texturePath,
  innerRadius,
  outerRadius,
  tiltRad,
}: {
  texturePath: string;
  innerRadius: number;
  outerRadius: number;
  tiltRad: number;
}) {
  const ringTexture = useTexture(texturePath);

  const geometry = useMemo(() => {
    const geo = new THREE.RingGeometry(innerRadius, outerRadius, 128);
    const pos = geo.attributes.position;
    const uv = geo.attributes.uv;
    const v3 = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      v3.fromBufferAttribute(pos, i);
      const dist = v3.length();
      const u = (dist - innerRadius) / (outerRadius - innerRadius);
      uv.setXY(i, u, 1);
    }
    return geo;
  }, [innerRadius, outerRadius]);

  return (
    <mesh
      rotation={[-Math.PI * 0.5, 0, -tiltRad]}
      receiveShadow
    >
      <primitive object={geometry} attach="geometry" />
      <meshStandardMaterial
        map={ringTexture}
        side={THREE.DoubleSide}
        transparent
        opacity={0.9}
        roughness={0.8}
      />
    </mesh>
  );
}

function EarthMoon({ parentSize }: { parentSize: number }) {
  const moonRef = useRef<THREE.Mesh>(null);
  const moonTexture = useTexture("/textures/moon.jpg");

  useFrame(() => {
    if (moonRef.current) {
      const time = performance.now() * 0.001;
      const orbitRadius = parentSize * 1.8;
      const tiltAngle = 5.145 * (Math.PI / 180);
      moonRef.current.position.x = Math.cos(time * 0.4) * orbitRadius;
      moonRef.current.position.z = Math.sin(time * 0.4) * orbitRadius;
      moonRef.current.position.y =
        Math.sin(time * 0.4) * orbitRadius * Math.sin(tiltAngle);
      moonRef.current.rotation.y += 0.005;
    }
  });

  return (
    <mesh ref={moonRef} castShadow receiveShadow>
      <sphereGeometry args={[1.2, 32, 16]} />
      <meshStandardMaterial map={moonTexture} roughness={0.9} />
    </mesh>
  );
}

function Planet({
  planet,
  orbitSpeedMultiplier,
  rotationSpeedMultiplier,
  isOrbitPaused,
  onClick,
  onHover,
}: PlanetProps) {
  const orbitGroupRef = useRef<THREE.Group>(null);
  const planetRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  const texture = useTexture(planet.texture);
  const bumpTexture = useTexture(planet.bumpMap || planet.texture);

  useEffect(() => {
    if (orbitGroupRef.current) {
      orbitGroupRef.current.rotation.y = planet.startAngle;
    }
  }, [planet.startAngle]);

  useEffect(() => {
    document.body.style.cursor = hovered ? "pointer" : "auto";
    return () => {
      document.body.style.cursor = "auto";
    };
  }, [hovered]);

  useFrame((_, delta) => {
    if (orbitGroupRef.current && !isOrbitPaused) {
      orbitGroupRef.current.rotation.y +=
        planet.orbitSpeed * orbitSpeedMultiplier * delta * 60;
    }
    if (planetRef.current) {
      planetRef.current.rotation.y +=
        planet.rotationSpeed * rotationSpeedMultiplier * delta * 60;
    }
  });

  const handleClick = useCallback(
    (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation();
      onClick(planet);
    },
    [onClick, planet]
  );

  const handlePointerOver = useCallback(
    (e: ThreeEvent<PointerEvent>) => {
      e.stopPropagation();
      setHovered(true);
      onHover(planet);
    },
    [onHover, planet]
  );

  const handlePointerOut = useCallback(() => {
    setHovered(false);
    onHover(null);
  }, [onHover]);

  const tiltRad = (planet.tiltDegrees * Math.PI) / 180;

  return (
    <>
      <OrbitLine radius={planet.position} />

      <group ref={orbitGroupRef}>
        <group position={[planet.position, 0, 0]}>
          <mesh
            ref={planetRef}
            rotation={[0, 0, tiltRad]}
            onClick={handleClick}
            onPointerOver={handlePointerOver}
            onPointerOut={handlePointerOut}
            castShadow
            receiveShadow
          >
            <sphereGeometry args={[planet.size, 64, 32]} />
            {planet.bumpMap ? (
              <meshPhongMaterial
                map={texture}
                bumpMap={bumpTexture}
                bumpScale={0.5}
              />
            ) : (
              <meshPhongMaterial map={texture} />
            )}
          </mesh>

          {hovered && (
            <group rotation={[0, 0, tiltRad]}>
              <mesh>
                <sphereGeometry args={[planet.size + 0.3, 32, 16]} />
                <meshBasicMaterial
                  color={planet.color}
                  transparent
                  opacity={0.12}
                  depthTest={false}
                />
              </mesh>
              <mesh>
                <sphereGeometry args={[planet.size + 0.6, 32, 16]} />
                <meshBasicMaterial
                  color="white"
                  transparent
                  opacity={0.05}
                  side={THREE.BackSide}
                  depthWrite={false}
                />
              </mesh>
            </group>
          )}

          {planet.hasAtmosphere && planet.atmosphereTexture && (
            <PlanetAtmosphere
              texturePath={planet.atmosphereTexture}
              size={planet.size}
            />
          )}

          {planet.ringTexture &&
            planet.ringInnerRadius &&
            planet.ringOuterRadius && (
              <PlanetRing
                texturePath={planet.ringTexture}
                innerRadius={planet.ringInnerRadius}
                outerRadius={planet.ringOuterRadius}
                tiltRad={tiltRad}
              />
            )}

          {planet.name === "Earth" && (
            <EarthMoon parentSize={planet.size} />
          )}

          {hovered && (
            <Html
              center
              position={[0, planet.size + 2.5, 0]}
              distanceFactor={60}
              style={{ pointerEvents: "none" }}
            >
              <div
                style={{
                  background: "rgba(0,0,0,0.8)",
                  color: "white",
                  padding: "5px 14px",
                  borderRadius: "8px",
                  fontSize: "13px",
                  fontWeight: 600,
                  whiteSpace: "nowrap",
                  border: `1.5px solid ${planet.color}`,
                  backdropFilter: "blur(8px)",
                  letterSpacing: "0.5px",
                  textShadow: `0 0 8px ${planet.color}66`,
                }}
              >
                {planet.name}
              </div>
            </Html>
          )}
        </group>
      </group>
    </>
  );
}

function OrbitLine({ radius }: { radius: number }) {
  const points = useMemo(() => {
    const pts: [number, number, number][] = [];
    const segments = 256;
    for (let i = 0; i <= segments; i++) {
      const angle = (i / segments) * Math.PI * 2;
      pts.push([Math.cos(angle) * radius, 0, Math.sin(angle) * radius]);
    }
    return pts;
  }, [radius]);

  return (
    <Line
      points={points}
      color="#4488ff"
      lineWidth={0.5}
      transparent
      opacity={0.08}
    />
  );
}

function CameraController({
  selectedPlanet,
  isOrbitPaused,
  onArrival,
}: {
  selectedPlanet: PlanetInfo | null;
  isOrbitPaused: boolean;
  onArrival: () => void;
}) {
  const { camera } = useThree();
  const controlsRef = useRef<any>(null);
  const targetPos = useRef(new THREE.Vector3(-175, 115, 5));
  const lookTarget = useRef(new THREE.Vector3(0, 0, 0));
  const isAnimating = useRef(false);
  const arrivalCalled = useRef(false);

  useEffect(() => {
    if (selectedPlanet) {
      arrivalCalled.current = false;
      const isSun = selectedPlanet.name === "The Sun";
      const offset = isSun
        ? selectedPlanet.size * 1.5 + 10
        : selectedPlanet.size * 2.5 + 6;
      const planetWorldPos = new THREE.Vector3(selectedPlanet.position, 0, 0);
      targetPos.current.copy(
        planetWorldPos
          .clone()
          .add(new THREE.Vector3(offset * 0.6, offset * 0.5, offset * 0.8))
      );
      lookTarget.current.copy(planetWorldPos);
      isAnimating.current = true;
    } else {
      targetPos.current.set(-175, 115, 5);
      lookTarget.current.set(0, 0, 0);
      isAnimating.current = true;
    }
  }, [selectedPlanet]);

  useFrame(() => {
    if (isAnimating.current) {
      camera.position.lerp(targetPos.current, 0.04);
      if (controlsRef.current?.target) {
        controlsRef.current.target.lerp(lookTarget.current, 0.04);
      }
      if (camera.position.distanceTo(targetPos.current) < 0.5) {
        isAnimating.current = false;
        if (selectedPlanet && !arrivalCalled.current) {
          arrivalCalled.current = true;
          onArrival();
        }
      }
    }
  });

  return (
    <OrbitControls
      ref={controlsRef}
      enableDamping
      dampingFactor={0.08}
      minDistance={0.5}
      maxDistance={800}
      enablePan={true}
      zoomSpeed={1.2}
      rotateSpeed={0.6}
      panSpeed={0.8}
    />
  );
}

function AsteroidBelt({
  minRadius,
  maxRadius,
  count,
  speed,
}: {
  minRadius: number;
  maxRadius: number;
  count: number;
  speed: number;
}) {
  const meshRef = useRef<THREE.InstancedMesh>(null);

  const asteroidInitData = useMemo(() => {
    const data: { radius: number; y: number; scale: number; rotSpeed: number; initAngle: number }[] = [];
    for (let i = 0; i < count; i++) {
      data.push({
        initAngle: Math.random() * Math.PI * 2,
        radius: minRadius + Math.random() * (maxRadius - minRadius),
        y: (Math.random() - 0.5) * 4,
        scale: 0.2 + Math.random() * 0.6,
        rotSpeed: speed * (0.8 + Math.random() * 0.4),
      });
    }
    return data;
  }, [minRadius, maxRadius, count, speed]);

  const anglesRef = useRef<Float64Array | null>(null);

  useEffect(() => {
    anglesRef.current = new Float64Array(count);
    for (let i = 0; i < count; i++) {
      anglesRef.current[i] = asteroidInitData[i].initAngle;
    }

    if (!meshRef.current) return;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const a = asteroidInitData[i];
      const angle = anglesRef.current[i];
      dummy.position.set(
        Math.cos(angle) * a.radius,
        a.y,
        Math.sin(angle) * a.radius
      );
      dummy.scale.setScalar(a.scale);
      dummy.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  }, [asteroidInitData, count]);

  useFrame((_, delta) => {
    if (!meshRef.current || !anglesRef.current) return;
    const angles = anglesRef.current;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < asteroidInitData.length; i++) {
      const a = asteroidInitData[i];
      angles[i] += a.rotSpeed * delta;
      dummy.position.set(
        Math.cos(angles[i]) * a.radius,
        a.y,
        Math.sin(angles[i]) * a.radius
      );
      dummy.scale.setScalar(a.scale);
      dummy.rotation.y += 0.001 * delta;
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <dodecahedronGeometry args={[1, 0]} />
      <meshStandardMaterial
        color="#B8A88A"
        roughness={0.9}
        metalness={0.15}
        emissive="#554433"
        emissiveIntensity={0.08}
      />
    </instancedMesh>
  );
}

function StarField() {
  return (
    <>
      <Stars
        radius={500}
        depth={150}
        count={10000}
        factor={6}
        saturation={0.1}
        fade
        speed={0.3}
      />
    </>
  );
}

function Scene({
  onPlanetClick,
  onPlanetHover,
  onSunClick,
  onSunHover,
  selectedPlanet,
  onCameraArrival,
  orbitSpeed,
  rotationSpeed,
  sunIntensity,
  isOrbitPaused,
}: {
  onPlanetClick: (planet: PlanetInfo) => void;
  onPlanetHover: (planet: PlanetInfo | null) => void;
  onSunClick: (sun: PlanetInfo) => void;
  onSunHover: (body: PlanetInfo | null) => void;
  selectedPlanet: PlanetInfo | null;
  onCameraArrival: () => void;
  orbitSpeed: number;
  rotationSpeed: number;
  sunIntensity: number;
  isOrbitPaused: boolean;
}) {
  return (
    <>
      <ambientLight intensity={0.06} />

      <Sun sunIntensity={sunIntensity} onClick={onSunClick} onHover={onSunHover} />

      <StarField />

      {PLANETS.map((planet) => (
        <Planet
          key={planet.name}
          planet={planet}
          orbitSpeedMultiplier={orbitSpeed}
          rotationSpeedMultiplier={rotationSpeed}
          isOrbitPaused={isOrbitPaused}
          onClick={onPlanetClick}
          onHover={onPlanetHover}
        />
      ))}

      <AsteroidBelt
        minRadius={130}
        maxRadius={170}
        count={800}
        speed={0.0001}
      />

      <AsteroidBelt
        minRadius={355}
        maxRadius={395}
        count={1200}
        speed={0.00003}
      />

      <CameraController
        selectedPlanet={selectedPlanet}
        isOrbitPaused={isOrbitPaused}
        onArrival={onCameraArrival}
      />

      <EffectComposer>
        <Bloom
          intensity={1.0}
          luminanceThreshold={0.5}
          luminanceSmoothing={0.9}
          radius={0.8}
        />
      </EffectComposer>
    </>
  );
}

export default function SolarSystem({
  onPlanetClick,
  onPlanetHover,
  onSunClick,
  onSunHover,
  selectedPlanet,
  onCameraArrival,
  orbitSpeed,
  rotationSpeed,
  sunIntensity,
  isOrbitPaused,
}: {
  onPlanetClick: (planet: PlanetInfo) => void;
  onPlanetHover: (planet: PlanetInfo | null) => void;
  onSunClick: (sun: PlanetInfo) => void;
  onSunHover: (body: PlanetInfo | null) => void;
  selectedPlanet: PlanetInfo | null;
  onCameraArrival: () => void;
  orbitSpeed: number;
  rotationSpeed: number;
  sunIntensity: number;
  isOrbitPaused: boolean;
}) {
  return (
    <Canvas
      camera={{
        fov: 45,
        near: 0.01,
        far: 3000,
        position: [-175, 115, 5],
      }}
      style={{ width: "100%", height: "100%" }}
      gl={{
        antialias: true,
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1,
        powerPreference: "high-performance",
      }}
      shadows
      dpr={[1, 2]}
    >
      <Scene
        onPlanetClick={onPlanetClick}
        onPlanetHover={onPlanetHover}
        onSunClick={onSunClick}
        onSunHover={onSunHover}
        selectedPlanet={selectedPlanet}
        onCameraArrival={onCameraArrival}
        orbitSpeed={orbitSpeed}
        rotationSpeed={rotationSpeed}
        sunIntensity={sunIntensity}
        isOrbitPaused={isOrbitPaused}
      />
    </Canvas>
  );
}
