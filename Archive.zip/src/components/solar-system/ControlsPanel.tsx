"use client";

import { Slider } from "@/components/ui/slider";
import {
  RotateCw,
  Orbit,
  Sun,
  Home,
} from "lucide-react";

interface ControlsPanelProps {
  orbitSpeed: number;
  rotationSpeed: number;
  sunIntensity: number;
  onOrbitSpeedChange: (value: number) => void;
  onRotationSpeedChange: (value: number) => void;
  onSunIntensityChange: (value: number) => void;
  onReset: () => void;
}

export default function ControlsPanel({
  orbitSpeed,
  rotationSpeed,
  sunIntensity,
  onOrbitSpeedChange,
  onRotationSpeedChange,
  onSunIntensityChange,
  onReset,
}: ControlsPanelProps) {
  return (
    <div className="absolute bottom-14 sm:bottom-16 right-2 sm:right-4 z-40">
      <div className="space-y-2.5">
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs">
              <Orbit size={12} />
              <span>Orbit Speed</span>
            </div>
            <span className="text-white/20 text-[10px] sm:text-xs font-mono">
              {orbitSpeed.toFixed(1)}x
            </span>
          </div>
          <Slider
            value={[orbitSpeed]}
            onValueChange={([v]) => onOrbitSpeedChange(v)}
            min={0}
            max={5}
            step={0.1}
            className="w-[140px] sm:w-[180px]"
          />
        </div>

        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs">
              <RotateCw size={12} />
              <span>Rotation Speed</span>
            </div>
            <span className="text-white/20 text-[10px] sm:text-xs font-mono">
              {rotationSpeed.toFixed(1)}x
            </span>
          </div>
          <Slider
            value={[rotationSpeed]}
            onValueChange={([v]) => onRotationSpeedChange(v)}
            min={0}
            max={5}
            step={0.1}
            className="w-[140px] sm:w-[180px]"
          />
        </div>

        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs">
              <Sun size={12} />
              <span>Sun Glow</span>
            </div>
            <span className="text-white/20 text-[10px] sm:text-xs font-mono">
              {sunIntensity.toFixed(1)}
            </span>
          </div>
          <Slider
            value={[sunIntensity]}
            onValueChange={([v]) => onSunIntensityChange(v)}
            min={0.5}
            max={10}
            step={0.1}
            className="w-[140px] sm:w-[180px]"
          />
        </div>

        <button
          onClick={onReset}
          className="flex items-center gap-2 text-white/30 text-[10px] sm:text-xs hover:text-white/60 transition-colors cursor-pointer"
        >
          <Home size={12} />
          <span>Reset View</span>
        </button>
      </div>
    </div>
  );
}
