"use client";

import { PlanetInfo } from "@/lib/planet-data";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Volume2,
  VolumeX,
  X,
  Globe,
  Thermometer,
  Weight,
  Moon,
  Wind,
  RotateCw,
  Orbit,
  Ruler,
  Sparkles,
  Info,
} from "lucide-react";

interface PlanetInfoPanelProps {
  planet: PlanetInfo | null;
  onClose: () => void;
  isSpeaking: boolean;
  onSpeak: (text: string) => void;
  onStopSpeaking: () => void;
}

export default function PlanetInfoPanel({
  planet,
  onClose,
  isSpeaking,
  onSpeak,
  onStopSpeaking,
}: PlanetInfoPanelProps) {
  if (!planet) return null;

  const handleSpeakToggle = () => {
    if (isSpeaking) {
      onStopSpeaking();
    } else {
      const fullText = `${planet.name}. ${planet.description} ${planet.funFact ? `Fun fact: ${planet.funFact}` : ""}`;
      onSpeak(fullText);
    }
  };

  return (
    <div className="fixed left-2 sm:left-4 top-1/2 -translate-y-1/2 z-50 w-[calc(100%-1rem)] sm:w-[380px] max-h-[80vh] animate-in slide-in-from-left duration-500">
      <Card
        className="border-0 shadow-2xl overflow-hidden"
        style={{
          background: `linear-gradient(135deg, rgba(0,0,20,0.92) 0%, rgba(10,5,30,0.95) 50%, rgba(0,0,20,0.92) 100%)`,
          borderColor: planet.color,
          borderWidth: "1px",
          borderStyle: "solid",
          boxShadow: `0 0 30px ${planet.color}33, 0 0 60px ${planet.color}11, inset 0 0 30px ${planet.color}08`,
        }}
      >
        <CardHeader className="pb-3 relative">
          <button
            onClick={onClose}
            className="absolute right-3 top-3 w-8 h-8 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors text-white/70 hover:text-white"
          >
            <X size={16} />
          </button>

          <div className="flex items-center gap-3 pr-10">
            <div
              className="w-4 h-4 rounded-full flex-shrink-0"
              style={{
                background: planet.color,
                boxShadow: `0 0 12px ${planet.color}`,
              }}
            />
            <CardTitle
              className="text-xl sm:text-2xl font-bold text-white tracking-wide"
              style={{ color: planet.color }}
            >
              {planet.name}
            </CardTitle>
          </div>

          <div className="flex items-center gap-2 mt-2">
            <Badge
              variant="outline"
              className="text-xs border-white/20 text-white/70"
            >
              {planet.type}
            </Badge>
          </div>

          <div className="mt-3">
            <Button
              onClick={handleSpeakToggle}
              size="sm"
              className="w-full gap-2 text-sm font-medium"
              style={{
                background: isSpeaking
                  ? "rgba(239, 68, 68, 0.2)"
                  : `rgba(${hexToRgb(planet.color)}, 0.2)`,
                borderColor: isSpeaking
                  ? "rgba(239, 68, 68, 0.5)"
                  : `${planet.color}66`,
                borderWidth: "1px",
                color: isSpeaking ? "#ef4444" : planet.color,
              }}
              variant="outline"
            >
              {isSpeaking ? (
                <>
                  <VolumeX size={16} className="animate-pulse" />
                  Stop Reading
                </>
              ) : (
                <>
                  <Volume2 size={16} />
                  Read Aloud
                </>
              )}
            </Button>
          </div>
        </CardHeader>

        <CardContent className="pt-0 pb-4 max-h-[50vh] overflow-y-auto custom-scrollbar">
          <div className="mb-4 p-3 rounded-lg bg-white/5 border border-white/10">
            <p className="text-white/85 text-sm leading-relaxed">
              {planet.description}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-4">
            <StatItem
              icon={<Ruler size={14} />}
              label="Radius"
              value={planet.radius}
              color={planet.color}
            />
            <StatItem
              icon={<Globe size={14} />}
              label="Distance"
              value={planet.distance}
              color={planet.color}
            />
            <StatItem
              icon={<RotateCw size={14} />}
              label="Rotation"
              value={planet.rotation}
              color={planet.color}
            />
            <StatItem
              icon={<Orbit size={14} />}
              label="Orbit"
              value={planet.orbit}
              color={planet.color}
            />
            <StatItem
              icon={<Thermometer size={14} />}
              label="Temperature"
              value={planet.temperature}
              color={planet.color}
            />
            <StatItem
              icon={<Weight size={14} />}
              label="Gravity"
              value={planet.gravity}
              color={planet.color}
            />
            <StatItem
              icon={<Moon size={14} />}
              label="Moons"
              value={planet.moons}
              color={planet.color}
            />
            <StatItem
              icon={<Wind size={14} />}
              label="Tilt"
              value={planet.tilt}
              color={planet.color}
            />
          </div>

          <div className="mb-3 p-3 rounded-lg bg-white/5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <Wind size={14} style={{ color: planet.color }} />
              <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                Atmosphere
              </span>
            </div>
            <p className="text-white/80 text-xs">{planet.atmosphere}</p>
          </div>

          <div className="mb-3 p-3 rounded-lg bg-white/5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <Weight size={14} style={{ color: planet.color }} />
              <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                Mass
              </span>
            </div>
            <p className="text-white/80 text-xs">{planet.mass}</p>
          </div>

          {planet.funFact && (
            <div
              className="p-3 rounded-lg border"
              style={{
                background: `rgba(${hexToRgb(planet.color)}, 0.08)`,
                borderColor: `${planet.color}33`,
              }}
            >
              <div className="flex items-center gap-2 mb-1">
                <Sparkles size={14} style={{ color: planet.color }} />
                <span
                  className="text-xs font-semibold uppercase tracking-wider"
                  style={{ color: planet.color }}
                >
                  Fun Fact
                </span>
              </div>
              <p className="text-white/85 text-xs leading-relaxed">
                {planet.funFact}
              </p>
            </div>
          )}

          <div className="mt-3 p-3 rounded-lg bg-white/5 border border-white/10">
            <div className="flex items-center gap-2 mb-1">
              <Info size={14} style={{ color: planet.color }} />
              <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                Discovered By
              </span>
            </div>
            <p className="text-white/80 text-xs">{planet.discoveredBy}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatItem({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className="p-2 rounded-lg bg-white/5 border border-white/8">
      <div className="flex items-center gap-1.5 mb-0.5">
        <span style={{ color }}>{icon}</span>
        <span className="text-[10px] font-semibold text-white/50 uppercase tracking-wider">
          {label}
        </span>
      </div>
      <p className="text-white/80 text-xs font-medium truncate" title={value}>
        {value}
      </p>
    </div>
  );
}

function hexToRgb(hex: string): string {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (result) {
    return `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`;
  }
  return "255, 255, 255";
}
