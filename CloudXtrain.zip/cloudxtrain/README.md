# ☁️ CloudXtrain

<div align="center">

**A realistic 3D cloud engineering simulator where you learn AWS by actually solving problems.**

[![Next.js](https://img.shields.io/badge/Next.js-16-black?logo=next.js&logoColor=white)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19-61dafb?logo=react&logoColor=white)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178c6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Three.js](https://img.shields.io/badge/Three.js-R3F-000000?logo=three.js&logoColor=white)](https://threejs.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-06b6d4?logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

*Don't read about AWS. Build it. Debug it. Master it.*

</div>

---

## 📖 Table of Contents

- [Overview](#-overview)
- [The Story](#-the-story)
- [Gameplay Loop](#-gameplay-loop)
- [Features](#-features)
- [3D Engine](#-3d-engine)
- [AWS Services Simulated](#-aws-services-simulated)
- [Missions & Chapters](#-missions--chapters)
- [Scoring & Progression](#-scoring--progression)
- [Tech Stack](#-tech-stack)
- [Getting Started](#-getting-started)
- [Project Structure](#-project-structure)
- [How It Works](#-how-it-works)
- [Accessibility](#-accessibility)
- [Roadmap](#-roadmap)
- [Contributing](#-contributing)
- [License](#-license)
- [Author](#-author)

---

## 🎯 Overview

**CloudXtrain** is a modern 3D strategy/simulation game that teaches AWS cloud engineering through realistic problem-solving gameplay. Instead of reading documentation or answering quiz questions, you step into the shoes of a junior cloud engineer at fictional tech companies and solve real infrastructure challenges.

You don't memorize service names. You **discover** them. You don't read about IAM roles. You **configure** them. You don't watch videos about VPCs. You **build** one, watch traffic flow through it, and debug it when something breaks.

> **Philosophy:** Give the player a problem → let them experiment → teach concepts when needed → let them build → simulate the result → create consequences → let them troubleshoot → reward mastery.

---

## 🎮 The Story

You join a series of fictional companies as a junior cloud engineer. Your mentors are 8 fictional characters with distinct personalities:

| Avatar | Character | Role |
|:------:|-----------|-----|
| 👩‍💼 | Priya Nair | CTO |
| 👨‍💻 | Marcus Chen | Senior Cloud Engineer |
| 👩‍🔧 | Aisha Rahman | DevOps Engineer |
| 🕵️ | Diego Park | Security Engineer |
| 👩‍🔬 | Sara Kim | Lead Developer |
| 📋 | Jordan Wells | Product Manager |
| 🧭 | Leo Nakamura | SRE |
| 👩‍🍳 | Rosa Ortiz | Database Engineer |

They send you missions. Each mission has a real business problem, a budget, a set of constraints, and a reward in XP. You design the architecture, deploy it, and watch the simulation play out.

---

## 🔁 Gameplay Loop

Every mission follows the same addictive loop:

```
Mission Briefing (one-liner + visual chips)
        ↓
Explore available AWS services (palette)
        ↓
Drag resources into the 3D canvas
        ↓
Connect them and configure
        ↓
Press DEPLOY
        ↓
Simulation runs (3D traffic flows)
        ↓
Resources turn green (healthy) or red (issues)
        ↓
Toast notifications tell you what happened
        ↓
Investigate (Logs, Metrics, Events panels)
        ↓
Fix and re-deploy
        ↓
Objectives complete = Mission Complete modal
        ↓
Earn stars, XP, badges, mastery
        ↓
Unlock next mission
```

---

## ✨ Features

### 🎨 Visual & 3D
- **Real 3D game simulation** built with `react-three-fiber` and `three.js`
- **3D resource meshes** with metallic materials, emissive glow, cast shadows, and float animations
- **3D connection curves** (quadratic bezier) arcing between resources
- **3D traffic packets** flowing along curves in real-time (green for success, red for errors)
- **Orbit camera controls** with constrained rotation and zoom
- **Glassmorphism panels** with backdrop blur and saturate
- **Aurora gradient backgrounds** with radial glows
- **Dust particle field** in the hero (Three.js Sparkles)

### 🎮 Game Mechanics
- **20 hand-crafted missions** across 4 chapters
- **Drag-and-drop resource placement** in 3D space
- **Click-to-connect** resources (Zap button + click target)
- **Real-time simulation engine** that evaluates your architecture
- **6-category score breakdown** (Architecture, Security, Availability, Performance, Cost, Monitoring)
- **1-3 star ratings** based on total score
- **XP system** with 7 ranks (Cloud Beginner → Cloud Master)
- **12 achievement badges**
- **Per-service mastery tracking** (0-100%)

### 📊 Simulation Engine
A pure-function rule engine that evaluates your architecture:
- Detects missing security groups on EC2
- Flags public S3 buckets as security risks
- Identifies publicly accessible RDS (major violation)
- Validates IAM least-privilege (warns on `*` permissions)
- Checks load balancer health checks
- Verifies VPC + Internet Gateway + Subnet topology
- Generates simulated metrics (CPU, latency, errors, connections)
- Produces realistic logs per resource

### 💬 Visual Feedback (No Walls of Text)
- **Toast notifications** on every deploy (errors, successes, objective completions)
- **Animated objective checklist** with spring-bounce checkmarks
- **Color-coded resource states** (green/amber/red)
- **Health bars** on every resource
- **Pulsing dots** for live status
- **Mission Complete modal** with stars, score bars, and concepts learned
- **Compact service cards** (game-item style, not textbook)

### 📱 Responsive & Accessible
- Fully responsive on mobile, tablet, and desktop
- Sticky footer with copyright
- Keyboard navigation support
- Reduced-motion mode (in settings)
- ARIA labels on interactive elements
- High-contrast typography

---

## 🧊 3D Engine

CloudXtrain uses [`@react-three/fiber`](https://github.com/pmndrs/react-three-fiber) (React renderer for Three.js) and [`@react-three/drei`](https://github.com/pmndrs/drei) (helpers).

### The 3D Canvas
- **`<Canvas>`** with shadows, antialiased rendering, alpha background
- **Lighting**: ambient + directional (with shadow map) + 2 colored point lights (amber + emerald)
- **Ground plane**: dark, slightly transparent, metalness 0.4
- **Grid helper** for spatial reference
- **OrbitControls** with constrained polar angle (no going below ground), no panning, damping enabled

### Resource Meshes
Each AWS resource on the canvas is a 3D object:
- **`<RoundedBox>`** from drei (rounded corners, smooth normals)
- **MeshStandardMaterial** with the service's color, emissive glow (intensified on hover/select), metalness 0.65, roughness 0.22, clearcoat
- **Float animation** via `useFrame` (sin-based vertical bob + slow Y rotation)
- **Drag in 3D** using raycasting onto a horizontal plane
- **Html label** (drei) floating above each resource showing icon, name, state, health bar
- **State ring** at the base (green/amber/red ringGeometry)

### Connection Curves & Traffic
- **`THREE.QuadraticBezierCurve3`** with arc upward (proportional to distance)
- **`<Line>`** from drei (dashed before deploy, solid after)
- **Moving packets**: 3D spheres with strong emissive, animated along curve via `curve.getPointAt(t)` in `useFrame`
- **Error packets** are larger and faster than success packets

---

## ☁️ AWS Services Simulated

CloudXtrain simulates 24 AWS services with full plain-English learning content:

### Compute
- **EC2 Instance** - Virtual computers in the cloud

### Storage
- **S3 Bucket** - Highly durable object storage

### Database
- **RDS Database** - Managed relational database
- **DynamoDB Table** - Serverless NoSQL database

### Networking
- **VPC** - Your private network in AWS
- **Public Subnet** - Internet-reachable subnet
- **Private Subnet** - Isolated subnet for sensitive workloads
- **Internet Gateway** - Door to the public internet
- **NAT Gateway** - Outbound internet for private subnets
- **Route 53** - DNS service
- **CloudFront** - CDN
- **Load Balancer** - Traffic distribution

### Security
- **Security Group** - Virtual firewall
- **IAM Role** - Permission set for services
- **IAM Policy** - JSON permission document
- **KMS Key** - Encryption key management
- **WAF** - Web Application Firewall

### Serverless
- **Lambda Function** - Serverless code execution
- **API Gateway** - HTTP API front door
- **SQS Queue** - Message queue
- **SNS Topic** - Pub/sub messaging

### Monitoring
- **CloudWatch** - Metrics and logs
- **CloudWatch Alarm** - Threshold alerts

### User
- **End User** - The visitor at the top of every architecture

Each service has a **quick-reference card** (game-item style) with: icon, one-line summary, plain-English analogy, use case chips, common mistakes (with red warning icons), and connection chips to related services.

---

## 🗺️ Missions & Chapters

The campaign contains **20 missions** across **4 chapters**:

### Chapter 1: Welcome to Cloud (Missions 1-5)
1. What Is the Cloud?
2. Launch Your First EC2
3. Make the Web Server Reachable (Route 53)
4. Lock the Front Door (Security Groups)
5. Store Files in S3

### Chapter 2: Building Applications (Missions 6-10)
6. Fix an S3 Permission Problem (IAM)
7. Introduce IAM (Lambda + S3)
8. Give EC2 Controlled S3 Access
9. Create a VPC
10. Public vs Private Subnets

### Chapter 3: Going Serverless (Missions 11-15)
11. Deploy EC2 Into a VPC
12. Connect EC2 to RDS
13. Fix a Database Connectivity Incident
14. Add a Load Balancer
15. Handle an Unhealthy EC2

### Chapter 4: Production (Missions 16-20)
16. Introduce CloudWatch
17. Investigate a CPU Incident
18. Create a Lambda Function
19. Connect S3 to Lambda (full pipeline)
20. **Capstone: Build a Production App** (tie everything together)

---

## 🏆 Scoring & Progression

### Score (per mission)
Six categories, each scored 0-100:
| Category | What it measures |
|----------|-----------------|
| **Architecture** | Required services present, connections correct |
| **Security** | Least privilege, no public DBs, no SSH open |
| **Availability** | Multi-instance, LB has healthy targets |
| **Performance** | Scaled, low latency, CDN |
| **Cost** | Under budget, no unused resources |
| **Monitoring** | CloudWatch + Alarms present |

**Total** is a weighted average. **Stars**: 1 star (≥50%), 2 stars (≥65%), 3 stars (≥85%).

### Ranks (7 tiers)
| Rank | XP Required |
|------|-------------|
| 🌱 Cloud Beginner | 0 |
| 🧭 Cloud Explorer | 250 |
| 🛠️ Cloud Builder | 700 |
| ⚙️ Cloud Engineer | 1,400 |
| 🏛️ Cloud Architect | 2,500 |
| 🧯 Senior Cloud Engineer | 4,000 |
| 👑 Cloud Master | 6,500 |

### Badges (12 achievements)
🚀 First Deployment · 🔐 IAM Apprentice · 🪣 S3 Explorer · 🖥️ EC2 Operator · 🌐 Network Engineer · 🗄️ Database Builder · ⚡ Serverless Engineer · 📊 Observability Expert · 🚨 Incident Responder · 🛡️ Security Guardian · 💰 Cost Optimizer · 🏗️ Architecture Master

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Framework** | [Next.js 16](https://nextjs.org/) (App Router, Turbopack) |
| **Language** | [TypeScript 5](https://www.typescriptlang.org/) |
| **3D Engine** | [Three.js](https://threejs.org/) + [@react-three/fiber](https://github.com/pmndrs/react-three-fiber) + [@react-three/drei](https://github.com/pmndrs/drei) |
| **Styling** | [Tailwind CSS 4](https://tailwindcss.com/) |
| **UI Components** | [shadcn/ui](https://ui.shadcn.com/) (New York style) |
| **Animations** | [Framer Motion](https://www.framer.com/motion/) |
| **State Management** | [Zustand 5](https://github.com/pmndrs/zustand) + localStorage persistence |
| **Icons** | [Lucide React](https://lucide.dev/) |
| **Toasts** | [Sonner](https://sonner.emilkowal.ski/) |
| **Fonts** | [Geist](https://vercel.com/font) (Sans + Mono) |

---

## 🚀 Getting Started

### Prerequisites

- **Node.js 18+** (or [Bun](https://bun.sh/) 1.0+)
- Any modern browser with WebGL support

### Installation

```bash
# Clone the repository
git clone https://github.com/cloudxplorer/CloudXtrain
cd CloudXtrain

# Install dependencies (using bun — recommended)
bun install

# Or with npm
npm install

# Or with pnpm
pnpm install
```

### Running the Dev Server

```bash
# With bun
bun run dev

# Or with npm
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Production Build

```bash
bun run build
bun run start
```

### Lint

```bash
bun run lint
```

---

## 📁 Project Structure

```
cloudxtrain/
├── public/
│   ├── favicon.svg              # CloudXtrain cloud + train favicon
│   └── robots.txt
├── src/
│   ├── app/
│   │   ├── globals.css          # Theme, 3D styles, animations
│   │   ├── layout.tsx           # Root layout, fonts, metadata
│   │   └── page.tsx             # Home page (renders GameShell)
│   ├── components/
│   │   ├── game/                # CloudXtrain game components
│   │   │   ├── GameShell.tsx          # Root game shell + view router
│   │   │   ├── HUD.tsx                # Top bar (logo, rank, XP, settings)
│   │   │   ├── Footer.tsx             # Minimal centered copyright
│   │   │   ├── LandingView.tsx        # Hero, stats, campaign map, badges
│   │   │   ├── HeroScene3D.tsx        # Dust particles (Sparkles)
│   │   │   ├── MissionView.tsx        # Active mission + briefing + tools
│   │   │   ├── ArchitectureCanvas.tsx # 3D canvas + resource palette
│   │   │   ├── ResourceNode.tsx      # Resource config sheet
│   │   │   ├── ServiceCardModal.tsx   # Quick-reference service card
│   │   │   ├── MissionCompleteModal.tsx
│   │   │   ├── ProfileView.tsx        # Player profile + badges + mastery
│   │   │   └── ServicesView.tsx       # All AWS services browser
│   │   └── ui/                  # shadcn/ui components (15 used)
│   └── lib/
│       ├── game/                # Game logic (no UI)
│       │   ├── types.ts         # All TypeScript types
│       │   ├── services.ts      # 24 AWS service catalog
│       │   ├── missions.ts      # 20 missions, 8 characters, ranks, badges
│       │   ├── simulation.ts    # Pure-function simulation engine
│       │   └── store.ts         # Zustand store + persistence
│       └── utils.ts             # cn() helper
├── .gitignore
├── eslint.config.mjs
├── next.config.ts
├── package.json
├── postcss.config.mjs
├── README.md
└── tsconfig.json
```

---

## ⚙️ How It Works

### The Simulation Engine (`src/lib/game/simulation.ts`)

A pure function: `runSimulation(architecture, mission) → SimResult`

**Input**: The architecture (resources + connections) and the active mission.

**Output**:
- `issues`: SimIssue[] (with severity + category)
- `events`: GameEvent[] (timeline of what happened)
- `score`: MissionScore (6 categories + total)
- `satisfied`: Record<objectiveRuleId, boolean>
- `resources`: Updated resources with state, health, metrics, logs
- `totalCost`: Estimated monthly cost

The engine walks the resource graph, applies ~10 rule families, generates metrics per resource type (CPU for EC2, invocations for Lambda, etc.), and produces realistic logs.

### The Game Store (`src/lib/game/store.ts`)

[Zustand](https://github.com/pmndrs/zustand) store with `persist` middleware. Only **durable progress** is persisted to localStorage (player XP, completed missions, earned badges, service mastery, settings). Transient mission state (active architecture, events, score) is reset on reload.

### 3D Rendering (`src/components/game/ArchitectureCanvas.tsx`)

The 3D scene uses react-three-fiber's `<Canvas>` with:
- Custom drag implementation using raycasting onto a horizontal plane
- Html labels (drei) for resource info above each 3D mesh
- AnimateMotion-style 3D packets flowing along bezier curves

---

## ♿ Accessibility

- **Keyboard navigation** — all interactive elements focusable
- **ARIA labels** — buttons, tabs, dialogs labeled
- **Reduced motion mode** — toggle in settings to disable all animations
- **High-contrast colors** — text passes WCAG AA contrast on dark background
- **Color + icon redundancy** — states never indicated by color alone (always paired with an icon and label)
- **Screen reader friendly** — semantic HTML (`<header>`, `<main>`, `<nav>`, `<footer>`, `<dialog>`)

---

## 🗺️ Roadmap

- [ ] Sandbox mode (free-build with no mission constraints)
- [ ] "What If?" experiment mode (simulate failures, traffic spikes)
- [ ] Daily/weekly challenges
- [ ] More AWS services (ECS, Fargate, Step Functions, CloudFormation)
- [ ] Real AWS integration (optional, server-side, sandboxed)
- [ ] Multiplayer leaderboard
- [ ] Sound effects (toggleable)
- [ ] More chapters (Security, Incidents, Advanced Architecture)

---

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Adding a New Mission
1. Add the mission object to `src/lib/game/missions.ts` (follow the existing shape)
2. Add any new objective rules to `computeObjectives()` in `src/lib/game/simulation.ts`
3. Add any new rule checks to `evaluateRules()` in the same file
4. Test by playing through the mission

### Adding a New AWS Service
1. Add the service to `SERVICE_CATALOG` in `src/lib/game/services.ts`
2. Add the type to `ResourceTypeId` in `src/lib/game/types.ts`
3. Add default config in `defaultConfigFor()` in `src/lib/game/store.ts`
4. Add config UI in `ConfigFields` in `src/components/game/ResourceNode.tsx`

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

> AWS service names and concepts are property of Amazon Web Services, Inc. This project is an educational simulation and is not affiliated with or endorsed by AWS. All costs, metrics, and incidents are simulated for gameplay and are not real AWS billing data.

---

## 👩‍💻 Author

**Pallavi Thakur**

- Building CloudXtrain for future cloud engineers
- Copyright © 2026 CloudXtrain by Pallavi Thakur. All Rights Reserved.

---

<div align="center">

**Don't read about the cloud. Build it.**

⭐ If you like this project, please star it on GitHub! ⭐

</div>
