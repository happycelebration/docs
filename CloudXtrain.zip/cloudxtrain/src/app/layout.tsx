import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster as Sonner } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CloudXtrain",
  description:
    "Become a cloud engineer. Solve realistic AWS infrastructure problems, design architectures, debug incidents, and progress from Cloud Beginner to Cloud Master.",
  keywords: [
    "AWS",
    "Cloud Engineering",
    "Simulation Game",
    "EC2",
    "S3",
    "Lambda",
    "VPC",
    "IAM",
    "RDS",
    "CloudWatch",
  ],
  authors: [{ name: "Pallavi Thakur" }],
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/favicon.svg",
  },
  openGraph: {
    title: "CloudXtrain",
    description:
      "Learn AWS by actually solving problems. A modern 3D strategy/simulation game where you become a cloud engineer.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Sonner />
      </body>
    </html>
  );
}
