
export type ResourceTypeId =
  | "user"
  | "route53"
  | "cloudfront"
  | "loadbalancer"
  | "ec2"
  | "lambda"
  | "s3"
  | "rds"
  | "dynamodb"
  | "vpc"
  | "subnet-public"
  | "subnet-private"
  | "internet-gateway"
  | "nat-gateway"
  | "security-group"
  | "iam-role"
  | "iam-policy"
  | "cloudwatch"
  | "alarm"
  | "sqs"
  | "sns"
  | "apigateway"
  | "kms"
  | "waf";

export type ServiceCategory =
  | "compute"
  | "storage"
  | "database"
  | "networking"
  | "security"
  | "serverless"
  | "monitoring"
  | "analytics";

export interface ServiceCatalogEntry {
  id: ResourceTypeId;
  label: string;
  awsName: string; // official AWS name
  shortName: string; // short label
  category: ServiceCategory;
  color: string; // hex/hsl accent for the icon
  icon: string; // emoji or short tag for icon
  summary: string; // one-line plain-English description
  whatIsIt: string;
  whyItExists: string;
  analogy: string;
  useCases: string[];
  commonMistakes: string[];
  connectsTo: ResourceTypeId[];
  baseCost: number;
  placeable: boolean;
}

export type ResourceState =
  | "pending"
  | "running"
  | "available"
  | "healthy"
  | "unhealthy"
  | "stopping"
  | "stopped"
  | "terminated"
  | "failed"
  | "denied"
  | "timedout"
  | "ready";

export interface ResourceConfig {
  [key: string]: string | number | boolean;
}

export interface PlacedResource {
  id: string; // unique instance id on canvas
  type: ResourceTypeId;
  x: number;
  y: number;
  config: ResourceConfig;
  state: ResourceState;
  health: number; // 0-100
  metrics: Record<string, number>;
  logs: LogEntry[];
  connections: string[];
}

export interface LogEntry {
  ts: number;
  level: "info" | "warn" | "error" | "success";
  message: string;
}

export interface Architecture {
  resources: PlacedResource[];
  connections: { from: string; to: string; kind: string }[];
}

export type GameEventKind =
  | "resource-created"
  | "resource-configured"
  | "deployment-started"
  | "deployment-succeeded"
  | "deployment-failed"
  | "request-received"
  | "request-succeeded"
  | "request-failed"
  | "permission-denied"
  | "instance-unhealthy"
  | "alarm-triggered"
  | "traffic-spike"
  | "database-unavailable"
  | "lambda-invoked"
  | "lambda-succeeded"
  | "lambda-failed"
  | "s3-upload"
  | "info";

export interface GameEvent {
  id: string;
  ts: number;
  kind: GameEventKind;
  resourceId?: string;
  message: string;
  severity: "info" | "success" | "warn" | "error";
}

export interface MissionObjective {
  id: string;
  label: string;
  hint: string;
  rule: string;
}

export interface MissionHint {
  level: number;
  title: string;
  body: string;
}

export interface MissionCharacter {
  name: string;
  role: string;
  avatar: string; // emoji
  accent: string; // color hex
}

export interface Mission {
  id: string; // e.g. "m1"
  index: number; // 1..20
  chapter: number;
  chapterTitle: string;
  title: string;
  tagline: string;
  company: string;
  budget: number; // monthly USD
  difficulty: 1 | 2 | 3 | 4 | 5;
  character: MissionCharacter;
  briefing: string; // narrative intro
  problem: string; // business problem
  requirements: string[];
  constraints: string[];
  learningObjectives: string[];
  objectives: MissionObjective[];
  hints: MissionHint[];
  serviceIds: ResourceTypeId[];
  paletteIds: ResourceTypeId[];
  starter?: Architecture;
  concepts: { id: string; label: string }[]; // concepts mastered
  xpReward: number;
  scenario: "ecommerce" | "media" | "food" | "fintech" | "gaming" | "saas" | "health" | "education" | "general";
}

export interface MissionResult {
  missionId: string;
  completedAt: number;
  stars: 1 | 2 | 3;
  score: MissionScore;
  xpEarned: number;
  hintsUsed: number;
}

export interface MissionScore {
  architecture: number;
  security: number;
  availability: number;
  performance: number;
  cost: number;
  monitoring: number;
  total: number;
}

export interface Badge {
  id: string;
  name: string;
  emoji: string;
  description: string;
  criteria: string;
}

export interface Rank {
  id: string;
  title: string;
  minXp: number;
  emoji: string;
}

export interface SimIssue {
  resourceId?: string;
  resourceType?: ResourceTypeId;
  severity: "info" | "warn" | "error";
  rule: string;
  message: string;
  category: "architecture" | "security" | "availability" | "performance" | "cost" | "monitoring";
}
