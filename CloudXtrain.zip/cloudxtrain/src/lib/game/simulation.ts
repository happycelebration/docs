import type {
  Architecture,
  PlacedResource,
  ResourceTypeId,
  SimIssue,
  GameEvent,
  Mission,
  MissionScore,
  LogEntry,
  ResourceState,
} from "./types";
import { SERVICE_CATALOG } from "./services";


let _id = 0;
const uid = () => `evt-${Date.now()}-${_id++}`;
const now = () => Date.now();

export interface SimResult {
  issues: SimIssue[];
  events: GameEvent[];
  score: MissionScore;
  satisfied: Record<string, boolean>;
  resources: PlacedResource[];
  totalCost: number;
}

const byId = (arch: Architecture, id: string) => arch.resources.find((r) => r.id === id);
const byType = (arch: Architecture, t: ResourceTypeId) => arch.resources.filter((r) => r.type === t);
const has = (arch: Architecture, t: ResourceTypeId) => byType(arch, t).length > 0;
const hasN = (arch: Architecture, t: ResourceTypeId, n: number) => byType(arch, t).length >= n;

function isConnected(arch: Architecture, fromType: ResourceTypeId, toType: ResourceTypeId): boolean {
  const from = byType(arch, fromType);
  const to = byType(arch, toType);
  return arch.connections.some((c) => {
    const f = byId(arch, c.from);
    const t = byId(arch, c.to);
    return f && t && f.type === fromType && t.type === toType;
  });
}

function isReachable(arch: Architecture, fromType: ResourceTypeId, toType: ResourceTypeId): boolean {
  const start = byType(arch, fromType);
  if (start.length === 0) return false;
  const visited = new Set<string>();
  const queue = [...start.map((r) => r.id)];
  while (queue.length) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const r = byId(arch, id);
    if (!r) continue;
    if (r.type === toType && r.id !== start[0]?.id) return true;
    for (const c of arch.connections) {
      if (c.from === id) {
        const t = byId(arch, c.to);
        if (t && !visited.has(t.id)) queue.push(t.id);
      }
    }
    for (const tid of r.connections) {
      if (!visited.has(tid)) queue.push(tid);
    }
  }
  return false;
}

export function calcCost(arch: Architecture): number {
  return arch.resources.reduce((sum, r) => sum + (SERVICE_CATALOG[r.type]?.baseCost ?? 0), 0);
}

interface RuleCtx {
  arch: Architecture;
  mission: Mission;
  issues: SimIssue[];
  events: GameEvent[];
  logs: LogEntry[];
}

function issue(
  ctx: RuleCtx,
  category: SimIssue["category"],
  severity: SimIssue["severity"],
  rule: string,
  message: string,
  resourceId?: string,
  resourceType?: ResourceTypeId,
) {
  ctx.issues.push({ category, severity, rule, message, resourceId, resourceType });
}

function event(
  ctx: RuleCtx,
  kind: GameEvent["kind"],
  message: string,
  severity: GameEvent["severity"] = "info",
  resourceId?: string,
): GameEvent {
  const e: GameEvent = { id: uid(), ts: now(), kind, message, severity, resourceId };
  ctx.events.push(e);
  return e;
}

function log(ctx: RuleCtx, resourceId: string | undefined, level: LogEntry["level"], message: string) {
  ctx.logs.push({ ts: now(), level, message });
}

function evaluateRules(arch: Architecture, mission: Mission): SimResult {
  const ctx: RuleCtx = { arch, mission, issues: [], events: [], logs: [] };

  if (!has(arch, "user")) {
    issue(ctx, "architecture", "warn", "no-user", "No User on the canvas - who is sending traffic?");
  } else {
    event(ctx, "info", "User on canvas - visitors can reach out.");
  }

  const ec2s = byType(arch, "ec2");
  for (const ec2 of ec2s) {
    if (ec2.config.state !== "running") {
      issue(ctx, "availability", "error", "ec2-not-running", `EC2 ${ec2.id} is not in 'running' state.`, ec2.id, "ec2");
      event(ctx, "instance-unhealthy", `EC2 ${ec2.id} state: ${ec2.config.state}`, "warn", ec2.id);
    } else {
      event(ctx, "resource-configured", `EC2 ${ec2.id} is running.`, "success", ec2.id);
    }
    const sgConnected = arch.connections.some((c) => {
      const f = byId(arch, c.from);
      const t = byId(arch, c.to);
      return (f?.type === "security-group" && t?.id === ec2.id) || (t?.type === "security-group" && f?.id === ec2.id);
    });
    if (!sgConnected && ec2s.length > 0 && mission.index >= 4) {
      issue(ctx, "security", "error", "ec2-no-sg", `EC2 ${ec2.id} has no Security Group - every port is open.`, ec2.id, "ec2");
    }
  }

  const sgs = byType(arch, "security-group");
  for (const sg of sgs) {
    const port = sg.config.allowedPort ? String(sg.config.allowedPort) : "";
    const source = sg.config.source ? String(sg.config.source) : "0.0.0.0/0";
    if (port === "22" || port === "all" || port === "0-65535") {
      issue(ctx, "security", "error", "sg-ssh-open", `Security Group ${sg.id} allows SSH/all ports from ${source}.`, sg.id, "security-group");
      event(ctx, "permission-denied", `Security Group ${sg.id} is dangerously permissive.`, "error", sg.id);
    }
    const attached = arch.connections.some((c) => {
      const f = byId(arch, c.from);
      const t = byId(arch, c.to);
      return (f?.id === sg.id) || (t?.id === sg.id);
    });
    if (!attached) {
      issue(ctx, "security", "warn", "sg-unattached", `Security Group ${sg.id} is not attached to any resource.`, sg.id, "security-group");
    }
  }

  const rdsList = byType(arch, "rds");
  for (const rds of rdsList) {
    const pub = rds.config.publiclyAccessible === true || rds.config.publiclyAccessible === "true";
    if (pub) {
      issue(ctx, "security", "error", "rds-public", `RDS ${rds.id} is publicly accessible - major security risk.`, rds.id, "rds");
      event(ctx, "permission-denied", `RDS ${rds.id} is publicly accessible!`, "error", rds.id);
    }
    const inSubnet = arch.connections.some((c) => {
      const f = byId(arch, c.from);
      const t = byId(arch, c.to);
      return (f?.id === rds.id && t?.type === "subnet-private") || (t?.id === rds.id && f?.type === "subnet-private");
    });
    if (!inSubnet && mission.index >= 10) {
      issue(ctx, "security", "warn", "rds-no-private-subnet", `RDS ${rds.id} is not in a private subnet.`, rds.id, "rds");
    }
    if (!isReachable(arch, "ec2", "rds") && mission.index >= 12) {
      issue(ctx, "availability", "error", "ec2-cant-rds", `EC2 cannot reach RDS - check the security group and connection.`, undefined, "ec2");
      event(ctx, "database-unavailable", "EC2 cannot reach the database.", "error");
    } else if (has(arch, "ec2") && has(arch, "rds") && mission.index >= 12) {
      event(ctx, "request-succeeded", "EC2 → RDS query succeeded.", "success");
    }
  }

  const s3s = byType(arch, "s3");
  for (const s3 of s3s) {
    const pub = s3.config.public === true || s3.config.public === "true";
    if (pub) {
      issue(ctx, "security", "error", "s3-public", `S3 bucket ${s3.id} is public - data exposure risk.`, s3.id, "s3");
      event(ctx, "permission-denied", `S3 bucket ${s3.id} is publicly readable!`, "error", s3.id);
    } else {
      event(ctx, "s3-upload", `S3 bucket ${s3.id} is private.`, "info", s3.id);
    }
    if (mission.index === 6 || mission.index === 8) {
      const roleAttached = arch.connections.some((c) => {
        const f = byId(arch, c.from);
        const t = byId(arch, c.to);
        return (f?.type === "iam-role" && t?.type === "ec2") || (t?.type === "iam-role" && f?.type === "ec2");
      });
      if (!roleAttached) {
        issue(ctx, "security", "error", "ec2-no-role", `EC2 has no IAM role - S3 writes will fail with AccessDenied.`);
        event(ctx, "permission-denied", "EC2 → S3: AccessDenied (no role).", "error");
      } else {
        const policyOK = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "iam-policy" && t?.type === "iam-role") || (t?.type === "iam-policy" && f?.type === "iam-role");
        });
        if (!policyOK) {
          issue(ctx, "security", "error", "role-no-policy", `Role has no policy - no actual permissions granted.`);
          event(ctx, "permission-denied", "Role has no policy attached.", "error");
        }
      }
    }
  }

  const lambdas = byType(arch, "lambda");
  for (const lam of lambdas) {
    const roleAttached = arch.connections.some((c) => {
      const f = byId(arch, c.from);
      const t = byId(arch, c.to);
      return (f?.type === "iam-role" && t?.id === lam.id) || (t?.type === "iam-role" && f?.id === lam.id);
    });
    if (!roleAttached && (mission.index === 7 || mission.index === 18 || mission.index === 19)) {
      issue(ctx, "security", "error", "lambda-no-role", `Lambda ${lam.id} has no execution role - will fail with AccessDenied.`);
      event(ctx, "lambda-failed", `Lambda ${lam.id} failed: no execution role.`, "error", lam.id);
    } else if (roleAttached) {
      event(ctx, "lambda-invoked", `Lambda ${lam.id} invoked.`, "info", lam.id);
      const policyOK = arch.connections.some((c) => {
        const f = byId(arch, c.from);
        const t = byId(arch, c.to);
        return (f?.type === "iam-policy" && t?.type === "iam-role") || (t?.type === "iam-policy" && f?.type === "iam-role");
      });
      if (policyOK) {
        event(ctx, "lambda-succeeded", `Lambda ${lam.id} executed successfully.`, "success", lam.id);
      } else {
        issue(ctx, "security", "error", "lambda-role-no-policy", `Lambda role has no policy.`);
        event(ctx, "lambda-failed", `Lambda ${lam.id} failed: role has no policy.`, "error", lam.id);
      }
    }
  }

  const policies = byType(arch, "iam-policy");
  for (const p of policies) {
    const action = String(p.config.action ?? "");
    if (action === "*" || action === "*:*" || action.toLowerCase().includes("administrator")) {
      issue(ctx, "security", "error", "wildcard-policy", `Policy ${p.id} grants administrator access - violates least privilege.`, p.id, "iam-policy");
    }
  }

  if (has(arch, "vpc")) {
    if (!isReachable(arch, "vpc", "internet-gateway") && mission.index >= 9) {
      issue(ctx, "architecture", "warn", "vpc-no-igw", `VPC has no Internet Gateway attached.`);
    }
    if (mission.index >= 9 && !has(arch, "subnet-public") && !has(arch, "subnet-private")) {
      issue(ctx, "architecture", "warn", "vpc-no-subnets", `VPC has no subnets defined.`);
    }
  }

  const lbs = byType(arch, "loadbalancer");
  for (const lb of lbs) {
    const targets = arch.connections
      .filter((c) => {
        const f = byId(arch, c.from);
        return f?.id === lb.id;
      })
      .map((c) => byId(arch, c.to))
      .filter((t) => t && t.type === "ec2") as PlacedResource[];
    if (targets.length === 0) {
      issue(ctx, "availability", "error", "lb-no-targets", `Load Balancer ${lb.id} has no EC2 targets behind it.`);
      event(ctx, "request-failed", `Load Balancer ${lb.id} has no healthy targets - returning 502.`, "error", lb.id);
    } else {
      const healthy = targets.filter((t) => t.config.state === "running");
      if (healthy.length === 0) {
        issue(ctx, "availability", "error", "lb-no-healthy", `Load Balancer ${lb.id} has no healthy EC2 targets.`);
        event(ctx, "instance-unhealthy", `All targets behind ${lb.id} are unhealthy.`, "warn", lb.id);
      } else {
        event(ctx, "request-succeeded", `Load Balancer ${lb.id} routing to ${healthy.length}/${targets.length} healthy targets.`, "success", lb.id);
      }
    }
  }

  if (mission.index >= 16) {
    if (!has(arch, "cloudwatch")) {
      issue(ctx, "monitoring", "warn", "no-cloudwatch", `No CloudWatch - you're operating blind.`);
    }
    if (!has(arch, "alarm")) {
      issue(ctx, "monitoring", "warn", "no-alarm", `No CloudWatch alarms - incidents will go unnoticed.`);
    } else {
      event(ctx, "alarm-triggered", `Alarm armed and watching.`, "info");
    }
  }

  const score = computeScore(ctx, mission);

  const satisfied = computeObjectives(arch, mission, ctx);

  return {
    issues: ctx.issues,
    events: ctx.events,
    score,
    satisfied,
    resources: applySimToResources(arch, ctx),
    totalCost: calcCost(arch),
  };
}

function applySimToResources(arch: Architecture, ctx: RuleCtx): PlacedResource[] {
  return arch.resources.map((r) => {
    const myIssues = ctx.issues.filter((i) => i.resourceId === r.id);
    let state: ResourceState = r.state;
    let health = 100;
    if (myIssues.some((i) => i.severity === "error")) {
      health = 35;
      if (r.type === "ec2" && r.config.state !== "running") {
        state = "stopped";
      } else if (r.type === "lambda") {
        state = "failed";
      } else if (r.type === "rds") {
        state = "unhealthy";
      } else {
        state = "unhealthy";
      }
    } else if (myIssues.some((i) => i.severity === "warn")) {
      health = 70;
      state = r.type === "ec2" ? (r.config.state === "running" ? "running" : "stopped") : "running";
    } else {
      if (r.type === "ec2") state = r.config.state === "running" ? "running" : "stopped";
      else if (r.type === "s3") state = "available";
      else if (r.type === "rds") state = "available";
      else if (r.type === "lambda") state = "ready";
      else if (r.type === "vpc" || r.type.startsWith("subnet")) state = "available";
      else state = "running";
    }
    return {
      ...r,
      state,
      health,
      metrics: generateMetrics(r, ctx),
      logs: generateLogs(r, ctx),
      connections: arch.connections
        .filter((c) => c.from === r.id)
        .map((c) => c.to),
    };
  });
}

function generateMetrics(r: PlacedResource, ctx: RuleCtx): Record<string, number> {
  const m: Record<string, number> = {};
  const issueCount = ctx.issues.filter((i) => i.resourceId === r.id).length;
  switch (r.type) {
    case "ec2":
      m.CPUUtilization = r.state === "running" ? 30 + issueCount * 15 + Math.random() * 8 : 0;
      m.NetworkIn = r.state === "running" ? 1000 + Math.random() * 500 : 0;
      m.RequestCount = r.state === "running" ? 50 + Math.floor(Math.random() * 40) : 0;
      break;
    case "lambda":
      m.Invocations = 10 + Math.floor(Math.random() * 20);
      m.Errors = issueCount;
      m.Duration = 200 + Math.floor(Math.random() * 100);
      break;
    case "rds":
      m.CPU = 25 + Math.random() * 10;
      m.Connections = 10 + Math.floor(Math.random() * 10);
      m.Latency = 5 + Math.random() * 3 + issueCount * 5;
      break;
    case "loadbalancer":
      m.RequestCount = 200 + Math.floor(Math.random() * 100);
      m.Latency = 50 + Math.random() * 20 + issueCount * 30;
      m.TargetHealthy = 1;
      m.TargetUnhealthy = issueCount;
      break;
    case "s3":
      m.BucketSize = 1024 * 1024 * 100;
      m.RequestCount = 30 + Math.floor(Math.random() * 20);
      break;
    default:
      break;
  }
  return m;
}

function generateLogs(r: PlacedResource, ctx: RuleCtx): LogEntry[] {
  const logs: LogEntry[] = [];
  const myIssues = ctx.issues.filter((i) => i.resourceId === r.id);
  switch (r.type) {
    case "ec2":
      if (r.config.state === "running") {
        logs.push({ ts: now(), level: "info", message: "instance state: running" });
        logs.push({ ts: now(), level: "info", message: "nginx: started on port 80" });
      } else {
        logs.push({ ts: now(), level: "warn", message: `instance state: ${r.config.state ?? "pending"}` });
      }
      break;
    case "lambda":
      logs.push({ ts: now(), level: "info", message: "INIT START" });
      if (myIssues.some((i) => i.rule === "lambda-no-role" || i.rule === "lambda-role-no-policy")) {
        logs.push({ ts: now(), level: "error", message: "AccessDenied: missing IAM role or policy" });
      } else {
        logs.push({ ts: now(), level: "success", message: "Invocation succeeded (200ms)" });
      }
      break;
    case "rds":
      if (r.config.publiclyAccessible === true || r.config.publiclyAccessible === "true") {
        logs.push({ ts: now(), level: "warn", message: "PubliclyAccessible=true - security risk!" });
      } else {
        logs.push({ ts: now(), level: "info", message: "Connections accepted from app SG" });
      }
      break;
    case "s3":
      logs.push({ ts: now(), level: r.config.public ? "warn" : "info", message: `Bucket is ${r.config.public ? "PUBLIC" : "private"}` });
      break;
  }
  return logs;
}

function computeScore(ctx: RuleCtx, mission: Mission): MissionScore {
  const { arch } = ctx;
  const errors = ctx.issues.filter((i) => i.severity === "error");
  const warns = ctx.issues.filter((i) => i.severity === "warn");
  const cost = calcCost(arch);

  let archScore = 100;
  for (const sid of mission.serviceIds) {
    if (!has(arch, sid)) archScore -= 15;
  }
  archScore -= warns.length * 4;
  archScore -= errors.length * 8;

  let secScore = 100;
  const secErrors = errors.filter((i) => i.category === "security");
  const secWarns = warns.filter((i) => i.category === "security");
  secScore -= secErrors.length * 18;
  secScore -= secWarns.length * 6;
  if (has(arch, "iam-policy") && !errors.some((e) => e.rule === "wildcard-policy")) secScore = Math.min(100, secScore + 5);

  let availScore = 100;
  const availErrors = errors.filter((i) => i.category === "availability");
  availScore -= availErrors.length * 18;
  if (mission.index >= 14) {
    if (byType(arch, "ec2").length >= 2) availScore = Math.min(100, availScore + 5);
    else availScore -= 15;
  }

  let perfScore = 100;
  if (mission.index >= 14 && byType(arch, "ec2").length >= 2) perfScore = Math.min(100, perfScore + 5);
  if (has(arch, "cloudfront")) perfScore = Math.min(100, perfScore + 8);
  perfScore -= errors.length * 4;

  let costScore = 100;
  if (cost > mission.budget) {
    const over = (cost - mission.budget) / mission.budget;
    costScore -= Math.min(50, over * 100);
  }
  const unconnected = arch.resources.filter((r) => {
    return !arch.connections.some((c) => c.from === r.id || c.to === r.id);
  });
  costScore -= unconnected.length * 5;
  costScore = Math.max(0, costScore);

  let monScore = 100;
  if (mission.index >= 16) {
    if (!has(arch, "cloudwatch")) monScore -= 50;
    if (!has(arch, "alarm")) monScore -= 30;
  } else {
    monScore = has(arch, "cloudwatch") ? 100 : 75;
  }

  const total = Math.round(
    (archScore * 0.2 + secScore * 0.2 + availScore * 0.18 + perfScore * 0.15 + costScore * 0.15 + monScore * 0.12),
  );

  return {
    architecture: clamp(Math.round(archScore)),
    security: clamp(Math.round(secScore)),
    availability: clamp(Math.round(availScore)),
    performance: clamp(Math.round(perfScore)),
    cost: clamp(Math.round(costScore)),
    monitoring: clamp(Math.round(monScore)),
    total: clamp(total),
  };
}

function clamp(n: number): number {
  return Math.max(0, Math.min(100, n));
}

function computeObjectives(arch: Architecture, mission: Mission, ctx: RuleCtx): Record<string, boolean> {
  const out: Record<string, boolean> = {};
  const hasRule = (rule: string) => !ctx.issues.some((i) => i.rule === rule);

  for (const obj of mission.objectives) {
    const r = obj.rule;
    switch (r) {
      case "has-user":
        out[r] = has(arch, "user");
        break;
      case "has-ec2":
        out[r] = has(arch, "ec2");
        break;
      case "has-user-and-ec2":
        out[r] = has(arch, "user") && has(arch, "ec2");
        break;
      case "user-to-ec2":
        out[r] = isReachable(arch, "user", "ec2");
        break;
      case "ec2-configured":
        out[r] = byType(arch, "ec2").some((e) => e.config.instanceType === "t3.micro");
        break;
      case "ec2-running":
        out[r] = byType(arch, "ec2").some((e) => e.config.state === "running");
        break;
      case "has-route53":
        out[r] = has(arch, "route53");
        break;
      case "route53-configured":
        out[r] = byType(arch, "route53").some((r) => String(r.config.recordName ?? "").length > 0);
        break;
      case "dns-to-ec2":
        out[r] = isReachable(arch, "user", "route53") && isReachable(arch, "route53", "ec2") && byType(arch, "ec2").some((e) => e.config.state === "running");
        break;
      case "has-sg":
        out[r] = has(arch, "security-group") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "security-group" && t?.type === "ec2") || (t?.type === "security-group" && f?.type === "ec2");
        });
        break;
      case "sg-port-80":
        out[r] = byType(arch, "security-group").some((s) => String(s.config.allowedPort) === "80");
        break;
      case "sg-no-ssh":
        out[r] = !byType(arch, "security-group").some((s) => String(s.config.allowedPort) === "22" || String(s.config.allowedPort) === "all");
        break;
      case "has-s3":
        out[r] = has(arch, "s3");
        break;
      case "s3-configured":
        out[r] = byType(arch, "s3").some((s) => String(s.config.bucketName ?? "").length > 0);
        break;
      case "ec2-to-s3":
        out[r] = isReachable(arch, "ec2", "s3");
        break;
      case "s3-private":
        out[r] = !byType(arch, "s3").some((s) => s.config.public === true || s.config.public === "true");
        break;
      case "has-role":
        out[r] = has(arch, "iam-role") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "iam-role" && t?.type === "ec2") || (t?.type === "iam-role" && f?.type === "ec2");
        });
        break;
      case "policy-least-priv":
        out[r] = has(arch, "iam-policy") && byType(arch, "iam-policy").some((p) => {
          const a = String(p.config.action ?? "");
          return a.includes("s3:PutObject") || a.includes("s3:GetObject");
        }) && !byType(arch, "iam-policy").some((p) => {
          const a = String(p.config.action ?? "");
          return a === "*" || a === "*:*" || a.toLowerCase().includes("administrator");
        });
        break;
      case "no-wildcard":
        out[r] = !byType(arch, "iam-policy").some((p) => {
          const a = String(p.config.action ?? "");
          return a === "*" || a === "*:*" || a.toLowerCase().includes("administrator");
        });
        break;
      case "s3-write-ok":
        out[r] = has(arch, "ec2") && has(arch, "s3") && has(arch, "iam-role") && has(arch, "iam-policy") && isReachable(arch, "ec2", "s3");
        break;
      case "has-lambda":
        out[r] = has(arch, "lambda");
        break;
      case "lambda-role":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "iam-role" && t?.type === "lambda") || (t?.type === "iam-role" && f?.type === "lambda");
        });
        break;
      case "lambda-policy-least":
        out[r] = has(arch, "iam-policy") && byType(arch, "iam-policy").some((p) => {
          const a = String(p.config.action ?? "");
          return a.includes("s3:GetObject") && a.includes("s3:PutObject");
        });
        break;
      case "s3-lambda-flow":
        out[r] = isReachable(arch, "s3", "lambda");
        break;
      case "lambda-succeeds":
        out[r] = has(arch, "lambda") && has(arch, "iam-role") && has(arch, "iam-policy") && isReachable(arch, "s3", "lambda");
        break;
      case "ec2-role":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "iam-role" && t?.type === "ec2") || (t?.type === "iam-role" && f?.type === "ec2");
        });
        break;
      case "ec2-read-only":
        out[r] = byType(arch, "iam-policy").some((p) => {
          const a = String(p.config.action ?? "");
          return a.includes("s3:GetObject") && !a.includes("s3:PutObject");
        });
        break;
      case "ec2-reads-s3":
        out[r] = has(arch, "ec2") && has(arch, "s3") && has(arch, "iam-role") && has(arch, "iam-policy") && isReachable(arch, "ec2", "s3");
        break;
      case "has-vpc":
        out[r] = has(arch, "vpc");
        break;
      case "has-igw":
        out[r] = has(arch, "internet-gateway") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "vpc" && t?.type === "internet-gateway") || (t?.type === "vpc" && f?.type === "internet-gateway");
        });
        break;
      case "has-public-subnet":
        out[r] = has(arch, "subnet-public") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "vpc" && t?.type === "subnet-public") || (t?.type === "vpc" && f?.type === "subnet-public");
        });
        break;
      case "ec2-in-subnet":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "ec2" && t?.type === "subnet-public") || (t?.type === "ec2" && f?.type === "subnet-public") ||
                 (f?.type === "ec2" && t?.type === "subnet-private") || (t?.type === "ec2" && f?.type === "subnet-private");
        });
        break;
      case "has-vpc-igw":
        out[r] = has(arch, "vpc") && has(arch, "internet-gateway") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "vpc" && t?.type === "internet-gateway") || (t?.type === "vpc" && f?.type === "internet-gateway");
        });
        break;
      case "has-private-subnet":
        out[r] = has(arch, "subnet-private") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "vpc" && t?.type === "subnet-private") || (t?.type === "vpc" && f?.type === "subnet-private");
        });
        break;
      case "rds-private":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "rds" && t?.type === "subnet-private") || (t?.type === "rds" && f?.type === "subnet-private");
        });
        break;
      case "rds-not-public":
        out[r] = byType(arch, "rds").every((rds) => rds.config.publiclyAccessible !== true && rds.config.publiclyAccessible !== "true");
        break;
      case "vpc-foundation":
        out[r] = has(arch, "vpc") && has(arch, "internet-gateway") && has(arch, "subnet-public") && has(arch, "subnet-private");
        break;
      case "lb-public":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "loadbalancer" && t?.type === "subnet-public") || (t?.type === "loadbalancer" && f?.type === "subnet-public");
        });
        break;
      case "ec2-rds-placement":
        out[r] = has(arch, "ec2") && has(arch, "rds") && byType(arch, "rds").every((rds) =>
          arch.connections.some((c) => {
            const f = byId(arch, c.from);
            const t = byId(arch, c.to);
            return (f?.id === rds.id && t?.type === "subnet-private") || (t?.id === rds.id && f?.type === "subnet-private");
          })
        );
        break;
      case "full-chain":
        out[r] = isReachable(arch, "user", "route53") && isReachable(arch, "route53", "loadbalancer") && isReachable(arch, "loadbalancer", "ec2") && isReachable(arch, "ec2", "rds");
        break;
      case "ec2-rds-private":
        out[r] = true; // soft - handled by other rules
        break;
      case "rds-sg-from-ec2":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "security-group" && t?.type === "rds");
        });
        break;
      case "investigated":
        out[r] = hasRule("rds-public") && hasRule("sg-ssh-open");
        break;
      case "rds-sg-fixed":
        out[r] = byType(arch, "rds").every((rds) =>
          arch.connections.some((c) => {
            const f = byId(arch, c.from);
            const t = byId(arch, c.to);
            return (f?.type === "security-group" && t?.id === rds.id);
          })
        );
        break;
      case "ec2-rds-ok":
        out[r] = isReachable(arch, "ec2", "rds") && hasRule("rds-public");
        break;
      case "has-lb":
        out[r] = has(arch, "loadbalancer");
        break;
      case "has-2-ec2":
        out[r] = hasN(arch, "ec2", 2);
        break;
      case "lb-to-2-ec2": {
        const lbs = byType(arch, "loadbalancer");
        if (lbs.length === 0) { out[r] = false; break; }
        const lb = lbs[0];
        const ec2Targets = arch.connections
          .filter((c) => c.from === lb.id)
          .map((c) => byId(arch, c.to))
          .filter((t) => t && t.type === "ec2");
        out[r] = ec2Targets.length >= 2;
        break;
      }
      case "all-healthy":
        out[r] = byType(arch, "ec2").every((e) => e.config.state === "running") && hasN(arch, "ec2", 1);
        break;
      case "lb-skips-unhealthy":
        out[r] = byType(arch, "loadbalancer").length > 0;
        break;
      case "ec2-restarted":
        out[r] = byType(arch, "ec2").every((e) => e.config.state === "running");
        break;
      case "has-cloudwatch":
        out[r] = has(arch, "cloudwatch") && isReachable(arch, "ec2", "cloudwatch");
        break;
      case "has-alarm":
        out[r] = has(arch, "alarm") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "alarm" && t?.type === "cloudwatch") || (t?.type === "alarm" && f?.type === "cloudwatch");
        });
        break;
      case "metrics-flowing":
        out[r] = has(arch, "cloudwatch") && has(arch, "ec2");
        break;
      case "added-3rd-ec2":
        out[r] = hasN(arch, "ec2", 3);
        break;
      case "latency-fixed":
        out[r] = hasN(arch, "ec2", 3) && has(arch, "loadbalancer");
        break;
      case "has-s3-lambda":
        out[r] = has(arch, "s3") && has(arch, "lambda");
        break;
      case "lambda-role-correct":
        out[r] = arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return (f?.type === "iam-role" && t?.type === "lambda") || (t?.type === "iam-role" && f?.type === "lambda");
        });
        break;
      case "lambda-invoked":
        out[r] = has(arch, "lambda") && has(arch, "iam-role") && has(arch, "iam-policy");
        break;
      case "has-2-s3":
        out[r] = hasN(arch, "s3", 2);
        break;
      case "full-pipeline":
        out[r] = isReachable(arch, "s3", "lambda") && arch.connections.some((c) => {
          const f = byId(arch, c.from);
          const t = byId(arch, c.to);
          return f?.type === "lambda" && t?.type === "s3";
        });
        break;
      case "role-correct":
        out[r] = has(arch, "iam-role") && has(arch, "iam-policy");
        break;
      case "pipeline-ok":
        out[r] = has(arch, "s3") && has(arch, "lambda") && has(arch, "iam-role") && has(arch, "iam-policy") && isReachable(arch, "s3", "lambda");
        break;
      case "dns-layer":
        out[r] = isReachable(arch, "user", "route53") && isReachable(arch, "route53", "loadbalancer");
        break;
      case "compute-layer":
        out[r] = hasN(arch, "ec2", 2) && isReachable(arch, "loadbalancer", "ec2");
        break;
      case "db-layer":
        out[r] = isReachable(arch, "ec2", "rds") && byType(arch, "rds").every((rds) => rds.config.publiclyAccessible !== true);
        break;
      case "storage-iam":
        out[r] = isReachable(arch, "ec2", "s3") && has(arch, "iam-role") && has(arch, "iam-policy") && byType(arch, "s3").every((s) => s.config.public !== true);
        break;
      case "observability":
        out[r] = has(arch, "cloudwatch") && has(arch, "alarm");
        break;
      default:
        out[r] = false;
    }
  }
  return out;
}

export function runSimulation(arch: Architecture, mission: Mission): SimResult {
  return evaluateRules(arch, mission);
}

export function buildStarter(mission: Mission): Architecture {
  if (mission.id === "m13") {
    return {
      resources: [
        {
          id: "r-ec2",
          type: "ec2",
          x: 220,
          y: 220,
          config: { state: "running", instanceType: "t3.micro" },
          state: "running",
          health: 100,
          metrics: {},
          logs: [],
          connections: ["r-rds"],
        },
        {
          id: "r-rds",
          type: "rds",
          x: 520,
          y: 220,
          config: { publiclyAccessible: false, port: 5432 },
          state: "available",
          health: 100,
          metrics: {},
          logs: [],
          connections: [],
        },
      ],
      connections: [{ from: "r-ec2", to: "r-rds", kind: "tcp" }],
    };
  }
  return { resources: [], connections: [] };
}
