import { create } from "zustand";
import { persist } from "zustand/middleware";
import { toast } from "sonner";
import type {
  Architecture,
  PlacedResource,
  ResourceTypeId,
  GameEvent,
  SimIssue,
  MissionScore,
  MissionResult,
  ResourceConfig,
} from "./types";
import { MISSIONS, rankForXp } from "./missions";
import { runSimulation, type SimResult } from "./simulation";


export type GameView = "home" | "mission" | "profile" | "services" | "leaderboard";

interface GameState {
  playerName: string;
  xp: number;
  completedMissions: Record<string, MissionResult>;
  unlockedMissionIds: string[];
  discoveredServiceIds: ResourceTypeId[];
  earnedBadgeIds: string[];
  serviceMastery: Record<string, number>; // serviceId -> 0..100
  hintsUsedTotal: number;
  attemptsPerMission: Record<string, number>;

  view: GameView;
  activeMissionId: string | null;

  activeArchitecture: Architecture;
  activeEvents: GameEvent[];
  activeIssues: SimIssue[];
  activeScore: MissionScore | null;
  activeSatisfied: Record<string, boolean>;
  activeHintsUsed: number;
  activeHintLevel: number;
  hasDeployed: boolean;
  isSimulating: boolean;

  soundEnabled: boolean;
  reducedMotion: boolean;
  showServiceCard: ResourceTypeId | null;

  setView: (v: GameView) => void;
  openMission: (id: string) => void;
  exitMission: () => void;
  placeResource: (t: ResourceTypeId, x: number, y: number) => void;
  moveResource: (id: string, x: number, y: number) => void;
  removeResource: (id: string) => void;
  updateResourceConfig: (id: string, patch: ResourceConfig) => void;
  connectResources: (fromId: string, toId: string, kind?: string) => void;
  disconnectResources: (fromId: string, toId: string) => void;
  deploy: () => void;
  useHint: () => void;
  completeMission: () => void;
  resetActiveMission: () => void;
  toggleSound: () => void;
  toggleReducedMotion: () => void;
  setShowServiceCard: (id: ResourceTypeId | null) => void;
  resetGame: () => void;
  getActiveMission: () => (typeof MISSIONS)[number] | undefined;
}

const emptyArch = (): Architecture => ({ resources: [], connections: [] });

let _rid = 0;
function nextRid() {
  _rid += 1;
  return `r${Date.now().toString(36)}${_rid}`;
}

export const useGame = create<GameState>()(
  persist(
    (set, get) => ({
      playerName: "Engineer",
      xp: 0,
      completedMissions: {},
      unlockedMissionIds: ["m1"],
      discoveredServiceIds: [],
      earnedBadgeIds: [],
      serviceMastery: {},
      hintsUsedTotal: 0,
      attemptsPerMission: {},

      view: "home",
      activeMissionId: null,
      activeArchitecture: emptyArch(),
      activeEvents: [],
      activeIssues: [],
      activeScore: null,
      activeSatisfied: {},
      activeHintsUsed: 0,
      activeHintLevel: 0,
      hasDeployed: false,
      isSimulating: false,

      soundEnabled: false,
      reducedMotion: false,
      showServiceCard: null,

      setView: (v) => set({ view: v }),
      openMission: (id) => {
        const mission = MISSIONS.find((m) => m.id === id);
        if (!mission) return;
        const starter = mission.starter ? { ...mission.starter, resources: mission.starter.resources.map((r) => ({ ...r, metrics: {}, logs: [] })) } : emptyArch();
        set({
          activeMissionId: id,
          view: "mission",
          activeArchitecture: starter,
          activeEvents: [],
          activeIssues: [],
          activeScore: null,
          activeSatisfied: {},
          activeHintsUsed: 0,
          activeHintLevel: 0,
          hasDeployed: false,
          isSimulating: false,
        });
      },
      exitMission: () => set({ activeMissionId: null, view: "home" }),

      placeResource: (t, x, y) => {
        const arch = get().activeArchitecture;
        const id = nextRid();
        const r: PlacedResource = {
          id,
          type: t,
          x,
          y,
          config: defaultConfigFor(t),
          state: defaultStateFor(t),
          health: 100,
          metrics: {},
          logs: [],
          connections: [],
        };
        set({
          activeArchitecture: { ...arch, resources: [...arch.resources, r] },
        });
        const discovered = get().discoveredServiceIds;
        if (!discovered.includes(t)) {
          set({ discoveredServiceIds: [...discovered, t] });
        }
      },
      moveResource: (id, x, y) => {
        const arch = get().activeArchitecture;
        set({
          activeArchitecture: {
            ...arch,
            resources: arch.resources.map((r) => (r.id === id ? { ...r, x, y } : r)),
          },
        });
      },
      removeResource: (id) => {
        const arch = get().activeArchitecture;
        set({
          activeArchitecture: {
            resources: arch.resources.filter((r) => r.id !== id),
            connections: arch.connections.filter((c) => c.from !== id && c.to !== id),
          },
        });
      },
      updateResourceConfig: (id, patch) => {
        const arch = get().activeArchitecture;
        set({
          activeArchitecture: {
            ...arch,
            resources: arch.resources.map((r) =>
              r.id === id ? { ...r, config: { ...r.config, ...patch } } : r,
            ),
          },
        });
      },
      connectResources: (fromId, toId, kind = "default") => {
        const arch = get().activeArchitecture;
        if (arch.connections.some((c) => c.from === fromId && c.to === toId)) return;
        set({
          activeArchitecture: {
            ...arch,
            connections: [...arch.connections, { from: fromId, to: toId, kind }],
          },
        });
      },
      disconnectResources: (fromId, toId) => {
        const arch = get().activeArchitecture;
        set({
          activeArchitecture: {
            ...arch,
            connections: arch.connections.filter((c) => !(c.from === fromId && c.to === toId)),
          },
        });
      },
      deploy: () => {
        const { activeArchitecture, activeMissionId } = get();
        const mission = MISSIONS.find((m) => m.id === activeMissionId);
        if (!mission) return;
        set({ isSimulating: true });
        const res: SimResult = runSimulation(activeArchitecture, mission);
        setTimeout(() => {
          const prevSatisfied = get().activeSatisfied;
          const newSatisfied = res.satisfied;
          const newlyDone = mission.objectives.filter(
            (o) => !prevSatisfied[o.rule] && newSatisfied[o.rule],
          );
          const allDone = mission.objectives.every((o) => newSatisfied[o.rule]);
          const errors = res.issues.filter((i) => i.severity === "error");

          set({
            activeEvents: res.events,
            activeIssues: res.issues,
            activeScore: res.score,
            activeSatisfied: res.satisfied,
            activeArchitecture: { ...activeArchitecture, resources: res.resources },
            hasDeployed: true,
            isSimulating: false,
          });

          try {
            if (errors.length > 0) {
              toast.error(`${errors.length} issue${errors.length > 1 ? "s" : ""} found`, {
                description: errors[0]?.message.slice(0, 80) + (errors[0] && errors[0].message.length > 80 ? "..." : ""),
              });
            }
            for (const o of newlyDone) {
              toast.success("Objective complete!", {
                description: o.label,
              });
            }
            if (allDone && newlyDone.length > 0) {
              toast.success("All objectives complete!", {
                description: "Mission ready to finish",
              });
            }
            if (errors.length === 0 && newlyDone.length === 0 && res.issues.length === 0 && res.resources.length > 0) {
              toast.success("Architecture deployed", {
                description: "No issues detected",
              });
            }
          } catch {
            // toasts unavailable, no-op
          }
        }, 400);
      },
      useHint: () => {
        const cur = get().activeHintLevel;
        const mission = get().getActiveMission();
        if (!mission) return;
        if (cur >= mission.hints.length) return;
        set({
          activeHintLevel: cur + 1,
          activeHintsUsed: get().activeHintsUsed + 1,
          hintsUsedTotal: get().hintsUsedTotal + 1,
        });
      },
      completeMission: () => {
        const state = get();
        const mission = state.getActiveMission();
        if (!mission) return;
        const score = state.activeScore;
        if (!score) return;
        const allObj = mission.objectives.every((o) => state.activeSatisfied[o.rule]);
        if (!allObj) return;

        let stars: 1 | 2 | 3 = 1;
        if (score.total >= 85) stars = 3;
        else if (score.total >= 65) stars = 2;

        const prevResult = state.completedMissions[mission.id];
        const xpEarned = Math.max(0, Math.round(mission.xpReward * (stars / 3)) - state.activeHintsUsed * 8);
        const result: MissionResult = {
          missionId: mission.id,
          completedAt: Date.now(),
          stars: prevResult ? Math.max(prevResult.stars, stars) : stars,
          score: prevResult ? bestScore(prevResult.score, score) : score,
          xpEarned,
          hintsUsed: state.activeHintsUsed,
        };

        const nextMission = MISSIONS.find((m) => m.index === mission.index + 1);
        const newUnlocked = nextMission && !state.unlockedMissionIds.includes(nextMission.id)
          ? [...state.unlockedMissionIds, nextMission.id]
          : state.unlockedMissionIds;

        const prevXp = prevResult ? prevResult.xpEarned : 0;
        const newXp = state.xp - prevXp + xpEarned;

        const masteryBump = { ...state.serviceMastery };
        for (const sid of mission.serviceIds) {
          masteryBump[sid] = Math.min(100, (masteryBump[sid] ?? 0) + (stars === 3 ? 18 : stars === 2 ? 12 : 6));
        }

        const newBadges = [...state.earnedBadgeIds];
        const addBadge = (id: string) => {
          if (!newBadges.includes(id)) newBadges.push(id);
        };
        if (Object.keys(state.completedMissions).length === 0) addBadge("b-first-deploy");
        if (mission.serviceIds.includes("iam-role") || mission.serviceIds.includes("iam-policy")) {
          if (score.security >= 90) addBadge("b-iam");
        }
        if (mission.serviceIds.includes("s3")) addBadge("b-s3");
        if (mission.serviceIds.includes("ec2")) addBadge("b-ec2");
        if (mission.serviceIds.includes("vpc")) addBadge("b-network");
        if (mission.serviceIds.includes("rds")) addBadge("b-db");
        if (mission.serviceIds.includes("lambda")) addBadge("b-serverless");
        if (mission.serviceIds.includes("cloudwatch") || mission.serviceIds.includes("alarm")) {
          if (score.monitoring >= 80) addBadge("b-observability");
        }
        if (mission.id === "m13" || mission.id === "m15" || mission.id === "m17") addBadge("b-incident");
        if (score.security >= 95) addBadge("b-security");
        if (score.cost >= 90) addBadge("b-cost");
        if (mission.id === "m20") addBadge("b-arch");

        set({
          completedMissions: { ...state.completedMissions, [mission.id]: result },
          unlockedMissionIds: newUnlocked,
          xp: Math.max(0, newXp),
          serviceMastery: masteryBump,
          earnedBadgeIds: newBadges,
          attemptsPerMission: {
            ...state.attemptsPerMission,
            [mission.id]: (state.attemptsPerMission[mission.id] ?? 0) + 1,
          },
        });
      },
      resetActiveMission: () => {
        const m = get().getActiveMission();
        if (!m) return;
        const starter = m.starter ? m.starter : emptyArch();
        set({
          activeArchitecture: { ...starter, resources: starter.resources.map((r) => ({ ...r, metrics: {}, logs: [] })) },
          activeEvents: [],
          activeIssues: [],
          activeScore: null,
          activeSatisfied: {},
          activeHintsUsed: 0,
          activeHintLevel: 0,
          hasDeployed: false,
          isSimulating: false,
        });
      },
      toggleSound: () => set({ soundEnabled: !get().soundEnabled }),
      toggleReducedMotion: () => set({ reducedMotion: !get().reducedMotion }),
      setShowServiceCard: (id) => set({ showServiceCard: id }),
      resetGame: () =>
        set({
          playerName: "Engineer",
          xp: 0,
          completedMissions: {},
          unlockedMissionIds: ["m1"],
          discoveredServiceIds: [],
          earnedBadgeIds: [],
          serviceMastery: {},
          hintsUsedTotal: 0,
          attemptsPerMission: {},
          view: "home",
          activeMissionId: null,
          activeArchitecture: emptyArch(),
          activeEvents: [],
          activeIssues: [],
          activeScore: null,
          activeSatisfied: {},
          activeHintsUsed: 0,
          activeHintLevel: 0,
          hasDeployed: false,
          isSimulating: false,
        }),
      getActiveMission: () => MISSIONS.find((m) => m.id === get().activeMissionId),
    }),
    {
      name: "cloudforge-save-v1",
      partialize: (s) => ({
        playerName: s.playerName,
        xp: s.xp,
        completedMissions: s.completedMissions,
        unlockedMissionIds: s.unlockedMissionIds,
        discoveredServiceIds: s.discoveredServiceIds,
        earnedBadgeIds: s.earnedBadgeIds,
        serviceMastery: s.serviceMastery,
        hintsUsedTotal: s.hintsUsedTotal,
        attemptsPerMission: s.attemptsPerMission,
        soundEnabled: s.soundEnabled,
        reducedMotion: s.reducedMotion,
      }),
    },
  ),
);

function bestScore(a: MissionScore, b: MissionScore): MissionScore {
  return a.total >= b.total ? a : b;
}

function defaultConfigFor(t: ResourceTypeId): ResourceConfig {
  switch (t) {
    case "ec2":
      return { state: "running", instanceType: "t3.micro", ami: "Amazon Linux 2023" };
    case "route53":
      return { recordName: "", recordType: "A" };
    case "s3":
      return { bucketName: "", public: false, versioning: false };
    case "rds":
      return { engine: "PostgreSQL", publiclyAccessible: false, port: 5432, multiAZ: false };
    case "security-group":
      return { allowedPort: "80", source: "0.0.0.0/0" };
    case "iam-role":
      return { trustedEntity: "ec2.amazonaws.com" };
    case "iam-policy":
      return { action: "s3:GetObject", resource: "arn:aws:s3:::bucket/*", effect: "Allow" };
    case "lambda":
      return { runtime: "Node.js 20", memory: 256, timeout: 5, state: "ready" };
    case "vpc":
      return { cidr: "10.0.0.0/16" };
    case "subnet-public":
      return { cidr: "10.0.1.0/24", az: "us-east-1a" };
    case "subnet-private":
      return { cidr: "10.0.2.0/24", az: "us-east-1a" };
    case "cloudwatch":
      return { retention: "30 days" };
    case "alarm":
      return { metric: "CPUUtilization", threshold: 80, comparison: ">" };
    case "loadbalancer":
      return { type: "application", port: 443 };
    default:
      return {};
  }
}

function defaultStateFor(t: ResourceTypeId): PlacedResource["state"] {
  switch (t) {
    case "ec2":
      return "running";
    case "s3":
      return "available";
    case "rds":
      return "available";
    case "lambda":
      return "ready";
    default:
      return "available";
  }
}

export function useCurrentRank() {
  const xp = useGame((s) => s.xp);
  return rankForXp(xp);
}
