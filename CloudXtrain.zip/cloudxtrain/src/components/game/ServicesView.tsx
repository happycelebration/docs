"use client";

import { useState } from "react";
import { SERVICE_CATALOG, CATEGORY_META } from "@/lib/game/services";
import { useGame } from "@/lib/game/store";
import type { ServiceCategory } from "@/lib/game/types";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge as UiBadge } from "@/components/ui/badge";
import { Search } from "lucide-react";

const CATEGORY_ORDER: ServiceCategory[] = [
  "compute",
  "storage",
  "database",
  "networking",
  "security",
  "serverless",
  "monitoring",
  "analytics",
];

export function ServicesView() {
  const setShowServiceCard = useGame((s) => s.setShowServiceCard);
  const discovered = useGame((s) => s.discoveredServiceIds);
  const [query, setQuery] = useState("");

  const filtered = (Object.values(SERVICE_CATALOG)).filter((s) => {
    if (!s.placeable) return false;
    const q = query.toLowerCase();
    return !q || s.label.toLowerCase().includes(q) || s.awsName.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q);
  });

  return (
    <div className="fade-in-up w-full px-4 py-8 sm:px-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">AWS Services</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Every service you'll meet in the simulator. Click any to learn what it is, why it exists, and how it connects to others.
        </p>
      </div>

      {/* search */}
      <div className="relative mb-6 max-w-md">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search services…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* grouped grid */}
      <div className="space-y-8">
        {CATEGORY_ORDER.map((cat) => {
          const services = filtered.filter((s) => s.category === cat);
          if (services.length === 0) return null;
          const meta = CATEGORY_META[cat];
          return (
            <section key={cat}>
              <div className="mb-3 flex items-center gap-2">
                <span className="text-lg">{meta.emoji}</span>
                <h2 className="text-lg font-bold">{meta.label}</h2>
                <span className="rounded-full bg-accent/60 px-2 py-0.5 text-[10px] text-muted-foreground">
                  {services.length}
                </span>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                {services.map((s) => {
                  const isDiscovered = discovered.includes(s.id);
                  return (
                    <Card
                      key={s.id}
                      onClick={() => setShowServiceCard(s.id)}
                      className="group glass flex cursor-pointer flex-col gap-2 p-4 transition-all hover:translate-y-[-2px] hover:border-amber-500/40"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className="grid h-10 w-10 place-items-center rounded-lg text-xl"
                          style={{ background: `${s.color}22`, border: `1px solid ${s.color}55` }}
                        >
                          {s.icon}
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-bold">{s.label}</div>
                          <div className="text-[11px] text-muted-foreground">{s.awsName}</div>
                        </div>
                        {isDiscovered && (
                          <UiBadge variant="outline" className="border-emerald-500/40 text-emerald-400 text-[9px]">
                            ✓
                          </UiBadge>
                        )}
                      </div>
                      <p className="text-[11px] leading-tight text-muted-foreground">{s.summary}</p>
                      <div className="mt-auto flex items-center justify-between pt-1 text-[10px] text-muted-foreground">
                        <span>${s.baseCost}/mo</span>
                        <span>{s.useCases.length} use cases</span>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
