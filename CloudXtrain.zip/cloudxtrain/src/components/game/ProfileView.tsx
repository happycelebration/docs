"use client";

import { useGame } from "@/lib/game/store";
import { MISSIONS, RANKS, BADGES, rankForXp, nextRank } from "@/lib/game/missions";
import { SERVICE_CATALOG } from "@/lib/game/services";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge as UiBadge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy, Zap, Star, Award } from "lucide-react";
import { motion } from "framer-motion";

export function ProfileView() {
  const xp = useGame((s) => s.xp);
  const completed = useGame((s) => s.completedMissions);
  const mastery = useGame((s) => s.serviceMastery);
  const earnedBadges = useGame((s) => s.earnedBadgeIds);
  const discovered = useGame((s) => s.discoveredServiceIds);
  const openMission = useGame((s) => s.openMission);
  const setView = useGame((s) => s.setView);

  const rank = rankForXp(xp);
  const next = nextRank(xp);
  const prevXp = rank.minXp;
  const nextXp = next?.minXp ?? xp;
  const progressPct = next ? Math.min(100, Math.max(0, ((xp - prevXp) / (nextXp - prevXp)) * 100)) : 100;

  const completedCount = Object.keys(completed).length;
  const starsCount = Object.values(completed).reduce((s, r) => s + r.stars, 0);
  const avgScore =
    completedCount > 0
      ? Math.round(Object.values(completed).reduce((s, r) => s + r.score.total, 0) / completedCount)
      : 0;

  const masteredServices = Object.entries(mastery)
    .filter(([_, v]) => v > 0)
    .sort((a, b) => b[1] - a[1]);

  return (
    <div className="fade-in-up w-full px-4 py-8 sm:px-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <Card className="glass-strong relative overflow-hidden p-6 sm:p-8">
          <div className="absolute inset-0 bg-aurora opacity-60" />
          <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
            <div className="grid h-20 w-20 place-items-center rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 text-4xl shadow-2xl shadow-amber-500/40">
              {rank.emoji}
            </div>
            <div className="flex-1">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Cloud Engineer</div>
              <h1 className="text-3xl font-bold tracking-tight">{rank.title}</h1>
              <div className="mt-1 text-sm text-muted-foreground">
                {next ? (
                  <>
                    {nextXp - xp} XP until <span className="text-amber-300">{next.emoji} {next.title}</span>
                  </>
                ) : (
                  <span className="text-amber-300">Maximum rank achieved 👑</span>
                )}
              </div>
              <div className="mt-3 w-full max-w-md">
                <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                  <span>{xp.toLocaleString()} XP</span>
                  <span>{next ? nextXp.toLocaleString() : "MAX"}</span>
                </div>
                <div className="xp-bar h-2.5 rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Stats grid */}
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatBox label="Missions" value={`${completedCount}/${MISSIONS.length}`} icon={<Trophy className="h-4 w-4" />} color="#10b981" />
        <StatBox label="Total Stars" value={`${starsCount}`} icon={<Star className="h-4 w-4" />} color="#f59e0b" />
        <StatBox label="Avg Score" value={`${avgScore}%`} icon={<Zap className="h-4 w-4" />} color="#ff9900" />
        <StatBox label="Badges" value={`${earnedBadges.length}/${BADGES.length}`} icon={<Award className="h-4 w-4" />} color="#a855f7" />
      </div>

      {/* AWS Mastery */}
      <section className="mt-8">
        <h2 className="mb-3 text-xl font-bold tracking-tight">AWS Service Mastery</h2>
        {masteredServices.length === 0 ? (
          <Card className="p-6 text-center text-sm text-muted-foreground">
            No services mastered yet. Complete missions to build mastery.
          </Card>
        ) : (
          <Card className="glass p-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {masteredServices.map(([sid, v]) => {
                const svc = SERVICE_CATALOG[sid as keyof typeof SERVICE_CATALOG];
                if (!svc) return null;
                return (
                  <div key={sid} className="flex items-center gap-3">
                    <div
                      className="grid h-9 w-9 place-items-center rounded-md text-base"
                      style={{ background: `${svc.color}22`, border: `1px solid ${svc.color}55` }}
                    >
                      {svc.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold">{svc.label}</span>
                        <span className="text-muted-foreground">{v}%</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${v}%` }}
                          transition={{ duration: 0.6 }}
                          className="h-full"
                          style={{ background: svc.color }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        )}
      </section>

      {/* Badges */}
      <section className="mt-8">
        <h2 className="mb-3 text-xl font-bold tracking-tight">Badges</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {BADGES.map((b) => {
            const earned = earnedBadges.includes(b.id);
            return (
              <Card
                key={b.id}
                className={`relative flex flex-col items-center gap-2 p-4 text-center transition-all ${
                  earned ? "glass-strong border-amber-500/40" : "opacity-50 grayscale"
                }`}
              >
                <div className={`text-3xl ${earned ? "pop-in" : ""}`}>{b.emoji}</div>
                <div className="text-xs font-semibold leading-tight">{b.name}</div>
                <div className="text-[10px] leading-tight text-muted-foreground">{b.description}</div>
                {earned && (
                  <UiBadge className="absolute -right-1 -top-1 bg-amber-500 text-[9px] text-black">
                    EARNED
                  </UiBadge>
                )}
              </Card>
            );
          })}
        </div>
      </section>

      {/* Rank ladder */}
      <section className="mt-8">
        <h2 className="mb-3 text-xl font-bold tracking-tight">Rank Ladder</h2>
        <Card className="glass p-4">
          <div className="space-y-2">
            {RANKS.map((r) => {
              const isCurrent = r.id === rank.id;
              const isPast = xp >= r.minXp;
              return (
                <div
                  key={r.id}
                  className={`flex items-center gap-3 rounded-lg border p-2.5 transition-all ${
                    isCurrent ? "border-amber-500/50 bg-amber-500/[0.07]" : isPast ? "border-emerald-500/30 bg-emerald-500/[0.04]" : "border-border/40 opacity-50"
                  }`}
                >
                  <div className="text-xl">{r.emoji}</div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold">{r.title}</div>
                    <div className="text-[11px] text-muted-foreground">{r.minXp.toLocaleString()} XP required</div>
                  </div>
                  {isCurrent && (
                    <UiBadge className="bg-amber-500 text-[10px] text-black">YOU</UiBadge>
                  )}
                  {isPast && !isCurrent && (
                    <span className="text-emerald-400 text-xs">✓ earned</span>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      </section>

      {/* Mission history */}
      <section className="mt-8">
        <h2 className="mb-3 text-xl font-bold tracking-tight">Mission History</h2>
        {completedCount === 0 ? (
          <Card className="p-6 text-center text-sm text-muted-foreground">
            No missions completed yet. <Button variant="link" onClick={() => setView("home")} className="p-0 h-auto">Start your first mission</Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {Object.values(completed)
              .sort((a, b) => b.completedAt - a.completedAt)
              .map((res) => {
                const m = MISSIONS.find((mm) => mm.id === res.missionId);
                if (!m) return null;
                return (
                  <Card key={res.missionId} className="glass p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Mission {m.index}</div>
                        <div className="text-sm font-semibold">{m.title}</div>
                        <div className="text-[11px] text-muted-foreground">{m.company}</div>
                      </div>
                      <div className="flex gap-0.5">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <Star key={i} className={`h-3.5 w-3.5 ${i < res.stars ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}`} />
                        ))}
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">Score: {res.score.total}%</span>
                      <span className="text-amber-300">+{res.xpEarned} XP</span>
                    </div>
                    <Button size="sm" variant="outline" className="mt-3 w-full" onClick={() => openMission(m.id)}>
                      Replay
                    </Button>
                  </Card>
                );
              })}
          </div>
        )}
      </section>
    </div>
  );
}

function StatBox({ label, value, icon, color }: { label: string; value: string; icon: React.ReactNode; color: string }) {
  return (
    <Card className="glass p-4">
      <div className="flex items-center gap-2" style={{ color }}>
        {icon}
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <div className="mt-1 text-2xl font-bold tracking-tight">{value}</div>
    </Card>
  );
}
