"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGame } from "@/lib/game/store";
import { ArchitectureCanvas, ResourcePalette } from "./ArchitectureCanvas";
import { ServiceCardModal } from "./ServiceCardModal";
import { MissionCompleteModal } from "./MissionCompleteModal";
import { Button } from "@/components/ui/button";
import { Badge as UiBadge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ArrowLeft,
  Play,
  RotateCcw,
  Target,
  Lightbulb,
  ScrollText,
  BarChart3,
  Bell,
  AlertTriangle,
  CheckCircle2,
  Circle,
  DollarSign,
  Trophy,
  Settings2,
  Check,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { calcCost } from "@/lib/game/simulation";
import { SERVICE_CATALOG } from "@/lib/game/services";
import type { ResourceTypeId, Architecture } from "@/lib/game/types";

export function MissionView() {
  const mission = useGame((s) => s.getActiveMission());
  const exitMission = useGame((s) => s.exitMission);
  const deploy = useGame((s) => s.deploy);
  const isSimulating = useGame((s) => s.isSimulating);
  const arch = useGame((s) => s.activeArchitecture);
  const resetActiveMission = useGame((s) => s.resetActiveMission);
  const [showBriefing, setShowBriefing] = useState(true);
  const [mobilePanel, setMobilePanel] = useState<"palette" | "tools" | null>(null);

  if (!mission) return null;

  const totalCost = calcCost(arch);
  const overBudget = totalCost > mission.budget;
  const ch = mission.character;

  return (
    <div className="fade-in-up flex h-[calc(100vh-3.5rem)] w-full flex-col gap-2 px-2 py-2 sm:h-[calc(100vh-4rem)] sm:px-3 sm:py-3 sm:gap-3 lg:px-4">
      <div className="flex items-center justify-between gap-2 rounded-xl border border-border/40 bg-card/40 px-2.5 py-2 sm:px-3 sm:py-2.5">
        <div className="flex min-w-0 flex-1 items-center gap-2 sm:gap-3">
          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={exitMission}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-accent/60 text-sm font-bold text-amber-300">
            {mission.index}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h1 className="truncate text-sm font-bold sm:text-base">{mission.title}</h1>
              <UiBadge variant="outline" className="hidden shrink-0 text-[9px] sm:inline-flex">
                Ch. {mission.chapter}
              </UiBadge>
            </div>
            <div className="flex items-center gap-2 truncate text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1 shrink-0">
                <span className="text-base">{ch.avatar}</span>
                <span className="font-medium">{ch.name}</span>
                <span className="hidden sm:inline">· {ch.role}</span>
              </span>
              <span className="text-border hidden sm:inline">|</span>
              <span className={cn("flex shrink-0 items-center gap-1", overBudget && "text-red-400 font-semibold")}>
                <DollarSign className="h-3 w-3" />
                ${totalCost}/{mission.budget}
              </span>
            </div>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowBriefing(true)} className="hidden sm:flex">
            <Target className="mr-1.5 h-3.5 w-3.5" /> Briefing
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setMobilePanel("palette")} className="lg:hidden">
            Services
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setMobilePanel("tools")} className="lg:hidden">
            Tools
          </Button>
          <Button variant="outline" size="sm" onClick={resetActiveMission} title="Clear canvas" className="px-2">
            <RotateCcw className="h-3.5 w-3.5" />
          </Button>
          <Button
            size="sm"
            onClick={deploy}
            disabled={isSimulating}
            className="bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-400 hover:to-orange-500"
          >
            <Play className="h-3.5 w-3.5" />
            <span className="ml-1.5 hidden sm:inline">Deploy</span>
          </Button>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-2 lg:grid-cols-[260px_minmax(0,1fr)_320px] sm:gap-3">
        <div className="hidden min-h-0 lg:block">
          <ResourcePalette missionPalette={mission.paletteIds} />
        </div>
        <div className="min-h-0">
          <ArchitectureCanvas />
        </div>
        <div className="hidden min-h-0 lg:block">
          <ToolsPanel />
        </div>
      </div>

      <Sheet open={mobilePanel === "palette"} onOpenChange={(o) => !o && setMobilePanel(null)}>
        <SheetContent side="left" className="w-[280px] p-3 sm:max-w-sm">
          <SheetHeader>
            <SheetTitle>Service palette</SheetTitle>
          </SheetHeader>
          <div className="h-[calc(100%-3rem)]">
            <ResourcePalette missionPalette={mission.paletteIds} />
          </div>
        </SheetContent>
      </Sheet>
      <Sheet open={mobilePanel === "tools"} onOpenChange={(o) => !o && setMobilePanel(null)}>
        <SheetContent side="right" className="w-[320px] p-3 sm:max-w-md">
          <SheetHeader>
            <SheetTitle>Tools</SheetTitle>
          </SheetHeader>
          <div className="h-[calc(100%-3rem)]">
            <ToolsPanel />
          </div>
        </SheetContent>
      </Sheet>

      <Sheet open={showBriefing} onOpenChange={setShowBriefing}>
        <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md p-0">
          <SheetHeader className="px-5 pt-5 pb-3">
            <div className="flex items-center gap-3">
              <motion.div
                initial={{ scale: 0.5, rotate: -10 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 240, damping: 14 }}
                className="grid h-12 w-12 shrink-0 place-items-center rounded-xl text-2xl"
                style={{ background: `${ch.accent}22`, border: `1px solid ${ch.accent}55` }}
              >
                {ch.avatar}
              </motion.div>
              <div className="min-w-0">
                <SheetTitle className="text-left text-base">Mission {mission.index}: {mission.title}</SheetTitle>
                <div className="truncate text-xs text-muted-foreground">{ch.name} · {ch.role}</div>
              </div>
            </div>
          </SheetHeader>

          <div className="max-h-[calc(100vh-12rem)] overflow-y-auto scroll-thin px-5 pb-5 space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-xl border p-3"
              style={{ borderColor: `${ch.accent}44`, background: `${ch.accent}10` }}
            >
              <p className="text-sm italic leading-snug" style={{ color: ch.accent }}>
                &ldquo;{truncate(mission.briefing, 140)}&rdquo;
              </p>
              <div className="mt-2 flex items-center gap-1.5 text-[10px] text-muted-foreground">
                <span className="text-base">{ch.avatar}</span>
                <span>{ch.name}, {ch.role}</span>
              </div>
            </motion.div>

            <div>
              <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                <Target className="h-3 w-3 text-amber-400" />
                Build these
              </div>
              <div className="space-y-1.5">
                {mission.requirements.map((r, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.15 + i * 0.06 }}
                    className="flex items-start gap-2 rounded-lg border border-border/40 bg-card/40 px-2.5 py-1.5"
                  >
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                    <span className="text-xs leading-snug">{r}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {mission.constraints.length > 0 && (
              <div>
                <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  <AlertTriangle className="h-3 w-3 text-amber-400" />
                  Watch out
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {mission.constraints.map((c, i) => (
                    <span key={i} className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/[0.07] px-2 py-0.5 text-[10px] text-amber-200">
                      <AlertTriangle className="h-2.5 w-2.5" />
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between rounded-lg border border-amber-500/30 bg-amber-500/[0.07] p-3">
              <div className="flex items-center gap-2 text-xs">
                <Trophy className="h-4 w-4 text-amber-400" />
                <span className="font-semibold">Reward</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-amber-300">+{mission.xpReward}</span>
                <span className="text-[10px] text-muted-foreground">XP</span>
              </div>
            </div>

            <Button
              onClick={() => setShowBriefing(false)}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-400 hover:to-orange-500"
            >
              <Play className="mr-2 h-4 w-4" />
              Start Building
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      <ServiceCardModal />
      <MissionCompleteModal />
    </div>
  );
}

function ToolsPanel() {
  const mission = useGame((s) => s.getActiveMission());
  const issues = useGame((s) => s.activeIssues);
  const events = useGame((s) => s.activeEvents);
  const satisfied = useGame((s) => s.activeSatisfied);
  const hintsUsed = useGame((s) => s.activeHintsUsed);
  const useHint = useGame((s) => s.useHint);
  const hasDeployed = useGame((s) => s.hasDeployed);
  const arch = useGame((s) => s.activeArchitecture);
  const [tab, setTab] = useState("objectives");

  if (!mission) return null;

  const errors = issues.filter((i) => i.severity === "error");
  const warns = issues.filter((i) => i.severity === "warn");

  return (
    <div className="flex h-full flex-col gap-2 rounded-lg border border-border/40 bg-card/40">
      <Tabs value={tab} onValueChange={setTab} className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center gap-1 border-b border-border/40 p-1.5">
          <TabsList className="grid h-8 w-full grid-cols-5 bg-transparent p-0">
            <TabBtn value="objectives" icon={<Target className="h-3.5 w-3.5" />} label="Obj" />
            <TabBtn value="hints" icon={<Lightbulb className="h-3.5 w-3.5" />} label="Hints" badge={hintsUsed} />
            <TabBtn value="metrics" icon={<BarChart3 className="h-3.5 w-3.5" />} label="Metrics" />
            <TabBtn value="logs" icon={<ScrollText className="h-3.5 w-3.5" />} label="Logs" />
            <TabBtn value="events" icon={<Bell className="h-3.5 w-3.5" />} label="Events" badge={errors.length || undefined} />
          </TabsList>
        </div>

        <TabsContent value="objectives" className="mt-0 flex-1 min-h-0">
          <ScrollArea className="h-full scroll-thin">
            <div className="space-y-2 p-3">
              {mission.objectives.map((o) => {
                const done = satisfied[o.rule];
                return (
                  <motion.div
                    key={o.id}
                    initial={false}
                    animate={done ? { scale: [1, 1.04, 1] } : { scale: 1 }}
                    transition={{ duration: 0.4 }}
                    className={cn("flex items-start gap-2 rounded-lg border p-2.5 transition-colors", done ? "border-emerald-500/40 bg-emerald-500/[0.07]" : "border-border/40 bg-background/30")}
                  >
                    <AnimatePresence mode="wait">
                      {done ? (
                        <motion.div key="check" initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} exit={{ scale: 0 }} transition={{ type: "spring", stiffness: 280, damping: 14 }}>
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                        </motion.div>
                      ) : (
                        <motion.div key="circle" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                          <Circle className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <div className="min-w-0">
                      <div className={cn("font-medium leading-tight", done && "text-emerald-300")}>{o.label}</div>
                      <div className="text-[11px] text-muted-foreground">{o.hint}</div>
                    </div>
                  </motion.div>
                );
              })}
              {hasDeployed && (
                <div className="rounded-lg border border-border/40 bg-card/40 p-3">
                  <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Issues found</div>
                  {issues.length === 0 ? (
                    <div className="flex items-center gap-1.5 text-sm text-emerald-400">
                      <CheckCircle2 className="h-4 w-4" />
                      No issues - architecture is clean!
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      {issues.map((issue, i) => (
                        <div key={i} className="flex items-start gap-1.5 text-[11px] leading-tight">
                          <AlertTriangle className={cn("mt-0.5 h-3 w-3 shrink-0", issue.severity === "error" ? "text-red-400" : "text-amber-400")} />
                          <span className={cn(issue.severity === "error" ? "text-red-300" : "text-amber-200")}>{issue.message}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="hints" className="mt-0 flex-1 min-h-0">
          <ScrollArea className="h-full scroll-thin">
            <div className="space-y-3 p-3">
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/[0.07] p-3 text-xs text-amber-200">
                💡 Using hints reduces your final XP and score. Try to deploy first, then unlock hints if you're stuck.
              </div>
              {mission.hints.slice(0, hintsUsed).map((h, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="rounded-lg border border-border/40 bg-card/40 p-3">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300">
                    <Lightbulb className="h-3.5 w-3.5" /> Hint {h.level}: {h.title}
                  </div>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{h.body}</p>
                </motion.div>
              ))}
              {hintsUsed === 0 && <div className="text-xs text-muted-foreground">No hints used yet. Use the button below to unlock your first clue.</div>}
              <Button variant="outline" size="sm" onClick={useHint} disabled={hintsUsed >= mission.hints.length} className="w-full">
                {hintsUsed >= mission.hints.length ? "All hints revealed" : `Unlock hint ${hintsUsed + 1}`}
              </Button>
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="metrics" className="mt-0 flex-1 min-h-0">
          <ScrollArea className="h-full scroll-thin">
            <div className="space-y-2 p-3">
              {arch.resources.length === 0 && <div className="text-xs text-muted-foreground">No resources yet - add some to see metrics.</div>}
              {arch.resources.map((r) => {
                if (Object.keys(r.metrics).length === 0) return null;
                return (
                  <div key={r.id} className="rounded-lg border border-border/40 bg-card/40 p-2.5">
                    <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold">
                      <span className="text-base">{SERVICE_CATALOG[r.type]?.icon}</span>
                      {SERVICE_CATALOG[r.type]?.shortName} · <span className="text-muted-foreground">{r.id.slice(0, 6)}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {Object.entries(r.metrics).map(([k, v]) => (
                        <div key={k} className="rounded bg-background/40 px-2 py-1.5 text-[10px]">
                          <div className="text-muted-foreground">{k}</div>
                          <div className="font-mono text-sm font-semibold text-foreground">{typeof v === "number" ? (v < 100 ? v.toFixed(1) : Math.round(v).toLocaleString()) : v}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
              {hasDeployed && arch.resources.length > 0 && <MetricsSummary />}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="logs" className="mt-0 flex-1 min-h-0">
          <ScrollArea className="h-full scroll-thin" >
            <LogsScrollInner arch={arch} />
          </ScrollArea>
        </TabsContent>

        <TabsContent value="events" className="mt-0 flex-1 min-h-0">
          <ScrollArea className="h-full scroll-thin">
            <div className="space-y-1.5 p-3">
              {events.length === 0 && <div className="text-xs text-muted-foreground">No events yet. Press Deploy to start the simulation.</div>}
              <AnimatePresence initial={false}>
                {[...events].reverse().map((e) => (
                  <motion.div
                    key={e.id}
                    initial={{ opacity: 0, x: 8 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    className={cn("flex items-start gap-1.5 rounded border-l-2 px-2 py-1.5 text-[11px] leading-tight",
                      e.severity === "error" ? "border-red-500 bg-red-500/[0.07] text-red-200"
                      : e.severity === "warn" ? "border-amber-500 bg-amber-500/[0.07] text-amber-200"
                      : e.severity === "success" ? "border-emerald-500 bg-emerald-500/[0.07] text-emerald-200"
                      : "border-cyan-500 bg-cyan-500/[0.05] text-cyan-200"
                    )}
                  >
                    <span className="text-[9px] text-muted-foreground">{new Date(e.ts).toLocaleTimeString()}</span>
                    <span className="flex-1">{e.message}</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function truncate(s: string, n: number): string {
  if (s.length <= n) return s;
  const cut = s.slice(0, n);
  const lastSpace = cut.lastIndexOf(" ");
  return cut.slice(0, lastSpace > 40 ? lastSpace : n) + "...";
}

function LogsScrollInner({ arch }: { arch: Architecture }) {
  const ref = useRef<HTMLDivElement>(null);
  const logs = arch.resources.flatMap((r) => r.logs.map((l, i) => ({ r, l, i })));
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [logs.length]);
  return (
    <div ref={ref} className="h-full space-y-1 overflow-y-auto scroll-thin p-3">
      {arch.resources.length === 0 && <div className="text-xs text-muted-foreground">No resources yet.</div>}
      {logs.length === 0 && arch.resources.length > 0 && (
        <div className="text-xs text-muted-foreground">No logs yet. Press Deploy to generate them.</div>
      )}
      {logs.map(({ r, l, i }) => (
        <div key={`${r.id}-${i}`} className={cn("log-line", l.level === "error" ? "text-red-300" : l.level === "warn" ? "text-amber-300" : l.level === "success" ? "text-emerald-300" : "text-muted-foreground")}>
          <span className="text-[9px] text-muted-foreground/60">[{new Date(l.ts).toLocaleTimeString()}]</span>{" "}
          <span className="text-[10px] text-cyan-300/80">{SERVICE_CATALOG[r.type]?.shortName}</span>{" "}
          {l.message}
        </div>
      ))}
    </div>
  );
}

function MetricsSummary() {
  const score = useGame((s) => s.activeScore);
  if (!score) return null;
  const items = [
    { label: "Architecture", v: score.architecture, c: "#ff9900" },
    { label: "Security", v: score.security, c: "#dc2626" },
    { label: "Availability", v: score.availability, c: "#10b981" },
    { label: "Performance", v: score.performance, c: "#0891b2" },
    { label: "Cost", v: score.cost, c: "#84cc16" },
    { label: "Monitoring", v: score.monitoring, c: "#a855f7" },
  ];
  return (
    <div className="rounded-lg border border-border/40 bg-card/40 p-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold">Live score</span>
        <span className="text-lg font-bold text-amber-300">{score.total}%</span>
      </div>
      <div className="space-y-1.5">
        {items.map((it) => (
          <div key={it.label}>
            <div className="flex justify-between text-[10px]">
              <span className="text-muted-foreground">{it.label}</span>
              <span style={{ color: it.c }}>{it.v}</span>
            </div>
            <div className="h-1 overflow-hidden rounded-full bg-muted">
              <div className="h-full transition-all" style={{ width: `${it.v}%`, background: it.c }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TabBtn({ value, icon, label, badge }: { value: string; icon: React.ReactNode; label: string; badge?: number }) {
  return (
    <TabsTrigger value={value} className="relative flex h-8 flex-row items-center justify-center gap-1 rounded-md text-[11px] data-[state=active]:bg-accent/60">
      {icon}
      <span className="hidden xl:inline">{label}</span>
      {badge !== undefined && badge > 0 && (
        <span className="absolute -right-0.5 -top-0.5 grid h-3.5 min-w-3.5 place-items-center rounded-full bg-red-500 px-1 text-[8px] font-bold text-white">
          {badge}
        </span>
      )}
    </TabsTrigger>
  );
}
