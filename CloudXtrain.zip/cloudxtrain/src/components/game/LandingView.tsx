"use client";

import { motion } from "framer-motion";
import { ArrowRight, Cloud, Cpu, Database, Network, Shield, Zap, Trophy, Flame } from "lucide-react";
import { useGame } from "@/lib/game/store";
import { MISSIONS, RANKS, BADGES, rankForXp, nextRank } from "@/lib/game/missions";
import { SERVICE_CATALOG } from "@/lib/game/services";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge as UiBadge } from "@/components/ui/badge";
import { HeroScene3D } from "./HeroScene3D";
import type { Mission } from "@/lib/game/types";

export function LandingView() {
  const xp = useGame((s) => s.xp);
  const completed = useGame((s) => s.completedMissions);
  const discovered = useGame((s) => s.discoveredServiceIds);
  const badges = useGame((s) => s.earnedBadgeIds);
  const unlocked = useGame((s) => s.unlockedMissionIds);
  const openMission = useGame((s) => s.openMission);
  const setView = useGame((s) => s.setView);

  const rank = rankForXp(xp);
  const next = nextRank(xp);
  const prevXp = rank.minXp;
  const nextXp = next?.minXp ?? xp;
  const progressPct = next ? Math.min(100, Math.max(0, ((xp - prevXp) / (nextXp - prevXp)) * 100)) : 100;

  const totalMissions = MISSIONS.length;
  const completedCount = Object.keys(completed).length;
  const starsCount = Object.values(completed).reduce((s, r) => s + r.stars, 0);
  const avgScore =
    completedCount > 0
      ? Math.round(Object.values(completed).reduce((s, r) => s + r.score.total, 0) / completedCount)
      : 0;

  const chapters = MISSIONS.reduce<Record<number, Mission[]>>((acc, m) => {
    (acc[m.chapter] ??= []).push(m);
    return acc;
  }, {});

  return (
    <div className="fade-in-up w-full">
      <section className="relative w-full overflow-hidden bg-aurora">
        <div className="absolute inset-0">
          <HeroScene3D />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background pointer-events-none" />
        <div className="relative mx-auto flex min-h-[78vh] w-full max-w-[1600px] flex-col items-center justify-center px-4 py-16 sm:px-6 sm:py-24">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mx-auto max-w-3xl text-center"
          >
            <h1 className="text-balance text-5xl font-bold leading-[1.05] tracking-tight sm:text-7xl">
              <span className="text-gradient-amber">CloudXtrain</span>
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-pretty text-base text-muted-foreground sm:text-xl">
              Become a cloud engineer. Solve realistic AWS infrastructure problems, design
              architectures, debug incidents, and progress from{" "}
              <span className="text-foreground">Cloud Beginner</span> to{" "}
              <span className="text-amber-300">Cloud Master</span>.
            </p>
            <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                onClick={() => openMission(unlocked[unlocked.length - 1] ?? "m1")}
                className="bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-400 hover:to-orange-500"
              >
                {completedCount === 0 ? "Start Mission 1" : "Continue"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" onClick={() => setView("services")}>
                <Cloud className="mr-2 h-4 w-4" />
                Browse services
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-12 grid w-full max-w-4xl grid-cols-2 gap-3 sm:grid-cols-4"
          >
            <StatCard label="Rank" value={rank.title} icon={<span className="text-lg">{rank.emoji}</span>} accent="amber" />
            <StatCard label="Total XP" value={xp.toLocaleString()} icon={<Zap className="h-4 w-4 text-amber-400" />} accent="amber" />
            <StatCard label="Missions done" value={`${completedCount}/${totalMissions}`} icon={<Trophy className="h-4 w-4 text-emerald-400" />} accent="emerald" />
            <StatCard label="Stars earned" value={`${starsCount}`} icon={<span className="text-sm">⭐</span>} accent="amber" />
          </motion.div>
        </div>
      </section>

      <section className="w-full px-4 sm:px-6">
        <Card className="glass-strong relative overflow-hidden p-5 sm:p-6">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="grid h-14 w-14 place-items-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-2xl shadow-lg shadow-orange-500/30">
                {rank.emoji}
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Current rank</div>
                <div className="text-xl font-bold">{rank.title}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {next ? (
                    <>
                      <span className="text-amber-300">{nextXp - xp} XP</span> until {next.emoji} {next.title}
                    </>
                  ) : (
                    <span className="text-amber-300">Maximum rank achieved 👑</span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex-1 sm:max-w-md">
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">XP progress</span>
                <span className="text-muted-foreground">
                  {xp.toLocaleString()} / {next ? nextXp.toLocaleString() : xp.toLocaleString()}
                </span>
              </div>
              <div className="xp-bar h-2.5 rounded-full bg-muted">
                <div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500" style={{ width: `${progressPct}%` }} />
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
                <MiniStat label="Avg Score" value={`${avgScore}%`} />
                <MiniStat label="Services" value={`${discovered.length}`} />
                <MiniStat label="Badges" value={`${badges.length}/${BADGES.length}`} />
              </div>
            </div>
          </div>
        </Card>
      </section>

      <section className="w-full px-4 py-10 sm:px-6">
        <div className="mb-5 flex items-end justify-between gap-3">
          <div>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Campaign</h2>
            <p className="text-sm text-muted-foreground">A long-form journey across 4 chapters and 20 missions.</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView("services")} className="hidden sm:flex shrink-0">
            Browse services <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
          </Button>
        </div>

        <div className="space-y-8">
          {Object.entries(chapters).map(([chStr, missions]) => {
            const chNum = Number(chStr);
            const chTitle = missions[0].chapterTitle;
            const doneInCh = missions.filter((m) => completed[m.id]).length;
            return (
              <div key={chStr}>
                <div className="mb-3 flex items-center gap-3">
                  <div className="grid h-9 w-9 place-items-center rounded-lg bg-accent/60 text-sm font-bold text-amber-300">
                    {chNum}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                      Chapter {chNum} · {chTitle}
                    </h3>
                    <p className="text-xs text-muted-foreground">{doneInCh}/{missions.length} missions complete</p>
                  </div>
                  <div className="ml-4 hidden flex-1 sm:block">
                    <Progress value={(doneInCh / missions.length) * 100} className="h-1.5" />
                  </div>
                </div>
                <div className="grid w-full grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {missions.map((m) => (
                    <MissionCard key={m.id} mission={m} unlocked={unlocked.includes(m.id)} completed={completed[m.id]} onOpen={() => openMission(m.id)} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="w-full px-4 py-10 sm:px-6">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Badges</h2>
            <p className="text-sm text-muted-foreground">Earn achievements as you master AWS.</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView("profile")} className="hidden sm:flex shrink-0">
            View all <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
          </Button>
        </div>
        <div className="grid w-full grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {BADGES.slice(0, 12).map((b) => {
            const earned = badges.includes(b.id);
            return (
              <Card key={b.id} className={`relative flex flex-col items-center gap-2 p-4 text-center transition-all ${earned ? "glass-strong border-amber-500/40" : "opacity-50 grayscale"}`}>
                <div className="text-3xl">{b.emoji}</div>
                <div className="text-xs font-semibold leading-tight">{b.name}</div>
                <div className="text-[10px] leading-tight text-muted-foreground">{b.description}</div>
                {earned && <UiBadge className="absolute -right-1 -top-1 bg-amber-500 text-[9px] text-black">EARNED</UiBadge>}
              </Card>
            );
          })}
        </div>
      </section>

      <section className="w-full px-4 py-10 sm:px-6">
        <div className="mb-4">
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">AWS Services You'll Master</h2>
          <p className="text-sm text-muted-foreground">Click any service in-game to learn what it is, why it exists, and how to use it.</p>
        </div>
        <div className="grid w-full grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {Object.values(SERVICE_CATALOG).filter((s) => s.placeable).slice(0, 12).map((s) => {
            const discoveredIt = discovered.includes(s.id);
            return (
              <Card key={s.id} className="group glass flex cursor-pointer flex-col gap-2 p-4 transition-all hover:translate-y-[-2px] hover:border-amber-500/40" onClick={() => useGame.getState().setShowServiceCard(s.id)}>
                <div className="grid h-10 w-10 place-items-center rounded-lg text-xl" style={{ background: `${s.color}22`, border: `1px solid ${s.color}55` }}>
                  {s.icon}
                </div>
                <div>
                  <div className="text-sm font-bold">{s.label}</div>
                  <div className="text-[11px] text-muted-foreground">{s.awsName}</div>
                </div>
                <p className="text-[11px] leading-tight text-muted-foreground">{s.summary}</p>
                {discoveredIt && <UiBadge variant="outline" className="w-fit border-emerald-500/40 text-emerald-400 text-[9px]">Discovered</UiBadge>}
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
}

function StatCard({ label, value, icon, accent }: { label: string; value: string; icon: React.ReactNode; accent: "amber" | "emerald" }) {
  return (
    <div className={`relative overflow-hidden rounded-xl border p-4 ${accent === "amber" ? "border-amber-500/30 bg-amber-500/[0.07]" : "border-emerald-500/30 bg-emerald-500/[0.07]"}`}>
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <div className="mt-1.5 text-xl font-bold tracking-tight">{value}</div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-card/50 px-2 py-1.5">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-sm font-semibold">{value}</div>
    </div>
  );
}

function MissionCard({ mission, unlocked, completed, onOpen }: { mission: Mission; unlocked: boolean; completed?: { stars: 1 | 2 | 3; score: { total: number } }; onOpen: () => void }) {
  const diffColor = ["#10b981", "#84cc16", "#f59e0b", "#f97316", "#ef4444"][mission.difficulty - 1];
  return (
    <Card
      onClick={unlocked ? onOpen : undefined}
      className={`group relative flex w-full flex-col gap-3 p-4 transition-all ${unlocked ? "glass-strong cursor-pointer hover:translate-y-[-2px] hover:border-amber-500/40 hover:shadow-lg hover:shadow-amber-500/10" : "opacity-60"}`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-accent/60 text-sm font-bold text-amber-300">
            {mission.index}
          </div>
          <div className="flex min-w-0 flex-col">
            <span className="truncate text-[10px] uppercase tracking-wider text-muted-foreground">{mission.company}</span>
            <span className="truncate text-xs text-muted-foreground">{mission.tagline}</span>
          </div>
        </div>
        {completed ? (
          <div className="flex shrink-0 gap-0.5 text-xs">
            {Array.from({ length: 3 }).map((_, i) => (
              <span key={i} className={i < completed.stars ? "text-amber-400" : "text-muted-foreground/30"}>★</span>
            ))}
          </div>
        ) : unlocked ? (
          <UiBadge variant="outline" className="shrink-0 text-[9px] text-emerald-400 border-emerald-500/40">NEW</UiBadge>
        ) : (
          <UiBadge variant="outline" className="shrink-0 text-[9px] text-muted-foreground">LOCKED</UiBadge>
        )}
      </div>
      <div>
        <div className="text-sm font-bold leading-tight">{mission.title}</div>
      </div>
      <div className="mt-auto flex items-center justify-between gap-2 text-[10px] text-muted-foreground">
        <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium" style={{ background: `${diffColor}22`, color: diffColor }}>
          <Flame className="h-2.5 w-2.5" />
          {["Easy", "Easy", "Medium", "Hard", "Expert"][mission.difficulty - 1]}
        </span>
        <span>${mission.budget}/mo</span>
        <span>{mission.xpReward} XP</span>
      </div>
      {unlocked && <div className="absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-gradient-to-r from-transparent via-amber-500/60 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />}
    </Card>
  );
}
