"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useGame } from "@/lib/game/store";
import { SERVICE_CATALOG, CATEGORY_META } from "@/lib/game/services";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge as UiBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Lightbulb, AlertTriangle, Workflow, Zap, DollarSign } from "lucide-react";

export function ServiceCardModal() {
  const showId = useGame((s) => s.showServiceCard);
  const setShow = useGame((s) => s.setShowServiceCard);
  const svc = showId ? SERVICE_CATALOG[showId] : null;

  return (
    <Dialog open={!!showId} onOpenChange={(o) => !o && setShow(null)}>
      <DialogContent aria-describedby={undefined} className="max-w-md overflow-hidden p-0 gap-0">
        <AnimatePresence mode="wait">
          {svc && (
            <motion.div
              key={svc.id}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.22 }}
            >
              <div
                className="relative overflow-hidden px-5 pt-5 pb-4"
                style={{
                  background: `linear-gradient(135deg, ${svc.color}22 0%, transparent 80%)`,
                  borderBottom: `1px solid ${svc.color}33`,
                }}
              >
                <div className="flex items-start gap-3">
                  <motion.div
                    initial={{ scale: 0.5, rotate: -20 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 260, damping: 16, delay: 0.05 }}
                    className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-3xl shadow-lg"
                    style={{
                      background: `${svc.color}26`,
                      border: `1px solid ${svc.color}66`,
                      boxShadow: `0 8px 24px -6px ${svc.color}50`,
                    }}
                  >
                    {svc.icon}
                  </motion.div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <DialogTitle className="text-lg font-bold leading-tight">{svc.label}</DialogTitle>
                      <UiBadge
                        variant="outline"
                        className="shrink-0 text-[10px]"
                        style={{ color: svc.color, borderColor: `${svc.color}55` }}
                      >
                        {CATEGORY_META[svc.category].label}
                      </UiBadge>
                    </div>
                    <DialogDescription className="text-[11px] text-muted-foreground">{svc.awsName}</DialogDescription>
                  </div>
                  <div className="flex shrink-0 items-center gap-1 rounded-full border border-amber-500/40 bg-amber-500/[0.1] px-2.5 py-1 text-xs font-bold text-amber-300">
                    <DollarSign className="h-3 w-3" />
                    {svc.baseCost}
                    <span className="text-[9px] font-normal text-muted-foreground">/mo</span>
                  </div>
                </div>
              </div>

              <div className="max-h-[60vh] overflow-y-auto scroll-thin">
                <div className="space-y-4 px-5 py-4">
                  <p className="text-sm leading-relaxed text-foreground/90">{svc.summary}</p>

                  <div
                    className="rounded-xl border p-3"
                    style={{
                      borderColor: `${svc.color}44`,
                      background: `${svc.color}10`,
                    }}
                  >
                    <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      <Lightbulb className="h-3 w-3 text-amber-400" />
                      In plain English
                    </div>
                    <p className="text-sm italic leading-snug" style={{ color: `${svc.color}` }}>
                      &ldquo;{svc.analogy}&rdquo;
                    </p>
                  </div>

                  <div>
                    <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      <Workflow className="h-3 w-3 text-emerald-400" />
                      Use it for
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {svc.useCases.map((u, i) => (
                        <span key={i} className="rounded-full border border-emerald-500/30 bg-emerald-500/[0.07] px-2.5 py-1 text-[11px] text-emerald-200">
                          {u}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      <AlertTriangle className="h-3 w-3 text-red-400" />
                      Watch out
                    </div>
                    <div className="space-y-1.5">
                      {svc.commonMistakes.map((m, i) => (
                        <div key={i} className="flex items-start gap-2 rounded-md border border-red-500/20 bg-red-500/[0.05] px-2.5 py-1.5">
                          <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-red-400" />
                          <span className="text-[11px] leading-snug text-red-200/90">{m}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      <Zap className="h-3 w-3 text-amber-400" />
                      Connects to
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {svc.connectsTo.map((cid) => {
                        const c = SERVICE_CATALOG[cid];
                        if (!c) return null;
                        return (
                          <button
                            key={cid}
                            onClick={() => useGame.getState().setShowServiceCard(cid)}
                            className="flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors hover:bg-accent/40"
                            style={{ borderColor: `${c.color}55`, color: c.color }}
                          >
                            <span>{c.icon}</span>
                            <span className="text-foreground">{c.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-border/40 bg-card/40 p-3">
                <Button onClick={() => setShow(null)} variant="default" size="sm" className="w-full">
                  Got it
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
