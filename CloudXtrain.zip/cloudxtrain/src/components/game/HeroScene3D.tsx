"use client";

import { Canvas } from "@react-three/fiber";
import { Sparkles } from "@react-three/drei";

export function HeroScene3D() {
  return (
    <Canvas
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true }}
      style={{ background: "transparent" }}
    >
      <Sparkles
        count={140}
        scale={24}
        size={3.5}
        speed={0.3}
        color="#ff9900"
        opacity={0.7}
        noise={1.5}
      />
    </Canvas>
  );
}
