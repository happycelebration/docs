"use client";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="mt-auto border-t border-border/40 bg-card/30">
      <div className="w-full px-4 py-5 text-center sm:px-6">
        <p className="text-xs text-muted-foreground">
          © {year} CloudXtrain by Pallavi Thakur. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
