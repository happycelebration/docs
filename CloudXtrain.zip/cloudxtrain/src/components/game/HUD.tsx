"use client";

import { Cloud, Zap, Trophy, Settings, BookOpen } from "lucide-react";
import { toast } from "sonner";
import { useGame, useCurrentRank } from "@/lib/game/store";
import { RANKS, nextRank } from "@/lib/game/missions";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Volume2, VolumeX, Sparkles, RotateCcw } from "lucide-react";

export function HUD() {
  const xp = useGame((s) => s.xp);
  const setView = useGame((s) => s.setView);
  const view = useGame((s) => s.view);
  const completedCount = Object.keys(useGame((s) => s.completedMissions)).length;
  const earnedBadges = useGame((s) => s.earnedBadgeIds).length;
  const soundEnabled = useGame((s) => s.soundEnabled);
  const reducedMotion = useGame((s) => s.reducedMotion);
  const toggleSound = useGame((s) => s.toggleSound);
  const toggleReducedMotion = useGame((s) => s.toggleReducedMotion);
  const resetGame = useGame((s) => s.resetGame);

  const rank = useCurrentRank();
  const next = nextRank(xp);
  const prevXp = rank.minXp;
  const nextXp = next?.minXp ?? xp;
  const progress = next ? Math.min(100, Math.max(0, ((xp - prevXp) / (nextXp - prevXp)) * 100)) : 100;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/40 bg-background/70 backdrop-blur-xl">
      <div className="flex h-14 w-full items-center gap-2 px-3 sm:h-16 sm:gap-3 sm:px-4 lg:px-6">
        <button onClick={() => setView("home")} className="flex shrink-0 items-center gap-2 transition-opacity hover:opacity-90">
          <div className="relative grid h-8 w-8 place-items-center overflow-hidden rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 shadow-lg shadow-orange-500/30 sm:h-9 sm:w-9">
            <Cloud className="h-4 w-4 text-white sm:h-5 sm:w-5" />
          </div>
          <span className="text-sm font-bold tracking-tight">CloudXtrain</span>
        </button>

        <nav className="ml-1 hidden items-center gap-1 sm:flex sm:ml-2">
          <NavTab id="home" label="Home" icon={<Cloud className="h-4 w-4" />} setView={setView} active={view === "home"} />
          <NavTab id="services" label="Services" icon={<BookOpen className="h-4 w-4" />} setView={setView} active={view === "services"} />
          <NavTab id="profile" label="Profile" icon={<Trophy className="h-4 w-4" />} setView={setView} active={view === "profile"} />
        </nav>

        <div className="flex-1" />

        <div className="hidden items-center gap-3 rounded-full border border-border/50 bg-card/40 px-3 py-1.5 md:flex">
          <span className="text-base leading-none">{rank.emoji}</span>
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Rank</span>
            <span className="text-xs font-semibold">{rank.title}</span>
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">XP</span>
            <span className="text-xs font-semibold text-amber-300">{xp.toLocaleString()}</span>
          </div>
          <div className="w-20">
            <Progress value={progress} className="h-1.5 bg-muted" />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 rounded-full border border-border/40 bg-card/40 px-2.5 py-1 text-xs">
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span className="font-semibold">{completedCount}</span>
            <span className="hidden text-muted-foreground sm:inline">missions</span>
          </div>
          <div className="hidden items-center gap-1.5 rounded-full border border-border/40 bg-card/40 px-2.5 py-1 text-xs sm:flex">
            <Trophy className="h-3.5 w-3.5 text-emerald-400" />
            <span className="font-semibold">{earnedBadges}</span>
            <span className="hidden text-muted-foreground md:inline">badges</span>
          </div>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 rounded-full">
              <Settings className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Settings</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={toggleSound}>
              {soundEnabled ? <Volume2 className="mr-2 h-4 w-4" /> : <VolumeX className="mr-2 h-4 w-4" />}
              Sound: {soundEnabled ? "On" : "Off"}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={toggleReducedMotion}>
              <Sparkles className="mr-2 h-4 w-4" />
              Reduced motion: {reducedMotion ? "On" : "Off"}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => {
                toast("Reset all progress?", {
                  description: "This will erase your XP, badges, and mission progress. This cannot be undone.",
                  duration: 7000,
                  action: {
                    label: "Reset",
                    onClick: () => {
                      resetGame();
                      toast.success("Progress reset", {
                        description: "Welcome back to Cloud Beginner.",
                      });
                    },
                  },
                  cancel: {
                    label: "Cancel",
                    onClick: () => {},
                  },
                  style: { borderColor: "oklch(0.65 0.22 22 / 0.4)" },
                });
              }}
              className="text-red-400 focus:text-red-400"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset progress
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

function NavTab({ id, label, icon, setView, active }: { id: "home" | "services" | "profile" | "leaderboard"; label: string; icon: React.ReactNode; setView: (v: "home" | "services" | "profile" | "leaderboard") => void; active: boolean }) {
  return (
    <button onClick={() => setView(id)} className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm transition-colors ${active ? "bg-accent/60 text-foreground" : "text-muted-foreground hover:bg-accent/30 hover:text-foreground"}`}>
      {icon}
      <span>{label}</span>
    </button>
  );
}
