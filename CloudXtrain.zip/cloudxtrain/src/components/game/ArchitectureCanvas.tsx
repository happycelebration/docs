"use client";

import { useRef, useState, useMemo, useEffect, useCallback } from "react";
import { Canvas, useThree, useFrame, type ThreeEvent } from "@react-three/fiber";
import { OrbitControls, Line, Html, RoundedBox } from "@react-three/drei";
import * as THREE from "three";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import type { PlacedResource, ResourceTypeId, ServiceCategory } from "@/lib/game/types";
import { SERVICE_CATALOG, CATEGORY_META } from "@/lib/game/services";
import { useGame } from "@/lib/game/store";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Search, Plus, Settings2, X, Zap } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ResourceConfigSheet } from "./ResourceNode";

const STATE_COLORS: Record<string, string> = {
  running: "#10b981",
  available: "#10b981",
  ready: "#84cc16",
  healthy: "#10b981",
  pending: "#f59e0b",
  stopping: "#f59e0b",
  stopped: "#94a3b8",
  terminated: "#94a3b8",
  unhealthy: "#ef4444",
  failed: "#ef4444",
  denied: "#ef4444",
  timedout: "#ef4444",
};

const SCALE = 1;
const RESOURCE_SIZE = 0.9;
const NODE_HEIGHT = 0.6;

type Vec3Tuple = [number, number, number];

function toWorld(px: number, py: number): Vec3Tuple {
  const wx = (px - 400) / 60;
  const wz = (py - 280) / 60;
  return [wx, NODE_HEIGHT, wz];
}

function toScreen(wx: number, wz: number): { x: number; y: number } {
  return { x: wx * 60 + 400, y: wz * 60 + 280 };
}

export function ArchitectureCanvas() {
  const arch = useGame((s) => s.activeArchitecture);
  const placeResource = useGame((s) => s.placeResource);
  const disconnectResources = useGame((s) => s.disconnectResources);
  const isSimulating = useGame((s) => s.isSimulating);
  const hasDeployed = useGame((s) => s.hasDeployed);
  const [selected, setSelected] = useState<string | null>(null);
  const [configId, setConfigId] = useState<string | null>(null);
  const [pendingPlace, setPendingPlace] = useState<ResourceTypeId | null>(null);
  const [connectFrom, setConnectFrom] = useState<string | null>(null);

  const resById = useMemo(() => {
    const m: Record<string, PlacedResource> = {};
    arch.resources.forEach((r) => (m[r.id] = r));
    return m;
  }, [arch.resources]);

  const handlePlaceOnPlane = useCallback((worldX: number, worldZ: number) => {
    if (!pendingPlace) return;
    const screen = toScreen(worldX, worldZ);
    placeResource(pendingPlace, screen.x, screen.y);
    setPendingPlace(null);
  }, [pendingPlace, placeResource]);

  return (
    <div className="relative h-full w-full overflow-hidden rounded-xl border border-border/40 bg-card/30">
      <div className="absolute inset-0 bg-aurora opacity-50" />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(circle at 30% 20%, oklch(0.72 0.19 55 / 0.10), transparent 60%), radial-gradient(circle at 70% 80%, oklch(0.72 0.16 162 / 0.08), transparent 60%)",
        }}
      />

      <AnimatePresence>
        {isSimulating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-30 flex items-center justify-center bg-background/60 backdrop-blur-sm"
          >
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="relative h-12 w-12">
                <motion.div
                  className="absolute inset-0 rounded-full border-4 border-amber-500/30 border-t-amber-400"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                />
              </div>
              <div className="text-sm font-medium text-amber-300">Simulating deployment...</div>
              <div className="text-[11px] text-muted-foreground">Evaluating rules, generating metrics and logs</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {pendingPlace && (
        <div className="absolute left-3 top-3 z-20 rounded-full bg-emerald-500 px-3 py-1 text-xs font-medium text-white shadow-lg">
          Click anywhere on the canvas to place {SERVICE_CATALOG[pendingPlace].label}
          <button className="ml-2 text-white/80 hover:text-white" onClick={() => setPendingPlace(null)}>cancel</button>
        </div>
      )}

      <div className="absolute inset-0">
        <Canvas3DScene
          resources={arch.resources}
          connections={arch.connections}
          hasDeployed={hasDeployed}
          selected={selected}
          setSelected={setSelected}
          setConnectFrom={setConnectFrom}
          connectFrom={connectFrom}
          onConfig={(id) => setConfigId(id)}
          onRemove={(id) => useGame.getState().removeResource(id)}
          onConnect={(from, to) => useGame.getState().connectResources(from, to)}
          onMove={(id, x, z) => {
            const screen = toScreen(x, z);
            useGame.getState().moveResource(id, screen.x, screen.y);
          }}
          onPlaceOnPlane={handlePlaceOnPlane}
          pendingPlace={pendingPlace}
          resById={resById}
          onDisconnect={disconnectResources}
        />
      </div>

      {arch.resources.length === 0 && !pendingPlace && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center px-4 text-center">
          <div className="max-w-sm">
            <div className="mb-2 text-4xl opacity-50 float-slow">☁️</div>
            <div className="text-sm font-medium">Your 3D canvas is empty</div>
            <div className="text-xs text-muted-foreground">
              Open the <span className="font-medium text-emerald-400">Services</span> panel,
              then double-tap a service (or drag it here) to place it in 3D space.
            </div>
          </div>
        </div>
      )}

      <ResourceConfigSheet resourceId={configId} onClose={() => setConfigId(null)} />
    </div>
  );
}

function Canvas3DScene({
  resources,
  connections,
  hasDeployed,
  selected,
  setSelected,
  setConnectFrom,
  connectFrom,
  onConfig,
  onRemove,
  onConnect,
  onMove,
  onPlaceOnPlane,
  pendingPlace,
  resById,
  onDisconnect,
}: {
  resources: PlacedResource[];
  connections: { from: string; to: string; kind: string }[];
  hasDeployed: boolean;
  selected: string | null;
  setSelected: (id: string | null) => void;
  setConnectFrom: (id: string | null) => void;
  connectFrom: string | null;
  onConfig: (id: string) => void;
  onRemove: (id: string) => void;
  onConnect: (from: string, to: string) => void;
  onMove: (id: string, x: number, z: number) => void;
  onPlaceOnPlane: (x: number, z: number) => void;
  pendingPlace: ResourceTypeId | null;
  resById: Record<string, PlacedResource>;
  onDisconnect: (from: string, to: string) => void;
}) {
  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      camera={{ position: [0, 6, 8], fov: 50 }}
      gl={{ antialias: true, alpha: true }}
      style={{ background: "transparent" }}
    >
      <ambientLight intensity={0.55} />
      <directionalLight position={[5, 10, 5]} intensity={1.6} castShadow shadow-mapSize={[1024, 1024]} />
      <pointLight position={[-6, 4, -4]} intensity={1.0} color="#ff5a00" />
      <pointLight position={[6, 4, -2]} intensity={0.8} color="#4b9f87" />

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial color="#0a0a0f" transparent opacity={0.3} metalness={0.4} roughness={0.8} />
      </mesh>

      <gridHelper args={[40, 40, "#1a1a25", "#0f0f15"]} position={[0, 0.001, 0]} />

      {pendingPlace && (
        <PlacementPlane onPlace={onPlaceOnPlane} />
      )}

      {resources.map((r) => (
        <ResourceMesh3D
          key={r.id}
          resource={r}
          selected={selected === r.id}
          onSelect={(id) => {
            setSelected(id);
            if (connectFrom && connectFrom !== id) {
              onConnect(connectFrom, id);
              setConnectFrom(null);
            } else if (connectFrom === id) {
              setConnectFrom(null);
            }
          }}
          onConfig={onConfig}
          onRemove={onRemove}
          onMove={onMove}
          isConnectSource={connectFrom === r.id}
          onSetConnectFrom={setConnectFrom}
        />
      ))}

      {connections.map((c, i) => {
        const f = resById[c.from];
        const t = resById[c.to];
        if (!f || !t) return null;
        const fWorld = toWorld(f.x, f.y);
        const tWorld = toWorld(t.x, t.y);
        const hasIssue =
          f.health < 60 || t.health < 60 ||
          f.state === "unhealthy" || t.state === "unhealthy" ||
          f.state === "failed" || t.state === "failed" ||
          f.state === "denied" || t.state === "denied";
        const color = hasIssue ? "#ef4444" : hasDeployed ? "#10b981" : "#94a3b8";
        return (
          <Connection3D
            key={`${c.from}-${c.to}-${i}`}
            from={fWorld}
            to={tWorld}
            color={color}
            hasDeployed={hasDeployed}
            hasIssue={hasIssue}
            index={i}
            onDisconnect={() => onDisconnect(c.from, c.to)}
          />
        );
      })}

      <OrbitControls
        enablePan={false}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2.4}
        minDistance={5}
        maxDistance={18}
        enableDamping
        dampingFactor={0.08}
      />
    </Canvas>
  );
}

function PlacementPlane({ onPlace }: { onPlace: (x: number, z: number) => void }) {
  const onPointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    const point = e.point;
    onPlace(point.x, point.z);
  };
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]} onPointerDown={onPointerDown}>
      <planeGeometry args={[40, 40]} />
      <meshStandardMaterial color="#ff9900" transparent opacity={0.05} emissive="#ff9900" emissiveIntensity={0.1} />
    </mesh>
  );
}

function ResourceMesh3D({
  resource,
  selected,
  onSelect,
  onConfig,
  onRemove,
  onMove,
  isConnectSource,
  onSetConnectFrom,
}: {
  resource: PlacedResource;
  selected: boolean;
  onSelect: (id: string) => void;
  onConfig: (id: string) => void;
  onRemove: (id: string) => void;
  onMove: (id: string, x: number, z: number) => void;
  isConnectSource: boolean;
  onSetConnectFrom: (id: string | null) => void;
}) {
  const ref = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [dragging, setDragging] = useState(false);
  const dragOffset = useRef(new THREE.Vector2());

  const { raycaster, camera, gl } = useThree();
  const dragPlane = useMemo(() => new THREE.Plane(new THREE.Vector3(0, 1, 0), -NODE_HEIGHT), []);

  const svc = SERVICE_CATALOG[resource.type];
  const stateColor = STATE_COLORS[resource.state] ?? "#94a3b8";
  const health = resource.health ?? 100;
  const worldPos = toWorld(resource.x, resource.y);

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.getElapsedTime();
    if (!dragging) {
      ref.current.position.y = NODE_HEIGHT + Math.sin(t * 1.4 + resource.x * 0.01) * 0.08;
    }
    ref.current.rotation.y = t * 0.25;
  });

  const onPointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(true);
    document.body.style.cursor = "grab";
  };

  const onPointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(false);
    document.body.style.cursor = "auto";
  };

  const onPointerDown = (e: ThreeEvent<PointerEvent>) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    onSelect(resource.id);
    setDragging(true);
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    const point = e.point;
    const screenPos = toScreen(point.x, point.z);
    const myScreen = toScreen(worldPos[0], worldPos[2]);
    dragOffset.current.set(myScreen.x - screenPos.x, myScreen.y - screenPos.y);
  };

  const onPointerMove = (e: ThreeEvent<PointerEvent>) => {
    if (!dragging) return;
    e.stopPropagation();
    const point = e.point;
    const screen = toScreen(point.x, point.z);
    const newScreen = { x: screen.x + dragOffset.current.x, y: screen.y + dragOffset.current.y };
    const world = toScreenToW(newScreen.x, newScreen.y);
    onMove(resource.id, world[0], world[2]);
  };

  const onPointerUp = (e: ThreeEvent<PointerEvent>) => {
    setDragging(false);
    (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
  };

  const hoverScale = hovered ? 1.12 : 1;
  const selectedScale = selected ? 1.18 : hoverScale;

  return (
    <group>
      <RoundedBox
        ref={ref}
        args={[RESOURCE_SIZE, RESOURCE_SIZE, RESOURCE_SIZE]}
        radius={0.12}
        smoothness={6}
        position={worldPos}
        castShadow
        receiveShadow
        scale={selectedScale}
        onPointerOver={onPointerOver}
        onPointerOut={onPointerOut}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
      >
        <meshStandardMaterial
          color={svc.color}
          emissive={svc.color}
          emissiveIntensity={hovered || selected ? 0.55 : 0.3}
          roughness={0.22}
          metalness={0.65}
          clearcoat={0.4}
        />
      </RoundedBox>

      <mesh position={[worldPos[0], NODE_HEIGHT - 0.2, worldPos[2]]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.55, 0.7, 32]} />
        <meshBasicMaterial color={stateColor} transparent opacity={0.6} side={THREE.DoubleSide} />
      </mesh>

      <Html
        position={[worldPos[0], NODE_HEIGHT + 0.95, worldPos[2]]}
        center
        distanceFactor={9}
        zIndexRange={[20, 0]}
      >
        <div
          className={`resource-label group flex w-24 cursor-pointer select-none flex-col items-center gap-1 rounded-xl border p-2 backdrop-blur-md transition-all ${selected ? "ring-2 ring-amber-400" : ""} ${isConnectSource ? "ring-2 ring-emerald-400" : ""}`}
          style={{
            background: `${svc.color}26`,
            borderColor: `${svc.color}66`,
            boxShadow: `0 8px 24px -6px ${svc.color}50, inset 0 1px 0 oklch(1 0 0 / 0.1)`,
          }}
          onPointerDown={(e) => { e.stopPropagation(); onSelect(resource.id); }}
        >
          <div
            className="grid h-9 w-9 place-items-center rounded-lg text-lg"
            style={{ background: `${svc.color}40`, border: `1px solid ${svc.color}80` }}
          >
            {svc.icon}
          </div>
          <div className="text-center text-[10px] font-semibold leading-tight text-white">{svc.shortName}</div>
          <div className="flex items-center gap-1 text-[9px]">
            <span className="pulse-dot h-1.5 w-1.5 rounded-full" style={{ background: stateColor, color: stateColor }} />
            <span style={{ color: stateColor }} className="font-medium">{resource.state}</span>
          </div>
          <div className="h-1 w-14 overflow-hidden rounded-full bg-black/40">
            <div className="h-full transition-all" style={{ width: `${health}%`, background: health > 70 ? "#10b981" : health > 40 ? "#f59e0b" : "#ef4444" }} />
          </div>

          <div className="pointer-events-auto absolute -right-2 -top-2 flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
            <button
              className="grid h-5 w-5 place-items-center rounded-full bg-emerald-500 text-white shadow hover:bg-emerald-400"
              onClick={(e) => { e.stopPropagation(); onSetConnectFrom(isConnectSource ? null : resource.id); }}
              title="Connect from this resource"
            >
              <Zap className="h-3 w-3" />
            </button>
            <button
              className="grid h-5 w-5 place-items-center rounded-full bg-blue-500 text-white shadow hover:bg-blue-400"
              onClick={(e) => { e.stopPropagation(); onConfig(resource.id); }}
              title="Configure"
            >
              <Settings2 className="h-3 w-3" />
            </button>
            <button
              className="grid h-5 w-5 place-items-center rounded-full bg-red-500 text-white shadow hover:bg-red-400"
              onClick={(e) => {
                e.stopPropagation();
                toast(`Remove ${svc.label}?`, {
                  description: "The resource and its connections will be removed.",
                  duration: 5000,
                  action: {
                    label: "Remove",
                    onClick: () => onRemove(resource.id),
                  },
                });
              }}
              title="Remove"
            >
              <X className="h-3 w-3" />
            </button>
          </div>

          {isConnectSource && (
            <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-emerald-500 px-2 py-0.5 text-[9px] font-medium text-white shadow">
              click target →
            </div>
          )}
        </div>
      </Html>
    </group>
  );
}

function toScreenToW(screenX: number, screenY: number): Vec3Tuple {
  return [(screenX - 400) / 60, NODE_HEIGHT, (screenY - 280) / 60];
}

function Connection3D({
  from,
  to,
  color,
  hasDeployed,
  hasIssue,
  index,
  onDisconnect,
}: {
  from: Vec3Tuple;
  to: Vec3Tuple;
  color: string;
  hasDeployed: boolean;
  hasIssue: boolean;
  index: number;
  onDisconnect: () => void;
}) {
  const curve = useMemo(() => {
    const start = new THREE.Vector3(from[0], NODE_HEIGHT, from[2]);
    const end = new THREE.Vector3(to[0], NODE_HEIGHT, to[2]);
    const mid = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);
    const dist = start.distanceTo(end);
    mid.y += Math.max(0.8, dist * 0.3);
    return new THREE.QuadraticBezierCurve3(start, mid, end);
  }, [from, to]);

  const points = useMemo(() => curve.getPoints(28), [curve]);

  return (
    <group>
      <Line
        points={points}
        color={color}
        lineWidth={hasDeployed ? 4 : 2.5}
        transparent
        opacity={hasDeployed ? 0.85 : 0.6}
        dashed={!hasDeployed}
        dashSize={0.15}
        gapSize={0.12}
      />
      {hasDeployed && (
        <MovingPacket curve={curve} color={color} duration={hasIssue ? 1.4 : 1.8} delay={index * 0.3} size={hasIssue ? 0.14 : 0.11} />
      )}
    </group>
  );
}

function MovingPacket({
  curve,
  color,
  duration,
  delay,
  size,
}: {
  curve: THREE.QuadraticBezierCurve3;
  color: string;
  duration: number;
  delay: number;
  size: number;
}) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (!ref.current) return;
    const t = ((state.clock.getElapsedTime() + delay) % duration) / duration;
    const point = curve.getPointAt(t);
    ref.current.position.copy(point);
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[size, 16, 16]} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={2.2} />
    </mesh>
  );
}

export function ResourcePalette({ missionPalette }: { missionPalette: ResourceTypeId[] }) {
  const [query, setQuery] = useState("");
  const placeResource = useGame((s) => s.placeResource);

  const grouped = useMemo(() => {
    const g: Record<ServiceCategory, ResourceTypeId[]> = {} as any;
    for (const id of missionPalette) {
      const svc = SERVICE_CATALOG[id];
      if (!svc) continue;
      const c = svc.category;
      (g[c] ??= []).push(id);
    }
    return g;
  }, [missionPalette]);

  const filtered = (ids: ResourceTypeId[]) =>
    ids.filter((id) => {
      const s = SERVICE_CATALOG[id];
      if (!s) return false;
      const q = query.toLowerCase();
      return !q || s.label.toLowerCase().includes(q) || s.awsName.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q);
    });

  return (
    <div className="flex h-full flex-col gap-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search AWS services..." value={query} onChange={(e) => setQuery(e.target.value)} className="h-9 pl-9 text-sm" />
      </div>
      <ScrollArea className="flex-1 rounded-lg border border-border/40 bg-card/40 pr-2">
        <div className="p-2">
          <Accordion type="multiple" defaultValue={Object.keys(grouped)} className="w-full">
            {Object.entries(grouped).map(([cat, ids]) => {
              const filteredIds = filtered(ids);
              if (filteredIds.length === 0) return null;
              const meta = CATEGORY_META[cat as ServiceCategory];
              return (
                <AccordionItem key={cat} value={cat} className="border-border/30">
                  <AccordionTrigger className="py-2 text-sm hover:no-underline">
                    <div className="flex items-center gap-2">
                      <span>{meta.emoji}</span>
                      <span className="font-semibold">{meta.label}</span>
                      <span className="ml-1 rounded-full bg-accent/60 px-1.5 py-0.5 text-[10px] text-muted-foreground">{filteredIds.length}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-1">
                    <div className="space-y-1">
                      {filteredIds.map((id) => {
                        const s = SERVICE_CATALOG[id];
                        return <PaletteItem key={id} id={id} onPlace={() => placeResource(id, 60 + Math.random() * 200, 60 + Math.random() * 150)} />;
                      })}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </div>
      </ScrollArea>
    </div>
  );
}

function PaletteItem({ id, onPlace }: { id: ResourceTypeId; onPlace: () => void }) {
  const s = SERVICE_CATALOG[id];
  const setShowServiceCard = useGame((st) => st.setShowServiceCard);
  const discovered = useGame((st) => st.discoveredServiceIds.includes(id));
  return (
    <div
      draggable
      onDragStart={(e) => { e.dataTransfer.setData("application/x-cloudxtrain-service", id); }}
      onDoubleClick={onPlace}
      className="group flex cursor-grab items-center gap-2.5 rounded-lg border border-transparent p-2 transition-all hover:border-border/60 hover:bg-accent/40 active:cursor-grabbing"
      title={s.summary}
    >
      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-md text-base" style={{ background: `${s.color}22`, border: `1px solid ${s.color}44` }}>
        {s.icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-xs font-semibold">{s.label}</span>
          {discovered && <span className="h-1 w-1 rounded-full bg-emerald-400" title="Discovered" />}
        </div>
        <div className="truncate text-[10px] text-muted-foreground">{s.awsName}</div>
      </div>
      <button
        onClick={(e) => { e.stopPropagation(); setShowServiceCard(id); }}
        className="opacity-0 transition-opacity group-hover:opacity-100"
        title="Learn about this service"
      >
        <Plus className="h-3.5 w-3.5 text-muted-foreground" />
      </button>
    </div>
  );
}
