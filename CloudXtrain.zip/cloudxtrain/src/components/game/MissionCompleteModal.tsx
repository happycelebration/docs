"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGame } from "@/lib/game/store";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogHeader,
  DialogFooter,
} from "@/components/ui/dialog";
import { Trophy, Zap, Star, ArrowRight, RotateCcw, AlertTriangle, CheckCircle2, Sparkles } from "lucide-react";

export function MissionCompleteModal() {
  const mission = useGame((s) => s.getActiveMission());
  const satisfied = useGame((s) => s.activeSatisfied);
  const score = useGame((s) => s.activeScore);
  const hasDeployed = useGame((s) => s.hasDeployed);
  const completeMission = useGame((s) => s.completeMission);
  const resetActiveMission = useGame((s) => s.resetActiveMission);
  const exitMission = useGame((s) => s.exitMission);
  const hintsUsed = useGame((s) => s.activeHintsUsed);
  const [completed, setCompleted] = useState(false);

  if (!mission || !hasDeployed || !score) return null;

  const allObj = mission.objectives.every((o) => satisfied[o.rule]);
  const success = allObj && score.total >= 50;
  const show = success && !completed;

  let stars: 1 | 2 | 3 = 1;
  if (score.total >= 85) stars = 3;
  else if (score.total >= 65) stars = 2;

  const xpEarned = Math.max(0, Math.round(mission.xpReward * (stars / 3)) - hintsUsed * 8);

  return (
    <Dialog open={show} onOpenChange={(o) => !o && (setCompleted(true), completeMission())}>
      <DialogContent aria-describedby={undefined} className="max-w-md overflow-hidden p-0">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 22 }}
        >
          {/* hero header */}
          <div className="relative overflow-hidden p-6 text-center">
            <div
              className="absolute inset-0"
              style={{
                background:
                  "radial-gradient(circle at 50% 0%, oklch(0.72 0.19 55 / 0.18), transparent 70%)",
              }}
            />
            <div className="relative">
              <motion.div
                initial={{ scale: 0, rotate: -12 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.15, type: "spring", stiffness: 200, damping: 12 }}
                className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-amber-400 to-orange-600 shadow-2xl shadow-amber-500/40"
              >
                <Trophy className="h-8 w-8 text-white" />
              </motion.div>
              <DialogTitle className="text-2xl font-bold">
                Mission Complete!
              </DialogTitle>
              <DialogDescription className="mt-1 text-sm">
                {mission.title} - {mission.company}
              </DialogDescription>
            </div>
          </div>

          {/* stars */}
          <div className="flex items-center justify-center gap-2 pb-2">
            {Array.from({ length: 3 }).map((_, i) => {
              const earned = i < stars;
              return (
                <motion.div
                  key={i}
                  initial={{ scale: 0, rotate: -30 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.3 + i * 0.15, type: "spring", stiffness: 220, damping: 14 }}
                >
                  <Star
                    className={`h-10 w-10 ${earned ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}`}
                  />
                </motion.div>
              );
            })}
          </div>

          {/* score breakdown */}
          <div className="p-4">
            <ScoreBar label="Architecture" v={score.architecture} c="#ff9900" />
            <ScoreBar label="Security" v={score.security} c="#dc2626" />
            <ScoreBar label="Availability" v={score.availability} c="#10b981" />
            <ScoreBar label="Performance" v={score.performance} c="#0891b2" />
            <ScoreBar label="Cost" v={score.cost} c="#84cc16" />
            <ScoreBar label="Monitoring" v={score.monitoring} c="#a855f7" />
            <div className="mt-3 flex items-center justify-between rounded-lg border border-amber-500/40 bg-amber-500/[0.08] p-3">
              <div>
                <div className="text-xs uppercase tracking-wide text-muted-foreground">Total</div>
                <div className="text-2xl font-bold text-amber-300">{score.total}%</div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-xs uppercase tracking-wide text-muted-foreground">
                  <Zap className="h-3 w-3" /> XP
                </div>
                <div className="text-2xl font-bold text-amber-300">+{xpEarned}</div>
              </div>
            </div>
            {hintsUsed > 0 && (
              <div className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-300/80">
                <AlertTriangle className="h-3 w-3" />
                {hintsUsed} hint{hintsUsed > 1 ? "s" : ""} used (-{hintsUsed * 8} XP)
              </div>
            )}
          </div>

          {/* concepts learned */}
          <div className="px-4 pb-4">
            <div className="mb-1.5 text-xs uppercase tracking-wide text-muted-foreground">
              Concepts learned
            </div>
            <div className="flex flex-wrap gap-1.5">
              {mission.concepts.map((c) => (
                <span
                  key={c.id}
                  className="inline-flex items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/[0.07] px-2 py-0.5 text-[11px] text-emerald-300"
                >
                  <CheckCircle2 className="h-3 w-3" /> {c.label}
                </span>
              ))}
            </div>
          </div>

          {/* footer */}
          <DialogFooter className="border-t border-border/40 bg-card/40 p-3">
            <Button variant="outline" onClick={() => { resetActiveMission(); setCompleted(false); }} className="flex-1">
              <RotateCcw className="mr-2 h-4 w-4" /> Replay
            </Button>
            <Button
              onClick={() => {
                completeMission();
                setCompleted(true);
                exitMission();
              }}
              className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-400 hover:to-orange-500"
            >
              Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </DialogFooter>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}

function ScoreBar({ label, v, c }: { label: string; v: number; c: string }) {
  return (
    <div className="mb-1.5">
      <div className="flex justify-between text-[11px]">
        <span className="text-muted-foreground">{label}</span>
        <span style={{ color: c }} className="font-semibold">
          {v}
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-muted">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${v}%` }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="h-full"
          style={{ background: c }}
        />
      </div>
    </div>
  );
}
