"use client";

import { useEffect } from "react";
import { useGame } from "@/lib/game/store";
import { HUD } from "@/components/game/HUD";
import { LandingView } from "@/components/game/LandingView";
import { MissionView } from "@/components/game/MissionView";
import { ProfileView } from "@/components/game/ProfileView";
import { ServicesView } from "@/components/game/ServicesView";
import { ServiceCardModal } from "@/components/game/ServiceCardModal";
import { Footer } from "./Footer";

export function GameShell() {
  const view = useGame((s) => s.view);
  const activeMissionId = useGame((s) => s.activeMissionId);
  const reducedMotion = useGame((s) => s.reducedMotion);

  useEffect(() => {
    const root = document.documentElement;
    if (reducedMotion) root.classList.add("reduce-motion");
    else root.classList.remove("reduce-motion");
  }, [reducedMotion]);

  const isMission = view === "mission" && activeMissionId;

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <HUD />
      <main className="flex-1">
        {view === "home" && <LandingView />}
        {view === "mission" && activeMissionId && <MissionView />}
        {view === "profile" && <ProfileView />}
        {view === "services" && <ServicesView />}
        {view === "leaderboard" && <LandingView />}
      </main>
      {!isMission && <Footer />}
      {/* global service card modal (also shown outside mission view) */}
      <ServiceCardModal />
    </div>
  );
}
