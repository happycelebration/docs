"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { PlacedResource, ResourceTypeId, ResourceConfig } from "@/lib/game/types";
import { SERVICE_CATALOG } from "@/lib/game/services";
import { useGame } from "@/lib/game/store";
import { Trash2, X, Settings2, Zap, AlertTriangle, CheckCircle2, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";

export function ResourceConfigSheet({
  resourceId,
  onClose,
}: {
  resourceId: string | null;
  onClose: () => void;
}) {
  const arch = useGame((s) => s.activeArchitecture);
  const updateConfig = useGame((s) => s.updateResourceConfig);
  const setShowServiceCard = useGame((s) => s.setShowServiceCard);

  const resource = resourceId ? arch.resources.find((r) => r.id === resourceId) : null;
  if (!resource) {
    return (
      <Sheet open={!!resourceId} onOpenChange={(o) => !o && onClose()}>
        <SheetContent side="right" />
      </Sheet>
    );
  }
  const svc = SERVICE_CATALOG[resource.type];

  return (
    <Sheet open={!!resourceId} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
        <SheetHeader>
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg text-xl" style={{ background: `${svc.color}22`, border: `1px solid ${svc.color}55` }}>
              {svc.icon}
            </div>
            <div>
              <SheetTitle className="text-left">{svc.label}</SheetTitle>
              <SheetDescription className="text-left">{svc.awsName}</SheetDescription>
            </div>
          </div>
        </SheetHeader>

        <div className="px-4 pb-6">
          <p className="mb-4 text-xs leading-relaxed text-muted-foreground">{svc.summary}</p>

          <div className="space-y-4">
            <ConfigFields type={resource.type} config={resource.config} onChange={(patch) => updateConfig(resource.id, patch)} />
          </div>

          {Object.keys(resource.metrics).length > 0 && (
            <div className="mt-5 rounded-lg border border-border/40 bg-card/40 p-3">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold">
                <Activity className="h-3.5 w-3.5 text-cyan-400" />
                Live Metrics
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                {Object.entries(resource.metrics).map(([k, v]) => (
                  <div key={k} className="rounded bg-background/40 px-2 py-1.5">
                    <div className="text-muted-foreground">{k}</div>
                    <div className="font-mono text-sm font-semibold">{typeof v === "number" ? v.toFixed(1) : v}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {resource.logs.length > 0 && (
            <div className="mt-4 rounded-lg border border-border/40 bg-black/40 p-3">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                Logs
              </div>
              <div className="space-y-1">
                {resource.logs.map((l, i) => (
                  <div key={i} className={`log-line ${l.level === "error" ? "text-red-400" : l.level === "warn" ? "text-amber-300" : l.level === "success" ? "text-emerald-300" : "text-muted-foreground"}`}>
                    {l.message}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-5 flex items-center justify-between rounded-lg border border-amber-500/30 bg-amber-500/[0.06] p-3">
            <div className="text-xs">
              <div className="font-semibold">Want to learn {svc.label}?</div>
              <div className="text-muted-foreground">Open the full service card.</div>
            </div>
            <Button size="sm" variant="outline" onClick={() => setShowServiceCard(resource.type)}>
              <Settings2 className="mr-1 h-3 w-3" /> Learn
            </Button>
          </div>
        </div>

        <SheetFooter>
          <Button onClick={onClose} variant="default" className="w-full">
            <CheckCircle2 className="mr-2 h-4 w-4" /> Done
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function ConfigFields({
  type,
  config,
  onChange,
}: {
  type: ResourceTypeId;
  config: ResourceConfig;
  onChange: (patch: ResourceConfig) => void;
}) {
  switch (type) {
    case "ec2":
      return (
        <>
          <Field label="Instance state">
            <Select value={String(config.state ?? "running")} onValueChange={(v) => onChange({ state: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="running">running</SelectItem>
                <SelectItem value="stopped">stopped</SelectItem>
                <SelectItem value="terminated">terminated</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Instance type">
            <Select value={String(config.instanceType ?? "t3.micro")} onValueChange={(v) => onChange({ instanceType: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="t3.micro">t3.micro - 2 vCPU / 1 GB</SelectItem>
                <SelectItem value="t3.small">t3.small - 2 vCPU / 2 GB</SelectItem>
                <SelectItem value="t3.medium">t3.medium - 2 vCPU / 4 GB</SelectItem>
                <SelectItem value="m5.large">m5.large - 2 vCPU / 8 GB</SelectItem>
                <SelectItem value="m5.xlarge">m5.xlarge - 4 vCPU / 16 GB</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="AMI (operating system)">
            <Select value={String(config.ami ?? "Amazon Linux 2023")} onValueChange={(v) => onChange({ ami: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Amazon Linux 2023">Amazon Linux 2023</SelectItem>
                <SelectItem value="Ubuntu 22.04 LTS">Ubuntu 22.04 LTS</SelectItem>
                <SelectItem value="Debian 12">Debian 12</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </>
      );
    case "route53":
      return (
        <Field label="Record name (domain)">
          <Input placeholder="example.com" value={String(config.recordName ?? "")} onChange={(e) => onChange({ recordName: e.target.value })} />
        </Field>
      );
    case "s3":
      return (
        <>
          <Field label="Bucket name">
            <Input placeholder="my-app-uploads" value={String(config.bucketName ?? "")} onChange={(e) => onChange({ bucketName: e.target.value })} />
          </Field>
          <div className="flex items-center justify-between rounded-lg border border-border/40 p-3">
            <div>
              <div className="text-sm font-medium">Public access</div>
              <div className="text-[10px] text-muted-foreground">Allow anyone on the internet to read/write.</div>
            </div>
            <Switch checked={config.public === true || config.public === "true"} onCheckedChange={(v) => onChange({ public: v })} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border/40 p-3">
            <div>
              <div className="text-sm font-medium">Versioning</div>
              <div className="text-[10px] text-muted-foreground">Keep old versions of objects.</div>
            </div>
            <Switch checked={config.versioning === true} onCheckedChange={(v) => onChange({ versioning: v })} />
          </div>
        </>
      );
    case "rds":
      return (
        <>
          <Field label="Engine">
            <Select value={String(config.engine ?? "PostgreSQL")} onValueChange={(v) => onChange({ engine: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="PostgreSQL">PostgreSQL 15</SelectItem>
                <SelectItem value="MySQL">MySQL 8</SelectItem>
                <SelectItem value="SQL Server">SQL Server Express</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <div className="flex items-center justify-between rounded-lg border border-red-500/30 bg-red-500/[0.07] p-3">
            <div>
              <div className="text-sm font-medium">Publicly accessible</div>
              <div className="text-[10px] text-red-400">Almost never. Keep this OFF in production.</div>
            </div>
            <Switch checked={config.publiclyAccessible === true || config.publiclyAccessible === "true"} onCheckedChange={(v) => onChange({ publiclyAccessible: v })} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border/40 p-3">
            <div>
              <div className="text-sm font-medium">Multi-AZ</div>
              <div className="text-[10px] text-muted-foreground">Standby in a second availability zone.</div>
            </div>
            <Switch checked={config.multiAZ === true} onCheckedChange={(v) => onChange({ multiAZ: v })} />
          </div>
        </>
      );
    case "security-group":
      return (
        <>
          <Field label="Allowed port">
            <Select value={String(config.allowedPort ?? "80")} onValueChange={(v) => onChange({ allowedPort: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="80">80 (HTTP)</SelectItem>
                <SelectItem value="443">443 (HTTPS)</SelectItem>
                <SelectItem value="22">22 (SSH) - DANGEROUS</SelectItem>
                <SelectItem value="5432">5432 (PostgreSQL)</SelectItem>
                <SelectItem value="all">All ports - DANGEROUS</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Source">
            <Select value={String(config.source ?? "0.0.0.0/0")} onValueChange={(v) => onChange({ source: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0.0.0.0/0">0.0.0.0/0 (internet)</SelectItem>
                <SelectItem value="sg-ec2">EC2 security group</SelectItem>
                <SelectItem value="sg-lb">Load balancer security group</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </>
      );
    case "iam-role":
      return (
        <Field label="Trusted entity">
          <Select value={String(config.trustedEntity ?? "ec2.amazonaws.com")} onValueChange={(v) => onChange({ trustedEntity: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ec2.amazonaws.com">ec2.amazonaws.com</SelectItem>
              <SelectItem value="lambda.amazonaws.com">lambda.amazonaws.com</SelectItem>
              <SelectItem value="s3.amazonaws.com">s3.amazonaws.com</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      );
    case "iam-policy":
      return (
        <>
          <Field label="Action">
            <Select value={String(config.action ?? "s3:GetObject")} onValueChange={(v) => onChange({ action: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="s3:GetObject">s3:GetObject (read)</SelectItem>
                <SelectItem value="s3:PutObject">s3:PutObject (write)</SelectItem>
                <SelectItem value="s3:GetObject,s3:PutObject">s3:GetObject + PutObject</SelectItem>
                <SelectItem value="dynamodb:GetItem">dynamodb:GetItem</SelectItem>
                <SelectItem value="*">* (AdministratorAccess - DANGEROUS)</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Resource ARN">
            <Input placeholder="arn:aws:s3:::my-bucket/*" value={String(config.resource ?? "")} onChange={(e) => onChange({ resource: e.target.value })} />
          </Field>
          <Field label="Effect">
            <Select value={String(config.effect ?? "Allow")} onValueChange={(v) => onChange({ effect: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Allow">Allow</SelectItem>
                <SelectItem value="Deny">Deny</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </>
      );
    case "lambda":
      return (
        <>
          <Field label="Runtime">
            <Select value={String(config.runtime ?? "Node.js 20")} onValueChange={(v) => onChange({ runtime: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Node.js 20">Node.js 20</SelectItem>
                <SelectItem value="Python 3.12">Python 3.12</SelectItem>
                <SelectItem value="Java 21">Java 21</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label={`Memory: ${config.memory ?? 256} MB`}>
            <input type="range" min={128} max={1024} step={64} value={Number(config.memory ?? 256)} onChange={(e) => onChange({ memory: Number(e.target.value) })} className="w-full" />
          </Field>
          <Field label={`Timeout: ${config.timeout ?? 5}s`}>
            <input type="range" min={1} max={15} value={Number(config.timeout ?? 5)} onChange={(e) => onChange({ timeout: Number(e.target.value) })} className="w-full" />
          </Field>
        </>
      );
    case "vpc":
      return (
        <Field label="CIDR block">
          <Select value={String(config.cidr ?? "10.0.0.0/16")} onValueChange={(v) => onChange({ cidr: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="10.0.0.0/16">10.0.0.0/16</SelectItem>
              <SelectItem value="10.1.0.0/16">10.1.0.0/16</SelectItem>
              <SelectItem value="172.16.0.0/16">172.16.0.0/16</SelectItem>
              <SelectItem value="192.168.0.0/16">192.168.0.0/16</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      );
    case "subnet-public":
    case "subnet-private":
      return (
        <Field label="CIDR block">
          <Input placeholder="10.0.1.0/24" value={String(config.cidr ?? "")} onChange={(e) => onChange({ cidr: e.target.value })} />
        </Field>
      );
    case "alarm":
      return (
        <>
          <Field label="Metric">
            <Select value={String(config.metric ?? "CPUUtilization")} onValueChange={(v) => onChange({ metric: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="CPUUtilization">CPUUtilization</SelectItem>
                <SelectItem value="ErrorRate">ErrorRate</SelectItem>
                <SelectItem value="Latency">Latency</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label={`Threshold: > ${config.threshold ?? 80}`}>
            <input type="range" min={50} max={100} value={Number(config.threshold ?? 80)} onChange={(e) => onChange({ threshold: Number(e.target.value) })} className="w-full" />
          </Field>
        </>
      );
    default:
      return (
        <div className="rounded-lg border border-border/40 bg-card/40 p-3 text-xs text-muted-foreground">
          No configurable properties. This resource is ready.
        </div>
      );
  }
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[11px] font-medium text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
