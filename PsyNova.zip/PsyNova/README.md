# PsyNova

### Your AI Companion for Better Mental Wellbeing

PsyNova is a privacy-first, AI-powered mental wellness platform. Chat or talk with an empathetic AI counselor, receive personalized coping strategies, track your emotional progress on a real-time dashboard, and generate a premium wellness report, all within a single, secure browser session.

Nothing is ever stored on a server. No accounts, no databases, no cookies. The moment you close or refresh the tab, every conversation, assessment, and report is permanently discarded.

---

## Table of Contents

1. [Overview](#overview)
2. [Key Features](#key-features)
3. [Important Ethical Notice](#important-ethical-notice)
4. [Technology Stack](#technology-stack)
5. [Architecture](#architecture)
6. [Privacy First](#privacy-first)
7. [AI Provider: OpenRouter with Automatic Failover](#ai-provider-openrouter-with-automatic-failover)
8. [Environment Variables](#environment-variables)
9. [Installation](#installation)
10. [Development](#development)
11. [Production Build](#production-build)
12. [Deployment to Vercel](#deployment-to-vercel)
13. [Folder Structure](#folder-structure)
14. [How It Works](#how-it-works)
15. [Crisis Detection and Safety](#crisis-detection-and-safety)
16. [Accessibility](#accessibility)
17. [Browser Support](#browser-support)
18. [Troubleshooting](#troubleshooting)
19. [License](#license)

---

## Overview

PsyNova was built to make mental wellness support feel calm, private, and always available. The application pairs a soothing, glassmorphic interface with an AI counselor that adapts to each user's assessment profile and remembers the full context of the active session.

The experience flows through five stages:

1. **Assessment** — a calming, multi-step form that captures the user's background, wellbeing indicators, personality, and lifestyle.
2. **Choice** — the user picks between a text chat or a voice call with the AI counselor.
3. **Counseling** — every message to the AI includes the assessment data and the current session conversation, so responses feel continuous and personalized.
4. **Dashboard** — a structured wellness analysis is generated from the session, with mood and stress trends, emotion breakdowns, strengths, growth areas, and recommendations.
5. **Report** — a premium, multi-page PDF is generated entirely in memory and offered for download. It is never persisted anywhere.

The entire application runs on a single route (`/`) with view-based state management, keeping the architecture simple and the bundle lean.

---

## Key Features

**Wellness Assessment**
- A four-step form with smooth animated transitions.
- Sliders, emoji mood cards, and personality chips for a gentle, low-friction experience.
- Zod validation with inline error messaging.
- Autosave to the in-memory session so progress is never lost mid-flow.

**AI Chat Counselor**
- A polished chat interface with markdown rendering and a typewriter streaming effect.
- Per-message text-to-speech using the browser's SpeechSynthesis API.
- Copy, pin, favorite, edit, and regenerate any message.
- Message search and a favorites filter.
- Conversation history is carried into every prompt so the counselor remembers the session.

**Voice Call Mode**
- A real phone-call experience with ringing, connecting, and active states.
- Browser SpeechRecognition for speech-to-text.
- Browser SpeechSynthesis for natural AI voice output.
- Live transcript, mute toggle, call timer, and animated waveforms.
- Continuous conversation — the AI listens, responds, and resumes listening automatically.

**Crisis Detection**
- Pattern-based detection for self-harm, suicide, violence, and immediate danger.
- Empathetic, resource-rich responses that guide users toward trusted contacts, crisis lines, and emergency services.
- Never encourages harmful behavior.

**Wellness Dashboard**
- A radial wellness score gauge.
- Mood and stress trend line charts.
- An emotion breakdown pie chart.
- Numbered session insights, positive strengths, and growth areas.
- Personalized recommendations and progress-tracked goals.
- All charts render with Recharts and update in real time as the session grows.

**PDF Wellness Report**
- A six-page, professionally designed report generated in memory with `@react-pdf/renderer`.
- Includes a cover, profile, assessment snapshot, mood and stress analysis, emotion breakdown, strengths and growth areas, recommendations, a daily wellness toolkit (breathing, mindfulness, journaling, affirmations, goals), and crisis resources.
- An HTML preview mirror is shown in a modal before download.
- The report exists only until the user downloads it or leaves the website.

**Neural Network Background**
- A custom canvas animation of floating, pulsing nodes connected by lines that fade with distance.
- Theme-aware — reads the brand color variables and adapts to light and dark mode automatically.
- Respects `prefers-reduced-motion` and freezes into a calm static state when requested.

**Design and Theming**
- Dark-mode-first with full light-mode support.
- A calming palette of soft blue, purple, and teal.
- Glassmorphism with blur and saturation on cards and the navbar.
- Fully responsive from mobile to ultrawide monitors, with wide desktop containers that utilize the full viewport.

---

## Important Ethical Notice

PsyNova is an AI-powered mental wellness companion. It is **not** a licensed therapist, a medical device, or a substitute for professional mental health care. It never diagnoses medical conditions and never prescribes medication.

If you are in crisis or sense imminent risk, please contact local emergency services or a qualified professional immediately:

- **United States**: 988 (Suicide and Crisis Lifeline) — call or text, 24/7, free and confidential.
- **United Kingdom**: 111 or 999.
- **India**: iCall at 9152987821.

The AI counselor always encourages professional help when concerns appear serious or persistent.

---

## Technology Stack

| Concern | Technology |
| --- | --- |
| Framework | Next.js 16 (App Router) with TypeScript |
| Styling | Tailwind CSS v4 |
| UI Components | shadcn/ui (New York style) built on Radix UI primitives |
| AI Provider | OpenRouter (OpenAI-compatible Chat Completions API) |
| State Management | Zustand (in-memory session only) |
| Server State | TanStack Query |
| Charts | Recharts |
| Animation | Framer Motion |
| Icons | Lucide React |
| PDF Generation | @react-pdf/renderer |
| Validation | Zod |
| Speech | Browser SpeechRecognition and SpeechSynthesis APIs |
| Theme | next-themes (class strategy, dark first) |

The application uses **no database**. There is no Prisma, no SQLite, no PostgreSQL, no Redis, and no persistent storage of any kind for user data.

---

## Architecture

PsyNova follows a single-route, view-based architecture.

**Frontend**
- One route (`/`) renders different views based on a `view` field in the Zustand store: `landing`, `assessment`, `choice`, `chat`, `voice`, and `dashboard`.
- The store holds the assessment data, the message history, the mood history, and the generated analysis — all in memory.
- Components are lazy and stateless except for the session store.

**Backend**
- Two Next.js Route Handlers under `src/app/api/`:
  - `POST /api/chat` — accepts the assessment, conversation history, and the latest message. Returns the counselor's reply. Includes crisis detection.
  - `POST /api/analyze` — accepts the assessment and full message history. Returns a structured JSON wellness analysis for the dashboard.
- Both routes delegate all AI work to the centralized OpenRouter service in `src/lib/openrouter.ts`. No route calls OpenRouter directly.

**AI Layer**
- `src/lib/openrouter.ts` is the single source of truth for AI requests. It reads environment variables, selects models, performs failover, makes the HTTP request, and returns a normalized string response.
- `src/lib/ai.ts` builds the counselor system prompt (personalized from the assessment), detects crisis phrases, and converts the internal message format to OpenRouter's `user`/`assistant` roles.

---

## Privacy First

PsyNova does not permanently store personal information, conversations, voice transcripts, assessments, or reports. Everything exists only during the current browser session and is automatically deleted when you leave or refresh the website.

The application uses:
- No database
- No `localStorage`
- No `sessionStorage`
- No `IndexedDB`
- No cookies for user data

The Zustand store lives entirely in JavaScript memory. On refresh or close, the JavaScript runtime is torn down and all data is garbage-collected permanently.

The only data that leaves the browser is the content of each AI request (the assessment context and the current conversation), which is sent to OpenRouter to generate a response. OpenRouter's own retention policies apply to that transit data. PsyNova itself retains nothing.

---

## AI Provider: OpenRouter with Automatic Failover

PsyNova uses [OpenRouter](https://openrouter.ai) exclusively for all AI requests. OpenRouter provides an OpenAI-compatible Chat Completions endpoint, which means the request format is simple, standard, and portable.

**Why OpenRouter?**
- A single API key gives access to hundreds of models from many providers.
- Free-tier models are available, making the app runnable at no cost.
- Built-in provider routing means if one upstream provider is down, OpenRouter can often route to another.

**Automatic Multi-Model Failover**

The centralized AI service reads a JSON array of model IDs from the `OPENROUTER_MODELS` environment variable. The first model is the primary; the rest are fallbacks, tried in order.

On any of the following conditions, the service immediately moves to the next model without retrying the failing one:

- HTTP 429 (rate limited)
- HTTP 500, 502, 503, 504 (server errors)
- Request timeout (60 seconds)
- Network failure
- Model or provider unavailable
- Empty response
- Invalid JSON response
- Missing `choices` array

The moment one model returns a valid response, the service stops trying additional models and returns that response to the user.

Authentication errors (HTTP 401, 402, 403) fail immediately with a clear message, because switching models cannot fix a bad key or insufficient credits.

If every configured model fails, the service returns a friendly error: "The AI service is temporarily unavailable. All models failed to respond. Please try again in a few moments." No stack traces or raw API responses are exposed to the user.

**No Third-Party SDK**

The OpenRouter integration uses the native `fetch()` API directly. There is no SDK dependency to maintain, no version drift, and no abstraction overhead. The request is a standard OpenAI-compatible payload:

```json
{
  "model": "nvidia/nemotron-3-ultra-550b-a55b:free",
  "messages": [
    { "role": "system", "content": "..." },
    { "role": "user", "content": "..." }
  ],
  "temperature": 0.7,
  "max_tokens": 2048
}
```

---

## Environment Variables

PsyNova requires exactly two environment variables. No database or authentication variables are needed.

| Variable | Required | Description |
| --- | --- | --- |
| `OPENROUTER_API_KEY` | Yes | Your OpenRouter API key. Get one for free at https://openrouter.ai/keys. |
| `OPENROUTER_MODELS` | Yes | A JSON array of model IDs to try, in order. The first is primary; the rest are automatic fallbacks. |

**Example `.env` file:**

```env
OPENROUTER_API_KEY=your_openrouter_api_key_here
OPENROUTER_MODELS=["poolside/laguna-xs-2.1:free","cohere/north-mini-code:free","nvidia/llama-nemotron-rerank-vl-1b-v2:free","nvidia/nemotron-3.5-content-safety:free","nvidia/nemotron-3-ultra-550b-a55b:free","nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free","google/gemma-4-26b-a4b-it:free","google/gemma-4-31b-it:free","nvidia/nemotron-3-super-120b-a12b:free","nvidia/llama-nemotron-embed-vl-1b-v2:free","nvidia/nemotron-3-nano-30b-a3b:free","nvidia/nemotron-nano-12b-v2-vl:free","nvidia/nemotron-nano-9b-v2:free","openai/gpt-oss-20b:free"]
```

The `OPENROUTER_MODELS` variable is a JSON array rather than a comma-separated string. This avoids parsing edge cases (model IDs can contain commas in rare cases) and makes it trivial to add, remove, or reorder models without touching application logic. Simply edit the array and restart the server.

You can browse the full list of available models at https://openrouter.ai/models. Free models are marked with a `:free` suffix.

---

## Installation

**Prerequisites**

- Node.js 18.18+ or Bun 1.1+
- An OpenRouter API key

**Steps**

```bash
# Clone the repository
git clone https://github.com/happycelebration/wellness.git
cd wellness

# Install dependencies (Bun is recommended for speed)
bun install

# Create your environment file
cp .env.example .env
```

Open `.env` and replace `your_openrouter_api_key_here` with your real OpenRouter key. Adjust the models array if you want to use different models.

---

## Development

Start the development server:

```bash
bun run dev
```

The application runs at `http://localhost:3000`.

**Linting**

```bash
bun run lint
```

This runs ESLint with the Next.js configuration. The codebase should pass with zero errors and zero warnings.

**Note on hot reload**: Because the session is stored in memory, refreshing the page or restarting the dev server will clear the current session. This is intentional and is the core of the privacy-first design.

---

## Production Build

```bash
bun run build
bun run start
```

The build compiles TypeScript, bundles the client and server, and outputs to `.next/`. The `start` script runs the production server.

---

## Deployment to Vercel

PsyNova is designed for Vercel and requires no database provisioning.

1. Push the repository to GitHub (or GitLab).
2. Import the project into [Vercel](https://vercel.com).
3. In **Project Settings > Environment Variables**, add both:
   - `OPENROUTER_API_KEY` — your OpenRouter key.
   - `OPENROUTER_MODELS` — the JSON array of model IDs.
4. Deploy.

Vercel's default regions (US-based) work well with OpenRouter. No special region configuration is required.

**Important**: Never commit your `.env` file. The included `.gitignore` already excludes it. Use Vercel's environment variables UI for production secrets.

---

## Folder Structure

```
wellness/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── chat/
│   │   │   │   └── route.ts        # AI counselor chat endpoint (OpenRouter + crisis detection)
│   │   │   └── analyze/
│   │   │       └── route.ts        # Wellness analysis endpoint for the dashboard
│   │   ├── globals.css             # Design system: color palette, glassmorphism, animations
│   │   ├── layout.tsx              # Root layout, metadata, providers, neural background
│   │   └── page.tsx                # Single-route view router
│   ├── components/
│   │   ├── ui/                     # shadcn/ui primitives (15 components)
│   │   ├── providers.tsx           # ThemeProvider + QueryClientProvider
│   │   ├── neural-background.tsx   # Canvas neural network animation
│   │   ├── navbar.tsx              # Sticky top navigation
│   │   ├── footer.tsx              # Footer with copyright
│   │   ├── landing.tsx             # Hero, features, privacy, how-it-works, FAQ, CTA
│   │   ├── assessment.tsx          # Four-step wellness assessment form
│   │   ├── choice.tsx              # Chat vs Voice selection screen
│   │   ├── chat.tsx                # AI chat interface
│   │   ├── voice.tsx               # Voice call interface
│   │   ├── dashboard.tsx           # Wellness analytics dashboard
│   │   └── report.tsx              # In-memory PDF report generator and preview
│   ├── lib/
│   │   ├── types.ts                # Shared TypeScript types and constants
│   │   ├── ai.ts                   # Counselor system prompt builder + crisis detection
│   │   ├── openrouter.ts           # Centralized AI service with multi-model failover
│   │   ├── speech.ts               # Browser speechSynthesis wrapper
│   │   ├── session-store.ts        # Zustand in-memory session store
│   │   └── utils.ts                # cn() class merge helper
│   └── hooks/
│       ├── use-mobile.ts           # Mobile viewport detection
│       └── use-toast.ts            # Toast hook (shadcn)
├── public/
│   ├── logo.svg
│   └── robots.txt
├── .env.example
├── .gitignore
├── components.json                 # shadcn/ui config
├── eslint.config.mjs
├── next.config.ts
├── package.json
├── postcss.config.mjs
├── README.md
├── tailwind.config.ts
└── tsconfig.json
```

---

## How It Works

### 1. Assessment

The user completes a four-step assessment: About You (name, age, gender, country, language, occupation, relationship status), Wellbeing (mood emoji cards plus seven sliders for sleep, exercise, stress, energy, confidence, social comfort, and optimism), Personality (type chips and three bipolar sliders), and Lifestyle (screen time, challenges, goals, emergency contact, notes).

The data is validated with Zod and committed to the Zustand in-memory store. It is never written to disk.

### 2. Choice

After the assessment, the user sees two large premium cards: Start Chat or Start Voice Call. A link to the dashboard is also available.

### 3. AI Counseling

Every message sent to the AI counselor triggers a request to `POST /api/chat`. The request body contains:

- The full assessment object
- The last twelve messages of conversation history
- The latest user message

The route handler builds a personalized system prompt from the assessment (the counselor knows the user's name, stress level, sleep quality, personality, challenges, and goals). It checks the message for crisis patterns. If a crisis is detected, it returns a resource-rich empathetic response immediately without calling the AI.

Otherwise, it delegates to the centralized OpenRouter service, which tries the primary model, then each fallback in order until one succeeds. The reply is returned to the client, where a typewriter effect reveals it gradually.

### 4. Dashboard

The user can open the dashboard at any time after the assessment. Clicking "Generate Analysis" sends the assessment and full conversation to `POST /api/analyze`. The route asks the AI to produce a strict JSON object containing a wellness score, mood and stress trends, an emotion breakdown, a conversation summary, insights, strengths, growth areas, recommendations, a daily routine, a breathing exercise, a mindfulness tip, journaling prompts, affirmations, goals, resources, and a personality insight.

The response is parsed and validated. If the AI fails or returns invalid JSON, a locally-computed fallback analysis is returned so the dashboard always renders. The dashboard visualizes the data with Recharts (radial bar, line, and pie charts).

### 5. Report

From the dashboard, the user can open the report preview modal. The modal shows an HTML mirror of the report content. Clicking "Download PDF" dynamically imports `@react-pdf/renderer`, builds a six-page A4 document entirely in memory, converts it to a Blob, and triggers a download. The PDF is never stored on the server.

---

## Crisis Detection and Safety

PsyNova includes a pattern-based crisis detector in `src/lib/ai.ts`. It scans every incoming user message for phrases indicating self-harm, suicide, violence, or immediate danger.

When a crisis is detected, the application **does not** forward the message to the AI model. Instead, it immediately returns a pre-written, empathetic response that:

- Validates the user's pain without judgment.
- Encourages them to reach out to a trusted person.
- Provides specific crisis line numbers (988 for the US, 111/999 for the UK, iCall for India).
- Recommends contacting local emergency services.
- Offers to try a grounding exercise together.

This ensures that even if the AI service is down or slow, a user in crisis receives immediate, appropriate guidance.

The AI counselor's system prompt also instructs it to never encourage self-harm, to remain calm and supportive, and to always encourage professional help when concerns are serious.

---

## Accessibility

PsyNova is built with accessibility as a first-class concern:

- **Semantic HTML**: `main`, `header`, `nav`, `section`, `article`, and `footer` elements are used throughout.
- **ARIA labels**: Interactive elements have descriptive `aria-label` attributes where needed.
- **Keyboard navigation**: All interactive elements are reachable and operable via keyboard.
- **Screen reader support**: Decorative elements (like the neural background canvas) are marked `aria-hidden`.
- **Reduced motion**: The neural background animation and all Framer Motion transitions respect `prefers-reduced-motion`. When reduced motion is requested, the background freezes into a calm static state and animations complete instantly.
- **Color contrast**: The color palette is designed to meet WCAG contrast standards in both light and dark mode.
- **Responsive typography**: Font sizes scale gracefully from mobile to desktop.
- **Focus management**: Focus styles are preserved and visible.

---

## Browser Support

PsyNova works on all modern browsers:

- **Chrome / Edge** (recommended): Full support including SpeechRecognition for voice calls.
- **Firefox**: Full support for chat and dashboard. Voice call speech recognition may be limited.
- **Safari**: Full support including SpeechRecognition and SpeechSynthesis.

The neural network background uses the Canvas API, which is universally supported. The PDF generation runs entirely in the browser via `@react-pdf/renderer`.

For the best voice call experience, Chrome or Edge is recommended because they have the most reliable `webkitSpeechRecognition` implementation.

---

## Troubleshooting

**The chat returns "OpenRouter authentication failed"**

Your `OPENROUTER_API_KEY` is missing, invalid, or expired. Get a fresh key at https://openrouter.ai/keys and update your `.env` file. Restart the dev server after changing environment variables.

**The chat returns "The AI service is temporarily unavailable"**

All configured models failed. This usually means every free-tier model is rate-limited at the moment. Wait a minute and try again, or add paid models to your `OPENROUTER_MODELS` array for higher limits.

**The dashboard shows a basic analysis instead of a detailed one**

The AI model failed to return valid JSON, so the application fell back to a locally-computed analysis. This is expected behavior — the dashboard always renders. Try regenerating after a moment.

**Voice call does not transcribe my speech**

Voice call uses the browser's SpeechRecognition API, which requires microphone permission. Ensure you've granted microphone access. Chrome or Edge provides the most reliable experience. Check that your `preferredLanguage` in the assessment matches your spoken language.

**The page resets my session when I refresh**

This is intentional. PsyNova is privacy-first and stores nothing permanently. Refreshing the page clears all session data. If you need to keep your conversation, do not refresh.

**Text-to-speech does not play**

The chat's text-to-speech uses the browser's SpeechSynthesis API. Some browsers require a user interaction before playing audio. Click anywhere on the page first, then try the speaker button again.

---

## License

Copyright (c) 2026 PsyNova by Pallavi Thakur. All Rights Reserved.

This project is provided as-is for educational and wellness-support purposes. It is **not** a medical device and is **not** a substitute for professional mental health care.

Permission is granted to use, copy, modify, and distribute this software for personal and educational purposes, provided that the above copyright notice and this permission notice appear in all copies. Commercial use requires explicit written permission from the author.

The software is provided "as is", without warranty of any kind, express or implied. In no event shall the author be liable for any claim, damages, or other liability arising from the use of this software.

---

*If you or someone you know is struggling, please reach out. You are not alone.*
