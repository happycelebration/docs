import { NextRequest, NextResponse } from "next/server";
import { generateReply } from "@/lib/openrouter";
import {
  buildCounselorSystemPrompt,
  buildCrisisResponse,
  detectCrisis,
  toOpenRouterHistory,
} from "@/lib/ai";
import type { AssessmentData, ChatMessage } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface ChatRequestBody {
  assessment: AssessmentData;
  history: ChatMessage[];
  message: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as ChatRequestBody;
    const message = (body.message || "").trim();
    const assessment = body.assessment;
    const history = Array.isArray(body.history) ? body.history : [];

    if (!message) {
      return NextResponse.json({ error: "Message is required." }, { status: 400 });
    }
    if (!assessment || !assessment.name) {
      return NextResponse.json(
        { error: "Assessment is required to begin a session." },
        { status: 400 },
      );
    }
    if (message.length > 4000) {
      return NextResponse.json(
        { error: "Message is too long. Please keep it under 4000 characters." },
        { status: 400 },
      );
    }

    if (detectCrisis(message)) {
      return NextResponse.json({
        reply: buildCrisisResponse(),
        crisis: true,
      });
    }

    const systemPrompt = buildCounselorSystemPrompt(assessment);
    const chatHistory = toOpenRouterHistory(history);

    const reply = await generateReply({
      systemPrompt,
      history: chatHistory,
      message,
    });

    return NextResponse.json({
      reply:
        reply.trim() ||
        "I'm here for you. Could you tell me a little more about how you're feeling right now?",
      crisis: false,
    });
  } catch (err) {
    const message =
      err instanceof Error
        ? err.message
        : "The AI service is temporarily unavailable. Please try again later.";
    return NextResponse.json({ error: message }, { status: 503 });
  }
}
