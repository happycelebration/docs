import { NextRequest, NextResponse } from "next/server";
import { generateFromPrompt } from "@/lib/openrouter";
import { buildCounselorSystemPrompt } from "@/lib/ai";
import type { AssessmentData, ChatMessage, AnalysisResult } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface AnalyzeRequestBody {
  assessment: AssessmentData;
  messages: ChatMessage[];
}

function safeParseJson(text: string): Record<string, unknown> | null {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced ? fenced[1] : trimmed;
  try {
    return JSON.parse(raw);
  } catch {
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(raw.slice(start, end + 1));
      } catch {
        return null;
      }
    }
    return null;
  }
}

function clamp(n: unknown, min: number, max: number, fallback: number): number {
  const v = typeof n === "number" ? n : Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.min(max, Math.max(min, v));
}

function asStringArray(v: unknown, fallback: string[]): string[] {
  if (Array.isArray(v)) {
    return v
      .map((x) => (typeof x === "string" ? x : String(x)))
      .filter((s) => s.trim().length > 0);
  }
  return fallback;
}

function labelFromScore(score: number, low: string, mid: string, high: string) {
  if (score <= 3) return low;
  if (score <= 6) return mid;
  return high;
}

function buildFallback(assessment: AssessmentData): AnalysisResult {
  return {
    wellnessScore: Math.round(
      ((assessment.mood + assessment.optimism + (10 - assessment.stressLevel)) /
        3) *
        10,
    ),
    moodLabel: "Balanced",
    moodScore: assessment.mood,
    stressLabel: "Moderate",
    stressScore: assessment.stressLevel,
    moodTrend: [
      { time: "Start", mood: assessment.mood },
      { time: "Now", mood: assessment.mood },
    ],
    stressTrend: [
      { time: "Start", stress: assessment.stressLevel },
      { time: "Now", stress: assessment.stressLevel },
    ],
    emotionBreakdown: [
      { name: "Calm", value: 40, color: "#7c9cf5" },
      { name: "Hopeful", value: 25, color: "#c084fc" },
      { name: "Anxious", value: 20, color: "#f59e0b" },
      { name: "Tired", value: 15, color: "#5eead4" },
    ],
    insights: [
      "Continue checking in with your feelings throughout the day.",
      "Small breathing pauses can lower stress in minutes.",
    ],
    conversationSummary:
      "Your session has begun. PsyNova is here to support you with empathy and practical tools.",
    positiveStrengths: ["You took the step to begin a wellness session."],
    growthAreas: ["Notice stress triggers and respond with a brief pause."],
    recommendations: [
      "Practice 5 minutes of mindful breathing daily.",
      "Aim for a consistent sleep schedule.",
    ],
    dailyRoutine: [
      "Morning: 5 min stretching and water.",
      "Midday: 10 min walk.",
      "Evening: screen-free wind-down.",
    ],
    breathingExercise:
      "Box breathing: inhale 4s, hold 4s, exhale 4s, hold 4s. Repeat 4 rounds.",
    mindfulnessTip:
      "Try the 5-4-3-2-1 grounding technique when feeling overwhelmed.",
    journalingPrompts: [
      "What am I grateful for today?",
      "What's one small win I can celebrate?",
    ],
    affirmations: [
      "I am allowed to take things one step at a time.",
      "My feelings are valid and temporary.",
    ],
    goals: [
      "Practice one coping technique daily.",
      "Reach out to someone I trust this week.",
    ],
    resources: [
      {
        name: "988 Suicide & Crisis Lifeline (US)",
        detail: "Call or text 988, 24/7, free and confidential.",
      },
    ],
    personalityInsights:
      "Your profile suggests a thoughtful, reflective nature that benefits from structured self-care.",
  };
}

export async function POST(req: NextRequest) {
  let body: AnalyzeRequestBody;
  try {
    body = (await req.json()) as AnalyzeRequestBody;
  } catch {
    return NextResponse.json(
      { error: "Invalid request body." },
      { status: 400 },
    );
  }

  const assessment = body.assessment;
  const messages = Array.isArray(body.messages) ? body.messages : [];

  if (!assessment || !assessment.name) {
    return NextResponse.json(
      { error: "Assessment is required for analysis." },
      { status: 400 },
    );
  }

  try {
    const transcript = messages
      .map((m) => `${m.role === "user" ? "User" : "PsyNova"}: ${m.content}`)
      .join("\n\n");

    const analysisPrompt = `You are PsyNova's clinical-analytics engine. Based ONLY on the user's assessment and this session's conversation, produce a compassionate, accurate wellness analysis as STRICT JSON.

USER ASSESSMENT:
${JSON.stringify(assessment, null, 2)}

SESSION CONVERSATION:
${transcript || "(The user has not spoken much yet. Base insights primarily on the assessment.)"}

Return ONLY valid JSON (no prose, no code fences) with EXACTLY this shape:
{
  "wellnessScore": number (0-100, overall wellbeing),
  "moodScore": number (0-10),
  "stressScore": number (0-10),
  "moodTrend": [{"time": "short label", "mood": 0-10}, 4-6 points earliest->latest],
  "stressTrend": [{"time": "short label", "stress": 0-10}, 4-6 points earliest->latest],
  "emotionBreakdown": [{"name": "Calm", "value": number, "color": "#hex"}, 4-6 emotions summing ~100],
  "conversationSummary": "2-3 sentence warm summary",
  "insights": ["array of 3-5 short actionable insights"],
  "positiveStrengths": ["array of 3-5 strengths observed"],
  "growthAreas": ["array of 2-4 areas for growth"],
  "recommendations": ["array of 4-6 practical recommendations"],
  "dailyRoutine": ["array of 4-6 morning-to-evening routine items"],
  "breathingExercise": "one concrete breathing technique with steps",
  "mindfulnessTip": "one concrete mindfulness tip",
  "journalingPrompts": ["array of 4-6 journaling prompts"],
  "affirmations": ["array of 4-6 affirmations"],
  "goals": ["array of 3-5 short-term wellness goals"],
  "resources": [{"name": "...", "detail": "..."}, 3-5 reputable resources],
  "personalityInsights": "1-2 sentence insight connecting personality to wellbeing"
}

Use calming, encouraging language. Be specific and grounded in the data. Numbers must be JSON numbers, not strings.`;

    const raw = await generateFromPrompt(
      buildCounselorSystemPrompt(assessment),
      analysisPrompt,
    );
    const parsed = safeParseJson(raw);

    const fallback = buildFallback(assessment);

    if (!parsed) {
      return NextResponse.json(fallback);
    }

    const moodScore = clamp(parsed.moodScore, 0, 10, assessment.mood);
    const stressScore = clamp(parsed.stressScore, 0, 10, assessment.stressLevel);
    const wellnessScore = clamp(parsed.wellnessScore, 0, 100, 60);

    const result: AnalysisResult = {
      wellnessScore,
      moodLabel: labelFromScore(moodScore, "Low", "Balanced", "Uplifted"),
      moodScore,
      stressLabel: labelFromScore(stressScore, "Calm", "Moderate", "High"),
      stressScore,
      moodTrend:
        Array.isArray(parsed.moodTrend) && parsed.moodTrend.length > 0
          ? (parsed.moodTrend as Array<Record<string, unknown>>).map((p) => ({
              time: String(p.time ?? ""),
              mood: clamp(p.mood, 0, 10, moodScore),
            }))
          : fallback.moodTrend,
      stressTrend:
        Array.isArray(parsed.stressTrend) && parsed.stressTrend.length > 0
          ? (parsed.stressTrend as Array<Record<string, unknown>>).map((p) => ({
              time: String(p.time ?? ""),
              stress: clamp(p.stress, 0, 10, stressScore),
            }))
          : fallback.stressTrend,
      emotionBreakdown:
        Array.isArray(parsed.emotionBreakdown) &&
        parsed.emotionBreakdown.length > 0
          ? (parsed.emotionBreakdown as Array<Record<string, unknown>>).map(
              (p) => ({
                name: String(p.name ?? "Emotion"),
                value: clamp(p.value, 0, 100, 20),
                color: String(p.color ?? "#7c9cf5"),
              }),
            )
          : fallback.emotionBreakdown,
      conversationSummary:
        typeof parsed.conversationSummary === "string"
          ? parsed.conversationSummary
          : fallback.conversationSummary,
      insights: asStringArray(parsed.insights, fallback.insights),
      positiveStrengths: asStringArray(
        parsed.positiveStrengths,
        fallback.positiveStrengths,
      ),
      growthAreas: asStringArray(parsed.growthAreas, fallback.growthAreas),
      recommendations: asStringArray(
        parsed.recommendations,
        fallback.recommendations,
      ),
      dailyRoutine: asStringArray(parsed.dailyRoutine, fallback.dailyRoutine),
      breathingExercise:
        typeof parsed.breathingExercise === "string"
          ? parsed.breathingExercise
          : fallback.breathingExercise,
      mindfulnessTip:
        typeof parsed.mindfulnessTip === "string"
          ? parsed.mindfulnessTip
          : fallback.mindfulnessTip,
      journalingPrompts: asStringArray(
        parsed.journalingPrompts,
        fallback.journalingPrompts,
      ),
      affirmations: asStringArray(parsed.affirmations, fallback.affirmations),
      goals: asStringArray(parsed.goals, fallback.goals),
      resources:
        Array.isArray(parsed.resources) && parsed.resources.length > 0
          ? (parsed.resources as Array<Record<string, unknown>>).map((p) => ({
              name: String(p.name ?? "Resource"),
              detail: String(p.detail ?? ""),
            }))
          : fallback.resources,
      personalityInsights:
        typeof parsed.personalityInsights === "string"
          ? parsed.personalityInsights
          : fallback.personalityInsights,
    };

    return NextResponse.json(result);
  } catch {
    return NextResponse.json(buildFallback(assessment));
  }
}
