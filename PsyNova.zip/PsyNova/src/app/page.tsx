"use client";

import { useSessionStore } from "@/lib/session-store";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Landing } from "@/components/landing";
import { Assessment } from "@/components/assessment";
import { Choice } from "@/components/choice";
import { Chat } from "@/components/chat";
import { Voice } from "@/components/voice";
import { Dashboard } from "@/components/dashboard";

export default function Home() {
  const view = useSessionStore((s) => s.view);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <div className="flex-1">
        {view === "landing" && <Landing />}
        {view === "assessment" && <Assessment />}
        {view === "choice" && <Choice />}
        {view === "chat" && <Chat />}
        {view === "voice" && <Voice />}
        {view === "dashboard" && <Dashboard />}
      </div>
      <Footer />
    </div>
  );
}
