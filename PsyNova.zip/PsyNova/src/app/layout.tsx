import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";
import { NeuralBackground } from "@/components/neural-background";

const inter = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "PsyNova — Your AI Companion for Better Mental Wellbeing",
  description:
    "PsyNova is a privacy-first AI mental wellness platform. Chat or talk with an empathetic AI counselor, track your emotional progress, and generate personalized wellness reports — all in a single, secure session.",
  keywords: [
    "PsyNova",
    "AI counselor",
    "mental wellness",
    "mental health",
    "AI therapy",
    "mindfulness",
    "wellbeing",
  ],
  authors: [{ name: "Pallavi Thakur" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "PsyNova — Your AI Companion for Better Mental Wellbeing",
    description:
      "Privacy-first AI mental wellness platform with chat, voice calls, and personalized reports.",
    siteName: "PsyNova",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "PsyNova",
    description: "Your AI Companion for Better Mental Wellbeing.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        <Providers>
          <NeuralBackground />
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
