const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const REQUEST_TIMEOUT_MS = 60_000;

export interface ChatMessageEntry {
  role: "system" | "user" | "assistant";
  content: string;
}

function getApiKey(): string {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) {
    throw new Error(
      "OPENROUTER_API_KEY environment variable is required. Get a key at https://openrouter.ai/keys",
    );
  }
  return key;
}

function getModels(): string[] {
  const raw = process.env.OPENROUTER_MODELS;
  if (!raw) {
    throw new Error(
      "OPENROUTER_MODELS environment variable is required. Set it to a JSON array of model IDs, e.g. [\"model-a\",\"model-b\"].",
    );
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error(
      "OPENROUTER_MODELS must be valid JSON (a string array). Example: [\"model-a\",\"model-b\"]",
    );
  }
  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error(
      "OPENROUTER_MODELS must be a non-empty JSON array of model ID strings.",
    );
  }
  const models = parsed
    .map((m) => (typeof m === "string" ? m.trim() : ""))
    .filter(Boolean);
  if (models.length === 0) {
    throw new Error("OPENROUTER_MODELS must contain at least one model ID.");
  }
  return models;
}

function shouldFailover(status: number, bodyText: string): boolean {
  if (status === 429) return true;
  if (status >= 500 && status <= 599) return true;
  const lower = bodyText.toLowerCase();
  if (
    lower.includes("rate limit") ||
    lower.includes("overloaded") ||
    lower.includes("unavailable") ||
    lower.includes("model is currently") ||
    lower.includes("provider") &&
      (lower.includes("error") || lower.includes("unavailable"))
  ) {
    return true;
  }
  return false;
}

function looksInvalid(text: string | undefined | null): boolean {
  if (!text) return true;
  const trimmed = text.trim();
  if (trimmed.length === 0) return true;
  return false;
}

async function callModel(
  model: string,
  messages: ChatMessageEntry[],
  apiKey: string,
  signal: AbortSignal,
): Promise<string> {
  const response = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://psynova.app",
      "X-Title": "PsyNova",
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.7,
      max_tokens: 2048,
    }),
    signal,
  });

  const bodyText = await response.text();

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new AiServiceError(
        "OpenRouter authentication failed. Check that OPENROUTER_API_KEY in .env is set to a valid key from https://openrouter.ai/keys",
      );
    }
    if (response.status === 402) {
      throw new AiServiceError(
        "OpenRouter payment required. Your account has insufficient credits for this model.",
      );
    }
    if (shouldFailover(response.status, bodyText)) {
      throw new FailoverError(
        `Model ${model} returned ${response.status}: ${bodyText.slice(0, 200)}`,
      );
    }
    throw new AiServiceError(
      `Request failed (${response.status}): ${bodyText.slice(0, 300)}`,
    );
  }

  let data: unknown;
  try {
    data = JSON.parse(bodyText);
  } catch {
    throw new FailoverError(`Model ${model} returned invalid JSON.`);
  }

  const choices = (data as { choices?: unknown })?.choices;
  if (!Array.isArray(choices) || choices.length === 0) {
    throw new FailoverError(`Model ${model} returned no choices.`);
  }

  const content = (choices[0] as { message?: { content?: unknown } })?.message
    ?.content;
  const text = typeof content === "string" ? content : "";

  if (looksInvalid(text)) {
    throw new FailoverError(`Model ${model} returned an empty response.`);
  }

  return text.trim();
}

class FailoverError extends Error {}
class AiServiceError extends Error {}

export interface GenerateOptions {
  systemPrompt: string;
  history: ChatMessageEntry[];
  message: string;
}

export async function generateReply(opts: GenerateOptions): Promise<string> {
  const apiKey = getApiKey();
  const models = getModels();
  const messages: ChatMessageEntry[] = [
    { role: "system", content: opts.systemPrompt },
    ...opts.history,
    { role: "user", content: opts.message },
  ];

  const failures: string[] = [];

  for (const model of models) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const text = await callModel(model, messages, apiKey, controller.signal);
      clearTimeout(timeout);
      return text;
    } catch (err) {
      clearTimeout(timeout);
      if (err instanceof FailoverError) {
        failures.push(`${model}: ${err.message}`);
        continue;
      }
      if (err instanceof DOMException && err.name === "AbortError") {
        failures.push(`${model}: timeout`);
        continue;
      }
      if (
        err instanceof TypeError ||
        (err instanceof Error && /fetch|network|ECONN/i.test(err.message))
      ) {
        failures.push(`${model}: network error — ${err.message}`);
        continue;
      }
      if (err instanceof AiServiceError) {
        throw err;
      }
      failures.push(`${model}: ${err instanceof Error ? err.message : "unknown"}`);
    }
  }

  throw new Error(
    "The AI service is temporarily unavailable. All models failed to respond. Please try again in a few moments.",
  );
}

export async function generateFromPrompt(
  systemPrompt: string,
  prompt: string,
): Promise<string> {
  return generateReply({
    systemPrompt,
    history: [],
    message: prompt,
  });
}
