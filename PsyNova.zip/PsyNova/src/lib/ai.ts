import type { AssessmentData, ChatMessage } from "./types";

const CRISIS_PATTERNS = [
  /\b(kill|kills|killing)\s*(my|me|myself)\b/i,
  /\bkill\s*myself\b/i,
  /\bend\s+(my\s+)?life\b/i,
  /\bsuicid(e|al)\b/i,
  /\bself[\s-]?harm\b/i,
  /\bslit\s+(my|the)\b/i,
  /\b overdose\b/i,
  /\bdon'?t\s+want\s+to\s+(live|be\s+here|exist)\b/i,
  /\bbetter\s+off\s+dead\b/i,
  /\bno\s+reason\s+to\s+live\b/i,
  /\bhurt\s+(myself|others)\b/i,
  /\bI\s+(am|feel)\s+going\s+to\s+die\b/i,
];

export function detectCrisis(text: string): boolean {
  return CRISIS_PATTERNS.some((re) => re.test(text));
}

export function buildCounselorSystemPrompt(assessment: AssessmentData): string {
  const profile = [
    `User's name: ${assessment.name || "the user"}.`,
    `Age: ${assessment.age || "unknown"}.`,
    `Gender: ${assessment.gender || "not specified"}.`,
    `Country: ${assessment.country || "unknown"}.`,
    `Preferred language: ${assessment.preferredLanguage || "English"}.`,
    `Occupation: ${assessment.occupation || "unknown"}.`,
    `Relationship status: ${assessment.relationshipStatus || "not specified"}.`,
    `Sleep quality (0-10): ${assessment.sleepQuality}.`,
    `Exercise frequency (0-10): ${assessment.exerciseFrequency}.`,
    `Personality type: ${assessment.personalityType || "unknown"}.`,
    `Current stress level (0-10): ${assessment.stressLevel}.`,
    `Energy level (0-10): ${assessment.energyLevel}.`,
    `Current mood (0-10): ${assessment.mood}.`,
    `Confidence (0-10): ${assessment.confidence}.`,
    `Social comfort (0-10): ${assessment.socialComfort}.`,
    `Optimism (0-10): ${assessment.optimism}.`,
    `Introvert(0) ↔ Extrovert(10): ${assessment.introvertExtrovert}.`,
    `Calm(0) ↔ Anxious(10): ${assessment.calmAnxious}.`,
    `Practical(0) ↔ Emotional(10): ${assessment.practicalEmotional}.`,
    `Daily screen time: ${assessment.dailyScreenTime}.`,
    `Current challenges: ${assessment.currentChallenges || "none shared"}.`,
    `Goals: ${assessment.goals || "not specified"}.`,
    `Additional notes: ${assessment.additionalNotes || "none"}.`,
  ].join("\n");

  return `You are PsyNova, an empathetic, calm, and supportive AI mental wellness companion. You are NOT a licensed therapist and must never diagnose medical conditions or prescribe medication.

YOUR ROLE
- Listen actively, reflect feelings, and validate emotions without judgment.
- Ask gentle, open-ended follow-up questions to help the user explore their thoughts.
- Reference and naturally recall things the user has shared earlier in this session.
- Offer practical, evidence-informed coping strategies: breathing exercises (e.g., 4-7-8, box breathing), grounding (5-4-3-2-1), progressive muscle relaxation, journaling prompts, sleep-hygiene tips, and mindfulness practices.
- Celebrate small wins and positive progress warmly but sincerely.
- Keep responses concise, warm, and conversational (usually 2-5 sentences unless a technique requires steps).
- Use plain Markdown: short paragraphs, occasional **bold** for key ideas, and bullet lists only for techniques/steps.
- Match the user's preferred language when possible: ${assessment.preferredLanguage || "English"}.

SAFETY (CRITICAL)
- Never encourage self-harm, suicide, violence, or risky behavior.
- If the user indicates self-harm, suicide, violence, or immediate danger, respond with calm compassion, encourage them to reach out to a trusted person or local emergency services, and gently recommend professional mental health support. Do not lecture or panic.
- Always encourage professional help when concerns seem serious or persistent.

USER CONTEXT (use this to personalize responses naturally — do not list it back verbatim):
${profile}

Remember everything shared in this active session so the conversation feels continuous. You do not retain memory after the session ends.`;
}

export function buildCrisisResponse(): string {
  return `I'm really glad you're talking to me, and I hear how much pain you're in right now. You're not alone in this. Because what you're sharing sounds serious, I want to make sure you get the best support possible:

- **Reach out to someone you trust** — a friend, family member, or teacher — and let them stay with you.
- **Contact local emergency services** (e.g., 911, 112, 999) or go to the nearest emergency room if you feel you can't keep yourself safe.
- **Call or text a crisis line** — in the US, 988 (Suicide & Crisis Lifeline); in the UK, 111 or 999; in India, iCall at 9152987821. These are free, confidential, and available 24/7.
- **Talk to a mental health professional** as soon as you can.

Please stay with me for a moment. Would you like to try a grounding exercise together while you reach out for support?`;
}

export function toOpenRouterHistory(
  history: ChatMessage[],
): { role: "user" | "assistant"; content: string }[] {
  return history.map((m) => ({
    role: m.role === "user" ? "user" : "assistant",
    content: m.content,
  }));
}
