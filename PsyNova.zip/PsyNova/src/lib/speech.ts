"use client";

let cachedVoice: SpeechSynthesisVoice | null = null;

function pickVoice(): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    return null;
  }
  if (cachedVoice) return cachedVoice;
  const voices = window.speechSynthesis.getVoices();
  if (voices.length === 0) return null;
  const preferred =
    voices.find(
      (v) =>
        v.name.includes("Google") &&
        v.lang.startsWith("en") &&
        v.name.toLowerCase().includes("female"),
    ) ||
    voices.find((v) => v.name.includes("Google") && v.lang.startsWith("en")) ||
    voices.find((v) => v.name.toLowerCase().includes("samantha")) ||
    voices.find((v) => v.name.toLowerCase().includes("aria")) ||
    voices.find((v) => v.lang.startsWith("en")) ||
    voices[0];
  cachedVoice = preferred || null;
  return cachedVoice;
}

if (typeof window !== "undefined" && "speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoice = null;
    pickVoice();
  };
}

export function isSpeechSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function speakText(
  text: string,
  opts?: { onEnd?: () => void; onStart?: () => void },
): void {
  if (!isSpeechSupported()) {
    opts?.onEnd?.();
    return;
  }
  window.speechSynthesis.cancel();
  const clean = text.replace(/[*#`>_~]/g, "").replace(/\s+/g, " ").trim();
  const chunks = clean.match(/[^.!?]+[.!?]+|\S[^.!?]*$/g) || [clean];
  const voice = pickVoice();
  let started = false;

  chunks.forEach((chunk, i) => {
    const u = new SpeechSynthesisUtterance(chunk);
    u.rate = 0.95;
    u.pitch = 1.0;
    u.volume = 1.0;
    if (voice) u.voice = voice;
    if (i === 0 && !started) {
      u.onstart = () => {
        started = true;
        opts?.onStart?.();
      };
    }
    if (i === chunks.length - 1) {
      u.onend = () => opts?.onEnd?.();
      u.onerror = () => opts?.onEnd?.();
    }
    window.speechSynthesis.speak(u);
  });

  if (!started) {
    opts?.onStart?.();
  }
}

export function stopSpeaking(): void {
  if (isSpeechSupported()) {
    window.speechSynthesis.cancel();
  }
}
