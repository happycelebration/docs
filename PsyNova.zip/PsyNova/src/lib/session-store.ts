"use client";

import { create } from "zustand";
import {
  type AssessmentData,
  type AnalysisResult,
  type ChatMessage,
  type MoodEntry,
  type View,
  DEFAULT_ASSESSMENT,
} from "./types";

interface SessionState {
  view: View;
  assessment: AssessmentData;
  assessmentDraft: AssessmentData;
  messages: ChatMessage[];
  moodHistory: MoodEntry[];
  analysis: AnalysisResult | null;
  sessionStartedAt: number;
  crisisCount: number;
  searchQuery: string;

  setView: (view: View) => void;
  setAssessmentDraft: (patch: Partial<AssessmentData>) => void;
  resetAssessmentDraft: () => void;
  commitAssessment: () => void;
  addMessage: (msg: Omit<ChatMessage, "id" | "timestamp">) => string;
  updateMessage: (id: string, patch: Partial<ChatMessage>) => void;
  removeMessage: (id: string) => void;
  togglePinned: (id: string) => void;
  toggleFavorite: (id: string) => void;
  clearMessages: () => void;
  recordMood: (mood: number, stress: number) => void;
  setAnalysis: (a: AnalysisResult) => void;
  incrementCrisis: () => void;
  setSearchQuery: (q: string) => void;
  resetSession: () => void;
}

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

export const useSessionStore = create<SessionState>((set) => ({
  view: "landing",
  assessment: { ...DEFAULT_ASSESSMENT },
  assessmentDraft: { ...DEFAULT_ASSESSMENT },
  messages: [],
  moodHistory: [],
  analysis: null,
  sessionStartedAt: Date.now(),
  crisisCount: 0,
  searchQuery: "",

  setView: (view) => set({ view }),
  setAssessmentDraft: (patch) =>
    set((s) => ({ assessmentDraft: { ...s.assessmentDraft, ...patch } })),
  resetAssessmentDraft: () =>
    set({ assessmentDraft: { ...DEFAULT_ASSESSMENT } }),
  commitAssessment: () =>
    set((s) => ({
      assessment: { ...s.assessmentDraft },
      moodHistory: [
        {
          timestamp: Date.now(),
          mood: s.assessmentDraft.mood,
          stress: s.assessmentDraft.stressLevel,
        },
      ],
    })),
  addMessage: (msg) => {
    const id = uid();
    set((s) => ({
      messages: [
        ...s.messages,
        { ...msg, id, timestamp: Date.now() },
      ],
    }));
    return id;
  },
  updateMessage: (id, patch) =>
    set((s) => ({
      messages: s.messages.map((m) =>
        m.id === id ? { ...m, ...patch } : m,
      ),
    })),
  removeMessage: (id) =>
    set((s) => ({ messages: s.messages.filter((m) => m.id !== id) })),
  togglePinned: (id) =>
    set((s) => ({
      messages: s.messages.map((m) =>
        m.id === id ? { ...m, pinned: !m.pinned } : m,
      ),
    })),
  toggleFavorite: (id) =>
    set((s) => ({
      messages: s.messages.map((m) =>
        m.id === id ? { ...m, favorite: !m.favorite } : m,
      ),
    })),
  clearMessages: () => set({ messages: [] }),
  recordMood: (mood, stress) =>
    set((s) => ({
      moodHistory: [...s.moodHistory, { timestamp: Date.now(), mood, stress }],
    })),
  setAnalysis: (a) => set({ analysis: a }),
  incrementCrisis: () => set((s) => ({ crisisCount: s.crisisCount + 1 })),
  setSearchQuery: (q) => set({ searchQuery: q }),
  resetSession: () =>
    set({
      view: "landing",
      assessment: { ...DEFAULT_ASSESSMENT },
      assessmentDraft: { ...DEFAULT_ASSESSMENT },
      messages: [],
      moodHistory: [],
      analysis: null,
      sessionStartedAt: Date.now(),
      crisisCount: 0,
      searchQuery: "",
    }),
}));
