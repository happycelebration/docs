export type View =
  | "landing"
  | "assessment"
  | "choice"
  | "chat"
  | "voice"
  | "dashboard";

export type Gender = "female" | "male" | "non-binary" | "prefer-not-to-say" | "";
export type RelationshipStatus =
  | "single"
  | "in-relationship"
  | "married"
  | "separated"
  | "divorced"
  | "widowed"
  | ""
  | "";

export interface AssessmentData {
  name: string;
  age: string;
  gender: Gender;
  country: string;
  preferredLanguage: string;
  occupation: string;
  relationshipStatus: RelationshipStatus;
  sleepQuality: number; // 0-10
  exerciseFrequency: number; // 0-10
  personalityType: string;
  stressLevel: number; // 0-10
  energyLevel: number; // 0-10
  mood: number; // 0-10
  confidence: number; // 0-10
  socialComfort: number; // 0-10
  optimism: number; // 0-10
  introvertExtrovert: number; // 0(intro)-10(extro)
  calmAnxious: number; // 0(calm)-10(anxious)
  practicalEmotional: number; // 0(practical)-10(emotional)
  dailyScreenTime: string;
  currentChallenges: string;
  goals: string;
  emergencyContact: string;
  additionalNotes: string;
}

export type MessageRole = "user" | "assistant";

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  mode: "chat" | "voice";
  pinned?: boolean;
  favorite?: boolean;
  edited?: boolean;
}

export interface MoodEntry {
  timestamp: number;
  mood: number;
  stress: number;
}

export interface AnalysisResult {
  wellnessScore: number;
  moodLabel: string;
  moodScore: number;
  stressLabel: string;
  stressScore: number;
  moodTrend: { time: string; mood: number }[];
  stressTrend: { time: string; stress: number }[];
  emotionBreakdown: { name: string; value: number; color: string }[];
  insights: string[];
  conversationSummary: string;
  positiveStrengths: string[];
  growthAreas: string[];
  recommendations: string[];
  dailyRoutine: string[];
  breathingExercise: string;
  mindfulnessTip: string;
  journalingPrompts: string[];
  affirmations: string[];
  goals: string[];
  resources: { name: string; detail: string }[];
  personalityInsights: string;
}

export const DEFAULT_ASSESSMENT: AssessmentData = {
  name: "",
  age: "",
  gender: "",
  country: "",
  preferredLanguage: "English",
  occupation: "",
  relationshipStatus: "",
  sleepQuality: 5,
  exerciseFrequency: 4,
  personalityType: "",
  stressLevel: 5,
  energyLevel: 5,
  mood: 5,
  confidence: 5,
  socialComfort: 5,
  optimism: 6,
  introvertExtrovert: 5,
  calmAnxious: 5,
  practicalEmotional: 5,
  dailyScreenTime: "3-5 hours",
  currentChallenges: "",
  goals: "",
  emergencyContact: "",
  additionalNotes: "",
};

export const PRIVACY_MESSAGE =
  "🔒 Your privacy comes first. PsyNova does not permanently store your personal information, conversations, voice transcripts, assessments, or reports. Everything exists only during your current session and is automatically deleted when you leave or refresh the website.";
