"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import {
  Send,
  Sparkles,
  Copy,
  Check,
  RefreshCw,
  Pin,
  PinOff,
  Heart,
  Search,
  Volume2,
  Square,
  Trash2,
  ArrowLeft,
  Pencil,
  X,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { speakText, stopSpeaking, isSpeechSupported } from "@/lib/speech";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useSessionStore } from "@/lib/session-store";
import { PRIVACY_MESSAGE } from "@/lib/types";
import { toast } from "sonner";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  mode: "chat" | "voice";
  pinned?: boolean;
  favorite?: boolean;
  edited?: boolean;
}

function timeOf(ts: number) {
  return new Date(ts).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function MessageBubble({
  msg,
  onCopy,
  onTts,
  onTogglePin,
  onToggleFav,
  onEdit,
  onRegenerate,
  ttsLoading,
  ttsPlaying,
  onStopTts,
  isLastAssistant,
}: {
  msg: ChatMessage;
  onCopy: (id: string, text: string) => void;
  onTts: (id: string, text: string) => void;
  onTogglePin: (id: string) => void;
  onToggleFav: (id: string) => void;
  onEdit: (id: string, text: string) => void;
  onRegenerate: (id: string) => void;
  ttsLoading: string | null;
  ttsPlaying: string | null;
  onStopTts: () => void;
  isLastAssistant: boolean;
}) {
  const isUser = msg.role === "user";
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(msg.content);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className={`group flex w-full gap-3 ${isUser ? "flex-row-reverse" : "flex-row"}`}
    >
      <div
        className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl shadow ${
          isUser
            ? "bg-gradient-to-br from-primary to-accent text-primary-foreground"
            : "bg-gradient-to-br from-secondary to-primary text-primary-foreground"
        }`}
      >
        {isUser ? (
          <span className="text-xs font-bold">
            {("You").slice(0, 1)}
          </span>
        ) : (
          <Sparkles className="h-4 w-4" />
        )}
      </div>

      <div className={`flex max-w-[78%] flex-col ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
            isUser
              ? "bg-primary/15 text-foreground rounded-tr-sm"
              : "glass text-foreground rounded-tl-sm"
          }`}
        >
          {editing ? (
            <div className="flex flex-col gap-2">
              <Textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={3}
                className="bg-background/60"
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    onEdit(msg.id, draft);
                    setEditing(false);
                  }}
                >
                  Save
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setDraft(msg.content);
                    setEditing(false);
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : isUser ? (
            <p className="whitespace-pre-wrap">{msg.content}</p>
          ) : (
            <div className="prose prose-sm max-w-none dark:prose-invert prose-p:my-1 prose-ul:my-1 prose-li:my-0 prose-strong:text-foreground">
              <ReactMarkdown>{msg.content}</ReactMarkdown>
            </div>
          )}
        </div>

        <div className="mt-1 flex items-center gap-1 px-1 text-xs text-muted-foreground">
          <span>{timeOf(msg.timestamp)}</span>
          {msg.edited && <span>· edited</span>}
          {msg.pinned && <Pin className="h-3 w-3 text-warning" />}

          {!editing && (
            <div className="ml-1 flex items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
              {!isUser && (
                <>
                  {ttsPlaying === msg.id ? (
                    <IconBtn title="Stop" onClick={onStopTts}>
                      <Square className="h-3.5 w-3.5" />
                    </IconBtn>
                  ) : (
                    <IconBtn
                      title="Read aloud"
                      onClick={() => onTts(msg.id, msg.content)}
                      loading={ttsLoading === msg.id}
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                    </IconBtn>
                  )}
                  {isLastAssistant && (
                    <IconBtn title="Regenerate" onClick={() => onRegenerate(msg.id)}>
                      <RefreshCw className="h-3.5 w-3.5" />
                    </IconBtn>
                  )}
                </>
              )}
              <IconBtn title="Copy" onClick={() => onCopy(msg.id, msg.content)}>
                <Copy className="h-3.5 w-3.5" />
              </IconBtn>
              <IconBtn
                title={msg.pinned ? "Unpin" : "Pin"}
                onClick={() => onTogglePin(msg.id)}
              >
                {msg.pinned ? (
                  <PinOff className="h-3.5 w-3.5 text-warning" />
                ) : (
                  <Pin className="h-3.5 w-3.5" />
                )}
              </IconBtn>
              <IconBtn
                title="Favorite"
                onClick={() => onToggleFav(msg.id)}
              >
                <Heart
                  className={`h-3.5 w-3.5 ${
                    msg.favorite ? "fill-destructive text-destructive" : ""
                  }`}
                />
              </IconBtn>
              {isUser && (
                <IconBtn
                  title="Edit"
                  onClick={() => {
                    setDraft(msg.content);
                    setEditing(true);
                  }}
                >
                  <Pencil className="h-3.5 w-3.5" />
                </IconBtn>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  loading,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  loading?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={onClick}
      disabled={loading}
      className="grid h-6 w-6 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary disabled:opacity-50"
    >
      {loading ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : children}
    </button>
  );
}

function TypingDots() {
  return (
    <div className="flex items-center gap-1 py-1">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="h-2 w-2 rounded-full bg-primary"
          animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }}
          transition={{
            duration: 0.9,
            repeat: Infinity,
            delay: i * 0.15,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

export function Chat() {
  const assessment = useSessionStore((s) => s.assessment);
  const messages = useSessionStore((s) => s.messages);
  const addMessage = useSessionStore((s) => s.addMessage);
  const updateMessage = useSessionStore((s) => s.updateMessage);
  const removeMessage = useSessionStore((s) => s.removeMessage);
  const togglePinned = useSessionStore((s) => s.togglePinned);
  const toggleFavorite = useSessionStore((s) => s.toggleFavorite);
  const clearMessages = useSessionStore((s) => s.clearMessages);
  const setView = useSessionStore((s) => s.setView);
  const recordMood = useSessionStore((s) => s.recordMood);
  const incrementCrisis = useSessionStore((s) => s.incrementCrisis);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [ttsLoading, setTtsLoading] = useState<string | null>(null);
  const [ttsPlaying, setTtsPlaying] = useState<string | null>(null);
  const [showFavsOnly, setShowFavsOnly] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef(false);

  const filtered = messages.filter((m) => {
    if (showFavsOnly && !m.favorite) return false;
    if (search.trim()) {
      return m.content.toLowerCase().includes(search.toLowerCase());
    }
    return true;
  });

  const pinned = messages.filter((m) => m.pinned);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages.length, loading]);

  const stopTts = useCallback(() => {
    stopSpeaking();
    setTtsPlaying(null);
  }, []);

  const sendToApi = useCallback(
    async (history: ChatMessage[]) => {
      setLoading(true);
      abortRef.current = false;
      const thinkingId = addMessage({
        role: "assistant",
        content: "",
        mode: "chat",
      });
      try {
        const finalRes = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            assessment,
            history: history.slice(-12),
            message: history[history.length - 1]?.content || "",
          }),
        });
        const data = await finalRes.json();
        if (!finalRes.ok) {
          throw new Error(data.error || "Request failed");
        }
        removeMessage(thinkingId);
        if (abortRef.current) return;
        const reply: string = data.reply;
        // typewriter effect
        let i = 0;
        const id = addMessage({ role: "assistant", content: "", mode: "chat" });
        const step = Math.max(2, Math.round(reply.length / 80));
        const interval = setInterval(() => {
          i += step;
          updateMessage(id, { content: reply.slice(0, i) });
          if (i >= reply.length) {
            clearInterval(interval);
            updateMessage(id, { content: reply });
          }
        }, 16);
        if (data.crisis) {
          incrementCrisis();
          toast.warning("Support resources shared. You're not alone.", {
            description: "Consider reaching out to a crisis line now.",
          });
        }
      } catch (err) {
        removeMessage(thinkingId);
        const message = err instanceof Error ? err.message : "Unknown error";
        addMessage({
          role: "assistant",
          content: `I had trouble responding just now — ${message}`,
          mode: "chat",
        });
        if (
          message.includes("authentication failed") ||
          message.includes("region") ||
          message.includes("API key") ||
          message.includes("temporarily unavailable")
        ) {
          toast.error("AI Service Error", {
            description: message,
            duration: 8000,
          });
        }
      } finally {
        setLoading(false);
      }
    },
    [assessment, addMessage, removeMessage, updateMessage, incrementCrisis],
  );

  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || loading) return;
    if (text.length > 4000) {
      toast.error("Message is too long (max 4000 characters).");
      return;
    }
    addMessage({ role: "user", content: text, mode: "chat" });
    setInput("");
    const nextHistory = [
      ...messages,
      {
        id: "tmp",
        role: "user" as const,
        content: text,
        timestamp: Date.now(),
        mode: "chat" as const,
      },
    ];
    await sendToApi(nextHistory);
    recordMood(assessment.mood, assessment.stressLevel);
  }, [
    input,
    loading,
    messages,
    addMessage,
    sendToApi,
    recordMood,
    assessment,
  ]);

  const handleRegenerate = useCallback(
    async (assistantId: string) => {
      if (loading) return;
      const idx = messages.findIndex((m) => m.id === assistantId);
      if (idx < 0) return;
      const history = messages.slice(0, idx);
      removeMessage(assistantId);
      await sendToApi(history);
    },
    [loading, messages, removeMessage, sendToApi],
  );

  const handleEdit = useCallback(
    async (id: string, text: string) => {
      const idx = messages.findIndex((m) => m.id === id);
      if (idx < 0) return;
      updateMessage(id, { content: text, edited: true });
      const history = [
        ...messages.slice(0, idx),
        {
          id,
          role: "user" as const,
          content: text,
          timestamp: messages[idx].timestamp,
          mode: "chat" as const,
        },
      ];
      const after = messages.slice(idx + 1);
      // remove messages after edited one
      after.forEach((m) => removeMessage(m.id));
      await sendToApi(history);
    },
    [messages, updateMessage, removeMessage, sendToApi],
  );

  const handleCopy = useCallback((id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    toast.success("Copied to clipboard");
    setTimeout(() => setCopied(null), 1500);
  }, []);

  const handleTts = useCallback((id: string, text: string) => {
    if (!isSpeechSupported()) {
      toast.error("Speech synthesis is not supported in this browser.");
      return;
    }
    stopSpeaking();
    setTtsLoading(id);
    setTtsPlaying(id);
    speakText(text, {
      onEnd: () => {
        setTtsPlaying(null);
        setTtsLoading(null);
      },
    });
    setTimeout(() => setTtsLoading(null), 300);
  }, []);

  useEffect(() => {
    return () => stopTts();
  }, [stopTts]);

  const lastAssistantId = [...messages]
    .reverse()
    .find((m) => m.role === "assistant")?.id;

  return (
    <main className="mx-auto flex h-[calc(100vh-4rem)] max-w-[1700px] flex-col px-3 sm:px-6 lg:px-10">
      {/* Header */}
      <div className="glass-strong sticky top-16 z-10 mb-2 flex items-center justify-between gap-2 rounded-2xl p-3">
        <div className="flex items-center gap-2.5">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setView("choice")}
            className="h-8 w-8"
            aria-label="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-secondary to-primary text-primary-foreground">
            <Sparkles className="h-4 w-4" />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight">PsyNova Counselor</p>
            <p className="text-xs text-muted-foreground leading-tight">
              {assessment.name ? `Session with ${assessment.name}` : "Active session"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {showFavsOnly && (
            <Badge variant="secondary" className="gap-1">
              <Heart className="h-3 w-3 fill-destructive text-destructive" />
              Favorites
            </Badge>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setShowFavsOnly((v) => !v)}
            aria-label="Toggle favorites"
          >
            <Heart
              className={`h-4 w-4 ${showFavsOnly ? "fill-destructive text-destructive" : ""}`}
            />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setShowSearch((v) => !v)}
            aria-label="Search messages"
          >
            <Search className="h-4 w-4" />
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive"
                aria-label="Clear conversation"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear conversation?</AlertDialogTitle>
                <AlertDialogDescription>
                  This removes all messages from your current session. This
                  cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => {
                    clearMessages();
                    toast.success("Conversation cleared.");
                  }}
                >
                  Clear
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* Search bar */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-2 overflow-hidden"
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search messages..."
                className="glass pl-9"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Pinned messages */}
      {pinned.length > 0 && !search && (
        <div className="mb-2 glass rounded-xl p-2">
          <p className="px-2 py-1 text-xs font-medium text-muted-foreground">
            Pinned
          </p>
          <div className="thin-scrollbar flex max-h-24 gap-2 overflow-x-auto">
            {pinned.map((p) => (
              <div
                key={p.id}
                className="glass-strong max-w-xs shrink-0 rounded-lg p-2 text-xs"
              >
                <p className="line-clamp-2">{p.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      <div
        ref={scrollRef}
        className="thin-scrollbar flex-1 space-y-4 overflow-y-auto rounded-2xl p-2 sm:p-4"
      >
        {filtered.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-lg">
              <Sparkles className="h-8 w-8" />
            </div>
            <div>
              <p className="text-lg font-semibold">
                Hi {assessment.name || "there"} 💙
              </p>
              <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                I'm your PsyNova counselor. Share whatever's on your mind —
                I'm here to listen and support you.
              </p>
            </div>
            <div className="glass mt-2 max-w-md rounded-xl p-3 text-xs text-muted-foreground">
              {PRIVACY_MESSAGE}
            </div>
          </div>
        )}

        {filtered.map((m) => (
          <MessageBubble
            key={m.id}
            msg={m}
            onCopy={handleCopy}
            onTts={handleTts}
            onTogglePin={togglePinned}
            onToggleFav={toggleFavorite}
            onEdit={handleEdit}
            onRegenerate={handleRegenerate}
            ttsLoading={ttsLoading}
            ttsPlaying={ttsPlaying}
            onStopTts={stopTts}
            isLastAssistant={m.id === lastAssistantId && !loading}
          />
        ))}

        {loading && (
          <div className="flex gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-secondary to-primary text-primary-foreground">
              <Sparkles className="h-4 w-4" />
            </div>
            <div className="glass rounded-2xl rounded-tl-sm px-4 py-3">
              <TypingDots />
            </div>
          </div>
        )}
      </div>

      {/* Crisis note */}
      {messages.some((m) => m.content.includes("crisis line")) && (
        <div className="mt-2 flex items-center gap-2 rounded-xl border border-warning/40 bg-warning/10 p-2.5 text-xs text-warning-foreground">
          <AlertTriangle className="h-4 w-4 shrink-0 text-warning" />
          If you're in immediate danger, please contact local emergency services
          or a crisis line right away.
        </div>
      )}

      {/* Input */}
      <div className="glass-strong sticky bottom-0 z-10 mt-2 rounded-2xl p-3">
        <div className="flex items-end gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type how you're feeling..."
            rows={1}
            className="max-h-32 min-h-[44px] resize-none bg-background/50"
            disabled={loading}
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            size="icon"
            className="h-11 w-11 shrink-0 rounded-xl bg-gradient-to-br from-primary to-secondary text-primary-foreground"
            aria-label="Send"
          >
            {loading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
        <p className="mt-1.5 px-1 text-[11px] text-muted-foreground">
          Press Enter to send · Shift+Enter for a new line · PsyNova is not a
          substitute for professional care.
        </p>
      </div>
    </main>
  );
}
