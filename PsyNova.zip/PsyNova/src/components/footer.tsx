"use client";

import { useSessionStore } from "@/lib/session-store";

export function Footer() {
  const setView = useSessionStore((s) => s.setView);
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto border-t border-border/60 glass">
      <div className="mx-auto max-w-[1700px] px-4 py-6 sm:px-6 lg:px-10">
        <button
          onClick={() => setView("landing")}
          className="block w-full text-center text-xs text-muted-foreground transition-colors hover:text-foreground"
        >
          © {year} PsyNova by Pallavi Thakur. All Rights Reserved.
        </button>
      </div>
    </footer>
  );
}
