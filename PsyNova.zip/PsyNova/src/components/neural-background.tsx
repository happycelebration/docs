"use client";

import { useEffect, useRef } from "react";

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  pulse: number;
  pulseSpeed: number;
}

const NODE_COUNT = 64;
const MAX_DISTANCE = 180;
const COLORS = ["#7c9cf5", "#b06cf5", "#5eead4"];

function prefersReducedMotion() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function readTheme() {
  if (typeof document === "undefined") return COLORS;
  const root = getComputedStyle(document.documentElement);
  const p = root.getPropertyValue("--primary").trim();
  const s = root.getPropertyValue("--secondary").trim();
  const a = root.getPropertyValue("--accent").trim();
  const out = [p, s, a].filter(Boolean);
  return out.length ? out : COLORS;
}

function resolveColor(raw: string): string {
  if (!raw) return COLORS[0];
  const trimmed = raw.trim();
  if (trimmed.startsWith("oklch")) {
    return `oklch(${trimmed.replace(/^oklch\((.*)\)$/i, "$1")})`;
  }
  return trimmed;
}

export function NeuralBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = prefersReducedMotion();
    let width = 0;
    let height = 0;
    let dpr = 1;
    let nodes: Node[] = [];
    let colors = readTheme();

    function resize() {
      if (!canvas || !ctx) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const density = Math.min(
        NODE_COUNT,
        Math.max(28, Math.floor((width * height) / 26000)),
      );
      nodes = Array.from({ length: density }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.28,
        vy: (Math.random() - 0.5) * 0.28,
        radius: 1.5 + Math.random() * 1.8,
        pulse: Math.random() * Math.PI * 2,
        pulseSpeed: 0.008 + Math.random() * 0.014,
      }));
    }

    function draw() {
      if (!ctx) return;
      ctx.clearRect(0, 0, width, height);

      const resolved = colors.map(resolveColor);
      const lineColor = resolved[0];

      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        if (!reduced) {
          a.x += a.vx;
          a.y += a.vy;
          a.pulse += a.pulseSpeed;
        }
        if (a.x < -20) a.x = width + 20;
        if (a.x > width + 20) a.x = -20;
        if (a.y < -20) a.y = height + 20;
        if (a.y > height + 20) a.y = -20;

        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < MAX_DISTANCE) {
            const alpha = (1 - dist / MAX_DISTANCE) * 0.4;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle =
              lineColor.startsWith("oklch")
                ? `oklch(from ${lineColor} l c h / ${alpha})`
                : lineColor;
            ctx.globalAlpha = lineColor.startsWith("oklch") ? 1 : alpha;
            ctx.lineWidth = 0.7;
            ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1;

      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        const pulseAlpha = reduced
          ? 0.5
          : 0.45 + Math.sin(a.pulse) * 0.25;
        const glowR = a.radius * (reduced ? 2.4 : 2.4 + Math.sin(a.pulse) * 0.6);
        const baseColor = resolved[i % resolved.length];

        const grad = ctx.createRadialGradient(a.x, a.y, 0, a.x, a.y, glowR);
        grad.addColorStop(
          0,
          baseColor.startsWith("oklch")
            ? `oklch(from ${baseColor} l c h / ${pulseAlpha})`
            : baseColor,
        );
        grad.addColorStop(1, "transparent");
        ctx.beginPath();
        ctx.arc(a.x, a.y, glowR, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        if (!baseColor.startsWith("oklch")) ctx.globalAlpha = pulseAlpha * 0.5;
        ctx.fill();
        ctx.globalAlpha = 1;

        ctx.beginPath();
        ctx.arc(a.x, a.y, a.radius, 0, Math.PI * 2);
        ctx.fillStyle = baseColor;
        if (!baseColor.startsWith("oklch")) ctx.globalAlpha = 0.85;
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      if (!reduced) {
        rafRef.current = requestAnimationFrame(draw);
      }
    }

    function handleTheme() {
      colors = readTheme();
    }

    resize();
    draw();
    window.addEventListener("resize", resize);
    window.addEventListener("focus", handleTheme);
    const themeObserver = new MutationObserver(handleTheme);
    themeObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
      window.removeEventListener("focus", handleTheme);
      themeObserver.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 h-full w-full opacity-70 dark:opacity-80"
    />
  );
}
