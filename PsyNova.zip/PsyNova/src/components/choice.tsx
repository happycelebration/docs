"use client";

import { motion } from "framer-motion";
import {
  MessageSquareHeart,
  PhoneCall,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  LayoutDashboard,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSessionStore } from "@/lib/session-store";
import { PRIVACY_MESSAGE } from "@/lib/types";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export function Choice() {
  const setView = useSessionStore((s) => s.setView);
  const name = useSessionStore((s) => s.assessment.name);

  return (
    <main className="relative mx-auto max-w-[1300px] px-4 pb-16 pt-12 sm:px-6 lg:px-10">
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        className="mb-10 text-center"
      >
        <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-xl shadow-primary/30">
          <Sparkles className="h-7 w-7" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
          Welcome, <span className="text-gradient">{name || "friend"}</span>
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
          Your assessment is ready. How would you like to connect with your AI
          counselor today?
        </p>
      </motion.div>

      <div className="grid gap-6 md:grid-cols-2">
        <motion.button
          variants={fadeUp}
          initial="hidden"
          animate="show"
          whileHover={{ y: -6 }}
          onClick={() => setView("chat")}
          className="group glass-strong relative overflow-hidden rounded-3xl p-8 text-left transition-shadow hover:shadow-2xl hover:shadow-primary/20"
        >
          <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 rounded-full bg-primary/20 blur-3xl transition-opacity group-hover:opacity-80" />
          <div className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-lg">
            <MessageSquareHeart className="h-7 w-7" />
          </div>
          <h2 className="text-2xl font-bold">Start Chat</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            A beautiful text conversation with your AI counselor. Markdown
            support, text-to-speech, copy, regenerate, and message search.
          </p>
          <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-primary">
            Open chat
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </span>
        </motion.button>

        <motion.button
          variants={fadeUp}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.1 }}
          whileHover={{ y: -6 }}
          onClick={() => setView("voice")}
          className="group glass-strong relative overflow-hidden rounded-3xl p-8 text-left transition-shadow hover:shadow-2xl hover:shadow-secondary/20"
        >
          <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 rounded-full bg-secondary/20 blur-3xl transition-opacity group-hover:opacity-80" />
          <div className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-secondary to-accent text-primary-foreground shadow-lg">
            <PhoneCall className="h-7 w-7" />
          </div>
          <h2 className="text-2xl font-bold">Start Voice Call</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            A real phone-call experience. Speak naturally and hear your
            counselor respond with a calming voice, continuously.
          </p>
          <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-secondary">
            Start call
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </span>
        </motion.button>
      </div>

      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        transition={{ delay: 0.2 }}
        className="mt-8 flex flex-col items-center gap-4"
      >
        <div className="glass flex w-full max-w-[1100px] items-center gap-3 rounded-2xl border-success/30 bg-success/5 p-4 text-sm text-muted-foreground">
          <ShieldCheck className="h-5 w-5 shrink-0 text-success" />
          {PRIVACY_MESSAGE}
        </div>
        <Button
          variant="outline"
          onClick={() => setView("dashboard")}
          className="gap-1.5"
        >
          <LayoutDashboard className="h-4 w-4" />
          View Dashboard
        </Button>
      </motion.div>
    </main>
  );
}
