"use client";

import { useCallback, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, X, FileText, Loader2 } from "lucide-react";
import type { AnalysisResult, AssessmentData } from "@/lib/types";
import { toast } from "sonner";

const PRIMARY = "#6c8df5";
const SECONDARY = "#b06cf5";
const ACCENT = "#3edccb";
const SUCCESS = "#3ec98f";
const WARNING = "#f5a623";
const DESTRUCTIVE = "#f56c6c";
const INK = "#1c2333";
const MUTE = "#6b7280";
const LIGHT = "#f4f6fb";

function MiniBars({
  data,
  color,
  max = 10,
}: {
  data: { label: string; value: number }[];
  color: string;
  max?: number;
}) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 70 }}>
      {data.map((d, i) => (
        <div
          key={i}
          style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}
        >
          <div
            style={{
              width: "100%",
              height: `${(d.value / max) * 100}%`,
              backgroundColor: color,
              borderRadius: 4,
              minHeight: 4,
            }}
          />
          <span style={{ fontSize: 7, color: MUTE, marginTop: 2 }}>{d.label}</span>
        </div>
      ))}
    </div>
  );
}

function EmotionBars({
  data,
}: {
  data: { name: string; value: number; color: string }[];
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {data.map((e, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 70, fontSize: 8, color: INK }}>{e.name}</span>
          <div style={{ flex: 1, height: 8, backgroundColor: LIGHT, borderRadius: 4 }}>
            <div
              style={{
                width: `${e.value}%`,
                height: "100%",
                backgroundColor: e.color,
                borderRadius: 4,
              }}
            />
          </div>
          <span style={{ fontSize: 8, color: MUTE, width: 24 }}>{e.value}%</span>
        </div>
      ))}
    </div>
  );
}

function SectionTitle({ children, color = PRIMARY }: { children: React.ReactNode; color?: string }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        marginBottom: 8,
        paddingBottom: 4,
        borderBottomWidth: 1.5,
        borderBottomColor: color,
        borderBottomStyle: "solid",
      }}
    >
      <span style={{ fontSize: 13, fontWeight: 700, color }}>{children}</span>
    </div>
  );
}

function Card({
  children,
  bg = "#ffffff",
}: {
  children: React.ReactNode;
  bg?: string;
}) {
  return (
    <div
      style={{
        backgroundColor: bg,
        borderRadius: 10,
        padding: 12,
        borderWidth: 1,
        borderColor: "#e5e7eb",
        borderStyle: "solid",
      }}
    >
      {children}
    </div>
  );
}

function ListItem({ children, color = PRIMARY }: { children: React.ReactNode; color?: string }) {
  return (
    <div style={{ display: "flex", gap: 6, marginBottom: 3 }}>
      <span style={{ color, fontWeight: 700 }}>•</span>
      <span style={{ fontSize: 9.5, color: INK, lineHeight: 1.5 }}>{children}</span>
    </div>
  );
}

export function WellnessReport({
  analysis,
  assessment,
  onClose,
}: {
  analysis: AnalysisResult;
  assessment: AssessmentData;
  onClose: () => void;
}) {
  const [downloading, setDownloading] = useState(false);

  const buildDoc = useCallback(async () => {
    const pdf = await import("@react-pdf/renderer");
    const { Page, Text, View, Document, StyleSheet } = pdf;

    const Row = ({ label, value }: { label: string; value: string }) => (
      <View style={{ display: "flex", flexDirection: "row", justifyContent: "space-between" }}>
        <Text style={{ fontSize: 9, color: "#6b7280" }}>{label}</Text>
        <Text style={{ fontSize: 9, fontWeight: 600, color: INK }}>{value}</Text>
      </View>
    );

    const Pill = ({ color, label }: { color: string; label: string }) => (
      <Text
        style={{
          fontSize: 8,
          color: "#ffffff",
          backgroundColor: color,
          paddingHorizontal: 7,
          paddingVertical: 3,
          borderRadius: 10,
          alignSelf: "flex-start",
        }}
      >
        {label}
      </Text>
    );

    const styles = StyleSheet.create({
      page: {
        padding: 36,
        fontFamily: "Helvetica",
        fontSize: 10,
        color: INK,
        backgroundColor: "#ffffff",
      },
      cover: {
        padding: 48,
        backgroundColor: "#0f1729",
        color: "#ffffff",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      },
      brand: { fontSize: 26, fontWeight: 700, color: "#ffffff" },
      brandAccent: { color: ACCENT },
      coverTitle: { fontSize: 34, fontWeight: 700, lineHeight: 1.2, marginTop: 24 },
      coverSub: { fontSize: 13, color: "#c7d2fe", marginTop: 12 },
      coverBadge: {
        fontSize: 9,
        color: ACCENT,
        backgroundColor: "rgba(62,220,203,0.12)",
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 12,
        alignSelf: "flex-start",
      },
      coverFooter: { fontSize: 9, color: "#94a3b8" },
      h1: { fontSize: 18, fontWeight: 700, marginBottom: 10 },
      grid2: { display: "flex", flexDirection: "row", gap: 10 },
      col: { flex: 1 },
      scoreBig: { fontSize: 44, fontWeight: 700, color: PRIMARY },
      label: { fontSize: 8, color: MUTE, textTransform: "uppercase", letterSpacing: 0.5 },
      value: { fontSize: 11, fontWeight: 600, color: INK },
      muted: { fontSize: 9, color: MUTE, lineHeight: 1.5 },
      pill: {
        fontSize: 8,
        paddingHorizontal: 7,
        paddingVertical: 3,
        borderRadius: 10,
        color: "#ffffff",
      },
      footer: {
        position: "absolute",
        bottom: 20,
        left: 36,
        right: 36,
        display: "flex",
        justifyContent: "space-between",
        fontSize: 8,
        color: MUTE,
        borderTopWidth: 1,
        borderTopColor: "#e5e7eb",
        borderTopStyle: "solid",
        paddingTop: 6,
      },
      disclaimer: {
        fontSize: 8,
        color: MUTE,
        backgroundColor: LIGHT,
        padding: 8,
        borderRadius: 6,
        marginTop: 8,
        lineHeight: 1.5,
      },
    });

    const dateStr = new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    const doc = (
      <Document>
        {/* Cover */}
        <Page size="A4" style={styles.cover}>
          <View>
            <Text style={styles.brand}>
              Psy<Text style={styles.brandAccent}>Nova</Text>
            </Text>
            <Text style={styles.coverBadge}>Private · Session-Based · AI Wellness</Text>
          </View>
          <View>
            <Text style={styles.coverTitle}>
              Personalized{"\n"}Wellness Report
            </Text>
            <Text style={styles.coverSub}>
              A compassionate snapshot of your mental wellbeing — generated
              securely in your browser, never stored.
            </Text>
          </View>
          <View>
            <Text style={{ fontSize: 11, color: "#ffffff", fontWeight: 600 }}>
              Prepared for {assessment.name || "You"}
            </Text>
            <Text style={styles.coverFooter}>{dateStr}</Text>
            <Text style={styles.coverFooter}>
              © {new Date().getFullYear()} PsyNova by Pallavi Thakur. All
              Rights Reserved.
            </Text>
          </View>
        </Page>

        {/* Page 2 — Profile + Assessment summary */}
        <Page size="A4" style={styles.page}>
          <Text style={styles.h1}>User Profile & Assessment</Text>
          <View style={styles.grid2}>
            <View style={styles.col}>
              <Card>
                <SectionTitle>Profile</SectionTitle>
                <View style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <Row label="Name" value={assessment.name || "—"} />
                  <Row label="Age" value={assessment.age || "—"} />
                  <Row label="Gender" value={assessment.gender || "—"} />
                  <Row label="Country" value={assessment.country || "—"} />
                  <Row label="Language" value={assessment.preferredLanguage || "—"} />
                  <Row label="Occupation" value={assessment.occupation || "—"} />
                  <Row
                    label="Relationship"
                    value={assessment.relationshipStatus || "—"}
                  />
                </View>
              </Card>
            </View>
            <View style={styles.col}>
              <Card bg={LIGHT}>
                <SectionTitle color={SECONDARY}>Wellness Score</SectionTitle>
                <Text style={styles.scoreBig}>{Math.round(analysis.wellnessScore)}</Text>
                <Text style={styles.muted}>out of 100</Text>
                <View style={{ marginTop: 10, display: "flex", gap: 6 }}>
                  <Pill color={PRIMARY} label={`Mood: ${analysis.moodScore}/10`} />
                  <Pill color={WARNING} label={`Stress: ${analysis.stressScore}/10`} />
                  <Pill color={SUCCESS} label={analysis.moodLabel} />
                </View>
              </Card>
            </View>
          </View>

          <View style={{ marginTop: 12 }}>
            <Card>
              <SectionTitle color={ACCENT}>Assessment Snapshot</SectionTitle>
              <View style={styles.grid2}>
                <View style={styles.col}>
                  <MiniBars
                    color={PRIMARY}
                    data={[
                      { label: "Sleep", value: assessment.sleepQuality },
                      { label: "Exercise", value: assessment.exerciseFrequency },
                      { label: "Mood", value: assessment.mood },
                      { label: "Energy", value: assessment.energyLevel },
                      { label: "Conf.", value: assessment.confidence },
                    ]}
                  />
                </View>
                <View style={styles.col}>
                  <MiniBars
                    color={SECONDARY}
                    data={[
                      { label: "Stress", value: assessment.stressLevel },
                      { label: "Social", value: assessment.socialComfort },
                      { label: "Optimism", value: assessment.optimism },
                      { label: "Extro", value: assessment.introvertExtrovert },
                      { label: "Anxious", value: assessment.calmAnxious },
                    ]}
                  />
                </View>
              </View>
            </Card>
          </View>

          <View style={{ marginTop: 12 }}>
            <Card>
              <SectionTitle color={PRIMARY}>Conversation Summary</SectionTitle>
              <Text style={{ fontSize: 10, lineHeight: 1.6, color: INK }}>
                {analysis.conversationSummary}
              </Text>
              <Text style={[styles.muted, { marginTop: 6 }]}>
                Personality insight: {analysis.personalityInsights}
              </Text>
            </Card>
          </View>

          <View style={styles.disclaimer}>
            PsyNova is an AI-powered mental wellness companion, not a
            replacement for licensed mental health professionals. If you are in
            crisis, contact local emergency services or a crisis line (US: 988,
            UK: 111/999, India: iCall 9152987821).
          </View>

          <View style={styles.footer} fixed>
            <Text>PsyNova Wellness Report · {assessment.name}</Text>
            <Text>{dateStr}</Text>
          </View>
        </Page>

        {/* Page 3 — Mood/Stress/Emotion analysis */}
        <Page size="A4" style={styles.page}>
          <Text style={styles.h1}>Mood & Stress Analysis</Text>
          <View style={styles.grid2}>
            <View style={styles.col}>
              <Card>
                <SectionTitle color={PRIMARY}>Mood Trend</SectionTitle>
                <MiniBars
                  color={PRIMARY}
                  data={analysis.moodTrend.map((m) => ({
                    label: m.time,
                    value: m.mood,
                  }))}
                />
                <Text style={[styles.muted, { marginTop: 6 }]}>
                  Current mood: {analysis.moodLabel} ({analysis.moodScore}/10)
                </Text>
              </Card>
            </View>
            <View style={styles.col}>
              <Card>
                <SectionTitle color={WARNING}>Stress Trend</SectionTitle>
                <MiniBars
                  color={WARNING}
                  data={analysis.stressTrend.map((s) => ({
                    label: s.time,
                    value: s.stress,
                  }))}
                />
                <Text style={[styles.muted, { marginTop: 6 }]}>
                  Current stress: {analysis.stressLabel} ({analysis.stressScore}/10)
                </Text>
              </Card>
            </View>
          </View>

          <View style={{ marginTop: 12 }}>
            <Card>
              <SectionTitle color={ACCENT}>Emotion Breakdown</SectionTitle>
              <EmotionBars data={analysis.emotionBreakdown} />
            </Card>
          </View>

          <View style={{ marginTop: 12 }}>
            <Card>
              <SectionTitle color={SECONDARY}>Session Insights</SectionTitle>
              {analysis.insights.map((ins, i) => (
                <ListItem key={i} color={SECONDARY}>
                  {ins}
                </ListItem>
              ))}
            </Card>
          </View>

          <View style={styles.footer} fixed>
            <Text>PsyNova Wellness Report · {assessment.name}</Text>
            <Text>{dateStr}</Text>
          </View>
        </Page>

        {/* Page 4 — Strengths, Growth, Recommendations */}
        <Page size="A4" style={styles.page}>
          <Text style={styles.h1}>Strengths & Recommendations</Text>
          <View style={styles.grid2}>
            <View style={styles.col}>
              <Card bg="#ecfdf5">
                <SectionTitle color={SUCCESS}>Positive Strengths</SectionTitle>
                {analysis.positiveStrengths.map((s, i) => (
                  <ListItem key={i} color={SUCCESS}>
                    {s}
                  </ListItem>
                ))}
              </Card>
            </View>
            <View style={styles.col}>
              <Card bg="#fff7ed">
                <SectionTitle color={WARNING}>Growth Areas</SectionTitle>
                {analysis.growthAreas.map((s, i) => (
                  <ListItem key={i} color={WARNING}>
                    {s}
                  </ListItem>
                ))}
              </Card>
            </View>
          </View>

          <View style={{ marginTop: 12 }}>
            <Card>
              <SectionTitle color={PRIMARY}>Recommendations</SectionTitle>
              <View style={styles.grid2}>
                <View style={styles.col}>
                  {analysis.recommendations
                    .filter((_, i) => i % 2 === 0)
                    .map((r, i) => (
                      <ListItem key={i} color={PRIMARY}>
                        {r}
                      </ListItem>
                    ))}
                </View>
                <View style={styles.col}>
                  {analysis.recommendations
                    .filter((_, i) => i % 2 === 1)
                    .map((r, i) => (
                      <ListItem key={i} color={PRIMARY}>
                        {r}
                      </ListItem>
                    ))}
                </View>
              </View>
            </Card>
          </View>

          <View style={styles.footer} fixed>
            <Text>PsyNova Wellness Report · {assessment.name}</Text>
            <Text>{dateStr}</Text>
          </View>
        </Page>

        {/* Page 5 — Daily routine, breathing, mindfulness, journaling */}
        <Page size="A4" style={styles.page}>
          <Text style={styles.h1}>Daily Wellness Toolkit</Text>
          <View style={{ marginTop: 4 }}>
            <Card>
              <SectionTitle color={ACCENT}>Daily Routine</SectionTitle>
              {analysis.dailyRoutine.map((r, i) => (
                <ListItem key={i} color={ACCENT}>
                  {r}
                </ListItem>
              ))}
            </Card>
          </View>

          <View style={[styles.grid2, { marginTop: 12 }]}>
            <View style={styles.col}>
              <Card bg={LIGHT}>
                <SectionTitle color={PRIMARY}>Breathing Exercise</SectionTitle>
                <Text style={{ fontSize: 9.5, lineHeight: 1.6, color: INK }}>
                  {analysis.breathingExercise}
                </Text>
              </Card>
            </View>
            <View style={styles.col}>
              <Card bg={LIGHT}>
                <SectionTitle color={SECONDARY}>Mindfulness Tip</SectionTitle>
                <Text style={{ fontSize: 9.5, lineHeight: 1.6, color: INK }}>
                  {analysis.mindfulnessTip}
                </Text>
              </Card>
            </View>
          </View>

          <View style={[styles.grid2, { marginTop: 12 }]}>
            <View style={styles.col}>
              <Card>
                <SectionTitle color={SECONDARY}>Journaling Prompts</SectionTitle>
                {analysis.journalingPrompts.map((p, i) => (
                  <ListItem key={i} color={SECONDARY}>
                    {p}
                  </ListItem>
                ))}
              </Card>
            </View>
            <View style={styles.col}>
              <Card>
                <SectionTitle color={SUCCESS}>Affirmations</SectionTitle>
                {analysis.affirmations.map((p, i) => (
                  <ListItem key={i} color={SUCCESS}>
                    {p}
                  </ListItem>
                ))}
              </Card>
            </View>
          </View>

          <View style={{ marginTop: 12 }}>
            <Card bg="#eef2ff">
              <SectionTitle color={PRIMARY}>Wellness Goals</SectionTitle>
              <View style={styles.grid2}>
                <View style={styles.col}>
                  {analysis.goals.map((g, i) => (
                    <ListItem key={i} color={PRIMARY}>
                      {g}
                    </ListItem>
                  ))}
                </View>
              </View>
            </Card>
          </View>

          <View style={styles.footer} fixed>
            <Text>PsyNova Wellness Report · {assessment.name}</Text>
            <Text>{dateStr}</Text>
          </View>
        </Page>

        {/* Page 6 — Resources + closing */}
        <Page size="A4" style={styles.page}>
          <Text style={styles.h1}>Resources & Support</Text>
          <View>
            <Card>
              <SectionTitle color={DESTRUCTIVE}>Crisis & Support Resources</SectionTitle>
              {analysis.resources.map((r, i) => (
                <View key={i} style={{ marginBottom: 6 }}>
                  <Text style={{ fontSize: 10, fontWeight: 700, color: INK }}>
                    {r.name}
                  </Text>
                  <Text style={{ fontSize: 9, color: MUTE, lineHeight: 1.5 }}>
                    {r.detail}
                  </Text>
                </View>
              ))}
            </Card>
          </View>

          <View style={{ marginTop: 16 }}>
            <Card bg="#0f1729">
              <Text style={{ fontSize: 14, fontWeight: 700, color: "#ffffff", marginBottom: 6 }}>
                You are not alone.
              </Text>
              <Text style={{ fontSize: 10, color: "#c7d2fe", lineHeight: 1.6 }}>
                Healing is not linear, and reaching out is a sign of strength.
                PsyNova is here whenever you need a calm, private space to
                reflect. Be gentle with yourself — every small step counts.
              </Text>
            </Card>
          </View>

          <View style={styles.disclaimer}>
            This report was generated in-memory during your PsyNova session
            and is not stored on any server. © {new Date().getFullYear()}{" "}
            PsyNova by Pallavi Thakur. All Rights Reserved. PsyNova is not a
            substitute for professional mental health care.
          </View>

          <View style={styles.footer} fixed>
            <Text>PsyNova Wellness Report · {assessment.name}</Text>
            <Text>{dateStr}</Text>
          </View>
        </Page>
      </Document>
    );

    return { pdf, doc };
  }, [analysis, assessment]);

  const handleDownload = useCallback(async () => {
    setDownloading(true);
    try {
      const { pdf, doc } = await buildDoc();
      const blob = await pdf.pdf(doc).toBlob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `PsyNova-Wellness-Report-${assessment.name || "report"}-${Date.now()}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("Report downloaded.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      toast.error(`Could not generate PDF: ${message}`);
    } finally {
      setDownloading(false);
    }
  }, [buildDoc, assessment.name]);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] w-[96vw] max-w-5xl overflow-hidden p-0">
        <DialogHeader className="border-b border-border/60 px-5 py-3">
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2 text-base">
              <FileText className="h-4 w-4 text-primary" />
              Wellness Report Preview
            </DialogTitle>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        <div className="thin-scrollbar flex flex-col gap-3 overflow-y-auto p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-muted/30 p-3">
            <div>
              <p className="text-sm font-medium">
                Report for {assessment.name || "You"}
              </p>
              <p className="text-xs text-muted-foreground">
                Generated in-memory · not stored on any server
              </p>
            </div>
            <Button
              onClick={handleDownload}
              disabled={downloading}
              className="gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground"
            >
              {downloading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Download className="h-4 w-4" />
              )}
              {downloading ? "Generating…" : "Download PDF"}
            </Button>
          </div>

          <ReportPreview analysis={analysis} assessment={assessment} />
        </div>
      </DialogContent>
    </Dialog>
  );
}

// HTML preview mirror of the PDF for the modal
function ReportPreview({
  analysis,
  assessment,
}: {
  analysis: AnalysisResult;
  assessment: AssessmentData;
}) {
  const dateStr = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-[#0f1729] p-6 text-white">
        <p className="text-2xl font-bold">
          Psy<span className="text-[#3edccb]">Nova</span>
        </p>
        <p className="mt-4 text-3xl font-bold leading-tight">
          Personalized Wellness Report
        </p>
        <p className="mt-2 text-sm text-indigo-200">
          Prepared for {assessment.name || "You"} · {dateStr}
        </p>
        <p className="mt-4 text-xs text-slate-400">
          © {new Date().getFullYear()} PsyNova by Pallavi Thakur. All Rights Reserved.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <PreviewCard title="Profile" color="#6c8df5">
          <ul className="space-y-1 text-xs">
            <li>Name: {assessment.name || "—"}</li>
            <li>Age: {assessment.age || "—"}</li>
            <li>Gender: {assessment.gender || "—"}</li>
            <li>Country: {assessment.country || "—"}</li>
            <li>Occupation: {assessment.occupation || "—"}</li>
          </ul>
        </PreviewCard>
        <PreviewCard title="Wellness Score" color="#b06cf5">
          <p className="text-4xl font-bold text-primary">
            {Math.round(analysis.wellnessScore)}
            <span className="text-sm text-muted-foreground">/100</span>
          </p>
          <p className="text-xs text-muted-foreground">
            Mood {analysis.moodScore}/10 · Stress {analysis.stressScore}/10
          </p>
        </PreviewCard>
      </div>

      <PreviewCard title="Conversation Summary" color="#3edccb">
        <p className="text-sm">{analysis.conversationSummary}</p>
        <p className="mt-2 text-xs text-muted-foreground">
          {analysis.personalityInsights}
        </p>
      </PreviewCard>

      <div className="grid gap-3 sm:grid-cols-2">
        <PreviewCard title="Positive Strengths" color="#3ec98f">
          <ul className="space-y-1 text-xs">
            {analysis.positiveStrengths.map((s, i) => (
              <li key={i}>• {s}</li>
            ))}
          </ul>
        </PreviewCard>
        <PreviewCard title="Growth Areas" color="#f5a623">
          <ul className="space-y-1 text-xs">
            {analysis.growthAreas.map((s, i) => (
              <li key={i}>• {s}</li>
            ))}
          </ul>
        </PreviewCard>
      </div>

      <PreviewCard title="Recommendations" color="#6c8df5">
        <ul className="grid gap-1 text-xs sm:grid-cols-2">
          {analysis.recommendations.map((r, i) => (
            <li key={i}>• {r}</li>
          ))}
        </ul>
      </PreviewCard>

      <PreviewCard title="Daily Wellness Toolkit" color="#3edccb">
        <p className="mb-2 text-xs font-semibold">Daily Routine</p>
        <ul className="mb-3 space-y-1 text-xs">
          {analysis.dailyRoutine.map((r, i) => (
            <li key={i}>• {r}</li>
          ))}
        </ul>
        <p className="mb-1 text-xs font-semibold">Breathing</p>
        <p className="mb-3 text-xs text-muted-foreground">{analysis.breathingExercise}</p>
        <p className="mb-1 text-xs font-semibold">Mindfulness</p>
        <p className="text-xs text-muted-foreground">{analysis.mindfulnessTip}</p>
      </PreviewCard>

      <div className="grid gap-3 sm:grid-cols-2">
        <PreviewCard title="Journaling Prompts" color="#b06cf5">
          <ul className="space-y-1 text-xs">
            {analysis.journalingPrompts.map((p, i) => (
              <li key={i}>• {p}</li>
            ))}
          </ul>
        </PreviewCard>
        <PreviewCard title="Affirmations" color="#3ec98f">
          <ul className="space-y-1 text-xs">
            {analysis.affirmations.map((p, i) => (
              <li key={i}>• {p}</li>
            ))}
          </ul>
        </PreviewCard>
      </div>

      <PreviewCard title="Resources & Support" color="#f56c6c">
        <ul className="space-y-2 text-xs">
          {analysis.resources.map((r, i) => (
            <li key={i}>
              <span className="font-semibold">{r.name}</span>
              <br />
              <span className="text-muted-foreground">{r.detail}</span>
            </li>
          ))}
        </ul>
      </PreviewCard>

      <div className="rounded-xl bg-muted/30 p-3 text-xs text-muted-foreground">
        PsyNova is an AI-powered mental wellness companion, not a replacement
        for licensed mental health professionals. If you are in crisis, contact
        local emergency services or a crisis line (US: 988, UK: 111/999, India:
        iCall 9152987821).
      </div>
    </div>
  );
}

function PreviewCard({
  title,
  color,
  children,
}: {
  title: string;
  color: string;
  children: React.ReactNode;
}) {
  return (
    <div className="glass rounded-xl p-4">
      <p
        className="mb-2 border-b-2 pb-1 text-sm font-bold"
        style={{ borderColor: color, color }}
      >
        {title}
      </p>
      {children}
    </div>
  );
}
