"use client";

import { motion } from "framer-motion";
import { Brain, Moon, Sun, ShieldCheck, LayoutDashboard } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { useSessionStore } from "@/lib/session-store";

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const setView = useSessionStore((s) => s.setView);
  const view = useSessionStore((s) => s.view);
  const hasAssessment = useSessionStore((s) => Boolean(s.assessment.name));
  const messages = useSessionStore((s) => s.messages);

  return (
    <motion.header
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="sticky top-0 z-50 w-full"
    >
      <div className="glass-strong border-b border-border/60">
        <div className="mx-auto flex h-16 max-w-[1700px] items-center justify-between px-4 sm:px-6 lg:px-10">
          <button
            onClick={() => setView("landing")}
            className="group flex items-center gap-2.5"
            aria-label="PsyNova home"
          >
            <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-primary via-secondary to-accent text-primary-foreground shadow-lg shadow-primary/30">
              <Brain className="h-5 w-5" />
            </span>
            <span className="text-lg font-semibold tracking-tight">
              Psy<span className="text-gradient">Nova</span>
            </span>
          </button>

          <nav className="flex items-center gap-1.5 sm:gap-2">
            {view !== "landing" && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setView("landing")}
                className="hidden sm:inline-flex"
              >
                Home
              </Button>
            )}
            {hasAssessment && messages.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setView("dashboard")}
                className="hidden sm:inline-flex"
              >
                <LayoutDashboard className="mr-1.5 h-4 w-4" />
                Dashboard
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              aria-label="Toggle theme"
            >
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>
            {view === "landing" ? (
              <Button
                size="sm"
                onClick={() => setView("assessment")}
                className="bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90"
              >
                Get Started
              </Button>
            ) : (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setView(hasAssessment ? "choice" : "assessment")}
                className="border-primary/40"
              >
                <ShieldCheck className="mr-1.5 h-4 w-4" />
                Session
              </Button>
            )}
          </nav>
        </div>
      </div>
    </motion.header>
  );
}
