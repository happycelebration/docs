"use client";

import { useCallback, useState } from "react";
import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadialBarChart,
  RadialBar,
  Legend,
} from "recharts";
import {
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  Smile,
  Brain,
  Sparkles,
  FileText,
  Download,
  RefreshCw,
  ArrowLeft,
  Target,
  CheckCircle2,
  Lightbulb,
  HeartPulse,
  Quote,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useSessionStore } from "@/lib/session-store";
import type { AnalysisResult } from "@/lib/types";
import { toast } from "sonner";
import { WellnessReport } from "@/components/report";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

function ScoreGauge({ score }: { score: number }) {
  const data = [{ name: "Wellness", value: score, fill: "url(#gaugeGrad)" }];
  return (
    <div className="relative h-44 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart
          innerRadius="72%"
          outerRadius="100%"
          data={data}
          startAngle={220}
          endAngle={-40}
        >
          <defs>
            <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="var(--primary)" />
              <stop offset="50%" stopColor="var(--secondary)" />
              <stop offset="100%" stopColor="var(--accent)" />
            </linearGradient>
          </defs>
          <RadialBar background dataKey="value" cornerRadius={20} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-bold">{Math.round(score)}</span>
        <span className="text-xs text-muted-foreground">/ 100</span>
      </div>
    </div>
  );
}

export function Dashboard() {
  const assessment = useSessionStore((s) => s.assessment);
  const messages = useSessionStore((s) => s.messages);
  const analysis = useSessionStore((s) => s.analysis);
  const setAnalysis = useSessionStore((s) => s.setAnalysis);
  const setView = useSessionStore((s) => s.setView);
  const [loading, setLoading] = useState(false);
  const [showReport, setShowReport] = useState(false);

  const generate = useCallback(async () => {
    if (!assessment.name) {
      toast.error("Please complete the assessment first.");
      setView("assessment");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assessment, messages }),
      });
      const data = (await res.json()) as AnalysisResult & { error?: string };
      if (!res.ok) throw new Error(data.error || "Analysis failed");
      setAnalysis(data);
      toast.success("Your wellness analysis is ready.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      toast.error(`Analysis failed: ${message}`);
    } finally {
      setLoading(false);
    }
  }, [assessment, messages, setAnalysis, setView]);

  const a = analysis;
  const messageCount = messages.length;
  const userMessageCount = messages.filter((m) => m.role === "user").length;

  if (!a) {
    return (
      <main className="mx-auto max-w-[800px] px-4 pb-16 pt-10 sm:px-6">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass-strong rounded-3xl p-8 text-center"
        >
          <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-lg">
            <LayoutDashboard className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-bold">Your Wellness Dashboard</h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Generate a personalized analysis of your current session — mood,
            stress, insights, and recommendations.
          </p>
          <Button
            onClick={generate}
            disabled={loading}
            className="mt-6 gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground"
          >
            {loading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4" />
            )}
            {loading ? "Analyzing your session…" : "Generate Analysis"}
          </Button>
          <p className="mt-4 text-xs text-muted-foreground">
            {messageCount} messages in this session · {userMessageCount} from you
          </p>
        </motion.div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-[1600px] px-4 pb-16 pt-8 sm:px-6 lg:px-10">
      {/* Header */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        className="mb-6 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center"
      >
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setView("choice")}
            className="gap-1.5"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
              Wellness Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">
              Session insights for {assessment.name}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={generate}
            disabled={loading}
            className="gap-1.5"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button
            size="sm"
            onClick={() => setShowReport(true)}
            className="gap-1.5 bg-gradient-to-r from-primary to-secondary text-primary-foreground"
          >
            <FileText className="h-4 w-4" />
            Download Report
          </Button>
        </div>
      </motion.div>

      {/* Top row: score + summary */}
      <div className="mb-6 grid gap-5 lg:grid-cols-3">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <div className="mb-2 flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <HeartPulse className="h-4 w-4 text-primary" />
            Wellness Score
          </div>
          <ScoreGauge score={a.wellnessScore} />
          <p className="mt-2 text-center text-xs text-muted-foreground">
            Based on your assessment & conversation
          </p>
        </motion.div>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6 lg:col-span-2"
        >
          <div className="mb-3 flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Quote className="h-4 w-4 text-secondary" />
            Conversation Summary
          </div>
          <p className="text-sm leading-relaxed">{a.conversationSummary}</p>
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Messages" value={messageCount} icon={Sparkles} />
            <Stat label="Mood" value={`${a.moodScore}/10`} icon={Smile} />
            <Stat label="Stress" value={`${a.stressScore}/10`} icon={Brain} />
            <Stat
              label="Trend"
              value={a.moodScore >= 6 ? "Uplifted" : a.moodScore <= 3 ? "Low" : "Steady"}
              icon={a.moodScore >= 6 ? TrendingUp : TrendingDown}
            />
          </div>
        </motion.div>
      </div>

      {/* Charts row */}
      <div className="mb-6 grid gap-5 lg:grid-cols-2">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <div className="mb-4 flex items-center justify-between">
            <span className="flex items-center gap-2 text-sm font-medium">
              <Smile className="h-4 w-4 text-primary" /> Mood Trend
            </span>
            <Badge variant="outline">{a.moodLabel}</Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={a.moodTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="time" stroke="var(--muted-foreground)" fontSize={11} />
              <YAxis domain={[0, 10]} stroke="var(--muted-foreground)" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 12,
                  color: "var(--popover-foreground)",
                }}
              />
              <Line
                type="monotone"
                dataKey="mood"
                stroke="var(--primary)"
                strokeWidth={3}
                dot={{ r: 4, fill: "var(--primary)" }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <div className="mb-4 flex items-center justify-between">
            <span className="flex items-center gap-2 text-sm font-medium">
              <Brain className="h-4 w-4 text-secondary" /> Stress Trend
            </span>
            <Badge variant="outline">{a.stressLabel}</Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={a.stressTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="time" stroke="var(--muted-foreground)" fontSize={11} />
              <YAxis domain={[0, 10]} stroke="var(--muted-foreground)" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 12,
                  color: "var(--popover-foreground)",
                }}
              />
              <Line
                type="monotone"
                dataKey="stress"
                stroke="var(--warning)"
                strokeWidth={3}
                dot={{ r: 4, fill: "var(--warning)" }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Emotion breakdown + insights */}
      <div className="mb-6 grid gap-5 lg:grid-cols-2">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <span className="mb-4 flex items-center gap-2 text-sm font-medium">
            <Sparkles className="h-4 w-4 text-accent" /> Emotion Breakdown
          </span>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={a.emotionBreakdown}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
              >
                {a.emotionBreakdown.map((e, i) => (
                  <Cell key={i} fill={e.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 12,
                  color: "var(--popover-foreground)",
                }}
              />
              <Legend
                iconType="circle"
                wrapperStyle={{ fontSize: 12, color: "var(--muted-foreground)" }}
              />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <span className="mb-4 flex items-center gap-2 text-sm font-medium">
            <Lightbulb className="h-4 w-4 text-warning" /> Session Insights
          </span>
          <ul className="space-y-3">
            {a.insights.map((ins, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm">
                <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/15 text-[10px] font-bold text-primary">
                  {i + 1}
                </span>
                {ins}
              </li>
            ))}
          </ul>
          <div className="mt-5 rounded-xl bg-muted/30 p-3">
            <p className="text-xs font-medium text-muted-foreground">
              Personality Insight
            </p>
            <p className="mt-1 text-sm">{a.personalityInsights}</p>
          </div>
        </motion.div>
      </div>

      {/* Strengths & growth */}
      <div className="mb-6 grid gap-5 lg:grid-cols-2">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <span className="mb-4 flex items-center gap-2 text-sm font-medium text-success">
            <CheckCircle2 className="h-4 w-4" /> Positive Strengths
          </span>
          <ul className="space-y-2">
            {a.positiveStrengths.map((s, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                {s}
              </li>
            ))}
          </ul>
        </motion.div>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          className="glass rounded-2xl p-6"
        >
          <span className="mb-4 flex items-center gap-2 text-sm font-medium text-warning">
            <Target className="h-4 w-4" /> Growth Areas
          </span>
          <ul className="space-y-2">
            {a.growthAreas.map((s, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <Target className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
                {s}
              </li>
            ))}
          </ul>
        </motion.div>
      </div>

      {/* Recommendations */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        className="glass-strong mb-6 rounded-2xl p-6"
      >
        <span className="mb-4 flex items-center gap-2 text-sm font-medium">
          <Sparkles className="h-4 w-4 text-primary" /> Personalized Recommendations
        </span>
        <div className="grid gap-3 sm:grid-cols-2">
          {a.recommendations.map((r, i) => (
            <div key={i} className="glass rounded-xl p-3 text-sm">
              <span className="mb-1 block text-xs font-bold text-primary">
                {String(i + 1).padStart(2, "0")}
              </span>
              {r}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Goals */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        className="glass rounded-2xl p-6"
      >
        <span className="mb-4 flex items-center gap-2 text-sm font-medium">
          <Target className="h-4 w-4 text-accent" /> Your Wellness Goals
        </span>
        <div className="space-y-3">
          {a.goals.map((g, i) => (
            <div key={i}>
              <div className="mb-1 flex items-center justify-between text-sm">
                <span>{g}</span>
              </div>
              <Progress
                value={Math.round(((i + 1) / a.goals.length) * 100)}
                className="h-1.5"
              />
            </div>
          ))}
        </div>
      </motion.div>

      {/* Report modal */}
      {showReport && (
        <WellnessReport analysis={a} assessment={assessment} onClose={() => setShowReport(false)} />
      )}
    </main>
  );
}

function Stat({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  icon: React.ElementType;
}) {
  return (
    <div className="glass rounded-xl p-3">
      <Icon className="mb-1 h-4 w-4 text-primary" />
      <p className="text-lg font-bold leading-tight">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
