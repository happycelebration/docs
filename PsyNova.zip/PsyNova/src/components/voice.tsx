"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  PhoneCall,
  PhoneOff,
  Mic,
  MicOff,
  PhoneIncoming,
  Volume2,
  Sparkles,
  ArrowLeft,
  Radio,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useSessionStore } from "@/lib/session-store";
import { PRIVACY_MESSAGE } from "@/lib/types";
import { speakText, stopSpeaking, isSpeechSupported } from "@/lib/speech";
import { toast } from "sonner";

type CallState = "idle" | "connecting" | "ringing" | "active" | "ended";

interface TranscriptEntry {
  id: string;
  role: "user" | "assistant";
  text: string;
  time: number;
}

function formatDuration(sec: number) {
  const m = Math.floor(sec / 60)
    .toString()
    .padStart(2, "0");
  const s = Math.floor(sec % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
}

export function Voice() {
  const assessment = useSessionStore((s) => s.assessment);
  const messages = useSessionStore((s) => s.messages);
  const addMessage = useSessionStore((s) => s.addMessage);
  const setView = useSessionStore((s) => s.setView);
  const incrementCrisis = useSessionStore((s) => s.incrementCrisis);

  const [callState, setCallState] = useState<CallState>("idle");
  const [muted, setMuted] = useState(false);
  const [aiSpeaking, setAiSpeaking] = useState(false);
  const [aiThinking, setAiThinking] = useState(false);
  const [listening, setListening] = useState(false);
  const [duration, setDuration] = useState(0);
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
  const [interim, setInterim] = useState("");
  const [error, setError] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const callActiveRef = useRef(false);
  const voiceHistoryRef = useRef<{ role: "user" | "assistant"; content: string }[]>([]);
  const interimRef = useRef("");
  const startRecognitionRef = useRef<() => void>(() => {});

  useEffect(() => {
    voiceHistoryRef.current = messages
      .filter((m) => m.mode === "voice")
      .map((m) => ({ role: m.role, content: m.content }));
  }, [messages]);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const stopRecognition = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore
      }
      recognitionRef.current = null;
    }
    setListening(false);
  }, []);

  const stopAudio = useCallback(() => {
    stopSpeaking();
    setAiSpeaking(false);
  }, []);

  const speak = useCallback(
    (text: string): Promise<boolean> => {
      if (!text.trim()) return Promise.resolve(false);
      if (!isSpeechSupported()) {
        return Promise.resolve(false);
      }
      stopSpeaking();
      setAiSpeaking(true);
      return new Promise<boolean>((resolve) => {
        speakText(text, {
          onEnd: () => {
            setAiSpeaking(false);
            resolve(true);
          },
        });
      });
    },
    [],
  );

  const processUserSpeech = useCallback(
    async (text: string) => {
      if (!text.trim() || !callActiveRef.current) return;
      const entry: TranscriptEntry = {
        id: `${Date.now()}-u`,
        role: "user",
        text,
        time: Date.now(),
      };
      setTranscript((t) => [...t, entry]);
      addMessage({ role: "user", content: text, mode: "voice" });
      voiceHistoryRef.current.push({ role: "user", content: text });

      setAiThinking(true);
      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            assessment,
            history: voiceHistoryRef.current.slice(-12),
            message: text,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed");
        const reply: string = data.reply;
        setAiThinking(false);
        const aEntry: TranscriptEntry = {
          id: `${Date.now()}-a`,
          role: "assistant",
          text: reply,
          time: Date.now(),
        };
        setTranscript((t) => [...t, aEntry]);
        addMessage({ role: "assistant", content: reply, mode: "voice" });
        voiceHistoryRef.current.push({ role: "assistant", content: reply });
        if (data.crisis) {
          incrementCrisis();
          toast.warning("Support resources shared during the call.");
        }
        await speak(reply);
        // resume listening after speaking
        if (callActiveRef.current && !muted) {
          startRecognitionRef.current();
        }
      } catch {
        setAiThinking(false);
        toast.error("I couldn't respond just now. Let's try again.");
        if (callActiveRef.current && !muted) startRecognitionRef.current();
      }
    },
    [assessment, addMessage, speak, incrementCrisis, muted],
  );

  const startRecognition = useCallback(() => {
    if (!callActiveRef.current || muted || aiSpeaking || aiThinking) return;
    const SR =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!SR) {
      setError(
        "Speech recognition isn't supported in this browser. Try Chrome or Edge.",
      );
      return;
    }
    try {
      const rec = new SR();
      rec.lang =
        assessment.preferredLanguage === "English"
          ? "en-US"
          : assessment.preferredLanguage === "Hindi"
            ? "hi-IN"
            : assessment.preferredLanguage === "Spanish"
              ? "es-ES"
              : "en-US";
      rec.continuous = false;
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onstart = () => setListening(true);
      rec.onresult = (event: any) => {
        let interimText = "";
        let finalText = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const t = event.results[i][0].transcript;
          if (event.results[i].isFinal) finalText += t;
          else interimText += t;
        }
        interimRef.current = interimText;
        setInterim(interimText);
        if (finalText.trim()) {
          interimRef.current = "";
          setInterim("");
          stopRecognition();
          processUserSpeech(finalText.trim());
        }
      };
      rec.onerror = (e: any) => {
        if (e.error === "no-speech") {
          if (callActiveRef.current && !muted && !aiSpeaking && !aiThinking) {
            setTimeout(() => startRecognitionRef.current(), 300);
          }
        } else if (e.error === "not-allowed") {
          setError("Microphone permission denied. Please allow access.");
        }
      };
      rec.onend = () => {
        setListening(false);
        if (
          callActiveRef.current &&
          !muted &&
          !aiSpeaking &&
          !aiThinking &&
          !interimRef.current
        ) {
          setTimeout(() => startRecognitionRef.current(), 400);
        }
      };
      recognitionRef.current = rec;
      rec.start();
    } catch {
      // recognition failed to start
    }
  }, [assessment, muted, aiSpeaking, aiThinking, processUserSpeech, stopRecognition]);

  useEffect(() => {
    startRecognitionRef.current = startRecognition;
  }, [startRecognition]);

  const endCall = useCallback(() => {
    callActiveRef.current = false;
    setCallState("ended");
    stopTimer();
    stopRecognition();
    stopAudio();
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setTimeout(() => {
      setCallState("idle");
      setDuration(0);
      setTranscript([]);
      setInterim("");
    }, 1800);
  }, [stopAudio, stopRecognition, stopTimer]);

  const startCall = useCallback(async () => {
    setError(null);
    setCallState("connecting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
    } catch {
      setError("Microphone access is required for voice calls.");
      setCallState("idle");
      return;
    }

    setCallState("ringing");
    setTimeout(() => {
      setCallState("active");
      callActiveRef.current = true;
      timerRef.current = setInterval(() => setDuration((d) => d + 1), 1000);
      // greeting
      const greeting = `Hi ${assessment.name || "there"}, I'm your PsyNova counselor. I'm here to listen — take your time and share whatever's on your mind.`;
      const gEntry: TranscriptEntry = {
        id: `${Date.now()}-g`,
        role: "assistant",
        text: greeting,
        time: Date.now(),
      };
      setTranscript([gEntry]);
      addMessage({ role: "assistant", content: greeting, mode: "voice" });
      voiceHistoryRef.current.push({ role: "assistant", content: greeting });
      speak(greeting).then(() => {
        if (callActiveRef.current) startRecognition();
      });
    }, 2600);
  }, [assessment, addMessage, speak, startRecognition]);

  useEffect(() => {
    return () => {
      callActiveRef.current = false;
      stopTimer();
      stopRecognition();
      stopAudio();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, [stopAudio, stopRecognition, stopTimer]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      if (next) stopRecognition();
      return next;
    });
  }, [stopRecognition]);

  return (
    <main className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-[1500px] flex-col px-4 pb-10 pt-8 sm:px-6 lg:px-10">
      <div className="mb-4 flex items-center justify-between">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            endCall();
            setView("choice");
          }}
          className="gap-1.5"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        <Badge variant="outline" className="gap-1.5 border-success/40 text-success">
          <Radio className="h-3 w-3" />
          Private session
        </Badge>
      </div>

      <div className="glass mb-4 flex items-start gap-2 rounded-xl border-success/30 bg-success/5 p-3 text-xs text-muted-foreground">
        <span className="text-base">🔒</span>
        {PRIVACY_MESSAGE}
      </div>

      {/* Call stage */}
      <div className="glass-strong relative flex flex-1 flex-col items-center justify-center overflow-hidden rounded-3xl p-8">
        {/* Avatar with states */}
        <div className="relative mb-6 h-40 w-40">
          {callState === "active" && (aiSpeaking || listening) && (
            <>
              <div className="animate-pulse-ring absolute inset-0 rounded-full bg-primary/30" />
              <div
                className="animate-pulse-ring absolute inset-0 rounded-full bg-secondary/30"
                style={{ animationDelay: "0.8s" }}
              />
            </>
          )}
          <div
            className={`absolute inset-2 rounded-full bg-gradient-to-br shadow-2xl shadow-primary/40 transition-all duration-500 ${
              aiSpeaking
                ? "from-secondary to-primary scale-105"
                : listening
                  ? "from-accent to-primary scale-105"
                  : "from-primary to-secondary"
            }`}
          />
          <div className="absolute inset-4 rounded-full bg-gradient-to-br from-white/25 to-transparent" />
          <div className="absolute inset-0 grid place-items-center">
            {callState === "idle" || callState === "ended" ? (
              <PhoneIncoming className="h-14 w-14 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.35)]" />
            ) : callState === "connecting" || callState === "ringing" ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <RefreshCw className="h-12 w-12 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.35)]" />
              </motion.div>
            ) : (
              <Sparkles className="h-14 w-14 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.35)]" />
            )}
          </div>
        </div>

        {/* Status text */}
        <div className="mb-1 text-center">
          {callState === "idle" && (
            <>
              <h2 className="text-xl font-semibold">PsyNova Counselor</h2>
              <p className="text-sm text-muted-foreground">
                Ready when you are. Tap call to begin.
              </p>
            </>
          )}
          {callState === "connecting" && (
            <p className="text-sm text-muted-foreground">Connecting securely…</p>
          )}
          {callState === "ringing" && (
            <>
              <h2 className="text-xl font-semibold">Ringing…</h2>
              <p className="text-sm text-muted-foreground">
                Your counselor is picking up.
              </p>
            </>
          )}
          {callState === "active" && (
            <>
              <h2 className="text-xl font-semibold">
                {aiThinking
                  ? "Thinking…"
                  : aiSpeaking
                    ? "Speaking…"
                    : listening
                      ? "Listening…"
                      : muted
                        ? "Muted"
                        : "In call"}
              </h2>
              <p className="font-mono text-sm text-muted-foreground">
                {formatDuration(duration)}
              </p>
            </>
          )}
          {callState === "ended" && (
            <p className="text-sm text-muted-foreground">Call ended</p>
          )}
        </div>

        {/* Waveform / interim */}
        {callState === "active" && (
          <div className="mt-4 h-10 w-full max-w-md">
            {aiSpeaking ? (
              <div className="flex h-full items-center justify-center gap-1">
                {Array.from({ length: 18 }).map((_, i) => (
                  <motion.span
                    key={i}
                    className="w-1 rounded-full bg-secondary"
                    animate={{
                      height: [
                        8,
                        Math.max(8, Math.random() * 32),
                        8,
                      ],
                    }}
                    transition={{
                      duration: 0.6 + Math.random() * 0.4,
                      repeat: Infinity,
                      delay: i * 0.04,
                    }}
                  />
                ))}
              </div>
            ) : listening ? (
              <div className="flex h-full items-center justify-center gap-1">
                {Array.from({ length: 18 }).map((_, i) => (
                  <motion.span
                    key={i}
                    className="w-1 rounded-full bg-accent"
                    animate={{
                      height: [
                        6,
                        Math.max(6, Math.random() * 28),
                        6,
                      ],
                    }}
                    transition={{
                      duration: 0.5 + Math.random() * 0.3,
                      repeat: Infinity,
                      delay: i * 0.05,
                    }}
                  />
                ))}
              </div>
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
                {interim || "Say something…"}
              </div>
            )}
          </div>
        )}

        {/* Controls */}
        <div className="mt-6 flex items-center justify-center gap-4">
          {callState === "idle" && (
            <Button
              size="lg"
              onClick={startCall}
              className="h-16 w-16 rounded-full bg-gradient-to-br from-success to-accent p-0 text-primary-foreground shadow-xl shadow-success/30 hover:opacity-90"
              aria-label="Start call"
            >
              <PhoneCall className="h-7 w-7" />
            </Button>
          )}

          {(callState === "connecting" || callState === "ringing") && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <motion.div
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1.2, repeat: Infinity }}
              >
                Please wait…
              </motion.div>
            </div>
          )}

          {callState === "active" && (
            <>
              <Button
                size="lg"
                variant="outline"
                onClick={toggleMute}
                className={`h-14 w-14 rounded-full p-0 ${muted ? "border-destructive text-destructive" : ""}`}
                aria-label={muted ? "Unmute" : "Mute"}
              >
                {muted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </Button>
              <Button
                size="lg"
                onClick={endCall}
                className="h-16 w-16 rounded-full bg-destructive p-0 text-destructive-foreground shadow-xl shadow-destructive/30 hover:opacity-90"
                aria-label="End call"
              >
                <PhoneOff className="h-7 w-7" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={stopAudio}
                disabled={!aiSpeaking}
                className="h-14 w-14 rounded-full p-0"
                aria-label="Stop speech"
              >
                <Volume2 className="h-6 w-6" />
              </Button>
            </>
          )}

          {callState === "ended" && (
            <Button
              size="lg"
              onClick={startCall}
              className="h-16 w-16 rounded-full bg-gradient-to-br from-success to-accent p-0 text-primary-foreground shadow-xl shadow-success/30 hover:opacity-90"
              aria-label="Call again"
            >
              <PhoneCall className="h-7 w-7" />
            </Button>
          )}
        </div>

        {error && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-warning/40 bg-warning/10 p-3 text-xs text-warning-foreground">
            <AlertTriangle className="h-4 w-4 shrink-0 text-warning" />
            {error}
          </div>
        )}
      </div>

      {/* Transcript */}
      {transcript.length > 0 && (
        <div className="thin-scrollbar mt-4 max-h-56 space-y-2 overflow-y-auto rounded-2xl glass p-3">
          <p className="px-1 text-xs font-medium text-muted-foreground">
            Live transcript
          </p>
          <AnimatePresence initial={false}>
            {transcript.map((t) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-2 ${t.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-xl px-3 py-2 text-sm ${
                    t.role === "user"
                      ? "bg-primary/15"
                      : "glass"
                  }`}
                >
                  <span className="mb-0.5 block text-[10px] uppercase tracking-wide text-muted-foreground">
                    {t.role === "user" ? "You" : "PsyNova"}
                  </span>
                  {t.text}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {interim && (
            <div className="flex justify-end">
              <div className="max-w-[80%] rounded-xl bg-muted/40 px-3 py-2 text-sm italic text-muted-foreground">
                {interim}…
              </div>
            </div>
          )}
        </div>
      )}
    </main>
  );
}
