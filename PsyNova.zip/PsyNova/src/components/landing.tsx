"use client";

import { motion, useReducedMotion } from "framer-motion";
import {
  Brain,
  MessageSquareHeart,
  PhoneCall,
  FileText,
  ShieldCheck,
  Sparkles,
  Heart,
  Wind,
  Moon,
  BookOpen,
  ArrowRight,
  Lock,
  Globe,
  Zap,
  TrendingUp,
  CheckCircle2,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useSessionStore } from "@/lib/session-store";
import { PRIVACY_MESSAGE } from "@/lib/types";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};

export function Landing() {
  const setView = useSessionStore((s) => s.setView);
  const reduce = useReducedMotion();

  return (
    <main className="relative">
      {/* Hero */}
      <section className="relative overflow-hidden px-4 pb-24 pt-20 sm:px-6 sm:pt-28">
        <div className="mx-auto max-w-4xl text-center">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            className="mx-auto mb-6 inline-flex"
          >
            <Badge
              variant="secondary"
              className="gap-1.5 rounded-full border-primary/30 bg-primary/10 px-4 py-1.5 text-primary"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Privacy-first AI Mental Wellness
            </Badge>
          </motion.div>

          <motion.h1
            variants={fadeUp}
            initial="hidden"
            animate="show"
            className="text-balance text-4xl font-bold tracking-tight sm:text-6xl"
          >
            Your AI Companion for{" "}
            <span className="text-gradient">Better Mental Wellbeing</span>
          </motion.h1>

          <motion.p
            variants={fadeUp}
            initial="hidden"
            animate="show"
            className="mx-auto mt-6 max-w-2xl text-pretty text-base text-muted-foreground sm:text-lg"
          >
            PsyNova offers a calm, empathetic AI counselor you can chat or
            speak with — anytime. Track your emotional progress, receive
            personalized support, and generate a beautiful wellness report.
            Everything stays private and disappears when you leave.
          </motion.p>

          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <Button
              size="lg"
              onClick={() => setView("assessment")}
              className="h-12 rounded-full bg-gradient-to-r from-primary to-secondary px-8 text-base text-primary-foreground shadow-xl shadow-primary/30 hover:opacity-90"
            >
              Get Started Free
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() =>
                document
                  .getElementById("how-it-works")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="h-12 rounded-full border-border/80 px-8 text-base"
            >
              How it works
            </Button>
          </motion.div>

          {/* Hero visual — animated orb */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative mx-auto mt-16 h-64 w-64 sm:h-80 sm:w-80"
          >
            <div className="absolute inset-0 animate-pulse-ring rounded-full bg-primary/30" />
            <div
              className="absolute inset-0 animate-pulse-ring rounded-full bg-secondary/30"
              style={{ animationDelay: "0.7s" }}
            />
            <div className="absolute inset-4 rounded-full bg-gradient-to-br from-primary via-secondary to-accent shadow-2xl shadow-primary/40" />
            <div className="absolute inset-6 rounded-full bg-gradient-to-br from-white/25 to-transparent" />
            <div className="absolute inset-0 grid place-items-center">
              <motion.div
                animate={
                  reduce
                    ? {}
                    : { y: [0, -8, 0], rotate: [0, 3, 0] }
                }
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="grid place-items-center"
              >
                <Brain className="h-24 w-24 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.35)] sm:h-28 sm:w-28" />
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Privacy banner */}
      <section className="px-4 sm:px-6">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="mx-auto max-w-[1300px]"
        >
          <div className="glass flex flex-col items-center gap-3 rounded-2xl border-success/30 bg-success/5 p-5 text-center sm:flex-row sm:text-left">
            <ShieldCheck className="h-8 w-8 shrink-0 text-success" />
            <p className="text-sm text-muted-foreground sm:text-base">
              {PRIVACY_MESSAGE}
            </p>
          </div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="px-4 py-24 sm:px-6">
        <div className="mx-auto max-w-[1500px]">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mx-auto mb-14 max-w-2xl text-center"
          >
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Everything you need to feel{" "}
              <span className="text-gradient">supported</span>
            </h2>
            <p className="mt-3 text-muted-foreground">
              Thoughtfully designed tools that meet you where you are.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
          >
            {[
              {
                icon: MessageSquareHeart,
                title: "AI Chat Counselor",
                desc: "Chat with an empathetic AI that remembers your session, offers coping strategies, and responds with warmth.",
                color: "from-primary to-secondary",
              },
              {
                icon: PhoneCall,
                title: "Voice Call Mode",
                desc: "Talk naturally with your AI counselor using real-time speech recognition and natural voice synthesis.",
                color: "from-secondary to-accent",
              },
              {
                icon: FileText,
                title: "Wellness Reports",
                desc: "Generate a premium, colorful PDF report with insights, recommendations, and progress charts — in memory only.",
                color: "from-accent to-primary",
              },
              {
                icon: TrendingUp,
                title: "Progress Dashboard",
                desc: "Track mood, stress, and wellness scores with beautiful charts and session insights updated in real time.",
                color: "from-primary to-accent",
              },
              {
                icon: ShieldCheck,
                title: "Privacy First",
                desc: "No accounts, no databases. Everything exists only in your browser session and is erased when you leave.",
                color: "from-success to-accent",
              },
              {
                icon: Lock,
                title: "Crisis Aware",
                desc: "Built-in crisis detection gently guides you to trusted people and emergency resources when you need them.",
                color: "from-destructive to-secondary",
              },
            ].map((f) => (
              <motion.div
                key={f.title}
                variants={fadeUp}
                className="group glass rounded-2xl p-6 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10"
              >
                <div
                  className={`mb-4 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${f.color} text-primary-foreground shadow-lg`}
                >
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Benefits */}
      <section className="px-4 py-16 sm:px-6">
        <div className="mx-auto max-w-[1500px]">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: "-80px" }}
            >
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Care that adapts to{" "}
                <span className="text-gradient">you</span>
              </h2>
              <p className="mt-4 text-muted-foreground">
                PsyNova blends your assessment with live conversation to
                deliver genuinely personalized support — from breathing
                exercises to journaling prompts tailored to how you feel right
                now.
              </p>
              <ul className="mt-6 space-y-3">
                {[
                  "Empathetic, non-judgmental listening 24/7",
                  "Coping strategies grounded in mindfulness & CBT",
                  "Personalized goals, affirmations & routines",
                  "Progress you can actually see and feel",
                ].map((b) => (
                  <li key={b} className="flex items-start gap-3">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-success" />
                    <span className="text-sm">{b}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: "-80px" }}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { icon: Wind, label: "Breathing", val: "4-7-8" },
                { icon: Moon, label: "Sleep tips", val: "Wind-down" },
                { icon: BookOpen, label: "Journaling", val: "Prompts" },
                { icon: Heart, label: "Self-care", val: "Daily" },
              ].map((c) => (
                <motion.div
                  key={c.label}
                  variants={fadeUp}
                  className="glass flex flex-col items-start gap-2 rounded-2xl p-5"
                >
                  <c.icon className="h-6 w-6 text-primary" />
                  <span className="text-xs uppercase tracking-wide text-muted-foreground">
                    {c.label}
                  </span>
                  <span className="text-lg font-semibold">{c.val}</span>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="px-4 py-24 sm:px-6">
        <div className="mx-auto max-w-[1300px]">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-14 text-center"
          >
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              How PsyNova works
            </h2>
            <p className="mt-3 text-muted-foreground">
              Three gentle steps to a calmer mind.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            className="grid gap-6 md:grid-cols-3"
          >
            {[
              {
                step: "01",
                icon: Sparkles,
                title: "Share how you feel",
                desc: "A quick, calming assessment helps your AI counselor understand you — sliders, emoji cards, no pressure.",
              },
              {
                step: "02",
                icon: MessageSquareHeart,
                title: "Chat or talk it out",
                desc: "Choose text chat or a voice call. Your counselor remembers everything from your current session.",
              },
              {
                step: "03",
                icon: FileText,
                title: "Reflect & grow",
                desc: "See your progress on a beautiful dashboard and download a personalized wellness report.",
              },
            ].map((s) => (
              <motion.div
                key={s.step}
                variants={fadeUp}
                className="glass relative overflow-hidden rounded-2xl p-6"
              >
                <span className="absolute -right-2 -top-4 text-7xl font-bold text-primary/10">
                  {s.step}
                </span>
                <s.icon className="mb-4 h-8 w-8 text-primary" />
                <h3 className="mb-2 text-lg font-semibold">{s.title}</h3>
                <p className="text-sm text-muted-foreground">{s.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials (clearly labeled as sample) */}
      <section className="px-4 py-16 sm:px-6">
        <div className="mx-auto max-w-[1500px]">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-10 text-center"
          >
            <Badge variant="outline" className="mb-3 gap-1.5">
              <Sparkles className="h-3 w-3" /> Sample testimonials
            </Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              A calmer way to feel heard
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              These are illustrative sample experiences, not verified user
              reviews.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            className="grid gap-5 md:grid-cols-3"
          >
            {[
              {
                quote:
                  "It felt like someone truly listened at 2am when I couldn't sleep. The breathing exercise calmed me instantly.",
                name: "Sample voice",
                tag: "Student",
              },
              {
                quote:
                  "The wellness report surprised me — it captured things I hadn't put into words. I felt understood.",
                name: "Sample voice",
                tag: "Designer",
              },
              {
                quote:
                  "Knowing nothing is stored made me open up more. Private, warm, and genuinely helpful.",
                name: "Sample voice",
                tag: "Engineer",
              },
            ].map((t, i) => (
              <motion.figure
                key={i}
                variants={fadeUp}
                className="glass flex flex-col gap-4 rounded-2xl p-6"
              >
                <Heart className="h-6 w-6 text-secondary" />
                <blockquote className="text-sm leading-relaxed text-foreground/90">
                  “{t.quote}”
                </blockquote>
                <figcaption className="mt-auto flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-primary to-secondary text-xs font-semibold text-primary-foreground">
                    {t.name[0]}
                  </span>
                  <span>
                    <span className="block text-sm font-medium">{t.name}</span>
                    <span className="block text-xs text-muted-foreground">
                      {t.tag}
                    </span>
                  </span>
                </figcaption>
              </motion.figure>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section className="px-4 py-16 sm:px-6">
        <div className="mx-auto max-w-4xl">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mb-10 text-center"
          >
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Frequently asked questions
            </h2>
          </motion.div>

          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
          >
            <Accordion type="single" collapsible className="glass rounded-2xl p-2">
              {[
                {
                  q: "Is PsyNova a replacement for a therapist?",
                  a: "No. PsyNova is an AI wellness companion, not a licensed therapist. It offers empathetic support and coping tools, and encourages professional care — especially in crisis situations.",
                },
                {
                  q: "Is my data really private?",
                  a: "Yes. PsyNova is completely session-based. We don't use accounts, databases, or persistent storage. Conversations, assessments, and reports exist only in your browser's active memory and vanish when you close or refresh the tab.",
                },
                {
                  q: "Can the AI detect a crisis?",
                  a: "PsyNova includes crisis-aware responses. If signs of self-harm or danger appear, it gently guides you toward trusted contacts, crisis lines, and emergency services — never encouraging harm.",
                },
                {
                  q: "What's the difference between chat and voice?",
                  a: "Chat offers a polished text interface with markdown, copy, and text-to-speech. Voice call gives a real phone-call experience with speech recognition and natural AI speech for continuous conversation.",
                },
                {
                  q: "Can I download a report?",
                  a: "Yes. After your session, generate a premium PDF wellness report with insights, charts, and recommendations. It's created in memory and never stored on our servers.",
                },
              ].map((item, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger className="px-4 text-left">
                    {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="px-4 text-muted-foreground">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 py-24 sm:px-6">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="mx-auto max-w-[1300px]"
        >
          <div className="relative overflow-hidden rounded-3xl glass-strong p-10 text-center sm:p-16">
            <Globe className="mx-auto mb-4 h-10 w-10 text-accent" />
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Your wellbeing journey{" "}
              <span className="text-gradient">starts now</span>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Take the first gentle step. It's private, free, and always here
              for you.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                onClick={() => setView("assessment")}
                className="h-12 rounded-full bg-gradient-to-r from-primary to-secondary px-8 text-base text-primary-foreground shadow-xl shadow-primary/30 hover:opacity-90"
              >
                Begin Assessment
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Zap className="h-3.5 w-3.5 text-warning" />
                Takes about 3 minutes
              </div>
            </div>
          </div>
        </motion.div>
      </section>
    </main>
  );
}
