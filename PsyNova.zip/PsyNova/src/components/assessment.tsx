"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { z } from "zod";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Lock,
  ShieldCheck,
  User,
  Heart,
  Brain,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { useSessionStore } from "@/lib/session-store";
import type { AssessmentData } from "@/lib/types";
import { PRIVACY_MESSAGE } from "@/lib/types";
import { toast } from "sonner";

const schema = z.object({
  name: z.string().trim().min(1, "Please tell us your name."),
  age: z
    .string()
    .trim()
    .min(1, "Age is required.")
    .refine((v) => Number(v) >= 13 && Number(v) <= 120, "Enter a valid age (13–120)."),
  gender: z.string().min(1, "Please select an option."),
  country: z.string().trim().min(1, "Please enter your country."),
  preferredLanguage: z.string().trim().min(1, "Please choose a language."),
  occupation: z.string().trim().min(1, "Please enter your occupation."),
  relationshipStatus: z.string().min(1, "Please select an option."),
});

const STEPS = [
  { key: "about", label: "About You", icon: User },
  { key: "wellbeing", label: "Wellbeing", icon: Heart },
  { key: "personality", label: "Personality", icon: Brain },
  { key: "lifestyle", label: "Lifestyle", icon: Sparkles },
] as const;

const SLIDER_CONFIG: {
  key: keyof AssessmentData;
  label: string;
  left: string;
  right: string;
  emoji: string;
}[] = [
  { key: "sleepQuality", label: "Sleep Quality", left: "Poor", right: "Excellent", emoji: "😴" },
  { key: "exerciseFrequency", label: "Exercise Frequency", left: "Rarely", right: "Daily", emoji: "🏃" },
  { key: "stressLevel", label: "Stress Level", left: "Calm", right: "Overwhelmed", emoji: "😮‍💨" },
  { key: "energyLevel", label: "Energy Level", left: "Drained", right: "Energetic", emoji: "⚡" },
  { key: "mood", label: "Current Mood", left: "Low", right: "Great", emoji: "🌤️" },
  { key: "confidence", label: "Confidence", left: "Unsure", right: "Confident", emoji: "💪" },
  { key: "socialComfort", label: "Social Comfort", left: "Isolated", right: "Connected", emoji: "🤝" },
  { key: "optimism", label: "Optimism", left: "Hopeless", right: "Hopeful", emoji: "🌈" },
];

const PERSONALITY_SLIDERS: {
  key: keyof AssessmentData;
  label: string;
  left: string;
  right: string;
}[] = [
  { key: "introvertExtrovert", label: "Introvert ↔ Extrovert", left: "Introvert", right: "Extrovert" },
  { key: "calmAnxious", label: "Calm ↔ Anxious", left: "Calm", right: "Anxious" },
  { key: "practicalEmotional", label: "Practical ↔ Emotional", left: "Practical", right: "Emotional" },
];

const MOOD_EMOJIS = ["😢", "😕", "😐", "🙂", "😄"];
const PERSONALITY_TYPES = [
  "Analytical",
  "Creative",
  "Empathetic",
  "Organized",
  "Adventurous",
  "Reserved",
  "Outgoing",
  "Reflective",
];

function SliderRow({
  label,
  left,
  right,
  emoji,
  value,
  onChange,
}: {
  label: string;
  left: string;
  right: string;
  emoji?: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="mb-3 flex items-center justify-between">
        <Label className="flex items-center gap-2 text-sm font-medium">
          {emoji && <span className="text-lg">{emoji}</span>}
          {label}
        </Label>
        <span className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">
          {value}/10
        </span>
      </div>
      <Slider
        value={[value]}
        min={0}
        max={10}
        step={1}
        onValueChange={(v) => onChange(v[0])}
        className="py-2"
        aria-label={label}
      />
      <div className="mt-1 flex justify-between text-xs text-muted-foreground">
        <span>{left}</span>
        <span>{right}</span>
      </div>
    </div>
  );
}

function EmojiCard({
  emoji,
  label,
  selected,
  onClick,
}: {
  emoji: string;
  label: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={`flex flex-col items-center gap-1 rounded-xl border p-3 transition-all ${
        selected
          ? "border-primary bg-primary/10 shadow-md shadow-primary/20"
          : "border-border glass hover:border-primary/50"
      }`}
    >
      <span className="text-2xl">{emoji}</span>
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

export function Assessment() {
  const draft = useSessionStore((s) => s.assessmentDraft);
  const setDraft = useSessionStore((s) => s.setAssessmentDraft);
  const commit = useSessionStore((s) => s.commitAssessment);
  const setView = useSessionStore((s) => s.setView);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const progress = useMemo(() => ((step + 1) / STEPS.length) * 100, [step]);

  function validateAbout() {
    const result = schema.safeParse(draft);
    if (result.success) {
      setErrors({});
      return true;
    }
    const next: Record<string, string> = {};
    for (const issue of result.error.issues) {
      next[issue.path[0] as string] = issue.message;
    }
    setErrors(next);
    return false;
  }

  function next() {
    if (step === 0 && !validateAbout()) {
      toast.error("Please complete the required fields.");
      return;
    }
    if (step < STEPS.length - 1) setStep(step + 1);
  }

  function back() {
    if (step > 0) setStep(step - 1);
  }

  function submit() {
    if (!validateAbout()) {
      setStep(0);
      toast.error("Please complete the required fields.");
      return;
    }
    commit();
    setView("choice");
    toast.success("Assessment saved for this session.");
  }

  return (
    <main className="relative mx-auto max-w-[1100px] px-4 pb-16 pt-10 sm:px-6 lg:px-10">
      <div className="mb-6 text-center">
        <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-lg">
          <Heart className="h-6 w-6" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight">Wellness Assessment</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Help your AI counselor understand you. This stays in your session only.
        </p>
      </div>

      <div className="glass mb-6 flex items-center gap-2 rounded-xl border-success/30 bg-success/5 p-3 text-xs text-muted-foreground">
        <Lock className="h-4 w-4 shrink-0 text-success" />
        {PRIVACY_MESSAGE}
      </div>

      {/* Stepper */}
      <div className="mb-6">
        <div className="mb-2 flex items-center justify-between">
          {STEPS.map((s, i) => (
            <div
              key={s.key}
              className={`flex items-center gap-2 text-xs font-medium ${
                i <= step ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <span
                className={`grid h-7 w-7 place-items-center rounded-full border ${
                  i < step
                    ? "border-primary bg-primary text-primary-foreground"
                    : i === step
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border"
                }`}
              >
                {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </span>
              <span className="hidden sm:inline">{s.label}</span>
            </div>
          ))}
        </div>
        <Progress value={progress} className="h-1.5" />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -24 }}
          transition={{ duration: 0.3 }}
          className="glass-strong rounded-2xl p-6 sm:p-8"
        >
          {step === 0 && (
            <div className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    value={draft.name}
                    onChange={(e) => setDraft({ name: e.target.value })}
                    placeholder="What should we call you?"
                  />
                  {errors.name && (
                    <p className="text-xs text-destructive">{errors.name}</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="age">Age *</Label>
                  <Input
                    id="age"
                    type="number"
                    inputMode="numeric"
                    value={draft.age}
                    onChange={(e) => setDraft({ age: e.target.value })}
                    placeholder="Your age"
                  />
                  {errors.age && (
                    <p className="text-xs text-destructive">{errors.age}</p>
                  )}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Gender *</Label>
                <RadioGroup
                  value={draft.gender}
                  onValueChange={(v) => setDraft({ gender: v as AssessmentData["gender"] })}
                  className="grid grid-cols-2 gap-2 sm:grid-cols-3"
                >
                  {[
                    { v: "female", l: "Female" },
                    { v: "male", l: "Male" },
                    { v: "non-binary", l: "Non-binary" },
                    { v: "prefer-not-to-say", l: "Prefer not to say" },
                  ].map((g) => (
                    <Label
                      key={g.v}
                      htmlFor={`g-${g.v}`}
                      className={`flex cursor-pointer items-center gap-2 rounded-lg border p-2.5 text-sm transition-all ${
                        draft.gender === g.v
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <RadioGroupItem id={`g-${g.v}`} value={g.v} />
                      {g.l}
                    </Label>
                  ))}
                </RadioGroup>
                {errors.gender && (
                  <p className="text-xs text-destructive">{errors.gender}</p>
                )}
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="country">Country *</Label>
                  <Input
                    id="country"
                    value={draft.country}
                    onChange={(e) => setDraft({ country: e.target.value })}
                    placeholder="e.g. India"
                  />
                  {errors.country && (
                    <p className="text-xs text-destructive">{errors.country}</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label>Preferred Language *</Label>
                  <Select
                    value={draft.preferredLanguage}
                    onValueChange={(v) => setDraft({ preferredLanguage: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      {["English", "Hindi", "Spanish", "French", "German", "Mandarin", "Arabic", "Portuguese"].map((l) => (
                        <SelectItem key={l} value={l}>
                          {l}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.preferredLanguage && (
                    <p className="text-xs text-destructive">{errors.preferredLanguage}</p>
                  )}
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="occupation">Occupation *</Label>
                  <Input
                    id="occupation"
                    value={draft.occupation}
                    onChange={(e) => setDraft({ occupation: e.target.value })}
                    placeholder="e.g. Student, Engineer"
                  />
                  {errors.occupation && (
                    <p className="text-xs text-destructive">{errors.occupation}</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label>Relationship Status *</Label>
                  <Select
                    value={draft.relationshipStatus}
                    onValueChange={(v) => setDraft({ relationshipStatus: v as AssessmentData["relationshipStatus"] })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {[
                        { v: "single", l: "Single" },
                        { v: "in-relationship", l: "In a relationship" },
                        { v: "married", l: "Married" },
                        { v: "separated", l: "Separated" },
                        { v: "divorced", l: "Divorced" },
                        { v: "widowed", l: "Widowed" },
                      ].map((r) => (
                        <SelectItem key={r.v} value={r.v}>
                          {r.l}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.relationshipStatus && (
                    <p className="text-xs text-destructive">{errors.relationshipStatus}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block text-sm font-medium">How's your mood right now?</Label>
                <div className="grid grid-cols-5 gap-2">
                  {MOOD_EMOJIS.map((e, i) => {
                    const val = i * 2.5;
                    return (
                      <EmojiCard
                        key={i}
                        emoji={e}
                        label={["Very low", "Low", "Okay", "Good", "Great"][i]}
                        selected={Math.abs(draft.mood - val) < 1.3}
                        onClick={() => setDraft({ mood: val })}
                      />
                    );
                  })}
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {SLIDER_CONFIG.filter((s) => s.key !== "mood").map((s) => (
                  <SliderRow
                    key={s.key}
                    label={s.label}
                    left={s.left}
                    right={s.right}
                    emoji={s.emoji}
                    value={draft[s.key] as number}
                    onChange={(v) => setDraft({ [s.key]: v } as Partial<AssessmentData>)}
                  />
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Personality Type</Label>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {PERSONALITY_TYPES.map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setDraft({ personalityType: p })}
                      className={`rounded-lg border px-3 py-2 text-sm transition-all ${
                        draft.personalityType === p
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border glass hover:border-primary/50"
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              {PERSONALITY_SLIDERS.map((s) => (
                <SliderRow
                  key={s.key}
                  label={s.label}
                  left={s.left}
                  right={s.right}
                  value={draft[s.key] as number}
                  onChange={(v) => setDraft({ [s.key]: v } as Partial<AssessmentData>)}
                />
              ))}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Daily Screen Time</Label>
                <RadioGroup
                  value={draft.dailyScreenTime}
                  onValueChange={(v) => setDraft({ dailyScreenTime: v })}
                  className="grid grid-cols-2 gap-2 sm:grid-cols-3"
                >
                  {["< 2 hours", "2-3 hours", "3-5 hours", "5-7 hours", "7-10 hours", "> 10 hours"].map((t) => (
                    <Label
                      key={t}
                      htmlFor={`st-${t}`}
                      className={`flex cursor-pointer items-center gap-2 rounded-lg border p-2.5 text-sm transition-all ${
                        draft.dailyScreenTime === t
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <RadioGroupItem id={`st-${t}`} value={t} />
                      {t}
                    </Label>
                  ))}
                </RadioGroup>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="challenges">Current Challenges</Label>
                <Textarea
                  id="challenges"
                  value={draft.currentChallenges}
                  onChange={(e) => setDraft({ currentChallenges: e.target.value })}
                  placeholder="What's been on your mind lately?"
                  rows={3}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="goals">Goals</Label>
                <Textarea
                  id="goals"
                  value={draft.goals}
                  onChange={(e) => setDraft({ goals: e.target.value })}
                  placeholder="What would you like to work toward?"
                  rows={3}
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="emergency">Emergency Contact (Optional)</Label>
                  <Input
                    id="emergency"
                    value={draft.emergencyContact}
                    onChange={(e) => setDraft({ emergencyContact: e.target.value })}
                    placeholder="Name & phone"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Input
                    id="notes"
                    value={draft.additionalNotes}
                    onChange={(e) => setDraft({ additionalNotes: e.target.value })}
                    placeholder="Anything else?"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Nav */}
          <div className="mt-8 flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={back}
              disabled={step === 0}
              className="gap-1.5"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5 text-success" />
              Autosaved to session
            </div>
            {step < STEPS.length - 1 ? (
              <Button
                onClick={next}
                className="gap-1.5 bg-gradient-to-r from-primary to-secondary text-primary-foreground"
              >
                Next
                <ArrowRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                onClick={submit}
                className="gap-1.5 bg-gradient-to-r from-primary to-secondary text-primary-foreground"
              >
                <Check className="h-4 w-4" />
                Complete
              </Button>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </main>
  );
}
