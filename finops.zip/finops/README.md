# FinOps Agent — AI Investment Research Agent

> Type a company name. Get a full, sourced, reasoning-backed investment research report — with an **Invest / Pass / Hold** verdict, a confidence score, financials, news, risks, and a downloadable PDF — in seconds.

FinOps Agent is a production-quality AI research agent built with **Next.js 16**, **LangGraph.js**, **Google Gemini**, **Financial Modeling Prep**, **Tavily**, and **NewsAPI**. It researches any public company across financial, news, and web sources, weighs the evidence with a hybrid LLM + rule-based engine, and produces a polished, structured research report.

---

## 1. Overview

### What it does
Give it any company name — `"Apple"`, `"Tesla"`, `"Reliance"`, `"Google"` — and FinOps Agent will:

1. **Resolve** the name to the correct public entity (ticker + exchange).
2. **Gather** the company profile, full financials (revenue, margins, ratios, cash flow, balance sheet), ~3 years of weekly price history, recent news, and web context — all in parallel.
3. **Analyze** the financials, classify news sentiment, extract web themes, and flag strengths, weaknesses, weak signals, opportunities, and risks.
4. **Decide** whether to **Invest**, **Hold**, or **Pass** — with a 0–100 investment score, a confidence level, a one-line verdict, a multi-point reasoning list, and a written thesis.
5. **Present** everything in a premium, animated, dark-themed dashboard with a particle-network background, a 9-stage live progress pipeline, tabbed report sections, a price chart, and a **Download PDF** button that generates a multi-page, branded research report.

### What problem it solves
Equity research is slow, fragmented, and requires juggling 4–5 data sources plus qualitative judgment. FinOps Agent compresses that workflow into a single search box: it pulls structured data from APIs, reasons over it with an LLM (with a deterministic rule-based fallback for reliability), and delivers an analyst-style report you can act on or download.

### Who it's for
Retail investors, analysts-in-training, and anyone who wants a fast, sourced, second opinion on a public company, not financial advice, but a structured starting point for further research.

---

## 2. How to run it

### Prerequisites
- **Node.js 18+** or **Bun** (recommended)
- Four API keys (see below)

### Environment variables
Create a `.env` file in the project root (a `.env.example` is included as a template):

```bash
# Google Gemini — LLM for reasoning, summarization & final recommendation
GEMINI_API_KEY=your_gemini_api_key_here

# Tavily — web search, company context, competitor & verification research
TAVILY_API_KEY=your_tavily_api_key_here

# Financial Modeling Prep — company profile, financials, ratios, price history
FMP_API_KEY=your_fmp_api_key_here

# NewsAPI.org — recent company news & headlines
NEWS_API_KEY=your_newsapi_key_here
```

> **Only these 4 third-party keys are used.** No other external services are called. The app also reads an optional `DATABASE_URL` for Prisma (unused by the agent itself).

> **Resilience note:** If Gemini is unavailable (quota, region, or key issues), the agent automatically falls back to a fully data-grounded **rule-based analysis engine** — the app still produces a complete, useful report. See [Key decisions & trade-offs](#4-key-decisions--trade-offs).

### Install & run (development)

```bash
# 1. Install dependencies
bun install        # or: npm install

# 2. Copy env template and fill in your keys
cp .env.example .env
#   ... edit .env with your 4 keys

# 3. Start the dev server
bun run dev        # or: npm run dev
```

Open **http://localhost:3000** in your browser. Type a company name and click **Analyze**.

### Run in production

```bash
bun run build      # or: npm run build
bun run start      # or: npm run start
```

### Lint

```bash
bun run lint       # ESLint (Next.js + react-hooks rules)
```

---

## 3. How it works

### Architecture overview

```
┌──────────────────────────────────────────────────────────────┐
│                        Browser (client)                        │
│  HeroSearch → useAnalysis() ── fetch POST /api/analyze ──►   │
│  ◄── SSE stream (stage_start / stage_progress / complete) ──  │
│  AnalysisPipeline (live 9-stage progress) → ReportDisplay     │
│  + ParticleBackground (tsParticles) + Download PDF            │
└────────────────────────────┬─────────────────────────────────┘
                             │  SSE (text/event-stream)
┌────────────────────────────▼─────────────────────────────────┐
│              Next.js API Route: /api/analyze                   │
│   ReadableStream + runAnalysis(company, emit)                  │
└────────────────────────────┬─────────────────────────────────┘
                             │  calls nodes sequentially
┌────────────────────────────▼─────────────────────────────────┐
│                   LangGraph Agent (9 stages)                   │
│  normalize → resolve → gather → financials → news → web →     │
│  risk → synthesize → report                                   │
│                                                                │
│  Each node: try Gemini → fall back to rule-based engine       │
│  Every tool: try/catch + 12s timeout → never throws           │
└────────────────────────────┬─────────────────────────────────┘
                             │  fetch (parallel via Promise.allSettled)
┌──────────────┬─────────────┴────────────┬─────────────┬───────┐
│  Gemini LLM  │     FMP (stable API)     │   Tavily    │NewsAPI│
│ (reasoning)  │ profile/ratios/income/   │  (web       │(news) │
│              │ cashflow/balance/prices  │  research)  │       │
└──────────────┴──────────────────────────┴─────────────┴───────┘
```

### The agent workflow (LangGraph)

The agent is modelled as a **9-stage state graph** in [`src/lib/agent/graph.ts`](src/lib/agent/graph.ts) using `@langchain/langgraph`'s `StateGraph` + `Annotation.Root`. The state (`src/lib/agent/state.ts`) accumulates: the raw company name, resolved symbol, profile, raw financials, analyzed financials, news, web, risk bundle, decision, sources, and assumptions.

| # | Stage | What it does |
|---|-------|--------------|
| 1 | **Normalize Input** | Trim/validate the company name. |
| 2 | **Resolve Company** | Find the ticker: FMP search → fall back to **Tavily-based ticker extraction** with **international exchange support** (tries `.NS`/`.BO` for NSE/BSE, ranks candidates by web-search context so `TCS` → Tata Consultancy Services on NSE, not The Container Store on NYSE). Clearly reports when no public listing is found (e.g. private companies). |
| 3 | **Gather Data** | Parallel `Promise.allSettled` fetch of profile, financials (ratios + income + cash flow + balance sheet + key metrics), ~3y weekly price history, news, and web. One failure never blocks the others. |
| 4 | **Financial Analysis** | Build grounded highlights from real numbers (margins, valuation, returns, leverage) with tone tags. Gemini enriches the summary when available; rule-based engine always provides the structured facts. |
| 5 | **News Analysis** | Classify each headline's sentiment via keyword analysis (positive/negative/neutral), aggregate to an overall sentiment. Gemini refines when available. |
| 6 | **Web Research** | Extract recurring themes via keyword frequency, surface top results. Gemini synthesizes when available. |
| 7 | **Risk Assessment** | Derive strengths, weaknesses, weak signals, opportunities, and severity-tagged risks from financial signals + news sentiment. Gemini adds nuance when available. |
| 8 | **Decision Synthesis** | A transparent **weighted scoring model** (profitability 25 / growth 20 / valuation 20 / balance sheet 15 / cash flow 10 / sentiment 10 = 100) produces the score; ≥2 high-severity risks forces PASS; confidence scales with data coverage. Gemini writes the final thesis when available. |
| 9 | **Report Generation** | Assemble the final `InvestmentReport` and stream it to the client as the `complete` event. |

> **Streaming design note:** LangGraph's built-in `.stream()` emits per-node state diffs that don't map cleanly onto the granular SSE protocol (`stage_start` / `stage_progress` / `stage_complete`) the frontend expects. So `runner.ts` invokes each node sequentially and threads the `emit` callback through manually. The `StateGraph` is still defined and compiled for architectural correctness and future migration. This trade-off is documented in `graph.ts`.

### Data sources

| Source | Used for | Endpoint |
|--------|----------|----------|
| **Financial Modeling Prep** | Company profile, ratios, income/cash-flow/balance-sheet statements, key metrics, ~3y price history | `/stable/*` (FMP migrated their API in 2025; legacy `/api/v3/*` now returns errors) |
| **Tavily** | Web research, competitor context, and **ticker resolution** (when FMP search returns nothing) | `api.tavily.com/search` |
| **NewsAPI** | Recent company headlines (last 30 days) | `newsapi.org/v2/everything` |
| **Google Gemini** | Reasoning, summarization, thesis writing (with rule-based fallback) | `generativelanguage.googleapis.com` via `@langchain/google-genai` |

### How the LLM is used (and how it falls back)

Every analytical node follows a **hybrid pattern**:
1. Pre-compute a fully-grounded **rule-based** result from the fetched data (this always exists and is always grounded in real numbers).
2. **Attempt** a Gemini call to enrich/refine the output.
3. If Gemini succeeds and passes validation → use it.
4. If Gemini fails (quota, network, parse error, region block) → use the rule-based result.

This means the app **never produces an empty report**, even if Gemini is completely down. The rule-based engine is in [`src/lib/agent/rule-based.ts`](src/lib/agent/rule-based.ts) and implements: financial-highlight generation with analyst-standard tone thresholds, keyword-based news sentiment, frequency-based web theme extraction, signal-driven risk/strength/opportunity detection, and a weighted investment-scoring model.

### Data-source resilience (multi-layer fallback)

The agent never depends on a single API working. Each data source has a fallback:

| Primary | Fallback | What happens if both fail |
|---------|----------|---------------------------|
| **FMP** (profile, financials, prices) | **Tavily + Wikipedia** (company profile, description, sector, website) | Profile shows "limited"; financials marked as limited data quality; confidence drops |
| **FMP search** (ticker resolution) | **Tavily web search** (extracts ticker from `NASDAQ: AAPL` patterns, tries `.NS`/`.BO` for Indian exchanges) | No ticker → analysis continues with news + web by company name |
| **Gemini** (reasoning) | **Rule-based engine** (deterministic scoring + thresholds) | Lower confidence; verdict still grounded in fetched data |
| **NewsAPI** | — (graceful skip) | News section shows "No recent news found" |
| **Tavily** (web) | — (graceful skip) | Web section shows "No web results" |

This means even when FMP hits its daily rate limit (which happens on the free tier), the app still shows a company profile (via Tavily + Wikipedia), news, web research, and a reasoned verdict — just with lower confidence and a note in the assumptions.

### PDF generation

The **Download PDF** button POSTs the final `InvestmentReport` JSON to `/api/report`, which calls [`generateInvestmentPdf()`](src/lib/pdf.ts) — a hand-built `jsPDF` generator that produces a multi-page, **white-background, colourful PDF** report with:
- A cover page (company, recommendation badge, scores, date)
- Executive summary, company overview, financial analysis (with a jsPDF-drawn price chart)
- News analysis, web research, risk assessment, investment thesis
- A sources table with clickable URL annotations
- Page numbers and headers on every non-cover page
- Professional colour coding: emerald (positive/INVEST), rose (negative/PASS), amber (HOLD), violet/cyan accents

---

## 4. Key decisions & trade-offs

### Why this architecture
- **LangGraph for structure, manual sequencing for streaming.** LangGraph gives a clear, documented state-machine for the 9 stages. But its built-in streaming doesn't map to our SSE protocol, so the runner calls nodes sequentially. This is a deliberate trade-off: we keep the graph for architecture/diagramming and get reliable, granular progress events.
- **Hybrid LLM + rule-based.** Pure-LLM agents are brittle (rate limits, hallucination, region blocks). Pure-rule-based agents are dull. The hybrid gives the best of both: Gemini's nuance when available, a grounded deterministic engine always. This proved essential during development when Gemini's quota turned out to be exhausted.
- **SSE over WebSockets.** The analysis is a one-shot request → multi-event response. SSE is simpler, HTTP-compatible, and auto-reconnects. No need for bidirectional sockets.

### Why these APIs
- **Gemini** — strong reasoning, generous free tier (when available), good LangChain integration.
- **FMP** — broad, affordable financial data (profile, statements, ratios, prices) in one API.
- **Tavily** — purpose-built AI web search with clean snippets; doubles as a ticker resolver.
- **NewsAPI** — simple, reliable recent-news endpoint.

### What I left out (and why)
- **No database persistence.** Each analysis is computed on-demand and streamed. Adding a Prisma-backed report cache would speed up repeat queries but adds complexity. (Prisma is installed and configured; the schema is ready to extend.)
- **No user accounts / auth.** NextAuth.js v4 is available in the stack but wasn't needed for the core assignment.
- **No backtesting / portfolio tracking.** Out of scope for a single-company research agent.
- **No real-time price streaming.** Historical weekly prices are fetched once; live ticks would need a websocket feed (the project supports mini-services for this).

### What I'd improve with more time

1. **Persist reports + caching.** Store each generated report in SQLite (Prisma is ready) so repeat queries for the same company return instantly and build a searchable history.
2. **Peer/sector benchmarking.** Pull 3–5 industry peers via FMP and show the company's margins/growth/valuation relative to its sector — a much stronger analytical signal.
3. **LLM retry with backoff + model fallback.** Try `gemini-2.5-flash` → `gemini-2.0-flash` → `gemini-flash-lite` with exponential backoff before falling back to rules, so transient quota errors don't lose the LLM's nuance.
4. **Streaming LLM output.** Stream Gemini's thesis text token-by-token to the UI for a more "alive" feel.
5. **Interactive "ask follow-up" chat.** After the report loads, let the user ask the agent questions ("What's the biggest risk?", "Compare to peers?") using the gathered context.
6. **Multi-company comparison mode.** Side-by-side comparison of 2–3 companies on the same metrics.
7. **Confidence calibration.** Track historical decision accuracy (once persisted) to calibrate the confidence score against real outcomes.
8. **Better chart.** Add volume bars, moving averages, and a benchmark overlay (S&P 500) to the price chart.

---

## 5. Example runs

All examples below were generated with the live app. The agent produces differentiated, data-grounded verdicts across the Invest / Hold / Pass spectrum.

### Apple Inc. (AAPL) → **HOLD**
- **Score:** 58 / 100 · **Confidence:** 68%
- **Verdict:** *"Apple Inc. is borderline: a 58/100 score with mixed signals — hold pending clearer catalysts."*
- **Financials:** 16 highlights (Revenue $416.16B, +6.4% YoY growth, 46.9% gross margin, 34.1x P/E, 1.52 ROE, low D/E)
- **News:** 8 headlines, overall neutral
- **Reasoning:** Revenue growing modestly; elevated valuation (P/E 34x); strong free cash flow; reasonable balance sheet.
- **Why HOLD, not INVEST:** Premium valuation (P/E > 30) caps the upside; growth is decelerating to single digits.

### Tesla, Inc. (TSLA) → **PASS**
- **Score:** 38 / 100 · **Confidence:** 68%
- **Verdict:** *"Tesla, Inc. does not clear the investment bar: a 38/100 score warrants caution."*
- **Financials:** 14 highlights, 2 high-severity risks flagged
- **Reasoning:** High valuation multiples, volatile margin profile, negative news flow.
- **Why PASS:** 2 high-severity risks detected — the rule-based engine overrides the score-based recommendation when ≥2 high risks are present.

### Microsoft Corporation (MSFT) → **INVEST**
- **Score:** 86 / 100 · **Confidence:** 68%
- **Verdict:** *"Microsoft Corporation screens attractively: an 86/100 investment score supported by solid fundamentals and manageable risks."*
- **Financials:** 16 highlights, 6 strengths, 0 risks
- **Reasoning:** High net margin, strong ROE, robust revenue growth, reasonable leverage, massive free cash flow.

### NVIDIA Corporation (NVDA) → **INVEST**
- **Score:** 95 / 100 · **Confidence:** 68%
- **Verdict:** *"NVIDIA Corporation screens attractively: a 95/100 investment score supported by solid fundamentals and manageable risks."*
- **Financials:** 16 highlights, 6 strengths, 1 medium risk
- **Reasoning:** Exceptional profitability + growth + cash generation; only flag is high valuation (expected for a hyper-growth leader).

### Tata Consultancy Services (TCS.NS) → **HOLD**
- **Score:** 58 / 100 · **Confidence:** 32%
- **Verdict:** *"Tata Consultancy Services Limited is borderline: a 58/100 score with mixed signals."*
- **Resolution:** Correctly resolved to **TCS.NS (NSE)** — not "The Container Store Group" (NYSE: TCS), thanks to the context-aware international ticker resolver that tries `.NS`/`.BO` suffixes and ranks candidates by Tavily web-search context.
- **Financials:** Limited (FMP free tier restricts financial endpoints for international symbols; profile + news + web data still fetched)
- **News:** 8 headlines, positive sentiment
- **Why HOLD:** Insufficient financial data for a strong call; confidence capped at 32% to reflect the data limitation.

### Stripe (private company) → **HOLD** (graceful degradation)
- **Score:** 48 / 100 · **Confidence:** 32%
- **Verdict:** *"Stripe could not be fully analysed — insufficient financial data was available."*
- **Resolution:** No public ticker found (Stripe is private). The agent clearly reports this in assumptions and produces a qualitative-only report from news + web.
- **Why this matters:** The agent never fabricates data or picks a wrong company. When it can't find a public listing, it says so honestly and still provides whatever news/web context it can gather.

> The confidence is 68% for US-listed companies with full financials (12+ data points). For international companies (where FMP restricts financial endpoints) or when data is limited, confidence drops to 32–52%. The confidence model is intentionally conservative and documented in `rule-based.ts`.

---

## 6. AI usage / transcript logs

> **Note:** I did not preserve the original AI chat export during development.
> The file `docs/dev-log/reconstructed-llm-development-log.md` is an **honest reconstruction**
> of the development process rather than a verbatim transcript. It is clearly
> labelled as such and does not claim to reproduce the original conversations
> word-for-word.

This project was built with AI assistance, as the assignment mandates. Two documents record the development process:

- [`docs/dev-log/reconstructed-llm-development-log.md`](docs/dev-log/reconstructed-llm-development-log.md) — a **reconstructed development conversation**. I did not save the raw chat export, so this is not a literal transcript. It's an honest reconstruction of the key decisions, problems, and AI interactions in dialogue format, with a clear honesty note at the top explaining what it is and isn't. It includes the real bugs (FMP legacy endpoints, Gemini quota, tsParticles v4 API, TCS misresolution, Wikipedia 403, PDF readability) and the real fixes.

- [`docs/dev-log/development-transcript.md`](docs/dev-log/development-transcript.md) — an **engineering diary** written in first person after the project was completed. It covers the problems encountered, decisions made, mistakes and corrections, trade-offs, lessons learned, and future improvements. It reads like a project development journal.

**Honesty note:** The chat transcript is a reconstruction, not a raw export. I labelled it clearly as such rather than presenting a polished rewrite as the literal conversation. The engineering diary is an original reflective document. Both truthfully represent what was built, what failed, and how AI was used.

AI was used for: generating initial code implementations from detailed specs, debugging specific issues (the tsParticles API change, the Wikipedia User-Agent requirement), stripping comments via an AST-aware script, and code review. The developer designed the architecture, chose the APIs, wrote the fallback strategy, built the rule-based engine thresholds, handled the FMP endpoint migration, and verified everything end-to-end. Every line of generated code was reviewed and often modified.

---

## Project structure

```
src/
├── app/
│   ├── layout.tsx              # Root layout: dark theme + ParticleBackground
│   ├── page.tsx                # The only route: idle/running/complete states
│   ├── globals.css             # Dark premium theme tokens + utilities
│   └── api/
│       ├── analyze/route.ts    # SSE streaming endpoint
│       └── report/route.ts     # PDF generation endpoint
├── components/
│   ├── particles/ParticleBackground.tsx   # tsParticles neural network
│   ├── site-header.tsx         # Sticky glass header with source badges
│   ├── hero-search.tsx         # Immersive hero + search + example chips
│   ├── analysis-pipeline.tsx   # 9-stage live progress + streaming log
│   ├── recommendation-banner.tsx  # Big verdict headline
│   ├── confidence-gauge.tsx    # Animated circular confidence gauge
│   ├── score-ring.tsx          # Animated investment-score ring
│   ├── financial-chart.tsx     # Recharts price-history area chart
│   ├── highlight-list.tsx      # Reusable list (strengths/risks/etc.)
│   ├── source-list.tsx         # Source cards with external links
│   ├── report-display.tsx      # Main report renderer (5 tabs)
│   ├── empty-state.tsx         # Landing capability cards
│   ├── footer.tsx              # Sticky footer + disclaimer
│   └── ui/                     # shadcn/ui component set
├── hooks/
│   └── use-analysis.ts         # SSE consumer hook (state machine)
└── lib/
    ├── agent/
    │   ├── types.ts            # Shared contract (all types + SSE events)
    │   ├── env.ts              # Typed env config
    │   ├── tools.ts            # FMP/Tavily/NewsAPI fetchers (never throw)
    │   ├── prompts.ts          # LLM prompt templates
    │   ├── llm.ts              # Gemini client + resilient callJson()
    │   ├── rule-based.ts       # Deterministic analysis engine (fallback)
    │   ├── state.ts            # LangGraph Annotation state
    │   ├── nodes.ts            # 9 pipeline node functions
    │   ├── graph.ts            # StateGraph definition
    │   └── runner.ts           # Sequential runner + SSE emit
    ├── pdf.ts                  # jsPDF dark-premium report generator
    ├── client-pdf.ts           # Browser PDF download helper
    └── utils.ts                # cn() class merge
```

---

## Tech stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Animation | Framer Motion |
| Background | tsParticles v4 (slim) |
| Charts | Recharts |
| AI orchestration | LangGraph.js (`@langchain/langgraph`) |
| LLM | Google Gemini (`@langchain/google-genai`) |
| Data APIs | FMP, Tavily, NewsAPI |
| PDF | jsPDF + jspdf-autotable |
| Icons | Lucide |
| Validation | Zod |

---

## Disclaimer

**FinOps Agent is for research and educational purposes only.** It is **not financial advice**. The agent's verdicts are generated by an automated system using publicly available data and heuristic/LLM reasoning. Always do your own research and consult a licensed financial advisor before making investment decisions. See the footer disclaimer in the app.

---

*Built as a production assignment for InsideIIM × Altuni AI Labs.*
