import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ParticleBackground } from "@/components/particles/ParticleBackground";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FinOps Agent — AI Investment Research",
  description:
    "FinOps Agent is an AI investment research agent that researches any public company across financials, news and web context, then decides whether to Invest or Pass — with full reasoning and sources.",
  keywords: [
    "AI Investment Research",
    "Investment Agent",
    "LangGraph",
    "Gemini",
    "Equity Research",
    "Financial Modeling Prep",
    "Tavily",
    "NewsAPI",
    "FinOps Agent",
  ],
  authors: [{ name: "FinOps Agent" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "FinOps Agent — AI Investment Research",
    description:
      "Research any public company with FinOps Agent, an AI analyst. Financials, news, web context, risks, and a clear Invest / Pass verdict.",
    siteName: "FinOps Agent",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FinOps Agent — AI Investment Research",
    description:
      "Research any public company with FinOps Agent. Invest or Pass, with full reasoning.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        <ParticleBackground />
        <div className="relative z-10 flex min-h-screen flex-col">
          {children}
        </div>
        <Toaster />
      </body>
    </html>
  );
}
