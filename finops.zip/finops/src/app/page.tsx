"use client";

import { useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, RotateCcw } from "lucide-react";
import { useAnalysis } from "@/hooks/use-analysis";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/footer";
import { HeroSearch } from "@/components/hero-search";
import { EmptyState } from "@/components/empty-state";
import { AnalysisPipeline } from "@/components/analysis-pipeline";
import { ReportDisplay } from "@/components/report-display";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { state, analyze, reset } = useAnalysis();

  const onAnalyze = useCallback(
    (company: string) => {
      if (state.status === "complete" || state.status === "error") {
        reset();
      }
      void analyze(company);
    },
    [analyze, reset, state.status],
  );

  const isRunning = state.status === "running";
  const isComplete = state.status === "complete" && !!state.report;
  const isError = state.status === "error";

  return (
    <>
      <SiteHeader />

      <main className="flex flex-1 flex-col">
        <AnimatePresence mode="wait">

          {!isRunning && !isComplete && !isError && (
            <motion.div
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.4 }}
              className="flex flex-1 flex-col"
            >
              <HeroSearch onAnalyze={onAnalyze} disabled={false} />
              <EmptyState />
            </motion.div>
          )}

          {isRunning && (
            <motion.div
              key="running"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="flex flex-1 flex-col"
            >
              <AnalysisPipeline state={state} onCancel={reset} />
            </motion.div>
          )}

          {(isComplete || isError) && (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="flex flex-1 flex-col gap-6 py-6"
            >
              <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
                <HeroSearch
                  onAnalyze={onAnalyze}
                  compact
                  initialValue={state.company ?? ""}
                  disabled={false}
                />
              </div>

              {isComplete && state.report ? (
                <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
                  <ReportDisplay report={state.report} />
                </div>
              ) : null}

              {isError ? (
                <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
                  <div className="glass-strong gradient-border rounded-2xl">
                    <div className="flex flex-col items-center gap-4 p-8 text-center">
                      <div className="grid size-14 place-items-center rounded-2xl border border-rose-400/30 bg-rose-400/10 text-rose-300">
                        <AlertTriangle className="size-6" />
                      </div>
                      <div>
                        <h2 className="text-xl font-semibold text-foreground">
                          Analysis could not complete
                        </h2>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {state.error ??
                            "An unexpected error occurred during the analysis."}
                        </p>
                      </div>
                      <Button
                        onClick={() => {
                          if (state.company) onAnalyze(state.company);
                          else reset();
                        }}
                        className="gap-2 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-400 text-white shadow-[0_0_24px_rgba(168,85,247,0.45)] hover:shadow-[0_0_36px_rgba(34,211,238,0.55)]"
                      >
                        <RotateCcw className="size-4" />
                        {state.company ? `Retry ${state.company}` : "Start over"}
                      </Button>
                    </div>
                  </div>
                </div>
              ) : null}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <SiteFooter />
    </>
  );
}
