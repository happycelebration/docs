import { runAnalysis } from "@/lib/agent/runner";
import type { AgentEvent } from "@/lib/agent/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<Response> {
  let company: string;
  try {
    const body = await req.json();
    company = typeof body?.company === "string" ? body.company : "";
  } catch {
    company = "";
  }

  if (!company.trim()) {
    return new Response(
      JSON.stringify({ error: "Missing 'company' in request body." }),
      { status: 400, headers: { "Content-Type": "application/json" } },
    );
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    start: async (controller) => {
      const emit = async (event: AgentEvent) => {
        const payload = `data: ${JSON.stringify(event)}\n\n`;
        try {
          controller.enqueue(encoder.encode(payload));
        } catch {
        }
      };

      try {
        await runAnalysis(company, emit);
      } catch (err) {
        const message =
          err instanceof Error ? err.message : "Unknown analysis error";
        try {
          await emit({
            type: "error",
            message: `Analysis failed unexpectedly: ${message}`,
            recoverable: false,
          });
        } catch {
        }
      } finally {
        try {
          controller.close();
        } catch {
        }
      }
    },
    cancel: () => {
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
