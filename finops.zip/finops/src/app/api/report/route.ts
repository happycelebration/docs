import { NextRequest } from "next/server";
import { generateInvestmentPdf } from "@/lib/pdf";
import type { InvestmentReport } from "@/lib/agent/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const report = (await req.json()) as InvestmentReport;
    if (!report || !report.companyName) {
      return new Response(JSON.stringify({ error: "Invalid report payload" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }
    const pdf = generateInvestmentPdf(report);
    const safeName = (report.companyName || "company")
      .replace(/[^a-z0-9]+/gi, "-")
      .replace(/^-+|-+$/g, "")
      .toLowerCase();
    return new Response(new Uint8Array(pdf), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${safeName}-investment-report.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "PDF generation failed";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
