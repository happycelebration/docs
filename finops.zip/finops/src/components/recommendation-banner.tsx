"use client";

import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { InvestmentReport, Recommendation } from "@/lib/agent/types";
import { cn } from "@/lib/utils";

interface RecommendationBannerProps {
  report: InvestmentReport;
  className?: string;
}

function theme(rec: Recommendation) {
  switch (rec) {
    case "INVEST":
      return {
        Icon: TrendingUp,
        accent: "from-emerald-400 via-emerald-300 to-cyan-300",
        ring: "shadow-[0_0_50px_rgba(52,211,153,0.35)]",
        chip: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
        glow: "text-glow-cyan",
      };
    case "PASS":
      return {
        Icon: TrendingDown,
        accent: "from-rose-400 via-rose-300 to-amber-300",
        ring: "shadow-[0_0_50px_rgba(244,63,94,0.35)]",
        chip: "border-rose-400/30 bg-rose-400/10 text-rose-300",
        glow: "text-glow-violet",
      };
    case "HOLD":
    default:
      return {
        Icon: Minus,
        accent: "from-amber-400 via-amber-300 to-violet-300",
        ring: "shadow-[0_0_50px_rgba(251,191,36,0.30)]",
        chip: "border-amber-400/30 bg-amber-400/10 text-amber-300",
        glow: "text-glow-violet",
      };
  }
}

export function RecommendationBanner({
  report,
  className,
}: RecommendationBannerProps) {
  const decision = report.decision;
  const t = theme(decision.recommendation);
  const Icon = t.Icon;

  const generatedAt = report.generatedAt
    ? new Date(report.generatedAt).toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      })
    : "";

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96, y: 8 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 180, damping: 18 }}
      className={cn("gradient-border relative overflow-hidden rounded-2xl", className)}
    >
      <div className={cn("glass-strong rounded-2xl p-6 sm:p-8", t.ring)}>
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-5">
            <motion.div
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 220, damping: 14, delay: 0.1 }}
              className={cn(
                "grid size-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br text-white",
                t.accent,
              )}
            >
              <Icon className="size-8" strokeWidth={2.2} />
            </motion.div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={cn(
                    "rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.18em]",
                    t.chip,
                  )}
                >
                  Verdict
                </span>
                <span className="text-xs text-muted-foreground">
                  {generatedAt}
                </span>
              </div>
              <h2
                className={cn(
                  "mt-1 text-5xl font-extrabold leading-none tracking-tight sm:text-6xl",
                  "bg-gradient-to-r bg-clip-text text-transparent",
                  t.accent,
                  t.glow,
                )}
              >
                {decision.recommendation}
              </h2>
              <div className="mt-1.5 text-sm text-foreground/80 sm:text-base">
                <span className="font-semibold text-foreground">
                  {report.companyName}
                </span>
                {report.symbol ? (
                  <span className="text-muted-foreground"> · {report.symbol}</span>
                ) : null}
                {report.exchange ? (
                  <span className="text-muted-foreground"> · {report.exchange}</span>
                ) : null}
              </div>
            </div>
          </div>

          {decision.verdict ? (
            <motion.blockquote
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.25 }}
              className="max-w-md text-pretty border-l-2 border-white/15 pl-4 text-sm italic leading-relaxed text-foreground/85"
            >
              &ldquo;{decision.verdict}&rdquo;
            </motion.blockquote>
          ) : null}
        </div>
      </div>
    </motion.div>
  );
}
