"use client";

import { motion } from "framer-motion";
import {
  Database,
  Globe,
  Newspaper,
  Sparkles,
  ExternalLink,
  type LucideIcon,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { SourceRef, SourceType } from "@/lib/agent/types";
import { cn } from "@/lib/utils";

interface SourceListProps {
  sources: SourceRef[];
  className?: string;
}

const SOURCE_CFG: Record<
  SourceType,
  { label: string; Icon: LucideIcon; chip: string; accent: string }
> = {
  fmp: {
    label: "FMP",
    Icon: Database,
    chip: "border-cyan-400/30 bg-cyan-400/10 text-cyan-300",
    accent: "text-cyan-300",
  },
  tavily: {
    label: "Tavily",
    Icon: Globe,
    chip: "border-violet-400/30 bg-violet-400/10 text-violet-300",
    accent: "text-violet-300",
  },
  newsapi: {
    label: "NewsAPI",
    Icon: Newspaper,
    chip: "border-amber-400/30 bg-amber-400/10 text-amber-300",
    accent: "text-amber-300",
  },
  gemini: {
    label: "Gemini",
    Icon: Sparkles,
    chip: "border-fuchsia-400/30 bg-fuchsia-400/10 text-fuchsia-300",
    accent: "text-fuchsia-300",
  },
};

export function SourceList({ sources, className }: SourceListProps) {
  if (!sources || sources.length === 0) {
    return (
      <div
        className={cn(
          "rounded-xl border border-dashed border-white/10 bg-white/[0.02] p-5 text-sm text-muted-foreground",
          className,
        )}
      >
        No sources were recorded for this analysis.
      </div>
    );
  }

  const grouped = sources.reduce<Record<string, SourceRef[]>>((acc, s) => {
    (acc[s.type] ??= []).push(s);
    return acc;
  }, {});
  const groups = Object.entries(grouped) as [SourceType, SourceRef[]][];

  return (
    <div className={cn("grid min-w-0 gap-4 sm:grid-cols-2", className)}>
      {groups.map(([type, items]) => {
        const cfg = SOURCE_CFG[type];
        const Icon = cfg.Icon;
        return (
          <motion.div
            key={type}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass min-w-0 overflow-hidden rounded-xl p-4"
          >
            <div className="mb-3 flex items-center justify-between">
              <div className="flex min-w-0 items-center gap-2">
                <div
                  className={cn(
                    "grid size-7 shrink-0 place-items-center rounded-lg border bg-background/60",
                    cfg.chip,
                  )}
                >
                  <Icon className="size-3.5" />
                </div>
                <span className="truncate text-sm font-semibold">{cfg.label}</span>
              </div>
              <Badge variant="outline" className="shrink-0 border-white/10 bg-white/5 text-muted-foreground">
                {items.length}
              </Badge>
            </div>
            <ul className="flex min-w-0 flex-col gap-2">
              {items.map((s, idx) => (
                <li
                  key={`${s.label}-${idx}`}
                  className="flex min-w-0 items-start justify-between gap-2 text-xs"
                >
                  <div className="min-w-0 flex-1 overflow-hidden">
                    <div className="truncate break-words text-foreground/90">{s.label}</div>
                    {s.detail ? (
                      <div className="truncate break-words text-muted-foreground">
                        {s.detail}
                      </div>
                    ) : null}
                  </div>
                  {s.url ? (
                    <a
                      href={s.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={cn(
                        "inline-flex size-6 shrink-0 items-center justify-center rounded-md border border-white/10 bg-white/5 transition-colors hover:bg-white/10",
                        cfg.accent,
                      )}
                      aria-label="Open source"
                    >
                      <ExternalLink className="size-3" />
                    </a>
                  ) : null}
                </li>
              ))}
            </ul>
          </motion.div>
        );
      })}
    </div>
  );
}
