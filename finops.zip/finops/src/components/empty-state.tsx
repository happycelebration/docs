"use client";

import { motion } from "framer-motion";
import { LineChart, Newspaper, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";

const CAPS = [
  {
    icon: LineChart,
    title: "Financials",
    body: "Revenue, margins, balance sheet & valuation ratios — pulled live from FMP.",
    accent: "from-violet-400/15 to-cyan-400/5",
    glow: "text-violet-300",
  },
  {
    icon: Newspaper,
    title: "News & Web",
    body: "Recent headlines from NewsAPI plus broad web context via Tavily search.",
    accent: "from-cyan-400/15 to-fuchsia-400/5",
    glow: "text-cyan-300",
  },
  {
    icon: ShieldAlert,
    title: "Risk & Verdict",
    body: "A Gemini-powered synthesis weighs every signal into a clear Invest / Pass call.",
    accent: "from-fuchsia-400/15 to-amber-400/5",
    glow: "text-fuchsia-300",
  },
];

export function EmptyState({ className }: { className?: string }) {
  return (
    <section className={cn("mx-auto w-full max-w-7xl px-4 pb-12 sm:px-6 lg:px-8", className)}>
      <div className="grid gap-4 sm:grid-cols-3">
        {CAPS.map((c, i) => {
          const Icon = c.icon;
          return (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.08, duration: 0.5 }}
              className="glass relative overflow-hidden rounded-xl p-5"
            >
              <div
                className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${c.accent} opacity-70`}
              />
              <div className="relative">
                <div className="mb-3 grid size-9 place-items-center rounded-lg border border-white/10 bg-background/60">
                  <Icon className={`size-4 ${c.glow}`} />
                </div>
                <h3 className="text-sm font-semibold text-foreground">{c.title}</h3>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {c.body}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
