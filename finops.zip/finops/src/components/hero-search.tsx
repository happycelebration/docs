"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Sparkles, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

const EXAMPLES = [
  "Apple",
  "Tesla",
  "Microsoft",
  "Nvidia",
  "Amazon",
  "Google",
  "Meta",
  "TCS",
];

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.08, delayChildren: 0.05 },
  },
};

const item = {
  hidden: { opacity: 0, y: 18 },
  show: {
    opacity: 1,
    y: 0,
    transition: { type: "spring" as const, stiffness: 220, damping: 22 },
  },
};

interface HeroSearchProps {
  onAnalyze: (company: string) => void;
  compact?: boolean;
  initialValue?: string;
  disabled?: boolean;
  className?: string;
}

export function HeroSearch({
  onAnalyze,
  compact = false,
  initialValue = "",
  disabled = false,
  className,
}: HeroSearchProps) {
  const [value, setValue] = useState(initialValue);

  const submit = () => {
    const v = value.trim();
    if (!v || disabled) return;
    onAnalyze(v);
  };

  if (compact) {
    return (
      <div
        className={cn(
          "mx-auto flex w-full max-w-2xl flex-col gap-2 sm:flex-row sm:items-center",
          className,
        )}
      >
        <div className="glass-strong group relative flex flex-1 items-center gap-2 rounded-xl px-3">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") submit();
            }}
            placeholder="Run another analysis…"
            className="h-11 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            disabled={disabled}
            aria-label="Company name"
          />
        </div>
        <button
          onClick={submit}
          disabled={disabled || !value.trim()}
          className={cn(
            "inline-flex h-11 items-center justify-center gap-2 rounded-xl px-5 text-sm font-semibold text-white",
            "bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-400 shadow-[0_0_24px_rgba(168,85,247,0.45)]",
            "transition-all hover:shadow-[0_0_36px_rgba(34,211,238,0.55)] disabled:cursor-not-allowed disabled:opacity-50",
          )}
        >
          <Sparkles className="size-4" />
          Analyze
        </button>
      </div>
    );
  }

  return (
    <section
      className={cn(
        "relative mx-auto flex w-full max-w-5xl flex-col items-center justify-center px-4 text-center",
        compact ? "py-10" : "min-h-[78vh] py-16 sm:py-20",
        className,
      )}
    >
      <div
        aria-hidden
        className="bg-grid pointer-events-none absolute inset-0 -z-10 opacity-60 [mask-image:radial-gradient(ellipse_at_center,black_10%,transparent_75%)]"
      />

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="flex w-full flex-col items-center"
      >
        <motion.div variants={item}>
          <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-muted-foreground backdrop-blur-md">
            <span className="size-1.5 animate-pulse rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.7)]" />
            Powered by a multi-source AI agent
          </span>
        </motion.div>

        <motion.h1
          variants={item}
          className="max-w-3xl text-balance text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl"
        >
          <span className="gradient-text text-glow-violet">
            AI Investment Research,
          </span>
          <br />
          <span className="text-foreground">in seconds.</span>
        </motion.h1>

        <motion.p
          variants={item}
          className="mt-5 max-w-xl text-pretty text-sm text-muted-foreground sm:text-base"
        >
          FinOps Agent researches any public company across financials, news and
          web context — then weighs the evidence into a clear{" "}
          <span className="text-foreground/90">Invest / Hold / Pass</span>{" "}
          verdict, with full reasoning and sources.
        </motion.p>

        <motion.div
          variants={item}
          className="mt-9 flex w-full max-w-2xl flex-col items-stretch gap-3 sm:flex-row sm:items-center"
        >
          <div className="glass-strong group relative flex flex-1 items-center gap-2.5 rounded-2xl px-4 py-3 transition-all focus-within:ring-glow-violet">
            <Search className="size-5 shrink-0 text-violet-300/80" />
            <input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
              }}
              placeholder="Try: Apple, Tesla, Microsoft, Reliance…"
              className="w-full bg-transparent text-base text-foreground outline-none placeholder:text-muted-foreground/80"
              disabled={disabled}
              aria-label="Company name"
              autoFocus
            />
          </div>
          <button
            onClick={submit}
            disabled={disabled || !value.trim()}
            className={cn(
              "inline-flex h-[52px] items-center justify-center gap-2 rounded-2xl px-6 text-sm font-semibold text-white",
              "bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-400 shadow-[0_0_28px_rgba(168,85,247,0.5)]",
              "transition-all hover:scale-[1.02] hover:shadow-[0_0_44px_rgba(34,211,238,0.6)] active:scale-100",
              "disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:scale-100",
            )}
          >
            <Sparkles className="size-4" />
            Analyze
            <ArrowRight className="size-4" />
          </button>
        </motion.div>

        <motion.div
          variants={item}
          className="mt-7 flex flex-wrap items-center justify-center gap-2"
        >
          <span className="text-xs text-muted-foreground">Examples:</span>
          {EXAMPLES.map((ex) => (
            <button
              key={ex}
              onClick={() => {
                setValue(ex);
                onAnalyze(ex);
              }}
              disabled={disabled}
              className={cn(
                "rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-foreground/85 backdrop-blur-md",
                "transition-all hover:border-violet-400/40 hover:bg-violet-500/10 hover:text-foreground",
                "disabled:cursor-not-allowed disabled:opacity-50",
              )}
            >
              {ex}
            </button>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
}
