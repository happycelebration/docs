"use client";

import { Radar, Sparkles, Globe, Database, Newspaper } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const SOURCES = [
  { label: "Gemini", icon: Sparkles },
  { label: "Tavily", icon: Globe },
  { label: "FMP", icon: Database },
  { label: "NewsAPI", icon: Newspaper },
] as const;

export function SiteHeader({ className }: { className?: string }) {
  return (
    <header
      className={cn(
        "sticky top-0 z-30 w-full border-b border-white/5 bg-background/85 backdrop-blur-xl",
        className,
      )}
    >
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2.5">
          <div className="relative grid size-9 place-items-center rounded-lg bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 shadow-[0_0_24px_rgba(168,85,247,0.45)]">
            <Radar className="size-5 text-white" strokeWidth={2.2} />
            <div className="pointer-events-none absolute inset-0 rounded-lg ring-1 ring-white/20" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-base font-semibold tracking-tight">
              <span className="gradient-text">FinOps Agent</span>
            </span>
            <span className="hidden text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:block">
              AI Investment Research
            </span>
          </div>
        </div>

        <div className="hidden items-center gap-1.5 md:flex">
          {SOURCES.map((s) => {
            const Icon = s.icon;
            return (
              <Badge
                key={s.label}
                variant="outline"
                className="gap-1 border-white/10 bg-white/5 text-muted-foreground backdrop-blur-md"
              >
                <Icon className="size-3 text-violet-300/80" />
                {s.label}
              </Badge>
            );
          })}
        </div>

        <div className="flex items-center gap-1.5 md:hidden">
          <span className="size-1.5 rounded-full bg-violet-400/80 shadow-[0_0_8px_rgba(168,85,247,0.6)]" />
          <span className="size-1.5 rounded-full bg-cyan-400/80 shadow-[0_0_8px_rgba(34,211,238,0.6)]" />
          <span className="size-1.5 rounded-full bg-fuchsia-400/80 shadow-[0_0_8px_rgba(236,72,153,0.6)]" />
        </div>
      </div>
    </header>
  );
}
