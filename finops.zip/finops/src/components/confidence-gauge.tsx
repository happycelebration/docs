"use client";

import { useEffect } from "react";
import {
  animate,
  motion,
  useMotionValue,
  useReducedMotion,
  useTransform,
} from "framer-motion";

interface ConfidenceGaugeProps {
  value: number;
  size?: number;
  label?: string;
}

function colorFor(v: number) {
  if (v < 40) {
    return {
      stroke: "rgb(244 63 94)",
      glow: "rgba(244,63,94,0.55)",
      text: "text-rose-300",
    };
  }
  if (v <= 70) {
    return {
      stroke: "rgb(251 191 36)",
      glow: "rgba(251,191,36,0.55)",
      text: "text-amber-300",
    };
  }
  return {
    stroke: "rgb(52 211 153)",
    glow: "rgba(52,211,153,0.55)",
    text: "text-emerald-300",
  };
}

export function ConfidenceGauge({
  value,
  size = 160,
  label = "Confidence",
}: ConfidenceGaugeProps) {
  const reduce = useReducedMotion();
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  const stroke = 10;
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const c = colorFor(clamped);

  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => Math.round(v));
  const offsetMv = useTransform(
    mv,
    (v) => circumference - (v / 100) * circumference,
  );

  useEffect(() => {
    if (reduce) {
      mv.set(clamped);
      return;
    }
    const controls = animate(mv, clamped, {
      duration: 0.9,
      ease: "easeOut",
    });
    return () => controls.stop();
  }, [clamped, mv, reduce]);

  return (
    <div
      className="flex flex-col items-center"
      style={{ width: size }}
      role="meter"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={`${label}: ${clamped} out of 100`}
    >
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <defs>
            <filter id="conf-glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke="rgba(255,255,255,0.08)"
            strokeWidth={stroke}
            fill="none"
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke={c.stroke}
            strokeWidth={stroke}
            strokeLinecap="round"
            fill="none"
            filter="url(#conf-glow)"
            style={{
              strokeDasharray: circumference,
              strokeDashoffset: offsetMv,
              filter: `drop-shadow(0 0 6px ${c.glow})`,
            }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span className={`text-3xl font-bold tabular-nums ${c.text}`}>
            {rounded}
          </motion.span>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            / 100
          </span>
        </div>
      </div>
      <div className="mt-2 text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </div>
    </div>
  );
}
