"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  motion,
  AnimatePresence,
  useMotionValue,
  useMotionValueEvent,
  useTransform,
  animate,
  type MotionValue,
} from "framer-motion";
import {
  CheckCircle2,
  Loader2,
  XCircle,
  Circle,
  type LucideIcon,
} from "lucide-react";
import {
  PIPELINE_STAGES,
  type PipelineStageId,
} from "@/lib/agent/types";
import type {
  AnalysisState,
  StageStatus,
} from "@/hooks/use-analysis";
import { DynamicIcon } from "@/components/icon-map";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

interface AnalysisPipelineProps {
  state: AnalysisState;
  onCancel?: () => void;
  className?: string;
}

function statusIcon(
  status: StageStatus,
): { Icon: LucideIcon; className: string } {
  switch (status) {
    case "running":
      return { Icon: Loader2, className: "animate-spin text-cyan-300" };
    case "complete":
      return { Icon: CheckCircle2, className: "text-emerald-300" };
    case "error":
      return { Icon: XCircle, className: "text-rose-400" };
    default:
      return { Icon: Circle, className: "text-muted-foreground/60" };
  }
}

function statusRing(status: StageStatus): string {
  switch (status) {
    case "running":
      return "border-cyan-400/60 ring-glow-cyan";
    case "complete":
      return "border-emerald-400/50 shadow-[0_0_18px_rgba(52,211,153,0.35)]";
    case "error":
      return "border-rose-400/60 shadow-[0_0_18px_rgba(244,63,94,0.4)]";
    default:
      return "border-white/10";
  }
}

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener?.("change", update);
    return () => mq.removeEventListener?.("change", update);
  }, []);
  return reduced;
}

function useAnimatedStageProgress(
  status: StageStatus,
  reducedMotion: boolean,
): MotionValue<number> {
  const progress = useMotionValue(0);

  useEffect(() => {
    if (reducedMotion) {
      if (status === "running") progress.set(50);
      else if (status === "complete") progress.set(100);
      else if (status === "pending") progress.set(0);
      return;
    }

    if (status === "running") {
      const controls = animate(progress, [null, 95], {
        duration: 6,
        ease: "linear",
      });
      return () => controls.stop();
    }
    if (status === "complete") {
      const controls = animate(progress, 100, {
        duration: 0.4,
        ease: "easeOut",
      });
      return () => controls.stop();
    }
    if (status === "pending") {
      progress.set(0);
    }
  }, [status, progress, reducedMotion]);

  return progress;
}

interface StageTileProps {
  id: PipelineStageId;
  label: string;
  description: string;
  iconName: string;
  status: StageStatus;
  isCurrent: boolean;
  latestLog: string | null;
  reducedMotion: boolean;
  onProgress: (id: PipelineStageId, value: number) => void;
}

function StageTile({
  id,
  label,
  description,
  iconName,
  status,
  isCurrent,
  latestLog,
  reducedMotion,
  onProgress,
}: StageTileProps) {
  const { Icon, className: iconCls } = statusIcon(status);
  const progress = useAnimatedStageProgress(status, reducedMotion);
  const widthPct = useTransform(progress, (v) => `${Math.max(0, Math.min(100, v))}%`);
  const [pctNum, setPctNum] = useState(0);

  useMotionValueEvent(progress, "change", (v) => {
    const clamped = Math.max(0, Math.min(100, v));
    const intV = Math.round(clamped);
    setPctNum((prev) => (prev === intV ? prev : intV));
    onProgress(id, clamped);
  });

  const showProgress = status === "running" || status === "complete";
  const doingText =
    status === "running"
      ? (latestLog ?? "Working…")
      : status === "complete"
        ? "Done"
        : status === "error"
          ? "Failed"
          : "Pending";

  return (
    <motion.div
      layout
      transition={{ type: "spring", stiffness: 240, damping: 24 }}
      className={cn(
        "relative flex min-w-0 flex-1 flex-col items-center gap-2 overflow-hidden rounded-xl border bg-white/[0.03] p-3 text-center backdrop-blur-sm transition-colors",
        statusRing(status),
        status === "pending" && "opacity-60",
      )}
    >
      <div className="relative grid size-9 place-items-center rounded-full border border-white/10 bg-background/60">
        {status === "pending" || status === "complete" ? (
          <DynamicIcon
            name={iconName}
            className={cn(
              "size-4",
              status === "complete" ? "text-emerald-300" : "text-muted-foreground",
            )}
          />
        ) : (
          <Icon className={cn("size-4", iconCls)} />
        )}
        {isCurrent && status === "running" && (
          <motion.span
            className="pointer-events-none absolute inset-0 rounded-full"
            initial={{ boxShadow: "0 0 0 0 rgba(34,211,238,0.45)" }}
            animate={{ boxShadow: "0 0 0 8px rgba(34,211,238,0)" }}
            transition={{ duration: 1.6, repeat: Infinity }}
          />
        )}
      </div>
      <div className="min-w-0 w-full space-y-0.5 overflow-hidden">
        <div className="min-w-0 break-words text-[11px] font-semibold leading-tight text-foreground sm:text-xs">
          {label}
        </div>
        <div className="hidden break-words text-[10px] leading-tight text-muted-foreground lg:block">
          {description}
        </div>
      </div>

      {showProgress ? (
        <div className="min-w-0 w-full">
          <div className="relative h-1 w-full overflow-hidden rounded-full bg-white/10">
            <motion.div
              className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-violet-400 to-cyan-400"
              style={{ width: widthPct }}
            />
          </div>
          <div className="mt-1 flex items-center justify-between gap-2">
            <AnimatePresence mode="wait">
              <motion.span
                key={doingText}
                initial={{ opacity: 0, y: 2 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -2 }}
                transition={{ duration: 0.25 }}
                className={cn(
                  "min-w-0 flex-1 truncate text-[9px] leading-tight",
                  status === "running"
                    ? "text-cyan-300/90"
                    : status === "complete"
                      ? "text-emerald-300/80"
                      : "text-muted-foreground",
                )}
                title={doingText}
              >
                {doingText}
              </motion.span>
            </AnimatePresence>
            <span
              className={cn(
                "shrink-0 font-mono text-[9px] tabular-nums",
                status === "running"
                  ? "text-cyan-300"
                  : status === "complete"
                    ? "text-emerald-300"
                    : "text-muted-foreground",
              )}
            >
              {pctNum}%
            </span>
          </div>
        </div>
      ) : null}
    </motion.div>
  );
}

function Connector({ active }: { active: boolean }) {
  return (
    <div className="relative hidden h-px flex-1 self-start lg:mt-[26px] lg:block">
      <div className="absolute inset-0 bg-white/10" />
      <motion.div
        className="absolute inset-0 origin-left bg-gradient-to-r from-violet-400/70 to-cyan-400/70"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: active ? 1 : 0 }}
        transition={{ duration: 0.5 }}
        style={{ transformOrigin: "left" }}
      />
    </div>
  );
}

function useAllStageLogs(
  logs: AnalysisState["logs"],
): Record<PipelineStageId, string | null> {
  return useMemo(() => {
    const acc = {} as Record<PipelineStageId, string | null>;
    for (const s of PIPELINE_STAGES) acc[s.id] = null;
    for (let i = logs.length - 1; i >= 0; i--) {
      const entry = logs[i];
      if (acc[entry.stage] == null) acc[entry.stage] = entry.message;
    }
    return acc;
  }, [logs]);
}

function emptyStagePcts(): Record<PipelineStageId, number> {
  const acc = {} as Record<PipelineStageId, number>;
  for (const s of PIPELINE_STAGES) acc[s.id] = 0;
  return acc;
}

export function AnalysisPipeline({
  state,
  onCancel,
  className,
}: AnalysisPipelineProps) {
  const logEndRef = useRef<HTMLDivElement>(null);
  const reducedMotion = usePrefersReducedMotion();
  const stageLogs = useAllStageLogs(state.logs);
  const [stagePcts, setStagePcts] = useState<Record<PipelineStageId, number>>(
    emptyStagePcts,
  );

  const handleProgress = useCallback(
    (id: PipelineStageId, value: number) => {
      const intV = Math.round(value);
      setStagePcts((prev) => {
        if (Math.round(prev[id]) === intV) return prev;
        return { ...prev, [id]: value };
      });
    },
    [],
  );

  const overallPct = useMemo(() => {
    const sum = Object.values(stagePcts).reduce((a, b) => a + b, 0);
    return Math.round(sum / PIPELINE_STAGES.length);
  }, [stagePcts]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [state.logs.length]);

  return (
    <section className={cn("mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8", className)}>
      <div className="glass-strong min-w-0 overflow-hidden rounded-2xl p-4 sm:p-6">
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <h2 className="flex min-w-0 items-center gap-2 text-lg font-semibold">
              <Loader2 className="size-4 shrink-0 animate-spin text-cyan-300" />
              <span className="shrink-0">Researching</span>
              <span className="gradient-text truncate">{state.company}</span>
            </h2>
            <p className="mt-0.5 break-words text-xs text-muted-foreground">
              {overallPct}% · {state.currentStage
                ? `current: ${state.currentStage}`
                : "starting…"}
            </p>
          </div>
          {onCancel && (
            <button
              onClick={onCancel}
              className="self-start rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground sm:self-auto"
            >
              Cancel
            </button>
          )}
        </div>

        <div className="mb-6">
          <Progress
            value={overallPct}
            className="h-1.5 bg-white/10 [&>[data-slot=progress-indicator]]:bg-gradient-to-r [&>[data-slot=progress-indicator]]:from-violet-400 [&>[data-slot=progress-indicator]]:to-cyan-400"
          />
        </div>

        <div className="hidden min-w-0 items-start gap-1 overflow-hidden lg:flex">
          {PIPELINE_STAGES.map((s, i) => {
            const status = state.stageStatuses[s.id];
            return (
              <div key={s.id} className="flex min-w-0 flex-1 items-start gap-1">
                <div className="min-w-0 flex-1 overflow-hidden">
                  <StageTile
                    id={s.id}
                    label={s.label}
                    description={s.description}
                    iconName={s.icon}
                    status={status}
                    isCurrent={state.currentStage === s.id}
                    latestLog={stageLogs[s.id]}
                    reducedMotion={reducedMotion}
                    onProgress={handleProgress}
                  />
                </div>
                {i < PIPELINE_STAGES.length - 1 && (
                  <Connector active={status === "complete"} />
                )}
              </div>
            );
          })}
        </div>

        <div className="flex min-w-0 flex-col gap-2 overflow-hidden lg:hidden">
          {PIPELINE_STAGES.map((s) => {
            const status = state.stageStatuses[s.id];
            return (
              <StageTile
                key={s.id}
                id={s.id}
                label={s.label}
                description={s.description}
                iconName={s.icon}
                status={status}
                isCurrent={state.currentStage === s.id}
                latestLog={stageLogs[s.id]}
                reducedMotion={reducedMotion}
                onProgress={handleProgress}
              />
            );
          })}
        </div>

        <div className="mt-6">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              Live log
            </h3>
            <span className="text-[10px] text-muted-foreground">
              {state.logs.length} events
            </span>
          </div>
          <div className="custom-scroll max-h-48 overflow-y-auto rounded-lg border border-white/10 bg-black/40 p-3 font-mono text-[11px] leading-relaxed">
            <AnimatePresence initial={false}>
              {state.logs.length === 0 ? (
                <div className="text-muted-foreground">
                  Waiting for agent output…
                </div>
              ) : (
                state.logs.map((l, idx) => (
                  <motion.div
                    key={`${l.ts}-${idx}`}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex min-w-0 gap-2"
                  >
                    <span className="shrink-0 text-muted-foreground/50">
                      {new Date(l.ts).toLocaleTimeString(undefined, {
                        hour12: false,
                      })}
                    </span>
                    <span className="shrink-0 text-violet-300/70">
                      [{l.stage}]
                    </span>
                    <span
                      className={cn(
                        "min-w-0 break-words text-foreground/85",
                        l.message.startsWith("⚠") && "text-amber-300",
                      )}
                    >
                      {l.message}
                    </span>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
            <div ref={logEndRef} />
          </div>
        </div>
      </div>

      <style jsx>{`
        .custom-scroll::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .custom-scroll::-webkit-scrollbar-thumb {
          background: rgba(168, 85, 247, 0.4);
          border-radius: 999px;
        }
        .custom-scroll::-webkit-scrollbar-track {
          background: transparent;
        }
      `}</style>
    </section>
  );
}
