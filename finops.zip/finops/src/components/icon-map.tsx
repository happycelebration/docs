"use client";

import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
  CircleDot,
  Database,
  ExternalLink,
  FileText,
  Globe,
  LineChart,
  Loader2,
  Minus,
  Newspaper,
  Radar,
  Scale,
  Search,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Type,
  XCircle,
  type LucideIcon,
  type LucideProps,
} from "lucide-react";

export const iconMap: Record<string, LucideIcon> = {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
  CircleDot,
  Database,
  ExternalLink,
  FileText,
  Globe,
  LineChart,
  Loader2,
  Minus,
  Newspaper,
  Radar,
  Scale,
  Search,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Type,
  XCircle,
};

export function getIcon(name: string | undefined): LucideIcon {
  if (name && iconMap[name]) return iconMap[name];
  return CircleDot;
}

interface DynamicIconProps extends LucideProps {
  name: string;
}

export function DynamicIcon({ name, ...rest }: DynamicIconProps) {
  const Comp = name && iconMap[name] ? iconMap[name] : CircleDot;
  return <Comp {...rest} />;
}
