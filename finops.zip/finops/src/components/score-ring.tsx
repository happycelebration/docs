"use client";

import { useEffect } from "react";
import {
  animate,
  motion,
  useMotionValue,
  useReducedMotion,
  useTransform,
} from "framer-motion";

interface ScoreRingProps {
  value: number;
  size?: number;
  label?: string;
}

export function ScoreRing({
  value,
  size = 160,
  label = "Investment Score",
}: ScoreRingProps) {
  const reduce = useReducedMotion();
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  const stroke = 10;
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;

  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => Math.round(v));
  const offsetMv = useTransform(
    mv,
    (v) => circumference - (v / 100) * circumference,
  );

  useEffect(() => {
    if (reduce) {
      mv.set(clamped);
      return;
    }
    const controls = animate(mv, clamped, {
      duration: 1.1,
      ease: "easeOut",
    });
    return () => controls.stop();
  }, [clamped, mv, reduce]);

  return (
    <div
      className="flex flex-col items-center"
      style={{ width: size }}
      role="meter"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={`${label}: ${clamped} out of 100`}
    >
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <defs>
            <linearGradient id="score-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgb(168 85 247)" />
              <stop offset="50%" stopColor="rgb(217 70 239)" />
              <stop offset="100%" stopColor="rgb(34 211 238)" />
            </linearGradient>
          </defs>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke="rgba(255,255,255,0.08)"
            strokeWidth={stroke}
            fill="none"
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke="url(#score-grad)"
            strokeWidth={stroke}
            strokeLinecap="round"
            fill="none"
            style={{
              strokeDasharray: circumference,
              strokeDashoffset: offsetMv,
              filter: "drop-shadow(0 0 6px rgba(168,85,247,0.55))",
            }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span className="text-3xl font-bold tabular-nums text-foreground text-glow-violet">
            {rounded}
          </motion.span>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            / 100
          </span>
        </div>
      </div>
      <div className="mt-2 text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </div>
    </div>
  );
}
