"use client";

import { motion } from "framer-motion";
import {
  ArrowUpRight,
  ArrowDownRight,
  ShieldAlert,
  Sparkles,
  CircleDot,
  LineChart,
  Newspaper,
  Globe,
  type LucideIcon,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type HighlightVariant =
  | "strength"
  | "weakness"
  | "risk"
  | "opportunity"
  | "weaksignal"
  | "financial"
  | "news"
  | "web";

interface BaseItem {
  title: string;
  detail?: string;
  value?: string;
  note?: string;
  tone?: "positive" | "negative" | "neutral";
  severity?: "low" | "medium" | "high";
  sentiment?: "positive" | "negative" | "neutral";
  source?: string;
  date?: string;
  url?: string;
  snippet?: string;
}

interface HighlightListProps {
  items: BaseItem[];
  variant: HighlightVariant;
  emptyMessage?: string;
  className?: string;
}

const VARIANT_CFG: Record<
  HighlightVariant,
  { Icon: LucideIcon; accent: string; ring: string }
> = {
  strength: {
    Icon: ArrowUpRight,
    accent: "text-emerald-300",
    ring: "border-emerald-400/20 bg-emerald-400/[0.04]",
  },
  weakness: {
    Icon: ArrowDownRight,
    accent: "text-rose-300",
    ring: "border-rose-400/20 bg-rose-400/[0.04]",
  },
  risk: {
    Icon: ShieldAlert,
    accent: "text-amber-300",
    ring: "border-amber-400/20 bg-amber-400/[0.04]",
  },
  opportunity: {
    Icon: Sparkles,
    accent: "text-violet-300",
    ring: "border-violet-400/20 bg-violet-400/[0.04]",
  },
  weaksignal: {
    Icon: CircleDot,
    accent: "text-cyan-300",
    ring: "border-cyan-400/20 bg-cyan-400/[0.04]",
  },
  financial: {
    Icon: LineChart,
    accent: "text-fuchsia-300",
    ring: "border-white/10 bg-white/[0.03]",
  },
  news: {
    Icon: Newspaper,
    accent: "text-cyan-300",
    ring: "border-white/10 bg-white/[0.03]",
  },
  web: {
    Icon: Globe,
    accent: "text-violet-300",
    ring: "border-white/10 bg-white/[0.03]",
  },
};

function toneClasses(tone?: BaseItem["tone"]) {
  switch (tone) {
    case "positive":
      return "border-emerald-400/30 bg-emerald-400/10 text-emerald-300";
    case "negative":
      return "border-rose-400/30 bg-rose-400/10 text-rose-300";
    default:
      return "border-white/10 bg-white/5 text-muted-foreground";
  }
}

function severityClasses(sev?: BaseItem["severity"]) {
  switch (sev) {
    case "high":
      return "border-rose-400/30 bg-rose-400/10 text-rose-300";
    case "medium":
      return "border-amber-400/30 bg-amber-400/10 text-amber-300";
    case "low":
      return "border-emerald-400/30 bg-emerald-400/10 text-emerald-300";
    default:
      return "border-white/10 bg-white/5 text-muted-foreground";
  }
}

function sentimentClasses(s?: BaseItem["sentiment"]) {
  switch (s) {
    case "positive":
      return "border-emerald-400/30 bg-emerald-400/10 text-emerald-300";
    case "negative":
      return "border-rose-400/30 bg-rose-400/10 text-rose-300";
    case "neutral":
      return "border-cyan-400/30 bg-cyan-400/10 text-cyan-300";
    default:
      return "border-white/10 bg-white/5 text-muted-foreground";
  }
}

export function HighlightList({
  items,
  variant,
  emptyMessage = "No data available for this section.",
  className,
}: HighlightListProps) {
  const cfg = VARIANT_CFG[variant];
  const Icon = cfg.Icon;

  if (!items || items.length === 0) {
    return (
      <div
        className={cn(
          "rounded-xl border border-dashed border-white/10 bg-white/[0.02] p-5 text-sm text-muted-foreground",
          className,
        )}
      >
        {emptyMessage}
      </div>
    );
  }

  return (
    <ul className={cn("flex min-w-0 flex-col gap-2.5 overflow-hidden", className)}>
      {items.map((it, idx) => {
        const badge =
          variant === "risk"
            ? it.severity
              ? {
                  text: it.severity.toUpperCase(),
                  cls: severityClasses(it.severity),
                }
              : null
            : variant === "news"
              ? it.sentiment
                ? {
                    text: it.sentiment.toUpperCase(),
                    cls: sentimentClasses(it.sentiment),
                  }
                : null
              : variant === "financial"
                ? it.tone
                  ? {
                      text: it.tone.toUpperCase(),
                      cls: toneClasses(it.tone),
                    }
                  : null
                : it.tone
                  ? {
                      text: it.tone.toUpperCase(),
                      cls: toneClasses(it.tone),
                    }
                  : null;

        return (
          <motion.li
            key={`${it.title}-${idx}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(idx * 0.04, 0.4), duration: 0.4 }}
            className={cn(
              "group flex min-w-0 items-start gap-3 overflow-hidden rounded-xl border p-3.5 transition-all hover:bg-white/[0.05]",
              cfg.ring,
            )}
          >
            <div
              className={cn(
                "mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg border border-white/10 bg-background/60",
                cfg.accent,
              )}
            >
              <Icon className="size-3.5" />
            </div>
            <div className="min-w-0 flex-1 overflow-hidden break-words">
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="min-w-0 break-words text-sm font-semibold leading-tight text-foreground">
                  {it.title}
                </h4>
                {badge ? (
                  <Badge
                    variant="outline"
                    className={cn("px-1.5 py-0 text-[9px] uppercase tracking-wide", badge.cls)}
                  >
                    {badge.text}
                  </Badge>
                ) : null}
                {it.source ? (
                  <span className="text-[10px] text-muted-foreground">
                    · {it.source}
                  </span>
                ) : null}
                {it.date ? (
                  <span className="text-[10px] text-muted-foreground">
                    · {it.date}
                  </span>
                ) : null}
              </div>
              {it.value ? (
                <div className="mt-1 break-words font-mono text-lg font-semibold tabular-nums text-foreground">
                  {it.value}
                </div>
              ) : null}
              {it.detail ? (
                <p className="mt-1 break-words text-xs leading-relaxed text-muted-foreground">
                  {it.detail}
                </p>
              ) : null}
              {it.snippet ? (
                <p className="mt-1 break-words text-xs leading-relaxed text-muted-foreground">
                  {it.snippet}
                </p>
              ) : null}
              {it.note ? (
                <p className="mt-1 break-words text-[11px] italic text-muted-foreground/80">
                  {it.note}
                </p>
              ) : null}
              {it.url ? (
                <a
                  href={it.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1.5 inline-flex items-center gap-1 break-all text-[11px] text-cyan-300/80 underline-offset-2 hover:underline"
                >
                  Source
                </a>
              ) : null}
            </div>
          </motion.li>
        );
      })}
    </ul>
  );
}
