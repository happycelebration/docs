"use client";

import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { TrendingUp } from "lucide-react";
import type { HistoricalPricePoint } from "@/lib/agent/types";
import { cn } from "@/lib/utils";

interface FinancialChartProps {
  data?: HistoricalPricePoint[];
  currency?: string;
  className?: string;
}

function formatDateTick(d: string, range: number) {
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return d;
  if (range > 365) {
    return dt.toLocaleDateString(undefined, { month: "short", year: "2-digit" });
  }
  return dt.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{ payload?: HistoricalPricePoint }>;
  label?: string | number;
  currency?: string;
}

function ChartTooltip({ active, payload, label, currency }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  const point = payload[0]?.payload;
  const value = point?.close;
  return (
    <div className="glass-strong rounded-lg px-3 py-2 text-xs shadow-lg">
      <div className="text-muted-foreground">
        {label
          ? new Date(label).toLocaleDateString(undefined, {
              year: "numeric",
              month: "short",
              day: "numeric",
            })
          : ""}
      </div>
      <div className="mt-0.5 flex items-center gap-1.5">
        <span className="size-2 rounded-full bg-gradient-to-r from-violet-400 to-cyan-400" />
        <span className="text-foreground">
          <span className="font-mono font-semibold tabular-nums">
            {value != null
              ? value.toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })
              : "—"}
          </span>
          {currency ? <span className="ml-1 text-muted-foreground">{currency}</span> : null}
        </span>
      </div>
      {point?.volume != null ? (
        <div className="mt-0.5 text-muted-foreground">
          Vol: {point.volume.toLocaleString()}
        </div>
      ) : null}
    </div>
  );
}

export function FinancialChart({ data, currency, className }: FinancialChartProps) {
  const [id] = useState(() => `fc-${Math.random().toString(36).slice(2, 9)}`);

  const sorted = useMemo(() => {
    if (!data || data.length === 0) return [];
    return [...data]
      .filter((d) => d && typeof d.close === "number")
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [data]);

  const rangeDays = useMemo(() => {
    if (sorted.length < 2) return 0;
    const a = new Date(sorted[0].date).getTime();
    const b = new Date(sorted[sorted.length - 1].date).getTime();
    return Math.max(1, Math.round((b - a) / 86_400_000));
  }, [sorted]);

  if (sorted.length === 0) {
    return (
      <div
        className={cn(
          "flex h-56 flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/10 bg-white/[0.02] text-center",
          className,
        )}
      >
        <TrendingUp className="size-6 text-muted-foreground/60" />
        <p className="text-sm text-muted-foreground">No price history available</p>
        <p className="text-xs text-muted-foreground/70">
          The agent couldn&apos;t fetch historical prices for this entity.
        </p>
      </div>
    );
  }

  return (
    <div className={cn("h-56 w-full sm:h-64", className)}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={sorted} margin={{ top: 8, right: 8, bottom: 0, left: -8 }}>
          <defs>
            <linearGradient id={`${id}-area`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgb(168 85 247)" stopOpacity={0.45} />
              <stop offset="55%" stopColor="rgb(217 70 239)" stopOpacity={0.18} />
              <stop offset="100%" stopColor="rgb(34 211 238)" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id={`${id}-line`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="rgb(168 85 247)" />
              <stop offset="50%" stopColor="rgb(217 70 239)" />
              <stop offset="100%" stopColor="rgb(34 211 238)" />
            </linearGradient>
          </defs>
          <CartesianGrid
            stroke="rgba(255,255,255,0.05)"
            strokeDasharray="3 6"
            vertical={false}
          />
          <XAxis
            dataKey="date"
            tickFormatter={(v) => formatDateTick(v, rangeDays)}
            tick={{ fill: "rgba(200,200,220,0.55)", fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            minTickGap={32}
          />
          <YAxis
            domain={["auto", "auto"]}
            tick={{ fill: "rgba(200,200,220,0.55)", fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            width={56}
            tickFormatter={(v: number) =>
              v.toLocaleString(undefined, { maximumFractionDigits: 0 })
            }
          />
          <Tooltip
            content={<ChartTooltip currency={currency} />}
            cursor={{ stroke: "rgba(168,85,247,0.4)", strokeWidth: 1 }}
          />
          <Area
            type="monotone"
            dataKey="close"
            stroke={`url(#${id}-line)`}
            strokeWidth={2.2}
            fill={`url(#${id}-area)`}
            isAnimationActive
            animationDuration={900}
            activeDot={{
              r: 4,
              fill: "rgb(217 70 239)",
              stroke: "rgba(255,255,255,0.6)",
              strokeWidth: 1,
            }}
            style={{ filter: "drop-shadow(0 0 6px rgba(168,85,247,0.55))" }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
