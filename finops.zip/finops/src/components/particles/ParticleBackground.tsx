"use client";

import { useMemo, useSyncExternalStore } from "react";
import Particles, { ParticlesProvider } from "@tsparticles/react";
import {
  type ISourceOptions,
  MoveDirection,
  OutMode,
} from "@tsparticles/engine";
import { loadSlim } from "@tsparticles/slim";

const reducedMotionQuery = "(prefers-reduced-motion: reduce)";

function subscribeReducedMotion(callback: () => void) {
  if (typeof window === "undefined") return () => {};
  const mq = window.matchMedia(reducedMotionQuery);
  mq.addEventListener("change", callback);
  return () => mq.removeEventListener("change", callback);
}

function getReducedMotionSnapshot() {
  if (typeof window === "undefined") return false;
  return window.matchMedia(reducedMotionQuery).matches;
}

function getReducedMotionServerSnapshot() {
  return false;
}

export function ParticleBackground() {
  const reducedMotion = useSyncExternalStore(
    subscribeReducedMotion,
    getReducedMotionSnapshot,
    getReducedMotionServerSnapshot,
  );

  const options: ISourceOptions = useMemo(
    () => ({
      fullScreen: { enable: false },
      background: { color: "transparent" },
      fpsLimit: 60,
      detectRetina: true,
      pauseOnBlur: true,
      pauseOnOutsideViewport: false,
      particles: {
        number: {
          value: 70,
          density: { enable: true, width: 1920, height: 1080 },
        },
        color: { value: ["#a855f7", "#22d3ee", "#ec4899", "#67e8f9"] },
        opacity: {
          value: { min: 0.2, max: 0.7 },
          animation: { enable: true, speed: 0.6, sync: false },
        },
        size: {
          value: { min: 1, max: 2.6 },
        },
        move: {
          enable: !reducedMotion,
          speed: 0.7,
          direction: MoveDirection.none,
          random: true,
          straight: false,
          outModes: { default: OutMode.out },
        },
        links: {
          enable: true,
          distance: 150,
          color: "#7c3aed",
          opacity: 0.18,
          width: 1,
        },
      },
      interactivity: {
        events: {
          onHover: {
            enable: !reducedMotion,
            mode: "grab",
            parallax: { enable: true, force: 30, smooth: 18 },
          },
          onClick: { enable: false },
          resize: { enable: true },
        },
        modes: {
          grab: { distance: 170, links: { opacity: 0.4 } },
        },
      },
    }),
    [reducedMotion],
  );

  return (
    <div
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      aria-hidden
    >
      <ParticlesProvider init={loadSlim}>
        <Particles
          id="premium-particles"
          options={options}
          className="h-full w-full"
        />
      </ParticlesProvider>

      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 120% at 50% 0%, transparent 55%, rgba(8,6,16,0.65) 100%)",
        }}
      />
    </div>
  );
}

export default ParticleBackground;
