"use client";

import { useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import {
  Building2,
  Download,
  Loader2,
  FileText,
  LayoutDashboard,
  Newspaper,
  ShieldAlert,
  ListChecks,
  BarChart3,
  Quote,
  Lightbulb,
} from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { RecommendationBanner } from "@/components/recommendation-banner";
import { ConfidenceGauge } from "@/components/confidence-gauge";
import { ScoreRing } from "@/components/score-ring";
import { FinancialChart } from "@/components/financial-chart";
import {
  HighlightList,
  type HighlightVariant,
} from "@/components/highlight-list";
import { SourceList } from "@/components/source-list";
import { downloadPdf } from "@/lib/client-pdf";
import type { InvestmentReport } from "@/lib/agent/types";
import { cn } from "@/lib/utils";

interface ReportDisplayProps {
  report: InvestmentReport;
  className?: string;
}

function SectionHeader({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: React.ElementType;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-2">
        <Icon className="size-4 text-violet-300" />
        <h3 className="text-sm font-semibold uppercase tracking-[0.14em] text-foreground/90">
          {title}
        </h3>
      </div>
      {subtitle ? (
        <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>
      ) : null}
      <div className="mt-2 h-px w-16 bg-gradient-to-r from-violet-400/70 to-cyan-400/40" />
    </div>
  );
}

function GlassCard({
  children,
  className,
  strong = false,
}: {
  children: ReactNode;
  className?: string;
  strong?: boolean;
}) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={cn(
        strong ? "glass-strong" : "glass",
        "min-w-0 overflow-hidden rounded-xl p-4 sm:p-6",
        className,
      )}
    >
      {children}
    </motion.div>
  );
}

function MetricRow({ label, value }: { label: string; value?: ReactNode }) {
  if (value == null || value === "") return null;
  return (
    <div className="flex items-start justify-between gap-3 py-1.5">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="break-words text-right text-xs font-medium text-foreground/90">
        {value}
      </span>
    </div>
  );
}

function fmtMoney(n?: number) {
  if (n == null || Number.isNaN(n)) return undefined;
  if (Math.abs(n) >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (Math.abs(n) >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (Math.abs(n) >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (Math.abs(n) >= 1e3) return `$${(n / 1e3).toFixed(2)}K`;
  return `$${n.toFixed(2)}`;
}

function fmtPct(n?: number) {
  if (n == null || Number.isNaN(n)) return undefined;
  return `${n.toFixed(1)}%`;
}

function fmtNum(n?: number, digits = 2) {
  if (n == null || Number.isNaN(n)) return undefined;
  return n.toLocaleString(undefined, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

function sentimentVariant(s?: string) {
  switch (s) {
    case "positive":
      return "border-emerald-400/30 bg-emerald-400/10 text-emerald-300";
    case "negative":
      return "border-rose-400/30 bg-rose-400/10 text-rose-300";
    case "mixed":
      return "border-amber-400/30 bg-amber-400/10 text-amber-300";
    default:
      return "border-cyan-400/30 bg-cyan-400/10 text-cyan-300";
  }
}

function dataQualityVariant(q?: string) {
  switch (q) {
    case "full":
      return "border-emerald-400/30 bg-emerald-400/10 text-emerald-300";
    case "partial":
      return "border-amber-400/30 bg-amber-400/10 text-amber-300";
    default:
      return "border-rose-400/30 bg-rose-400/10 text-rose-300";
  }
}

function DownloadButton({ report }: { report: InvestmentReport }) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const onClick = async () => {
    setLoading(true);
    try {
      const name = await downloadPdf(report);
      toast({
        title: "PDF ready",
        description: `Saved as ${name}`,
      });
    } catch (err) {
      toast({
        title: "PDF generation failed",
        description:
          err instanceof Error ? err.message : "Unknown error.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      onClick={onClick}
      disabled={loading}
      variant="outline"
      className="gap-2 border-white/15 bg-white/5 text-foreground hover:bg-white/10"
    >
      {loading ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <Download className="size-4" />
      )}
      <span className="hidden sm:inline">Download PDF</span>
      <span className="sm:hidden">PDF</span>
    </Button>
  );
}

export function ReportDisplay({ report, className }: ReportDisplayProps) {
  const { profile, financials, news, web, decision } = report;

  return (
    <div className={cn("flex min-w-0 flex-col gap-6", className)}>
      <div className="flex flex-col gap-6">
        <RecommendationBanner report={report} />

        <div className="grid min-w-0 gap-4 lg:grid-cols-[1fr_auto]">
          <GlassCard strong className="flex min-w-0 flex-col items-center justify-around gap-4 overflow-hidden sm:flex-row sm:items-center sm:gap-8">
            <ConfidenceGauge value={decision.confidence} size={140} />
            <Separator
              orientation="vertical"
              className="hidden h-32 bg-white/10 sm:block"
            />
            <ScoreRing value={decision.investmentScore} size={140} />
          </GlassCard>

          <GlassCard className="flex min-w-0 flex-row items-center justify-between gap-4 overflow-hidden lg:flex-col lg:items-start lg:justify-center">
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Export
              </div>
              <div className="mt-1 break-words text-sm font-medium text-foreground/90">
                Take this report offline
              </div>
            </div>
            <DownloadButton report={report} />
          </GlassCard>
        </div>
      </div>

      <Tabs defaultValue="overview" className="min-w-0 w-full overflow-hidden">
        <div className="overflow-x-auto">
          <TabsList className="mb-4 grid w-full min-w-max grid-cols-5 gap-1 bg-white/5">
            <TabsTrigger value="overview" className="gap-1.5">
              <LayoutDashboard className="size-3.5" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="financials" className="gap-1.5">
              <BarChart3 className="size-3.5" />
              <span className="hidden sm:inline">Financials</span>
            </TabsTrigger>
            <TabsTrigger value="news-web" className="gap-1.5">
              <Newspaper className="size-3.5" />
              <span className="hidden sm:inline">News &amp; Web</span>
            </TabsTrigger>
            <TabsTrigger value="risks" className="gap-1.5">
              <ShieldAlert className="size-3.5" />
              <span className="hidden sm:inline">Risks &amp; Signals</span>
            </TabsTrigger>
            <TabsTrigger value="sources" className="gap-1.5">
              <ListChecks className="size-3.5" />
              <span className="hidden sm:inline">Sources</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="overview" className="min-w-0 flex flex-col gap-6 overflow-hidden">
          <div className="grid min-w-0 gap-4 lg:grid-cols-[1fr_1.2fr]">
            <GlassCard className="min-w-0 overflow-hidden">
              <SectionHeader
                icon={Building2}
                title="Company Profile"
                subtitle="Resolved entity from FMP"
              />
              {profile ? (
                <div className="space-y-1">
                  <div className="mb-3 flex flex-wrap items-center gap-2">
                    <span className="break-words text-lg font-semibold text-foreground">
                      {profile.companyName}
                    </span>
                    {profile.symbol ? (
                      <Badge variant="outline" className="border-violet-400/30 bg-violet-400/10 text-violet-300">
                        {profile.symbol}
                      </Badge>
                    ) : null}
                    {profile.exchange ? (
                      <Badge variant="outline" className="border-white/10 bg-white/5 text-muted-foreground">
                        {profile.exchange}
                      </Badge>
                    ) : null}
                  </div>
                  <MetricRow label="Sector" value={profile.sector} />
                  <MetricRow label="Industry" value={profile.industry} />
                  <MetricRow label="CEO" value={profile.ceo} />
                  <MetricRow label="Country" value={profile.country} />
                  <MetricRow label="Employees" value={profile.employees} />
                  <MetricRow label="IPO Date" value={profile.ipoDate} />
                  <MetricRow label="Market Cap" value={fmtMoney(profile.marketCap)} />
                  <MetricRow label="Price" value={profile.price != null ? `${profile.currency ?? "$"}${fmtNum(profile.price)}` : undefined} />
                  <MetricRow label="Beta" value={fmtNum(profile.beta)} />
                  {profile.website ? (
                    <div className="pt-2">
                      <a
                        href={profile.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 break-all text-xs text-cyan-300/90 underline-offset-2 hover:underline"
                      >
                        {profile.website.replace(/^https?:\/\//, "").replace(/\/$/, "")}
                      </a>
                    </div>
                  ) : null}
                  {profile.description ? (
                    <p className="mt-3 line-clamp-6 break-words text-xs leading-relaxed text-muted-foreground">
                      {profile.description}
                    </p>
                  ) : null}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No profile data was resolved for this entity.
                </p>
              )}
            </GlassCard>

            <GlassCard className="min-w-0 overflow-hidden">
              <SectionHeader
                icon={BarChart3}
                title="Price History"
                subtitle={profile?.currency ? `Prices in ${profile.currency}` : "Recent close prices"}
              />
              <FinancialChart
                data={report.historicalPrices}
                currency={profile?.currency}
              />
            </GlassCard>
          </div>

          <GlassCard className="min-w-0 overflow-hidden">
            <SectionHeader
              icon={Quote}
              title="Executive Summary"
              subtitle="The agent's investment thesis & key reasoning"
            />
            {decision.thesis ? (
              <p className="mb-4 break-words text-sm leading-relaxed text-foreground/90">
                {decision.thesis}
              </p>
            ) : null}
            {decision.reasoning?.length ? (
              <ul className="flex flex-col gap-2">
                {decision.reasoning.map((r, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: Math.min(i * 0.05, 0.4) }}
                    className="flex min-w-0 items-start gap-2 text-sm text-muted-foreground"
                  >
                    <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-gradient-to-r from-violet-400 to-cyan-400" />
                    <span className="break-words text-foreground/85">{r}</span>
                  </motion.li>
                ))}
              </ul>
            ) : null}
          </GlassCard>

          {report.assumptions?.length ? (
            <GlassCard className="min-w-0 overflow-hidden">
              <SectionHeader
                icon={Lightbulb}
                title="Assumptions & Notes"
                subtitle="Caveats applied while building this report"
              />
              <ul className="flex flex-col gap-1.5">
                {report.assumptions.map((a, i) => (
                  <li
                    key={i}
                    className="flex min-w-0 items-start gap-2 text-xs text-muted-foreground"
                  >
                    <span className="mt-1 size-1 shrink-0 rounded-full bg-amber-300/80" />
                    <span className="break-words">{a.note}</span>
                  </li>
                ))}
              </ul>
            </GlassCard>
          ) : null}
        </TabsContent>

        <TabsContent value="financials" className="min-w-0 flex flex-col gap-6 overflow-hidden">
          <GlassCard className="min-w-0 overflow-hidden">
            <div className="mb-4 flex items-center justify-between">
              <SectionHeader
                icon={BarChart3}
                title="Financial Highlights"
                subtitle="Key metrics analysed by the agent"
              />
              {financials?.dataQuality ? (
                <Badge
                  variant="outline"
                  className={cn("uppercase", dataQualityVariant(financials.dataQuality))}
                >
                  {financials.dataQuality} data
                </Badge>
              ) : null}
            </div>
            <HighlightList
              items={
                financials?.highlights?.map((h) => ({
                  title: h.label,
                  value: h.value,
                  note: h.note,
                  tone: h.tone,
                })) ?? []
              }
              variant="financial"
              emptyMessage="No financial highlights were extracted for this entity."
            />
          </GlassCard>

          {financials?.summary ? (
            <GlassCard className="min-w-0 overflow-hidden">
              <SectionHeader
                icon={FileText}
                title="Financial Summary"
                subtitle="The agent's narrative on the financials"
              />
              <p className="break-words text-sm leading-relaxed text-muted-foreground">
                {financials.summary}
              </p>
            </GlassCard>
          ) : null}
        </TabsContent>

        <TabsContent value="news-web" className="min-w-0 flex flex-col gap-6 overflow-hidden">
          <div className="grid min-w-0 gap-4 lg:grid-cols-2">
            <GlassCard className="min-w-0 overflow-hidden">
              <div className="mb-4 flex items-center justify-between">
                <SectionHeader
                  icon={Newspaper}
                  title="News"
                  subtitle="Recent market-moving headlines"
                />
                {news?.overallSentiment ? (
                  <Badge
                    variant="outline"
                    className={cn("uppercase", sentimentVariant(news.overallSentiment))}
                  >
                    {news.overallSentiment}
                  </Badge>
                ) : null}
              </div>
              {news?.summary ? (
                <p className="mb-3 break-words text-sm leading-relaxed text-muted-foreground">
                  {news.summary}
                </p>
              ) : null}
              <HighlightList
                items={
                  news?.highlights?.map((h) => ({
                    title: h.title,
                    detail: h.source,
                    date: h.date,
                    sentiment: h.sentiment,
                  })) ?? []
                }
                variant="news"
                emptyMessage="No recent news was found for this entity."
              />
            </GlassCard>

            <GlassCard className="min-w-0 overflow-hidden">
              <SectionHeader
                icon={FileText}
                title="Web Research"
                subtitle="Tavily web search context"
              />
              {web?.themes?.length ? (
                <div className="mb-3 flex flex-wrap gap-1.5">
                  {web.themes.map((th, i) => (
                    <Badge
                      key={i}
                      variant="outline"
                      className="border-violet-400/30 bg-violet-400/10 text-violet-200"
                    >
                      #{th}
                    </Badge>
                  ))}
                </div>
              ) : null}
              {web?.summary ? (
                <p className="mb-3 break-words text-sm leading-relaxed text-muted-foreground">
                  {web.summary}
                </p>
              ) : null}
              <HighlightList
                items={
                  web?.highlights?.map((h) => ({
                    title: h.title,
                    snippet: h.snippet,
                    url: h.url,
                  })) ?? []
                }
                variant="web"
                emptyMessage="No web results were returned for this entity."
              />
            </GlassCard>
          </div>
        </TabsContent>

        <TabsContent value="risks" className="min-w-0 flex flex-col gap-6 overflow-hidden">
          <div className="grid min-w-0 gap-4 lg:grid-cols-2">
            <SubSection
              title="Strengths"
              icon={LayoutDashboard}
              variant="strength"
              items={report.strengths?.map((s) => ({ title: s.title, detail: s.detail })) ?? []}
              emptyMessage="No notable strengths were identified."
            />
            <SubSection
              title="Weaknesses"
              icon={LayoutDashboard}
              variant="weakness"
              items={report.weaknesses?.map((s) => ({ title: s.title, detail: s.detail })) ?? []}
              emptyMessage="No notable weaknesses were identified."
            />
            <SubSection
              title="Opportunities"
              icon={Lightbulb}
              variant="opportunity"
              items={report.opportunities?.map((s) => ({ title: s.title, detail: s.detail })) ?? []}
              emptyMessage="No opportunities were flagged."
            />
            <SubSection
              title="Weak Signals"
              icon={LayoutDashboard}
              variant="weaksignal"
              items={report.weakSignals?.map((s) => ({ title: s.title, detail: s.detail })) ?? []}
              emptyMessage="No weak signals were detected."
            />
          </div>

          <GlassCard strong className="min-w-0 overflow-hidden">
            <SectionHeader
              icon={ShieldAlert}
              title="Risk Assessment"
              subtitle="Severity-flagged risks identified during research"
            />
            <HighlightList
              items={
                report.risks?.map((r) => ({
                  title: r.title,
                  detail: r.detail,
                  severity: r.severity,
                })) ?? []
              }
              variant="risk"
              emptyMessage="No specific risks were flagged for this entity."
            />
          </GlassCard>

          {decision.reasoning?.length ? (
            <GlassCard strong className="min-w-0 overflow-hidden">
              <SectionHeader
                icon={Quote}
                title="Investment Thesis"
                subtitle="The full chain of reasoning behind the verdict"
              />
              <ol className="flex flex-col gap-2.5">
                {decision.reasoning.map((r, i) => (
                  <li key={i} className="flex min-w-0 items-start gap-3 text-sm">
                    <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-md border border-violet-400/30 bg-violet-400/10 font-mono text-[10px] font-semibold text-violet-200">
                      {i + 1}
                    </span>
                    <span className="break-words text-foreground/85">{r}</span>
                  </li>
                ))}
              </ol>
            </GlassCard>
          ) : null}
        </TabsContent>

        <TabsContent value="sources" className="min-w-0 flex flex-col gap-6 overflow-hidden">
          <GlassCard className="min-w-0 overflow-hidden">
            <SectionHeader
              icon={ListChecks}
              title="Sources & Provenance"
              subtitle="Every data point in this report traces back to one of these sources"
            />
            <SourceList sources={report.sources ?? []} />
          </GlassCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function SubSection({
  title,
  icon,
  variant,
  items,
  emptyMessage,
}: {
  title: string;
  icon: React.ElementType;
  variant: HighlightVariant;
  items: { title: string; detail?: string; severity?: "low" | "medium" | "high"; tone?: "positive" | "negative" | "neutral" }[];
  emptyMessage: string;
}) {
  return (
    <GlassCard className="min-w-0 overflow-hidden">
      <SectionHeader icon={icon} title={title} />
      <HighlightList items={items} variant={variant} emptyMessage={emptyMessage} />
    </GlassCard>
  );
}
