"use client";

import { Sparkles, Globe, Database, Newspaper } from "lucide-react";
import { cn } from "@/lib/utils";

const LINKS = [
  { label: "Gemini", href: "https://ai.google.dev/", icon: Sparkles },
  { label: "Tavily", href: "https://tavily.com/", icon: Globe },
  { label: "FMP", href: "https://financialmodelingprep.com/", icon: Database },
  { label: "NewsAPI", href: "https://newsapi.org/", icon: Newspaper },
] as const;

export function SiteFooter({ className }: { className?: string }) {
  return (
    <footer
      className={cn(
        "mt-auto w-full border-t border-white/5 bg-background/85 backdrop-blur-xl",
        className,
      )}
    >
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-3 px-4 py-6 text-center sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-muted-foreground">
          <span className="font-medium">
            <span className="gradient-text">FinOps Agent</span>
            <span className="ml-1.5 text-muted-foreground/80">
              · AI Investment Research
            </span>
          </span>
          <span className="hidden h-3 w-px bg-white/10 sm:block" />
          <span className="text-muted-foreground/70">
            Not financial advice. For research &amp; educational purposes only.
          </span>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3">
          {LINKS.map((l) => {
            const Icon = l.icon;
            return (
              <a
                key={l.label}
                href={l.href}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[11px] text-muted-foreground/80 transition-colors hover:text-foreground"
              >
                <Icon className="size-3" />
                {l.label}
              </a>
            );
          })}
        </div>
      </div>
    </footer>
  );
}
