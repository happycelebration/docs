import { jsPDF } from "jspdf";
import autoTable, { type CellHookData, type PageHook, type RowInput, type Styles, type UserOptions } from "jspdf-autotable";
import type {
  FinancialHighlight,
  HistoricalPricePoint,
  InvestmentReport,
  Recommendation,
  RiskItem,
  SourceRef,
} from "@/lib/agent/types";

type RGB = readonly [number, number, number];

const COLORS = {
  bg: [255, 255, 255] as RGB,
  text: [26, 26, 46] as RGB,
  textMuted: [75, 85, 99] as RGB,
  textDim: [107, 114, 128] as RGB,
  violet: [124, 58, 237] as RGB,
  cyan: [8, 145, 178] as RGB,
  emerald: [5, 150, 105] as RGB,
  rose: [220, 38, 38] as RGB,
  amber: [217, 119, 6] as RGB,
  border: [229, 231, 235] as RGB,
  borderStrong: [209, 213, 219] as RGB,
  panel: [249, 250, 251] as RGB,
  violetTint: [245, 243, 255] as RGB,
  cyanTint: [236, 254, 255] as RGB,
  emeraldTint: [236, 253, 229] as RGB,
  roseTint: [254, 242, 242] as RGB,
  amberTint: [255, 251, 235] as RGB,
  grayTint: [243, 244, 246] as RGB,
  white: [255, 255, 255] as RGB,
} as const;

const PAGE = { w: 612, h: 792 };
const MARGIN = { top: 78, bottom: 64, left: 54, right: 54 };
const CONTENT_W = PAGE.w - MARGIN.left - MARGIN.right;
const TABLE_MARGIN = { left: MARGIN.left, right: MARGIN.right, top: MARGIN.top, bottom: MARGIN.bottom };

interface Ctx {
  y: number;
}

function setFill(doc: jsPDF, c: RGB): void {
  doc.setFillColor(c[0], c[1], c[2]);
}
function setStroke(doc: jsPDF, c: RGB): void {
  doc.setDrawColor(c[0], c[1], c[2]);
}
function setText(doc: jsPDF, c: RGB): void {
  doc.setTextColor(c[0], c[1], c[2]);
}
function rgbArr(c: RGB): [number, number, number] {
  return [c[0], c[1], c[2]];
}

function recColor(rec: Recommendation | undefined): RGB {
  switch (rec) {
    case "INVEST":
      return COLORS.emerald;
    case "PASS":
      return COLORS.rose;
    case "HOLD":
      return COLORS.amber;
    default:
      return COLORS.amber;
  }
}

function sentimentColor(s: string | undefined): RGB {
  switch (s) {
    case "positive":
      return COLORS.emerald;
    case "negative":
      return COLORS.rose;
    case "mixed":
      return COLORS.amber;
    case "neutral":
      return COLORS.textDim;
    default:
      return COLORS.textDim;
  }
}

function severityColor(s: string | undefined): RGB {
  switch (s) {
    case "high":
      return COLORS.rose;
    case "medium":
      return COLORS.amber;
    case "low":
      return COLORS.emerald;
    default:
      return COLORS.textDim;
  }
}

function toneColor(t: string | undefined): RGB {
  switch (t) {
    case "positive":
      return COLORS.emerald;
    case "negative":
      return COLORS.rose;
    case "neutral":
      return COLORS.textDim;
    default:
      return COLORS.textDim;
  }
}

function toneTint(t: string | undefined): RGB {
  switch (t) {
    case "positive":
      return COLORS.emeraldTint;
    case "negative":
      return COLORS.roseTint;
    case "neutral":
      return COLORS.grayTint;
    default:
      return COLORS.grayTint;
  }
}

function formatMoney(n: number | undefined | null): string {
  if (n == null || !isFinite(n)) return "—";
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1e12) return `${sign}$${(abs / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `${sign}$${(abs / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${sign}$${(abs / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `${sign}$${(abs / 1e3).toFixed(2)}K`;
  return `${sign}$${abs.toFixed(2)}`;
}

function formatDate(iso: string | undefined | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function formatShortDate(iso: string | undefined | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

function truncateUrl(url: string | undefined, max = 72): string {
  if (!url) return "—";
  return url.length > max ? url.slice(0, max - 1) + "…" : url;
}

function str(v: unknown): string {
  if (v == null || v === "") return "—";
  return String(v);
}

function newPage(doc: jsPDF, ctx: Ctx): void {
  doc.addPage();
  ctx.y = MARGIN.top;
}

function ensureSpace(doc: jsPDF, ctx: Ctx, needed: number): number {
  if (ctx.y + needed > PAGE.h - MARGIN.bottom) {
    newPage(doc, ctx);
  }
  return ctx.y;
}

function gradientBar(doc: jsPDF, x: number, y: number, w: number, h = 2): void {
  const segs = 18;
  const segW = w / segs;
  for (let i = 0; i < segs; i++) {
    const t = i / (segs - 1);
    const r = Math.round(COLORS.violet[0] + (COLORS.cyan[0] - COLORS.violet[0]) * t);
    const g = Math.round(COLORS.violet[1] + (COLORS.cyan[1] - COLORS.violet[1]) * t);
    const b = Math.round(COLORS.violet[2] + (COLORS.cyan[2] - COLORS.violet[2]) * t);
    doc.setFillColor(r, g, b);
    doc.rect(x + i * segW, y, segW + 0.6, h, "F");
  }
}

function addSectionHeader(doc: jsPDF, ctx: Ctx, text: string, accent: RGB, tint: RGB): void {
  ensureSpace(doc, ctx, 60);
  const y = ctx.y;
  const h = 30;
  setFill(doc, tint);
  doc.rect(MARGIN.left, y, CONTENT_W, h, "F");
  setFill(doc, accent);
  doc.rect(MARGIN.left, y, 4, h, "F");
  setText(doc, accent);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.text("FINOPS AGENT", MARGIN.left + 16, y + 10);
  setText(doc, COLORS.text);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text(text, MARGIN.left + 16, y + 24);
  ctx.y = y + h + 12;
}

function addLabel(doc: jsPDF, ctx: Ctx, text: string, color: RGB = COLORS.violet): void {
  ensureSpace(doc, ctx, 20);
  setText(doc, color);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text(text.toUpperCase(), MARGIN.left, ctx.y);
  ctx.y += 14;
}

function addParagraph(doc: jsPDF, ctx: Ctx, text: string | undefined, maxWidth = CONTENT_W, size = 10): void {
  if (!text || !text.trim()) return;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(size);
  setText(doc, COLORS.text);
  const lines = doc.splitTextToSize(text, maxWidth) as string[];
  const lineH = size * 1.45;
  for (const line of lines) {
    ensureSpace(doc, ctx, lineH);
    doc.text(line, MARGIN.left, ctx.y);
    ctx.y += lineH;
  }
  ctx.y += 6;
}

function addBullets(doc: jsPDF, ctx: Ctx, items: string[] | undefined, maxWidth = CONTENT_W, size = 10): void {
  if (!items || items.length === 0) return;
  const indent = 16;
  const lineH = size * 1.45;
  for (const item of items) {
    if (!item || !item.trim()) continue;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(item, maxWidth - indent) as string[];
    for (let i = 0; i < lines.length; i++) {
      ensureSpace(doc, ctx, lineH);
      if (i === 0) {
        setFill(doc, COLORS.violet);
        doc.circle(MARGIN.left + 3, ctx.y - 3, 1.7, "F");
      }
      setText(doc, COLORS.text);
      doc.text(lines[i], MARGIN.left + indent, ctx.y);
      ctx.y += lineH;
    }
    ctx.y += 4;
  }
}

function addNumbered(doc: jsPDF, ctx: Ctx, items: string[] | undefined, maxWidth = CONTENT_W, size = 10): void {
  if (!items || items.length === 0) return;
  const indent = 22;
  const lineH = size * 1.45;
  items.forEach((item, idx) => {
    if (!item || !item.trim()) return;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(item, maxWidth - indent) as string[];
    for (let i = 0; i < lines.length; i++) {
      ensureSpace(doc, ctx, lineH);
      if (i === 0) {
        setFill(doc, COLORS.violet);
        doc.roundedRect(MARGIN.left, ctx.y - 11, 14, 14, 3, 3, "F");
        setText(doc, COLORS.white);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8.5);
        doc.text(String(idx + 1), MARGIN.left + 7, ctx.y - 1, { align: "center" });
        doc.setFont("helvetica", "normal");
        doc.setFontSize(size);
      }
      setText(doc, COLORS.text);
      doc.text(lines[i], MARGIN.left + indent, ctx.y);
      ctx.y += lineH;
    }
    ctx.y += 4;
  });
}

function addBadge(doc: jsPDF, x: number, y: number, text: string, bg: RGB, opts?: { size?: number; padX?: number; h?: number; fg?: RGB }): number {
  const size = opts?.size ?? 11;
  const padX = opts?.padX ?? 14;
  const h = opts?.h ?? 22;
  const fg = opts?.fg ?? COLORS.white;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(size);
  const tw = doc.getTextWidth(text);
  const w = tw + padX * 2;
  setFill(doc, bg);
  doc.roundedRect(x, y, w, h, 6, 6, "F");
  setText(doc, fg);
  doc.text(text, x + w / 2, y + h / 2 + size / 3, { align: "center" });
  return w;
}

function addNoData(doc: jsPDF, ctx: Ctx): void {
  ensureSpace(doc, ctx, 18);
  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(9.5);
  doc.text("No data available.", MARGIN.left, ctx.y);
  ctx.y += 18;
}

function drawLineChart(doc: jsPDF, prices: HistoricalPricePoint[], x: number, y: number, w: number, h: number): void {
  setFill(doc, COLORS.white);
  setStroke(doc, COLORS.border);
  doc.setLineWidth(0.7);
  doc.roundedRect(x, y, w, h, 8, 8, "FD");

  const padL = 52;
  const padR = 18;
  const padT = 22;
  const padB = 28;
  const plotX = x + padL;
  const plotY = y + padT;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.text("PRICE HISTORY", x + 12, y + 14);

  if (!prices || prices.length < 2) {
    setText(doc, COLORS.textDim);
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.text("Insufficient price history to render chart.", x + w / 2, y + h / 2, { align: "center" });
    return;
  }

  let pts = prices;
  if (prices.length > 60) {
    pts = [];
    const step = (prices.length - 1) / 59;
    for (let i = 0; i < 60; i++) pts.push(prices[Math.round(i * step)]);
    if (pts[pts.length - 1] !== prices[prices.length - 1]) pts.push(prices[prices.length - 1]);
  }

  const closes = pts.map((p) => p.close).filter((n) => typeof n === "number" && isFinite(n));
  if (closes.length < 2) {
    setText(doc, COLORS.textDim);
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.text("Price data incomplete.", x + w / 2, y + h / 2, { align: "center" });
    return;
  }
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const range = max - min || 1;
  const pad = range * 0.08;
  const lo = min - pad;
  const hi = max + pad;
  const rng = hi - lo || 1;

  setStroke(doc, COLORS.border);
  doc.setLineWidth(0.4);
  doc.setLineDashPattern([2, 3], 0);
  for (let i = 0; i <= 4; i++) {
    const gy = plotY + (plotH / 4) * i;
    doc.line(plotX, gy, plotX + plotW, gy);
  }
  doc.setLineDashPattern([], 0);

  setStroke(doc, COLORS.borderStrong);
  doc.setLineWidth(0.5);
  doc.line(plotX, plotY + plotH, plotX + plotW, plotY + plotH);
  doc.line(plotX, plotY, plotX, plotY + plotH);

  setText(doc, COLORS.textMuted);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(max.toFixed(2), plotX - 6, plotY + 3, { align: "right" });
  doc.text((((max + min) / 2)).toFixed(2), plotX - 6, plotY + plotH / 2 + 3, { align: "right" });
  doc.text(min.toFixed(2), plotX - 6, plotY + plotH + 3, { align: "right" });

  setText(doc, COLORS.textDim);
  doc.setFontSize(7.5);
  const first = pts[0]?.date;
  const last = pts[pts.length - 1]?.date;
  if (first) doc.text(formatShortDate(first), plotX, plotY + plotH + 16);
  if (last) doc.text(formatShortDate(last), plotX + plotW, plotY + plotH + 16, { align: "right" });

  setStroke(doc, COLORS.violet);
  doc.setLineWidth(1.8);
  const n = pts.length;
  const xy: Array<[number, number]> = pts.map((p, i) => {
    const px = plotX + (plotW * i) / (n - 1);
    const py = plotY + plotH - ((p.close - lo) / rng) * plotH;
    return [px, py];
  });
  for (let i = 1; i < xy.length; i++) {
    doc.line(xy[i - 1][0], xy[i - 1][1], xy[i][0], xy[i][1]);
  }

  const lastPt = xy[xy.length - 1];
  setFill(doc, COLORS.white);
  doc.circle(lastPt[0], lastPt[1], 4, "F");
  setFill(doc, COLORS.cyan);
  doc.circle(lastPt[0], lastPt[1], 3, "F");

  setText(doc, COLORS.cyan);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text(pts[pts.length - 1].close.toFixed(2), lastPt[0] + 8, lastPt[1] + 3);
}

const BASE_STYLES: Partial<Styles> = {
  font: "helvetica",
  fontSize: 9,
  cellPadding: { top: 6, bottom: 6, left: 9, right: 9 },
  fillColor: COLORS.white as [number, number, number],
  textColor: COLORS.text as [number, number, number],
  lineColor: COLORS.border as [number, number, number],
  lineWidth: 0.4,
  valign: "middle",
  overflow: "linebreak",
};

const HEAD_STYLES: Partial<Styles> = {
  fillColor: COLORS.violet as [number, number, number],
  textColor: COLORS.white as [number, number, number],
  fontStyle: "bold",
  fontSize: 9.5,
  cellPadding: { top: 7, bottom: 7, left: 9, right: 9 },
};

const ALT_STYLES: Partial<Styles> = {
  fillColor: COLORS.panel as [number, number, number],
};

function runTable(doc: jsPDF, ctx: Ctx, opts: UserOptions): void {
  const startPage = doc.getNumberOfPages();
  let endY = ctx.y;

  const userWillDrawPage = opts.willDrawPage as PageHook | undefined;
  const userDidDrawPage = opts.didDrawPage as PageHook | undefined;

  autoTable(doc, {
    ...opts,
    startY: ctx.y,
    margin: opts.margin ?? TABLE_MARGIN,
    theme: opts.theme ?? "grid",
    styles: { ...BASE_STYLES, ...(opts.styles ?? {}) },
    headStyles: { ...HEAD_STYLES, ...(opts.headStyles ?? {}) },
    alternateRowStyles: { ...ALT_STYLES, ...(opts.alternateRowStyles ?? {}) },
    willDrawPage: (data) => {
      if (data.pageNumber > startPage) {
        setFill(doc, COLORS.white);
        doc.rect(0, 0, PAGE.w, PAGE.h, "F");
      }
      userWillDrawPage?.(data);
    },
    didDrawPage: (data) => {
      if (data.cursor) endY = data.cursor.y;
      userDidDrawPage?.(data);
    },
  });

  ctx.y = endY + 16;
}

function addKeyValueTable(doc: jsPDF, ctx: Ctx, rows: Array<[string, string]>): void {
  const body: RowInput[] = rows.map(([k, v]) => [k, v]);
  runTable(doc, ctx, {
    head: [["Field", "Value"]],
    body,
    columnStyles: {
      0: { cellWidth: 180, textColor: rgbArr(COLORS.textMuted), fontStyle: "bold" },
      1: { cellWidth: "auto", textColor: rgbArr(COLORS.text) },
    },
  });
}

function addFinancialHighlightsTable(doc: jsPDF, ctx: Ctx, highlights: FinancialHighlight[]): void {
  const items = highlights;
  const body: RowInput[] = highlights.map((h) => [
    h.label || "—",
    h.value || "—",
    (h.tone || "neutral").toUpperCase(),
    h.note || "",
  ]);
  const didParseCell = (data: CellHookData) => {
    if (data.section === "body") {
      const h = items[data.row.index];
      if (data.column.index === 1) {
        const tone = h?.tone;
        if (tone === "positive" || tone === "negative") {
          data.cell.styles.textColor = rgbArr(toneColor(tone));
          data.cell.styles.fontStyle = "bold";
        } else {
          data.cell.styles.textColor = rgbArr(COLORS.text);
        }
      }
      if (data.column.index === 2) {
        const tone = h?.tone || "neutral";
        data.cell.styles.fillColor = rgbArr(toneTint(tone));
        data.cell.styles.textColor = rgbArr(toneColor(tone));
        data.cell.styles.fontStyle = "bold";
        data.cell.styles.halign = "center";
      }
    }
  };
  runTable(doc, ctx, {
    head: [["Metric", "Value", "Tone", "Note"]],
    body,
    columnStyles: {
      0: { cellWidth: 175, textColor: rgbArr(COLORS.textMuted) },
      1: { cellWidth: 110, halign: "right" },
      2: { cellWidth: 70, halign: "center" },
      3: { cellWidth: "auto", textColor: rgbArr(COLORS.textMuted), fontSize: 8.5 },
    },
    didParseCell,
  });
}

interface NewsHighlight {
  title: string;
  sentiment: "positive" | "negative" | "neutral";
  source: string;
  date?: string;
}

function addNewsTable(doc: jsPDF, ctx: Ctx, items: NewsHighlight[]): void {
  const body: RowInput[] = items.map((n) => [
    n.title || "—",
    (n.sentiment || "neutral").toUpperCase(),
    n.source || "—",
    n.date ? formatShortDate(n.date) : "—",
  ]);
  const didParseCell = (data: CellHookData) => {
    if (data.section === "body" && data.column.index === 1) {
      const it = items[data.row.index];
      const sent = it?.sentiment || "neutral";
      data.cell.styles.fillColor = rgbArr(toneTint(sent === "neutral" ? "neutral" : sent));
      data.cell.styles.textColor = rgbArr(sentimentColor(sent));
      data.cell.styles.fontStyle = "bold";
      data.cell.styles.halign = "center";
    }
  };
  runTable(doc, ctx, {
    head: [["Headline", "Sentiment", "Source", "Date"]],
    body,
    columnStyles: {
      0: { cellWidth: "auto" },
      1: { cellWidth: 78, halign: "center" },
      2: { cellWidth: 110, textColor: rgbArr(COLORS.textMuted) },
      3: { cellWidth: 72, halign: "center", textColor: rgbArr(COLORS.textMuted) },
    },
    didParseCell,
  });
}

function addWebTable(doc: jsPDF, ctx: Ctx, items: Array<{ title: string; snippet: string; url: string }>): void {
  const refs = items;
  const body: RowInput[] = items.map((w) => [w.title || "—", w.snippet || "—", truncateUrl(w.url)]);
  const didDrawCell = (data: CellHookData) => {
    if (data.section === "body" && data.column.index === 2) {
      const ref = refs[data.row.index];
      if (ref?.url) {
        doc.link(data.cell.x, data.cell.y, data.cell.width, data.cell.height, { url: ref.url });
      }
    }
  };
  runTable(doc, ctx, {
    head: [["Title", "Snippet", "URL"]],
    body,
    columnStyles: {
      0: { cellWidth: 165, fontStyle: "bold", textColor: rgbArr(COLORS.text) },
      1: { cellWidth: "auto", textColor: rgbArr(COLORS.textMuted), fontSize: 8.5 },
      2: { cellWidth: 145, textColor: rgbArr(COLORS.cyan), fontSize: 8 },
    },
    didDrawCell,
  });
}

function addRisksTable(doc: jsPDF, ctx: Ctx, risks: RiskItem[]): void {
  const items = risks;
  const body: RowInput[] = risks.map((r) => [r.title || "—", (r.severity || "low").toUpperCase(), r.detail || "—"]);
  const didParseCell = (data: CellHookData) => {
    if (data.section === "body" && data.column.index === 1) {
      const r = items[data.row.index];
      const sev = r?.severity || "low";
      data.cell.styles.fillColor = rgbArr(sev === "high" ? COLORS.roseTint : sev === "medium" ? COLORS.amberTint : COLORS.emeraldTint);
      data.cell.styles.textColor = rgbArr(severityColor(sev));
      data.cell.styles.fontStyle = "bold";
      data.cell.styles.halign = "center";
    }
  };
  runTable(doc, ctx, {
    head: [["Risk", "Severity", "Detail"]],
    body,
    columnStyles: {
      0: { cellWidth: 155, fontStyle: "bold" },
      1: { cellWidth: 78, halign: "center" },
      2: { cellWidth: "auto", textColor: rgbArr(COLORS.textMuted), fontSize: 8.5 },
    },
    didParseCell,
  });
}

function addSourcesTable(doc: jsPDF, ctx: Ctx, sources: SourceRef[]): void {
  const refs = sources;
  const body: RowInput[] = sources.map((s) => [s.type.toUpperCase(), s.label || "—", truncateUrl(s.url), s.detail || "—"]);
  const didDrawCell = (data: CellHookData) => {
    if (data.section === "body" && data.column.index === 2) {
      const ref = refs[data.row.index];
      if (ref?.url) {
        doc.link(data.cell.x, data.cell.y, data.cell.width, data.cell.height, { url: ref.url });
      }
    }
    if (data.section === "body" && data.column.index === 0) {
      const ref = refs[data.row.index];
      const t = ref?.type;
      if (t === "fmp") data.cell.styles.fillColor = rgbArr(COLORS.violetTint);
      else if (t === "tavily") data.cell.styles.fillColor = rgbArr(COLORS.cyanTint);
      else if (t === "newsapi") data.cell.styles.fillColor = rgbArr(COLORS.amberTint);
      else if (t === "gemini") data.cell.styles.fillColor = rgbArr(COLORS.emeraldTint);
      data.cell.styles.textColor = rgbArr(COLORS.text);
      data.cell.styles.fontStyle = "bold";
      data.cell.styles.halign = "center";
    }
  };
  runTable(doc, ctx, {
    head: [["Type", "Label", "URL", "Detail"]],
    body,
    columnStyles: {
      0: { cellWidth: 70, halign: "center" },
      1: { cellWidth: 150 },
      2: { cellWidth: "auto", textColor: rgbArr(COLORS.cyan), fontSize: 8 },
      3: { cellWidth: 130, textColor: rgbArr(COLORS.textMuted), fontSize: 8 },
    },
    didDrawCell,
  });
}

function addLabelledList(doc: jsPDF, ctx: Ctx, label: string, items: Array<{ title: string; detail: string }> | undefined, accent: RGB): void {
  if (!items || items.length === 0) return;
  ctx.y += 6;
  addLabel(doc, ctx, label, accent);
  for (const item of items) {
    ensureSpace(doc, ctx, 36);
    setFill(doc, accent);
    doc.circle(MARGIN.left + 3, ctx.y - 3, 1.7, "F");
    setText(doc, COLORS.text);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    const titleLines = doc.splitTextToSize(item.title || "—", CONTENT_W - 16) as string[];
    doc.text(titleLines[0], MARGIN.left + 16, ctx.y);
    ctx.y += 14;
    for (let i = 1; i < titleLines.length; i++) {
      ensureSpace(doc, ctx, 14);
      doc.text(titleLines[i], MARGIN.left + 16, ctx.y);
      ctx.y += 14;
    }
    if (item.detail) {
      setText(doc, COLORS.textMuted);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      const detailLines = doc.splitTextToSize(item.detail, CONTENT_W - 26) as string[];
      for (const line of detailLines) {
        ensureSpace(doc, ctx, 13);
        doc.text(line, MARGIN.left + 26, ctx.y);
        ctx.y += 13;
      }
    }
    ctx.y += 6;
  }
}

function drawCover(doc: jsPDF, report: InvestmentReport): void {
  setFill(doc, COLORS.white);
  doc.rect(0, 0, PAGE.w, PAGE.h, "F");

  setText(doc, COLORS.violet);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text("FinOps Agent", MARGIN.left, 56);

  setText(doc, COLORS.textMuted);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  doc.text("AI Investment Research", MARGIN.left + 102, 56);

  setText(doc, COLORS.cyan);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text("CONFIDENTIAL", PAGE.w - MARGIN.right, 56, { align: "right" });

  gradientBar(doc, MARGIN.left, 70, CONTENT_W, 2);

  setFill(doc, COLORS.violetTint);
  doc.rect(MARGIN.left, 110, CONTENT_W, 90, "F");
  setFill(doc, COLORS.violet);
  doc.rect(MARGIN.left, 110, 4, 90, "F");
  setText(doc, COLORS.violet);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("RESEARCH REPORT", MARGIN.left + 18, 132);
  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(`Generated ${formatDate(report.generatedAt)}`, MARGIN.left + 18, 150);
  setText(doc, COLORS.textMuted);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.text("Prepared by an autonomous AI research agent. For informational purposes only.", MARGIN.left + 18, 178);

  const name = report.companyName || "Unknown Company";
  setText(doc, COLORS.text);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(34);
  const nameLines = doc.splitTextToSize(name, CONTENT_W - 40) as string[];
  let yy = 290;
  for (const line of nameLines) {
    doc.text(line, PAGE.w / 2, yy, { align: "center" });
    yy += 38;
  }

  const subParts: string[] = [];
  if (report.symbol) subParts.push(report.symbol);
  if (report.exchange || report.profile?.exchange) subParts.push(report.exchange || report.profile?.exchange || "");
  if (report.profile?.sector) subParts.push(report.profile.sector);
  if (report.profile?.industry) subParts.push(report.profile.industry);
  if (subParts.length) {
    setText(doc, COLORS.cyan);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    const subText = subParts.filter(Boolean).join("    ·    ");
    const subLines = doc.splitTextToSize(subText, CONTENT_W - 40) as string[];
    let sy = yy + 6;
    for (const line of subLines) {
      doc.text(line, PAGE.w / 2, sy, { align: "center" });
      sy += 16;
    }
    yy = sy;
  }

  const rec = report.decision?.recommendation || "HOLD";
  doc.setFont("helvetica", "bold");
  doc.setFontSize(26);
  const badgeText = rec;
  const tw = doc.getTextWidth(badgeText);
  const bw = Math.max(220, tw + 90);
  const bh = 64;
  const bx = (PAGE.w - bw) / 2;
  const by = yy + 40;

  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("RECOMMENDATION", PAGE.w / 2, by - 12, { align: "center" });

  setFill(doc, recColor(rec));
  doc.roundedRect(bx, by, bw, bh, 14, 14, "F");
  setText(doc, COLORS.white);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(26);
  doc.text(badgeText, PAGE.w / 2, by + bh / 2 + 9, { align: "center" });

  const score = report.decision?.investmentScore ?? 0;
  const conf = report.decision?.confidence ?? 0;
  const sy2 = by + bh + 56;
  const colX1 = PAGE.w / 2 - 120;
  const colX2 = PAGE.w / 2 + 120;

  setText(doc, COLORS.textMuted);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("INVESTMENT SCORE", colX1, sy2, { align: "center" });
  doc.text("CONFIDENCE", colX2, sy2, { align: "center" });

  setText(doc, COLORS.violet);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(32);
  doc.text(`${score}`, colX1 - 18, sy2 + 36, { align: "center" });
  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(13);
  doc.text("/ 100", colX1 + 22, sy2 + 36, { align: "center" });

  setText(doc, COLORS.cyan);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(32);
  doc.text(`${conf}%`, colX2, sy2 + 36, { align: "center" });

  if (report.decision?.verdict) {
    setText(doc, COLORS.textMuted);
    doc.setFont("helvetica", "italic");
    doc.setFontSize(10);
    const vlines = doc.splitTextToSize(report.decision.verdict, CONTENT_W - 80) as string[];
    let vy = sy2 + 64;
    for (const line of vlines) {
      doc.text(line, PAGE.w / 2, vy, { align: "center" });
      vy += 14;
    }
  }

  gradientBar(doc, MARGIN.left, PAGE.h - 92, CONTENT_W, 2);
  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(8);
  const disclaimer =
    "This report is generated by an autonomous AI research agent for informational purposes only. " +
    "It does not constitute investment advice or a recommendation to buy or sell any security. " +
    "Always conduct your own due diligence before making investment decisions.";
  const dlines = doc.splitTextToSize(disclaimer, CONTENT_W - 40) as string[];
  let dy = PAGE.h - 74;
  for (const line of dlines) {
    doc.text(line, PAGE.w / 2, dy, { align: "center" });
    dy += 11;
  }
}

function addChrome(doc: jsPDF, report: InvestmentReport): void {
  const total = doc.getNumberOfPages();
  const name = report.companyName || "Company";
  for (let i = 2; i <= total; i++) {
    doc.setPage(i);

    setFill(doc, COLORS.white);
    doc.rect(0, 0, PAGE.w, 60, "F");

    setText(doc, COLORS.violet);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text("FinOps Agent", MARGIN.left, 36);
    setText(doc, COLORS.textMuted);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text(`— ${name}`, MARGIN.left + 70, 36);
    setText(doc, COLORS.cyan);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text("CONFIDENTIAL", PAGE.w - MARGIN.right, 36, { align: "right" });

    gradientBar(doc, MARGIN.left, 44, CONTENT_W, 1.5);

    setStroke(doc, COLORS.border);
    doc.setLineWidth(0.5);
    doc.line(MARGIN.left, PAGE.h - 46, PAGE.w - MARGIN.right, PAGE.h - 46);

    setText(doc, COLORS.textDim);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text("FinOps Agent · Confidential", MARGIN.left, PAGE.h - 30);
    doc.text(`Page ${i} of ${total}`, PAGE.w - MARGIN.right, PAGE.h - 30, { align: "right" });
  }
}

function sectionExecutiveSummary(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Executive Summary", COLORS.violet, COLORS.violetTint);

  if (report.decision?.verdict) {
    addLabel(doc, ctx, "Verdict");
    addParagraph(doc, ctx, report.decision.verdict);
  }
  if (report.decision?.thesis) {
    ctx.y += 2;
    addLabel(doc, ctx, "Thesis", COLORS.cyan);
    addParagraph(doc, ctx, report.decision.thesis);
  }
  if (report.decision?.reasoning?.length) {
    ctx.y += 2;
    addLabel(doc, ctx, "Key Reasoning", COLORS.emerald);
    addBullets(doc, ctx, report.decision.reasoning);
  }
  if (!report.decision?.verdict && !report.decision?.thesis && !report.decision?.reasoning?.length) {
    addNoData(doc, ctx);
  }
}

function sectionCompanyOverview(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Company Overview", COLORS.cyan, COLORS.cyanTint);
  const p = report.profile;
  const rows: Array<[string, string]> = [
    ["Name", str(report.companyName)],
    ["Symbol", str(report.symbol)],
    ["Exchange", str(report.exchange || p?.exchange)],
    ["Sector", str(p?.sector)],
    ["Industry", str(p?.industry)],
    ["CEO", str(p?.ceo)],
    ["Website", str(p?.website)],
    ["Country", str(p?.country)],
    ["Employees", p?.employees ? Number(p.employees).toLocaleString() : "—"],
    ["IPO Date", p?.ipoDate ? formatDate(p.ipoDate) : "—"],
    ["Market Cap", p?.marketCap != null ? formatMoney(p.marketCap) : "—"],
    ["Price", p?.price != null ? `${p.price.toFixed(2)} ${p?.currency || ""}`.trim() : "—"],
    ["Beta", p?.beta != null ? p.beta.toFixed(2) : "—"],
    ["Currency", str(p?.currency)],
  ];
  ensureSpace(doc, ctx, 80);
  addKeyValueTable(doc, ctx, rows);

  if (p?.description) {
    ctx.y += 4;
    addLabel(doc, ctx, "About the Company");
    addParagraph(doc, ctx, p.description);
  }
}

function sectionFinancials(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Financial Analysis", COLORS.emerald, COLORS.emeraldTint);

  if (report.financials?.summary) {
    addParagraph(doc, ctx, report.financials.summary);
  } else if (!report.financials) {
    addNoData(doc, ctx);
    return;
  }

  if (report.financials?.highlights?.length) {
    ctx.y += 2;
    addLabel(doc, ctx, "Key Metrics", COLORS.emerald);
    ensureSpace(doc, ctx, 60);
    addFinancialHighlightsTable(doc, ctx, report.financials.highlights);
  }

  ctx.y += 4;
  ensureSpace(doc, ctx, 40);
  const dq = report.financials?.dataQuality || "limited";
  const dqColor = dq === "full" ? COLORS.emerald : dq === "partial" ? COLORS.amber : COLORS.rose;
  addBadge(doc, MARGIN.left, ctx.y, `DATA QUALITY: ${dq.toUpperCase()}`, dqColor, { size: 9 });
  ctx.y += 34;

  ctx.y += 4;
  addLabel(doc, ctx, "Price Chart", COLORS.cyan);
  if (report.historicalPrices && report.historicalPrices.length >= 2) {
    const chartH = 180;
    ensureSpace(doc, ctx, chartH + 20);
    drawLineChart(doc, report.historicalPrices, MARGIN.left, ctx.y, CONTENT_W, chartH);
    ctx.y += chartH + 18;
  } else {
    ensureSpace(doc, ctx, 20);
    setText(doc, COLORS.textDim);
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.text("No historical price data available for this issuer.", MARGIN.left, ctx.y);
    ctx.y += 16;
  }
}

function sectionNews(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "News Analysis", COLORS.amber, COLORS.amberTint);

  if (report.news?.summary) {
    addParagraph(doc, ctx, report.news.summary);
  }

  if (report.news) {
    ctx.y += 2;
    addLabel(doc, ctx, "Overall Sentiment", COLORS.amber);
    const sent = report.news.overallSentiment || "neutral";
    ensureSpace(doc, ctx, 30);
    addBadge(doc, MARGIN.left, ctx.y, sent.toUpperCase(), sentimentColor(sent), { size: 10 });
    ctx.y += 34;
  }

  if (report.news?.highlights?.length) {
    addLabel(doc, ctx, "News Highlights", COLORS.amber);
    ensureSpace(doc, ctx, 60);
    addNewsTable(doc, ctx, report.news.highlights);
  } else if (report.news) {
    addNoData(doc, ctx);
  }
}

function sectionWeb(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Web Research", COLORS.violet, COLORS.violetTint);

  if (report.web?.summary) {
    addParagraph(doc, ctx, report.web.summary);
  }

  if (report.web?.themes?.length) {
    ctx.y += 2;
    addLabel(doc, ctx, "Themes", COLORS.violet);
    setText(doc, COLORS.cyan);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    const themesLine = report.web.themes.join("    ·    ");
    const tlines = doc.splitTextToSize(themesLine, CONTENT_W) as string[];
    const lineH = 14;
    for (const line of tlines) {
      ensureSpace(doc, ctx, lineH);
      doc.text(line, MARGIN.left, ctx.y);
      ctx.y += lineH;
    }
    ctx.y += 6;
  }

  if (report.web?.highlights?.length) {
    addLabel(doc, ctx, "Web Highlights", COLORS.violet);
    ensureSpace(doc, ctx, 60);
    addWebTable(doc, ctx, report.web.highlights);
  } else if (report.web) {
    addNoData(doc, ctx);
  }
}

function sectionRisk(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Risk Assessment", COLORS.rose, COLORS.roseTint);

  if (report.risks?.length) {
    addLabel(doc, ctx, "Risk Factors", COLORS.rose);
    ensureSpace(doc, ctx, 60);
    addRisksTable(doc, ctx, report.risks);
  } else {
    addNoData(doc, ctx);
  }

  addLabelledList(doc, ctx, "Strengths", report.strengths, COLORS.emerald);
  addLabelledList(doc, ctx, "Weaknesses", report.weaknesses, COLORS.rose);
  addLabelledList(doc, ctx, "Opportunities", report.opportunities, COLORS.cyan);
  addLabelledList(doc, ctx, "Weak Signals", report.weakSignals, COLORS.amber);
}

function sectionThesis(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Investment Thesis", COLORS.emerald, COLORS.emeraldTint);

  if (report.decision?.thesis) {
    addParagraph(doc, ctx, report.decision.thesis);
  }
  if (report.decision?.reasoning?.length) {
    ctx.y += 2;
    addLabel(doc, ctx, "Reasoning", COLORS.violet);
    addNumbered(doc, ctx, report.decision.reasoning);
  }

  ctx.y += 8;
  ensureSpace(doc, ctx, 100);
  const py = ctx.y;
  const ph = 82;
  setFill(doc, COLORS.panel);
  setStroke(doc, COLORS.border);
  doc.setLineWidth(0.6);
  doc.roundedRect(MARGIN.left, py, CONTENT_W, ph, 10, 10, "FD");
  setFill(doc, recColor(report.decision?.recommendation));
  doc.rect(MARGIN.left, py, 6, ph, "F");

  setText(doc, COLORS.textMuted);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("FINAL RECOMMENDATION", MARGIN.left + 24, py + 26);

  const rec = report.decision?.recommendation || "HOLD";
  setText(doc, recColor(rec));
  doc.setFont("helvetica", "bold");
  doc.setFontSize(24);
  doc.text(rec, MARGIN.left + 24, py + 58);

  const rx = PAGE.w - MARGIN.right;
  setText(doc, COLORS.textMuted);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text("Investment Score", rx - 170, py + 26, { align: "left" });
  doc.text("Confidence", rx - 50, py + 26, { align: "left" });
  setText(doc, COLORS.violet);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text(`${report.decision?.investmentScore ?? 0}`, rx - 170, py + 56);
  setText(doc, COLORS.textDim);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text("/ 100", rx - 145, py + 56);
  setText(doc, COLORS.cyan);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text(`${report.decision?.confidence ?? 0}%`, rx - 50, py + 56);

  ctx.y = py + ph + 14;
}

function sectionSources(doc: jsPDF, ctx: Ctx, report: InvestmentReport): void {
  addSectionHeader(doc, ctx, "Sources & Methodology", COLORS.cyan, COLORS.cyanTint);
  if (report.sources?.length) {
    addLabel(doc, ctx, "Data Sources", COLORS.cyan);
    ensureSpace(doc, ctx, 60);
    addSourcesTable(doc, ctx, report.sources);
  } else {
    addNoData(doc, ctx);
  }

  if (report.assumptions?.length) {
    ctx.y += 6;
    addLabel(doc, ctx, "Methodology Notes", COLORS.violet);
    addBullets(doc, ctx, report.assumptions.map((a) => a.note).filter(Boolean));
  }
}

export function generateInvestmentPdf(report: InvestmentReport): Uint8Array {
  const doc = new jsPDF({ unit: "pt", format: "letter", orientation: "portrait" });

  drawCover(doc, report);

  doc.addPage();
  const ctx: Ctx = { y: MARGIN.top };

  sectionExecutiveSummary(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionCompanyOverview(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionFinancials(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionNews(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionWeb(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionRisk(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionThesis(doc, ctx, report);
  ensureSpace(doc, ctx, 40);
  ctx.y += 8;

  sectionSources(doc, ctx, report);

  addChrome(doc, report);

  const buf: ArrayBuffer = doc.output("arraybuffer");
  return new Uint8Array(buf);
}
