import { END, START, StateGraph } from "@langchain/langgraph";
import { AgentState, type AgentStateType } from "@/lib/agent/state";
import {
  analyzeFinancialsNode,
  analyzeNewsNode,
  gatherDataNode,
  normalizeInputNode,
  reportGenerationNode,
  resolveCompanyNode,
  riskAssessmentNode,
  synthesizeDecisionNode,
  webResearchNode,
  type NodeEmit,
} from "@/lib/agent/nodes";

function graphAdapter<T extends (state: AgentStateType, ctx: { emit: NodeEmit }) => Promise<{ state: Partial<AgentStateType> }>>(fn: T) {
  return async (state: AgentStateType): Promise<Partial<AgentStateType>> => {
    const result = await fn(state, { emit: async () => undefined });
    return result.state;
  };
}

const builder = new StateGraph(AgentState)
  .addNode("normalize", graphAdapter(normalizeInputNode))
  .addNode("resolve", graphAdapter(resolveCompanyNode))
  .addNode("gather", graphAdapter(gatherDataNode))
  .addNode("financials", graphAdapter(analyzeFinancialsNode))
  .addNode("news", graphAdapter(analyzeNewsNode))
  .addNode("web", graphAdapter(webResearchNode))
  .addNode("risk", graphAdapter(riskAssessmentNode))
  .addNode("synthesize", graphAdapter(synthesizeDecisionNode))
  .addNode("report", graphAdapter(reportGenerationNode))
  .addEdge(START, "normalize")
  .addEdge("normalize", "resolve")
  .addEdge("resolve", "gather")
  .addEdge("gather", "financials")
  .addEdge("financials", "news")
  .addEdge("news", "web")
  .addEdge("web", "risk")
  .addEdge("risk", "synthesize")
  .addEdge("synthesize", "report")
  .addEdge("report", END);

export const app = builder.compile();

export const PIPELINE_ORDER = [
  "normalize",
  "resolve",
  "gather",
  "financials",
  "news",
  "web",
  "risk",
  "synthesize",
  "report",
] as const;
