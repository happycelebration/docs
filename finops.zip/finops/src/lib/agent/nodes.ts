import type {
  AgentEvent,
  AnalyzedFinancials,
  AssumptionNote,
  CompanyProfile,
  FinancialSnapshot,
  InvestmentDecision,
  InvestmentReport,
  NewsAnalysis,
  NewsItem,
  PipelineStageId,
  SourceRef,
  WebAnalysis,
  WebResult,
} from "@/lib/agent/types";
import type { AgentStateType, RiskAssessmentBundle } from "@/lib/agent/state";

import {
  combineFinancials,
  delay,
  fetchCompanyProfileViaTavily,
  fmpBalanceSheet,
  fmpCashFlowStatement,
  fmpHistoricalPrices,
  fmpIncomeStatement,
  fmpKeyMetrics,
  fmpProfile,
  fmpRatios,
  fmpSearchCompany,
  newsApiEverything,
  resolveTickerViaTavily,
  tavilySearch,
} from "@/lib/agent/tools";
import { callJson } from "@/lib/agent/llm";
import {
  ruleBasedDecision as computeRuleBasedDecision,
  ruleBasedFinancialAnalysis,
  ruleBasedNewsAnalysis,
  ruleBasedRiskAssessment,
  ruleBasedWebAnalysis,
} from "@/lib/agent/rule-based";
import {
  PROMPT_DECISION,
  PROMPT_FINANCIAL_ANALYSIS,
  PROMPT_NEWS_ANALYSIS,
  PROMPT_RISK_STRENGTHS,
  PROMPT_RESOLVE,
  PROMPT_WEB_ANALYSIS,
} from "@/lib/agent/prompts";

export type NodeEmit = (event: AgentEvent) => Promise<void> | void;

interface NodeContext {
  emit: NodeEmit;
}

export interface NodeResult {
  state: Partial<AgentStateType>;
}

const STAGE_META: Record<
  PipelineStageId,
  { label: string; description: string }
> = {
  normalize: {
    label: "Normalize Input",
    description: "Cleaning & validating the company name",
  },
  resolve: {
    label: "Resolve Company",
    description: "Identifying the correct public entity via FMP",
  },
  gather: {
    label: "Gather Data",
    description: "Pulling profile, financials, news & web context",
  },
  financials: {
    label: "Financial Analysis",
    description: "Evaluating revenue, margins, balance sheet & ratios",
  },
  news: {
    label: "News Analysis",
    description: "Scanning recent headlines for market-moving signals",
  },
  web: {
    label: "Web Research",
    description: "Broadening context with Tavily web search",
  },
  risk: {
    label: "Risk Assessment",
    description: "Flagging risks, weak signals & red flags",
  },
  synthesize: {
    label: "Decision Synthesis",
    description: "Weighing evidence into an Invest / Pass verdict",
  },
  report: {
    label: "Report Generation",
    description: "Composing the final structured research report",
  },
};

async function emitStart(
  emit: NodeEmit,
  stage: PipelineStageId,
  message?: string,
) {
  await emit({
    type: "stage_start",
    stage,
    label: STAGE_META[stage].label,
    description: STAGE_META[stage].description,
    message,
  });
}

async function emitProgress(
  emit: NodeEmit,
  stage: PipelineStageId,
  message: string,
) {
  await emit({ type: "stage_progress", stage, message });
}

async function emitComplete(
  emit: NodeEmit,
  stage: PipelineStageId,
  payload?: Partial<InvestmentReport>,
) {
  await emit({ type: "stage_complete", stage, payload });
}

function addAssumption(
  out: Partial<AgentStateType>,
  note: string,
): AssumptionNote[] {
  const existing = out.assumptions || [];
  return [...existing, { note }];
}

function addSources(
  out: Partial<AgentStateType>,
  refs: SourceRef[],
): SourceRef[] {
  const existing = out.sources || [];
  return [...existing, ...refs];
}

export async function normalizeInputNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "normalize";
  await emitStart(ctx.emit, stage);

  const raw = (state.rawCompany || "").trim();
  if (!raw) {
    await emitProgress(
      ctx.emit,
      stage,
      "No company name provided — proceeding with empty input (degraded mode).",
    );
    return {
      state: {
        rawCompany: "",
        assumptions: addAssumption(
          {},
          "No company name was provided in the request — analysis will be empty/degraded.",
        ),
      },
    };
  }

  const cleaned = raw.replace(/\s+/g, " ").replace(/^["']|["']$/g, "").trim();
  await emitProgress(ctx.emit, stage, `Normalized input: "${cleaned}".`);
  await delay(300);
  await emitComplete(ctx.emit, stage, { companyName: cleaned });
  return { state: { rawCompany: cleaned } };
}

export async function resolveCompanyNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "resolve";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  const query = (state.rawCompany || "").trim();
  if (!query) {
    await emitProgress(ctx.emit, stage, "Skipping resolution — empty company name.");
    await emitComplete(ctx.emit, stage);
    return { state: out };
  }

  await emitProgress(ctx.emit, stage, `Searching FMP for "${query}"…`);
  await delay(300);
  let candidates = await fmpSearchCompany(query);

  if (candidates.length === 0) {
    await emitProgress(
      ctx.emit,
      stage,
      "FMP search returned no candidates — resolving ticker via Tavily web search…",
    );
    await delay(300);
    const resolved = await resolveTickerViaTavily(query);
    if (resolved) {
      const profile = await fmpProfile(resolved.symbol);
      candidates = [
        {
          symbol: resolved.symbol,
          name: profile?.companyName || resolved.symbol,
          exchange: profile?.exchange,
        },
      ];
      await emitProgress(
        ctx.emit,
        stage,
        `Resolved ticker ${resolved.symbol} via web search (verified via FMP profile).`,
      );
    }
  }

  if (candidates.length === 0) {
    await emitProgress(
      ctx.emit,
      stage,
      `Could not resolve a public listing for "${query}" — analysis will be limited to news & web by name.`,
    );
    out.assumptions = addAssumption(
      out,
      `No public ticker could be resolved for "${query}" (FMP search + Tavily resolution both returned nothing). This may be a private company, or the name may be too ambiguous. Financial data lookups will be skipped.`,
    );
    await emitComplete(ctx.emit, stage);
    return { state: out };
  }

  const preferredExchanges = new Set(["NASDAQ", "NYSE", "NYSE ARCA", "AMEX", "NSE", "BSE", "LSE", "TSX"]);
  const etfNameCues = /\b(etf|fund|trust|index)\b/i;
  const scored = candidates.map((c) => {
    let score = 0;
    if (c.exchange && preferredExchanges.has(c.exchange.toUpperCase())) score += 3;
    if (!etfNameCues.test(c.name)) score += 2;
    if (c.name.toLowerCase().includes(query.toLowerCase())) score += 2;
    if (
      c.name.toLowerCase().split(/\s+/)[0] === query.toLowerCase().split(/\s+/)[0]
    ) {
      score += 2;
    }
    return { c, score };
  });
  scored.sort((a, b) => b.score - a.score);
  const chosen = scored[0]?.c ?? candidates[0];

  out.symbol = chosen.symbol;
  out.sources = addSources(out, [
    {
      type: "fmp",
      label: `FMP — Company search: "${query}"`,
      url: "https://financialmodelingprep.com/stable/profile",
      detail: `Resolved to ${chosen.symbol} (${chosen.name}) on ${chosen.exchange || "unknown exchange"}.`,
    },
  ]);

  await delay(300);
  await emitProgress(
    ctx.emit,
    stage,
    `Resolved to ${chosen.symbol} — ${chosen.name} (${chosen.exchange || "n/a"}).`,
  );
  await emitComplete(ctx.emit, stage, {
    symbol: chosen.symbol,
  });
  return { state: out };
}

interface GatheredData {
  profile?: CompanyProfile;
  financials?: FinancialSnapshot;
  historicalPrices?: { date: string; close: number; volume?: number }[];
  news?: NewsItem[];
  web?: WebResult[];
  sources: SourceRef[];
  assumptions: AssumptionNote[];
}

async function gatherAll(
  symbol: string,
  name: string,
  emit: NodeEmit,
): Promise<GatheredData> {
  const result: GatheredData = { sources: [], assumptions: [] };

  const tasks = await Promise.allSettled([
    (async () => {
      let p = await fmpProfile(symbol);
      if (p) {
        result.profile = p;
        result.sources.push({
          type: "fmp",
          label: `FMP — Company profile: ${symbol}`,
          url: `https://financialmodelingprep.com/stable/profile`,
        });
      } else {
        const tavilyProfile = await fetchCompanyProfileViaTavily(name, symbol);
        if (tavilyProfile) {
          p = tavilyProfile as CompanyProfile;
          result.profile = p;
          result.sources.push({
            type: "tavily",
            label: `Tavily + Wikipedia — Company profile (FMP unavailable): ${name}`,
            url: "https://api.tavily.com/search",
          });
          result.assumptions.push({
            note: "FMP profile was unavailable (rate limit or not found); profile data was enriched via Tavily web search and Wikipedia.",
          });
        }
      }
      return p;
    })(),
    (async () => {
      const [ratios, income, cashflow, balance, metrics] = await Promise.all([
        fmpRatios(symbol),
        fmpIncomeStatement(symbol),
        fmpCashFlowStatement(symbol),
        fmpBalanceSheet(symbol),
        fmpKeyMetrics(symbol),
      ]);
      const snap = combineFinancials(ratios, income, cashflow, balance, metrics);
      const hasAny =
        snap.peRatio !== undefined ||
        snap.revenue !== undefined ||
        snap.roe !== undefined;
      if (hasAny) {
        result.financials = snap;
        result.sources.push({
          type: "fmp",
          label: `FMP — Financials (ratios + statements): ${symbol}`,
          url: `https://financialmodelingprep.com/api/v3/ratios/${symbol}`,
        });
      }
      return snap;
    })(),
    (async () => {
      const prices = await fmpHistoricalPrices(symbol);
      if (prices.length > 0) {
        result.historicalPrices = prices;
        result.sources.push({
          type: "fmp",
          label: `FMP — Historical prices (weekly, ~3y): ${symbol}`,
          url: `https://financialmodelingprep.com/api/v3/historical-price-full/${symbol}`,
        });
      }
      return prices;
    })(),
    (async () => {
      const items = await newsApiEverything(`${name} stock`);
      if (items.length > 0) {
        result.news = items;
        result.sources.push({
          type: "newsapi",
          label: `NewsAPI — Recent headlines: ${name}`,
          url: "https://newsapi.org/v2/everything",
        });
      }
      return items;
    })(),
    (async () => {
      const results = await tavilySearch(`${name} stock investment analysis`, {
        maxResults: 6,
        searchDepth: "basic",
      });
      if (results.length > 0) {
        result.web = results;
        result.sources.push({
          type: "tavily",
          label: `Tavily — Web research: ${name}`,
          url: "https://api.tavily.com/search",
        });
      }
      return results;
    })(),
  ]);

  const labels = [
    "company profile",
    "financial statements",
    "historical prices",
    "recent news",
    "web search results",
  ];
  tasks.forEach((t, i) => {
    if (t.status === "rejected") {
      const note = `${labels[i]} fetch failed — proceeding without it.`;
      result.assumptions.push({ note });
    } else if (t.status === "fulfilled") {
      const val = t.value;
      const empty =
        val == null ||
        (Array.isArray(val) && val.length === 0) ||
        (typeof val === "object" && Object.keys(val as object).length === 0);
      if (empty) {
        result.assumptions.push({
          note: `${labels[i]} returned no data — proceeding without it.`,
        });
      }
    }
  });

  await emit(
    {
      type: "stage_progress",
      stage: "gather",
      message: `Gather complete: profile=${result.profile ? "ok" : "—"}, financials=${
        result.financials ? "ok" : "—"
      }, prices=${result.historicalPrices?.length ?? 0}w, news=${
        result.news?.length ?? 0
      }, web=${result.web?.length ?? 0}.`,
    },
  );

  return result;
}

export async function gatherDataNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "gather";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  const symbol = state.symbol;
  const name = state.profile?.companyName || state.rawCompany || symbol || "";

  if (!symbol) {
    await emitProgress(
      ctx.emit,
      stage,
      "No ticker resolved — fetching profile, news & web by company name only.",
    );
    const [news, web, profileResult] = await Promise.allSettled([
      newsApiEverything(state.rawCompany || ""),
      tavilySearch(`${state.rawCompany || ""} company investment`),
      fetchCompanyProfileViaTavily(state.rawCompany || ""),
    ]);
    if (profileResult.status === "fulfilled" && profileResult.value) {
      out.profile = profileResult.value as CompanyProfile;
      out.sources = addSources(out, [
        {
          type: "tavily",
          label: `Tavily + Wikipedia — Company profile: ${state.rawCompany}`,
          url: "https://api.tavily.com/search",
        },
      ]);
    }
    if (news.status === "fulfilled" && news.value.length > 0) {
      out.newsRaw = news.value;
      out.sources = addSources(out, [
        {
          type: "newsapi",
          label: `NewsAPI — Recent headlines: ${state.rawCompany}`,
          url: "https://newsapi.org/v2/everything",
        },
      ]);
    } else {
      out.assumptions = addAssumption(
        out,
        "News lookup by name returned no results (no ticker was resolved).",
      );
    }
    if (web.status === "fulfilled" && web.value.length > 0) {
      out.webRaw = web.value;
      out.sources = addSources(out, [
        {
          type: "tavily",
          label: `Tavily — Web research: ${state.rawCompany}`,
          url: "https://api.tavily.com/search",
        },
      ]);
    } else {
      out.assumptions = addAssumption(
        out,
        "Web research by name returned no results (no ticker was resolved).",
      );
    }
    await emitComplete(ctx.emit, stage, {
      profile: out.profile,
      historicalPrices: out.historicalPrices,
    });
    return { state: out };
  }

  await emitProgress(
    ctx.emit,
    stage,
    `Fetching profile, financials, prices, news & web for ${symbol} in parallel…`,
  );
  const gathered = await gatherAll(symbol, name, ctx.emit);

  if (gathered.profile) out.profile = gathered.profile;
  if (gathered.financials) out.financialsRaw = gathered.financials;
  if (gathered.historicalPrices) out.historicalPrices = gathered.historicalPrices;
  if (gathered.news) out.newsRaw = gathered.news;
  if (gathered.web) out.webRaw = gathered.web;
  out.sources = addSources(out, gathered.sources);
  if (gathered.assumptions.length > 0) {
    out.assumptions = (out.assumptions || []).concat(gathered.assumptions);
  }

  await delay(150);

  await emitComplete(ctx.emit, stage, {
    profile: out.profile,
    historicalPrices: out.historicalPrices,
  });
  return { state: out };
}

function isAnalyzedFinancials(v: unknown): v is AnalyzedFinancials {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    Array.isArray(o.highlights) &&
    typeof o.summary === "string" &&
    (o.dataQuality === "full" ||
      o.dataQuality === "partial" ||
      o.dataQuality === "limited")
  );
}

export async function analyzeFinancialsNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "financials";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  const snapshot = state.financialsRaw;
  if (!snapshot || Object.keys(snapshot).length === 0) {
    const fallback = ruleBasedFinancialAnalysis(state.profile, {});
    out.financialsAnalyzed = fallback;
    out.assumptions = addAssumption(
      out,
      "Financial statements unavailable — financial analysis limited to qualitative signals.",
    );
    await emitProgress(ctx.emit, stage, "No financial data available — using limited analysis.");
    await delay(400);
    await emitComplete(ctx.emit, stage, { financials: fallback });
    return { state: out };
  }

  const ruleBased = ruleBasedFinancialAnalysis(state.profile, snapshot);

  await emitProgress(ctx.emit, stage, "Analysing financials & valuation metrics…");
  await delay(600);
  const result = await callJson<AnalyzedFinancials>(
    PROMPT_FINANCIAL_ANALYSIS(state.profile, snapshot),
    ruleBased,
    isAnalyzedFinancials,
  );

  result.highlights = Array.isArray(result.highlights) ? result.highlights : [];
  if (result.highlights.length === 0 && ruleBased.highlights.length > 0) {
    result.highlights = ruleBased.highlights;
    result.summary = ruleBased.summary;
    result.dataQuality = ruleBased.dataQuality;
  }
  out.financialsAnalyzed = result;
  out.sources = addSources(out, [
    {
      type: "gemini",
      label: "Gemini — Financial analysis reasoning",
      detail: `dataQuality=${result.dataQuality}; ${result.highlights.length} highlights generated.`,
    },
  ]);

  await emitProgress(
    ctx.emit,
    stage,
    `Generated ${result.highlights.length} financial highlights (quality: ${result.dataQuality}).`,
  );
  await emitComplete(ctx.emit, stage, { financials: result });
  return { state: out };
}

function isNewsAnalysis(v: unknown): v is NewsAnalysis {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    Array.isArray(o.highlights) &&
    typeof o.summary === "string" &&
    typeof o.overallSentiment === "string"
  );
}

export async function analyzeNewsNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "news";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  const news = state.newsRaw;
  if (!news || news.length === 0) {
    const fallback = ruleBasedNewsAnalysis(
      state.profile?.companyName || state.rawCompany || "the company",
      [],
    );
    out.newsAnalyzed = fallback;
    out.assumptions = addAssumption(out, "No recent news found — news analysis set to neutral default.");
    await emitProgress(ctx.emit, stage, "No news items to analyze — using neutral default.");
    await emitComplete(ctx.emit, stage, { news: fallback });
    return { state: out };
  }

  const ruleBased = ruleBasedNewsAnalysis(
    state.profile?.companyName || state.rawCompany || "the company",
    news,
  );

  await emitProgress(
    ctx.emit,
    stage,
    `Scanning ${news.length} recent headlines for market signals…`,
  );
  await delay(600);
  const result = await callJson<NewsAnalysis>(
    PROMPT_NEWS_ANALYSIS(state.profile?.companyName || state.rawCompany, news),
    ruleBased,
    isNewsAnalysis,
  );
  result.highlights = Array.isArray(result.highlights) ? result.highlights : [];
  if (result.highlights.length === 0 && ruleBased.highlights.length > 0) {
    result.highlights = ruleBased.highlights;
    result.summary = ruleBased.summary;
    result.overallSentiment = ruleBased.overallSentiment;
  }

  out.newsAnalyzed = result;
  out.sources = addSources(out, [
    {
      type: "gemini",
      label: "Gemini — News analysis reasoning",
      detail: `${result.highlights.length} headlines classified; overall sentiment: ${result.overallSentiment}.`,
    },
  ]);

  await emitProgress(
    ctx.emit,
    stage,
    `Classified ${result.highlights.length} headlines (overall: ${result.overallSentiment}).`,
  );
  await emitComplete(ctx.emit, stage, { news: result });
  return { state: out };
}

function isWebAnalysis(v: unknown): v is WebAnalysis {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    Array.isArray(o.highlights) &&
    typeof o.summary === "string" &&
    Array.isArray(o.themes)
  );
}

export async function webResearchNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "web";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  const web = state.webRaw;
  if (!web || web.length === 0) {
    const fallback = ruleBasedWebAnalysis(
      state.profile?.companyName || state.rawCompany || "the company",
      [],
    );
    out.webAnalyzed = fallback;
    out.assumptions = addAssumption(out, "No web results found — web research set to empty default.");
    await emitProgress(ctx.emit, stage, "No web results to analyze — using empty default.");
    await emitComplete(ctx.emit, stage, { web: fallback });
    return { state: out };
  }

  const ruleBased = ruleBasedWebAnalysis(
    state.profile?.companyName || state.rawCompany || "the company",
    web,
  );

  await emitProgress(
    ctx.emit,
    stage,
    `Synthesizing ${web.length} web results into themes…`,
  );
  await delay(600);
  const result = await callJson<WebAnalysis>(
    PROMPT_WEB_ANALYSIS(state.profile?.companyName || state.rawCompany, web),
    ruleBased,
    isWebAnalysis,
  );
  result.highlights = Array.isArray(result.highlights) ? result.highlights : [];
  result.themes = Array.isArray(result.themes) ? result.themes : [];
  if (result.highlights.length === 0 && ruleBased.highlights.length > 0) {
    result.highlights = ruleBased.highlights;
    result.summary = ruleBased.summary;
    result.themes = ruleBased.themes;
  }

  out.webAnalyzed = result;
  out.sources = addSources(out, [
    {
      type: "gemini",
      label: "Gemini — Web research synthesis",
      detail: `${result.highlights.length} highlights; ${result.themes.length} themes.`,
    },
  ]);

  await emitProgress(
    ctx.emit,
    stage,
    `Identified ${result.themes.length} themes from ${result.highlights.length} web highlights.`,
  );
  await emitComplete(ctx.emit, stage, { web: result });
  return { state: out };
}

function isRiskBundle(v: unknown): v is RiskAssessmentBundle {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    Array.isArray(o.strengths) &&
    Array.isArray(o.weaknesses) &&
    Array.isArray(o.weakSignals) &&
    Array.isArray(o.opportunities) &&
    Array.isArray(o.risks)
  );
}

export async function riskAssessmentNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "risk";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  await emitProgress(
    ctx.emit,
    stage,
    "Assessing risks, strengths, weak signals & opportunities…",
  );
  await delay(700);

  const ruleBased = ruleBasedRiskAssessment({
    profile: state.profile,
    financialsRaw: state.financialsRaw,
    financialsAnalyzed: state.financialsAnalyzed,
    newsAnalyzed: state.newsAnalyzed,
    webAnalyzed: state.webAnalyzed,
  });

  const result = await callJson<RiskAssessmentBundle>(
    PROMPT_RISK_STRENGTHS({
      profile: state.profile,
      financialSnapshot: state.financialsRaw,
      financialSummary: state.financialsAnalyzed?.summary,
      newsSummary: state.newsAnalyzed?.summary,
      webSummary: state.webAnalyzed?.summary,
    }),
    ruleBased,
    isRiskBundle,
  );

  result.strengths = Array.isArray(result.strengths) ? result.strengths : [];
  result.weaknesses = Array.isArray(result.weaknesses) ? result.weaknesses : [];
  result.weakSignals = Array.isArray(result.weakSignals) ? result.weakSignals : [];
  result.opportunities = Array.isArray(result.opportunities)
    ? result.opportunities
    : [];
  result.risks = Array.isArray(result.risks) ? result.risks : [];
  if (
    result.strengths.length === 0 &&
    result.weaknesses.length === 0 &&
    result.risks.length === 0
  ) {
    result.strengths = ruleBased.strengths;
    result.weaknesses = ruleBased.weaknesses;
    result.weakSignals = ruleBased.weakSignals;
    result.opportunities = ruleBased.opportunities;
    result.risks = ruleBased.risks;
  }

  out.riskData = result;
  out.sources = addSources(out, [
    {
      type: "gemini",
      label: "Gemini — Risk & strengths synthesis",
      detail: `strengths=${result.strengths.length}, weaknesses=${result.weaknesses.length}, risks=${result.risks.length}.`,
    },
  ]);

  await emitProgress(
    ctx.emit,
    stage,
    `Identified ${result.strengths.length} strengths, ${result.weaknesses.length} weaknesses, ${result.risks.length} risks.`,
  );
  await emitComplete(ctx.emit, stage, {
    strengths: result.strengths,
    weaknesses: result.weaknesses,
    weakSignals: result.weakSignals,
    opportunities: result.opportunities,
    risks: result.risks,
  });
  return { state: out };
}

function clamp(n: unknown, min = 0, max = 100): number {
  const x = typeof n === "number" && Number.isFinite(n) ? n : 0;
  return Math.max(min, Math.min(max, Math.round(x)));
}

function isInvestmentDecision(v: unknown): v is InvestmentDecision {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    (o.recommendation === "INVEST" ||
      o.recommendation === "PASS" ||
      o.recommendation === "HOLD") &&
    typeof o.verdict === "string" &&
    Array.isArray(o.reasoning) &&
    typeof o.thesis === "string"
  );
}

function ruleBasedDecision(state: AgentStateType): InvestmentDecision {
  return computeRuleBasedDecision({
    profile: state.profile,
    financialsRaw: state.financialsRaw,
    financialsAnalyzed: state.financialsAnalyzed,
    newsAnalyzed: state.newsAnalyzed,
    riskData: state.riskData,
  });
}

export async function synthesizeDecisionNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "synthesize";
  await emitStart(ctx.emit, stage);
  const out: Partial<AgentStateType> = {};

  await emitProgress(ctx.emit, stage, "Weighing all evidence into a final verdict…");
  await delay(800);

  const fallback = ruleBasedDecision(state);
  const result = await callJson<InvestmentDecision>(
    PROMPT_DECISION({
      profile: state.profile,
      financialSnapshot: state.financialsRaw,
      financialSummary: state.financialsAnalyzed?.summary,
      financialDataQuality: state.financialsAnalyzed?.dataQuality,
      newsSummary: state.newsAnalyzed?.summary,
      newsSentiment: state.newsAnalyzed?.overallSentiment,
      webSummary: state.webAnalyzed?.summary,
      strengths: state.riskData?.strengths ?? [],
      weaknesses: state.riskData?.weaknesses ?? [],
      weakSignals: state.riskData?.weakSignals ?? [],
      opportunities: state.riskData?.opportunities ?? [],
      risks: state.riskData?.risks ?? [],
    }),
    fallback,
    isInvestmentDecision,
  );

  result.investmentScore = clamp(result.investmentScore);
  result.confidence = clamp(result.confidence);
  if (
    result.recommendation !== "INVEST" &&
    result.recommendation !== "PASS" &&
    result.recommendation !== "HOLD"
  ) {
    result.recommendation = "HOLD";
  }
  result.reasoning = Array.isArray(result.reasoning) ? result.reasoning : [];
  result.thesis = typeof result.thesis === "string" ? result.thesis : "";

  if (state.financialsAnalyzed?.dataQuality === "limited" && result.confidence > 40) {
    result.confidence = 40;
    out.assumptions = addAssumption(
      out,
      "Confidence was capped at 40 because financial data quality was 'limited'.",
    );
  }

  out.decision = result;
  out.sources = addSources(out, [
    {
      type: "gemini",
      label: "Gemini — Final investment decision",
      detail: `recommendation=${result.recommendation}; score=${result.investmentScore}; confidence=${result.confidence}.`,
    },
  ]);

  await emitProgress(
    ctx.emit,
    stage,
    `Verdict: ${result.recommendation} (score ${result.investmentScore}/100, confidence ${result.confidence}%).`,
  );
  await emitComplete(ctx.emit, stage, { decision: result });
  return { state: out };
}

export async function reportGenerationNode(
  state: AgentStateType,
  ctx: NodeContext,
): Promise<NodeResult> {
  const stage: PipelineStageId = "report";
  await emitStart(ctx.emit, stage);
  await emitProgress(ctx.emit, stage, "Assembling the final structured report…");
  await delay(400);

  const report = {
    companyName:
      state.profile?.companyName || state.rawCompany || "Unknown company",
    symbol: state.symbol,
    exchange: state.profile?.exchange,
    generatedAt: new Date().toISOString(),
    profile: state.profile,
    financials: state.financialsAnalyzed,
    news: state.newsAnalyzed,
    web: state.webAnalyzed,
    strengths: state.riskData?.strengths ?? [],
    weaknesses: state.riskData?.weaknesses ?? [],
    weakSignals: state.riskData?.weakSignals ?? [],
    opportunities: state.riskData?.opportunities ?? [],
    risks: state.riskData?.risks ?? [],
    decision:
      state.decision ??
      ruleBasedDecision(state),
    sources: state.sources ?? [],
    assumptions: state.assumptions ?? [],
    historicalPrices: state.historicalPrices,
  };

  await emitProgress(ctx.emit, stage, "Report assembled.");
  await emitComplete(ctx.emit, stage, report);
  return { state: { decision: report.decision } };
}
