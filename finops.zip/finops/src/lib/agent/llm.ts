import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { env } from "@/lib/agent/env";

let _gemini: ChatGoogleGenerativeAI | null = null;

export function getGemini(): ChatGoogleGenerativeAI {
  if (_gemini) return _gemini;
  _gemini = new ChatGoogleGenerativeAI({
    model: env.GEMINI_MODEL,
    apiKey: env.GEMINI_API_KEY,
    temperature: env.GEMINI_TEMPERATURE,
    maxOutputTokens: env.GEMINI_MAX_TOKENS,
  });
  return _gemini;
}

export function extractJson(raw: string): unknown | null {
  if (!raw) return null;
  let text = raw.trim();

  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenceMatch) {
    text = fenceMatch[1].trim();
  }

  const start = text.search(/[\[{]/);
  if (start === -1) return null;
  const openChar = text[start];
  const closeChar = openChar === "{" ? "}" : "]";
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escape) {
        escape = false;
      } else if (ch === "\\") {
        escape = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
      continue;
    }
    if (ch === openChar) depth++;
    else if (ch === closeChar) {
      depth--;
      if (depth === 0) {
        const candidate = text.slice(start, i + 1);
        try {
          return JSON.parse(candidate);
        } catch {
          return null;
        }
      }
    }
  }
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

export async function callJson<T>(
  prompt: string,
  fallback: T,
  validate?: (value: unknown) => value is T,
): Promise<T> {
  try {
    const model = getGemini();
    const res = await model.invoke([
      { role: "user", content: prompt },
    ]);
    const content = (res as unknown as { content?: unknown })?.content;
    const text =
      typeof content === "string"
        ? content
        : Array.isArray(content)
          ? content
              .map((p: unknown) =>
                typeof p === "string"
                  ? p
                  : (p as { text?: string; content?: string })?.text ??
                    (p as { content?: string })?.content ??
                    "",
              )
              .join("")
          : "";
    const parsed = extractJson(text);
    if (parsed === null || parsed === undefined) return fallback;
    if (validate && !validate(parsed)) return fallback;
    return parsed as T;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const short = msg.split("\n")[0].slice(0, 160);
    return fallback;
  }
}
