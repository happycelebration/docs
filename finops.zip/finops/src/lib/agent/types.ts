export type PipelineStageId =
  | "normalize"
  | "resolve"
  | "gather"
  | "financials"
  | "news"
  | "web"
  | "risk"
  | "synthesize"
  | "report";

export interface StageInfo {
  id: PipelineStageId;
  label: string;
  description: string;
  icon: string;
}

export const PIPELINE_STAGES: StageInfo[] = [
  { id: "normalize", label: "Normalize Input", description: "Cleaning & validating the company name", icon: "Type" },
  { id: "resolve", label: "Resolve Company", description: "Identifying the correct public entity via FMP", icon: "Search" },
  { id: "gather", label: "Gather Data", description: "Pulling profile, financials, news & web context", icon: "Database" },
  { id: "financials", label: "Financial Analysis", description: "Evaluating revenue, margins, balance sheet & ratios", icon: "LineChart" },
  { id: "news", label: "News Analysis", description: "Scanning recent headlines for market-moving signals", icon: "Newspaper" },
  { id: "web", label: "Web Research", description: "Broadening context with Tavily web search", icon: "Globe" },
  { id: "risk", label: "Risk Assessment", description: "Flagging risks, weak signals & red flags", icon: "ShieldAlert" },
  { id: "synthesize", label: "Decision Synthesis", description: "Weighing evidence into an Invest / Pass verdict", icon: "Scale" },
  { id: "report", label: "Report Generation", description: "Composing the final structured research report", icon: "FileText" },
];

export interface CompanyProfile {
  symbol: string;
  companyName: string;
  exchange?: string;
  industry?: string;
  sector?: string;
  description?: string;
  website?: string;
  ceo?: string;
  employees?: string;
  country?: string;
  address?: string;
  marketCap?: number;
  price?: number;
  beta?: number;
  currency?: string;
  isEtf?: boolean;
  isFund?: boolean;
  ipoDate?: string;
}

export interface FinancialSnapshot {
  revenue?: number;
  revenueGrowth?: number;
  grossProfitMargin?: number;
  operatingMargin?: number;
  netProfitMargin?: number;
  eps?: number;
  peRatio?: number;
  pegRatio?: number;
  pbRatio?: number;
  psRatio?: number;
  roe?: number;
  roa?: number;
  debtToEquity?: number;
  currentRatio?: number;
  quickRatio?: number;
  freeCashFlow?: number;
  operatingCashFlow?: number;
  totalCash?: number;
  totalDebt?: number;
  dividendYield?: number;
  payoutRatio?: number;
  asOfDate?: string;
}

export interface HistoricalPricePoint {
  date: string;
  close: number;
  volume?: number;
}

export interface NewsItem {
  title: string;
  source: string;
  url?: string;
  publishedAt?: string;
  description?: string;
  sentiment?: "positive" | "negative" | "neutral";
}

export interface WebResult {
  title: string;
  url: string;
  snippet?: string;
  score?: number;
  publishedDate?: string;
}

export interface FinancialHighlight {
  label: string;
  value: string;
  tone?: "positive" | "negative" | "neutral";
  note?: string;
}

export interface AnalyzedFinancials {
  highlights: FinancialHighlight[];
  summary: string;
  dataQuality: "full" | "partial" | "limited";
}

export interface NewsAnalysis {
  highlights: { title: string; sentiment: "positive" | "negative" | "neutral"; source: string; date?: string }[];
  summary: string;
  overallSentiment: "positive" | "negative" | "neutral" | "mixed";
}

export interface WebAnalysis {
  highlights: { title: string; snippet: string; url: string }[];
  summary: string;
  themes: string[];
}

export interface RiskItem {
  title: string;
  severity: "low" | "medium" | "high";
  detail: string;
}

export interface StrengthItem {
  title: string;
  detail: string;
}

export interface WeakSignal {
  title: string;
  detail: string;
}

export interface OpportunitySignal {
  title: string;
  detail: string;
}

export interface RiskAssessmentBundleLike {
  strengths: StrengthItem[];
  weaknesses: StrengthItem[];
  weakSignals: WeakSignal[];
  opportunities: OpportunitySignal[];
  risks: RiskItem[];
}

export type Recommendation = "INVEST" | "PASS" | "HOLD";

export interface InvestmentDecision {
  recommendation: Recommendation;
  investmentScore: number;
  confidence: number;
  verdict: string;
  reasoning: string[];
  thesis: string;
}

export interface AssumptionNote {
  note: string;
}

export type SourceType = "fmp" | "tavily" | "newsapi" | "gemini";

export interface SourceRef {
  type: SourceType;
  label: string;
  url?: string;
  detail?: string;
}

export interface InvestmentReport {
  companyName: string;
  symbol?: string;
  exchange?: string;
  generatedAt: string;
  profile?: CompanyProfile;
  financials?: AnalyzedFinancials;
  news?: NewsAnalysis;
  web?: WebAnalysis;
  strengths: StrengthItem[];
  weaknesses: StrengthItem[];
  weakSignals: WeakSignal[];
  opportunities: OpportunitySignal[];
  risks: RiskItem[];
  decision: InvestmentDecision;
  sources: SourceRef[];
  assumptions: AssumptionNote[];
  historicalPrices?: HistoricalPricePoint[];
}

export interface StageStartEvent {
  type: "stage_start";
  stage: PipelineStageId;
  label: string;
  description: string;
  message?: string;
}

export interface StageProgressEvent {
  type: "stage_progress";
  stage: PipelineStageId;
  message: string;
}

export interface StageCompleteEvent {
  type: "stage_complete";
  stage: PipelineStageId;
  payload?: Partial<InvestmentReport>;
}

export interface ErrorEvent {
  type: "error";
  stage?: PipelineStageId;
  message: string;
  recoverable: boolean;
}

export interface CompleteEvent {
  type: "complete";
  report: InvestmentReport;
}

export type AgentEvent =
  | StageStartEvent
  | StageProgressEvent
  | StageCompleteEvent
  | ErrorEvent
  | CompleteEvent;

export interface AnalyzeRequest {
  company: string;
}
