import type {
  AgentEvent,
  InvestmentReport,
  PipelineStageId,
} from "@/lib/agent/types";
import type { AgentStateType } from "@/lib/agent/state";
import { env } from "@/lib/agent/env";

import {
  analyzeFinancialsNode,
  analyzeNewsNode,
  gatherDataNode,
  normalizeInputNode,
  reportGenerationNode,
  resolveCompanyNode,
  riskAssessmentNode,
  synthesizeDecisionNode,
  webResearchNode,
  type NodeEmit,
  type NodeResult,
} from "@/lib/agent/nodes";

interface NodeStep {
  id: PipelineStageId;
  fn: (state: AgentStateType, ctx: { emit: NodeEmit }) => Promise<NodeResult>;
}

const STEPS: NodeStep[] = [
  { id: "normalize", fn: normalizeInputNode },
  { id: "resolve", fn: resolveCompanyNode },
  { id: "gather", fn: gatherDataNode },
  { id: "financials", fn: analyzeFinancialsNode },
  { id: "news", fn: analyzeNewsNode },
  { id: "web", fn: webResearchNode },
  { id: "risk", fn: riskAssessmentNode },
  { id: "synthesize", fn: synthesizeDecisionNode },
  { id: "report", fn: reportGenerationNode },
];

function mergeState(
  state: AgentStateType,
  patch: Partial<AgentStateType>,
): AgentStateType {
  const next: AgentStateType = { ...state };
  for (const [k, v] of Object.entries(patch)) {
    const key = k as keyof AgentStateType;
    if (
      Array.isArray(v) &&
      (key === "sources" || key === "assumptions" || key === "errors")
    ) {
      const cur = (state[key] as unknown[] | undefined) || [];
      (next[key] as unknown[]) = [...cur, ...(v as unknown[])];
    } else {
      (next[key] as unknown) = v;
    }
  }
  return next;
}

function buildReport(state: AgentStateType): InvestmentReport {
  const fallbackDecision = {
    recommendation: "HOLD" as const,
    investmentScore: 50,
    confidence: 10,
    verdict: "Analysis was interrupted before a final verdict could be synthesized.",
    reasoning: [
      "The pipeline did not complete the decision-synthesis stage.",
      "Treat this report as preliminary; manually review the gathered data.",
    ],
    thesis:
      "This thesis was generated as a fallback because the pipeline was interrupted before final synthesis.",
  };

  return {
    companyName:
      state.profile?.companyName || state.rawCompany || "Unknown company",
    symbol: state.symbol,
    exchange: state.profile?.exchange,
    generatedAt: new Date().toISOString(),
    profile: state.profile,
    financials: state.financialsAnalyzed,
    news: state.newsAnalyzed,
    web: state.webAnalyzed,
    strengths: state.riskData?.strengths ?? [],
    weaknesses: state.riskData?.weaknesses ?? [],
    weakSignals: state.riskData?.weakSignals ?? [],
    opportunities: state.riskData?.opportunities ?? [],
    risks: state.riskData?.risks ?? [],
    decision: state.decision ?? fallbackDecision,
    sources: state.sources ?? [],
    assumptions: state.assumptions ?? [],
    historicalPrices: state.historicalPrices,
  };
}

export async function runAnalysis(
  company: string,
  emit: (event: AgentEvent) => Promise<void> | void,
): Promise<void> {
  const safeEmit: NodeEmit = async (event) => {
    try {
      await emit(event);
    } catch {
    }
  };

  let state: AgentStateType = {
    rawCompany: (company || "").trim(),
    symbol: undefined,
    profile: undefined,
    financialsRaw: undefined,
    newsRaw: undefined,
    webRaw: undefined,
    historicalPrices: undefined,
    financialsAnalyzed: undefined,
    newsAnalyzed: undefined,
    webAnalyzed: undefined,
    riskData: undefined,
    decision: undefined,
    sources: [],
    assumptions: [],
    errors: [],
  };

  let timedOut = false;
  const timeoutHandle = setTimeout(() => {
    timedOut = true;
  }, env.RUN_TIMEOUT_MS);

  try {
    for (const step of STEPS) {
      if (timedOut) break;
      try {
        const result = await step.fn(state, { emit: safeEmit });
        if (result?.state) {
          state = mergeState(state, result.state);
        }
      } catch (err) {
        const message =
          err instanceof Error ? err.message : "Unknown node error";
        state = mergeState(state, {
          errors: [`${step.id}: ${message}`],
          assumptions: [
            {
              note: `Stage "${step.id}" failed unexpectedly: ${message}. The pipeline continued with degraded state for this stage.`,
            },
          ],
        });
        await safeEmit({
          type: "error",
          stage: step.id,
          message: `Stage "${step.id}" failed unexpectedly — proceeding with degraded state.`,
          recoverable: true,
        });
      }
    }

    if (timedOut) {
      state = mergeState(state, {
        assumptions: [
          {
            note: `Analysis was interrupted after ${Math.round(
              env.RUN_TIMEOUT_MS / 1000,
            )}s (top-level timeout). The report reflects partial state.`,
          },
        ],
        errors: ["Top-level timeout exceeded."],
      });
      await safeEmit({
        type: "error",
        message: `Analysis timed out after ${Math.round(
          env.RUN_TIMEOUT_MS / 1000,
        )}s — returning a degraded report.`,
        recoverable: true,
      });
    }

    const report = buildReport(state);
    await safeEmit({ type: "complete", report });
  } finally {
    clearTimeout(timeoutHandle);
  }
}
