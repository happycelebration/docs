import type {
  AnalyzedFinancials,
  CompanyProfile,
  FinancialSnapshot,
  InvestmentDecision,
  NewsAnalysis,
  NewsItem,
  RiskItem,
  StrengthItem,
  OpportunitySignal,
  WeakSignal,
  WebAnalysis,
  WebResult,
} from "@/lib/agent/types";

const STRICT_PREAMBLE = `You are a senior equity research analyst AI.
You MUST return STRICT JSON ONLY — no markdown, no prose, no code fences.
If you do not know a value, OMIT the field or set it to null. NEVER fabricate numbers, dates, sources, or quotes.
Only use the data provided in the prompt. If data is missing or partial, reflect that in your output (lower confidence, "N/A" strings, etc.).
`;

export function PROMPT_RESOLVE(
  rawCompany: string,
  candidates: { symbol: string; name: string; exchange?: string }[],
): string {
  return `${STRICT_PREAMBLE}

A user typed the free-text company name: "${rawCompany}".

Here are candidate matches from Financial Modeling Prep's search API:
${JSON.stringify(candidates, null, 2)}

Pick the single best candidate that is most likely the public company the user meant.
Prefer:
  1. Exact or near-exact name matches (case-insensitive).
  2. Common-stock listings on major US exchanges (NASDAQ, NYSE) over ETFs/funds.
  3. The entity whose name is closest in meaning to the user's input.

Return STRICT JSON ONLY matching:
{
  "symbol": string,           // the chosen ticker, e.g. "AAPL"
  "name": string,             // the chosen company name
  "exchange": string | null,
  "confidence": "high" | "medium" | "low"
}
`;
}

export function PROMPT_FINANCIAL_ANALYSIS(
  profile: CompanyProfile | null | undefined,
  snapshot: FinancialSnapshot,
): string {
  return `${STRICT_PREAMBLE}

Analyze the financial health of the company below. Use ONLY the provided
numbers. Convert raw ratios into plain-English highlights (e.g. "P/E of 12.4 —
below sector median", "Debt-to-equity 1.8 — elevated"). For each highlight,
assign a tone (positive / negative / neutral).

COMPANY PROFILE:
${JSON.stringify(profile || {}, null, 2)}

FINANCIAL SNAPSHOT (ratios + income + cash flow + balance sheet):
${JSON.stringify(snapshot, null, 2)}

Return STRICT JSON ONLY matching this schema:
{
  "highlights": [
    {
      "label": string,          // e.g. "P/E Ratio"
      "value": string,          // e.g. "12.4" or "N/A"
      "tone": "positive" | "negative" | "neutral",
      "note": string            // short plain-English explanation
    }
  ],
  "summary": string,            // 2-4 sentence overall financial summary
  "dataQuality": "full" | "partial" | "limited"
}

Rules:
- Include at least 4 highlights covering valuation, profitability, growth, and balance-sheet strength (where data exists).
- If a metric is missing, set value to "N/A" and tone to "neutral".
- Set dataQuality to "full" if >= 8 metrics present, "partial" if 4-7, "limited" if < 4.
`;
}

export function PROMPT_NEWS_ANALYSIS(
  companyName: string,
  news: NewsItem[],
): string {
  return `${STRICT_PREAMBLE}

Below are recent news headlines about ${companyName}. Classify each headline's
sentiment (positive / negative / neutral) and write a 2-3 sentence overall
summary. Do NOT invent headlines — only summarize what is provided.

NEWS ITEMS:
${JSON.stringify(
  news.map((n) => ({
    title: n.title,
    source: n.source,
    url: n.url,
    publishedAt: n.publishedAt,
    description: n.description,
  })),
  null,
  2,
)}

Return STRICT JSON ONLY matching:
{
  "highlights": [
    {
      "title": string,                              // the headline (verbatim or lightly trimmed)
      "sentiment": "positive" | "negative" | "neutral",
      "source": string,                              // e.g. "Reuters"
      "date": string | null                          // ISO date or null
    }
  ],
  "summary": string,                                 // 2-3 sentence summary
  "overallSentiment": "positive" | "negative" | "neutral" | "mixed"
}
`;
}

export function PROMPT_WEB_ANALYSIS(
  companyName: string,
  results: WebResult[],
): string {
  return `${STRICT_PREAMBLE}

Below are web search results about ${companyName}. Synthesize them into a short
list of theme highlights and identify 2-5 recurring themes. Do NOT invent
sources — only reference what is provided.

WEB RESULTS:
${JSON.stringify(
  results.map((r) => ({
    title: r.title,
    url: r.url,
    snippet: r.snippet,
    publishedDate: r.publishedDate,
  })),
  null,
  2,
)}

Return STRICT JSON ONLY matching:
{
  "highlights": [
    {
      "title": string,        // short headline summarizing one result
      "snippet": string,      // 1-2 sentence summary of the source content
      "url": string           // the source URL
    }
  ],
  "summary": string,          // 2-4 sentence overall summary
  "themes": string[]          // 2-5 short theme labels, e.g. "AI monetization", "regulatory pressure"
}
`;
}

export function PROMPT_RISK_STRENGTHS(input: {
  profile: CompanyProfile | null | undefined;
  financialSummary?: string;
  newsSummary?: string;
  webSummary?: string;
  financialSnapshot?: FinancialSnapshot;
}): string {
  return `${STRICT_PREAMBLE}

You are synthesizing risks and strengths for an investment thesis. Use ONLY the
provided context. If a category has no clear evidence, return an empty array
for it — do not invent items.

CONTEXT:
- Company profile: ${JSON.stringify(profileOrEmpty(input.profile), null, 2)}
- Financial snapshot: ${JSON.stringify(input.financialSnapshot || {}, null, 2)}
- Financial analysis summary: ${input.financialSummary || "N/A"}
- News analysis summary: ${input.newsSummary || "N/A"}
- Web research summary: ${input.webSummary || "N/A"}

Return STRICT JSON ONLY matching:
{
  "strengths": [ { "title": string, "detail": string } ],
  "weaknesses": [ { "title": string, "detail": string } ],
  "weakSignals": [ { "title": string, "detail": string } ],
  "opportunities": [ { "title": string, "detail": string } ],
  "risks": [
    {
      "title": string,
      "severity": "low" | "medium" | "high",
      "detail": string
    }
  ]
}

Definitions:
- strengths: clearly evidenced competitive / financial advantages.
- weaknesses: clearly evidenced competitive / financial disadvantages.
- weakSignals: subtle, ambiguous, or early-stage concerns worth monitoring.
- opportunities: plausible upside catalysts.
- risks: events or conditions that could materially hurt the investment. Assign severity honestly.
`;
}

function profileOrEmpty(p: CompanyProfile | null | undefined) {
  if (!p) return {};
  return {
    symbol: p.symbol,
    name: p.companyName,
    industry: p.industry,
    sector: p.sector,
    country: p.country,
    marketCap: p.marketCap,
    beta: p.beta,
  };
}

export function PROMPT_DECISION(input: {
  profile: CompanyProfile | null | undefined;
  financialSummary?: string;
  newsSummary?: string;
  webSummary?: string;
  strengths: StrengthItem[];
  weaknesses: StrengthItem[];
  weakSignals: WeakSignal[];
  opportunities: OpportunitySignal[];
  risks: RiskItem[];
  financialSnapshot?: FinancialSnapshot;
  financialDataQuality?: "full" | "partial" | "limited";
  newsSentiment?: NewsAnalysis["overallSentiment"];
}): string {
  return `${STRICT_PREAMBLE}

You are the final decision-maker. Weigh ALL of the gathered evidence and
produce a thoughtful, conservative investment verdict. Be a disciplined value
investor: reward durable competitive advantages, reasonable valuation, strong
balance sheets and consistent cash generation; penalize elevated leverage,
deteriorating margins, high valuation, and unmitigated risks.

If data is limited, lower your confidence and explicitly note the assumptions
you are making. NEVER fabricate numbers or reasoning.

EVIDENCE:
- Company: ${JSON.stringify(profileOrEmpty(input.profile), null, 2)}
- Financial snapshot: ${JSON.stringify(input.financialSnapshot || {}, null, 2)}
- Financial data quality: ${input.financialDataQuality || "unknown"}
- Financial analysis summary: ${input.financialSummary || "N/A"}
- News summary (sentiment: ${input.newsSentiment || "unknown"}): ${input.newsSummary || "N/A"}
- Web research summary: ${input.webSummary || "N/A"}

STRENGTHS:
${JSON.stringify(input.strengths, null, 2)}

WEAKNESSES:
${JSON.stringify(input.weaknesses, null, 2)}

WEAK SIGNALS:
${JSON.stringify(input.weakSignals, null, 2)}

OPPORTUNITIES:
${JSON.stringify(input.opportunities, null, 2)}

RISKS:
${JSON.stringify(input.risks, null, 2)}

Return STRICT JSON ONLY matching this schema (a InvestmentDecision object):
{
  "recommendation": "INVEST" | "PASS" | "HOLD",
  "investmentScore": number,        // 0-100, higher = more attractive
  "confidence": number,             // 0-100, your confidence in the recommendation
  "verdict": string,                // 1-sentence headline verdict
  "reasoning": string[],            // 3-6 distinct reasoning points, each one sentence
  "thesis": string                  // 2-4 paragraph investment thesis (use \\n between paragraphs)
}

Rules:
- INVEST = clearly attractive risk/reward; HOLD = mixed/uncertain or fairly valued; PASS = clearly unattractive or excessive risk.
- If financial data quality is "limited", cap confidence at 40 and lean toward HOLD unless evidence is overwhelming.
- If any "high" severity risk exists with no clear mitigation, lean toward PASS or HOLD.
- investmentScore and confidence MUST be integers in [0, 100].
`;
}

export type { AnalyzedFinancials, InvestmentDecision, NewsAnalysis, WebAnalysis };
