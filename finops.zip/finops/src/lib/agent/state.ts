import { Annotation } from "@langchain/langgraph";
import type {
  AnalyzedFinancials,
  AssumptionNote,
  CompanyProfile,
  FinancialSnapshot,
  HistoricalPricePoint,
  InvestmentDecision,
  NewsAnalysis,
  NewsItem,
  RiskItem,
  SourceRef,
  StrengthItem,
  WeakSignal,
  OpportunitySignal,
  WebAnalysis,
  WebResult,
} from "@/lib/agent/types";

export interface RiskAssessmentBundle {
  strengths: StrengthItem[];
  weaknesses: StrengthItem[];
  weakSignals: WeakSignal[];
  opportunities: OpportunitySignal[];
  risks: RiskItem[];
}

export const AgentState = Annotation.Root({
  rawCompany: Annotation<string>({
    reducer: (_left, right) => right,
    default: () => "",
  }),

  symbol: Annotation<string | undefined>(),
  profile: Annotation<CompanyProfile | undefined>(),

  financialsRaw: Annotation<FinancialSnapshot | undefined>(),
  newsRaw: Annotation<NewsItem[] | undefined>(),
  webRaw: Annotation<WebResult[] | undefined>(),
  historicalPrices: Annotation<HistoricalPricePoint[] | undefined>(),

  financialsAnalyzed: Annotation<AnalyzedFinancials | undefined>(),
  newsAnalyzed: Annotation<NewsAnalysis | undefined>(),
  webAnalyzed: Annotation<WebAnalysis | undefined>(),

  riskData: Annotation<RiskAssessmentBundle | undefined>(),

  decision: Annotation<InvestmentDecision | undefined>(),

  sources: Annotation<SourceRef[]>({
    reducer: (left, right) => [...left, ...right],
    default: () => [],
  }),
  assumptions: Annotation<AssumptionNote[]>({
    reducer: (left, right) => [...left, ...right],
    default: () => [],
  }),
  errors: Annotation<string[]>({
    reducer: (left, right) => [...left, ...right],
    default: () => [],
  }),
});

export type AgentStateType = typeof AgentState.State;
export type AgentStateUpdate = typeof AgentState.Update;
