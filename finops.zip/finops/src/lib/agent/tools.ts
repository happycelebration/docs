import type {
  CompanyProfile,
  FinancialSnapshot,
  HistoricalPricePoint,
  NewsItem,
  WebResult,
} from "@/lib/agent/types";
import { env } from "@/lib/agent/env";

const DEFAULT_TIMEOUT_MS = 12_000;

async function fetchJson<T>(
  url: string,
  init: RequestInit = {},
  timeoutMs = DEFAULT_TIMEOUT_MS,
): Promise<T | null> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(url, {
      ...init,
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        ...(init.headers || {}),
      },
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const text = await res.text();
    if (!text) return null;
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

const FMP_BASE = "https://financialmodelingprep.com/stable";

interface FmpSearchHit {
  symbol: string;
  name?: string;
  exchange?: string;
  currency?: string;
  type?: string;
}

export async function fmpSearchCompany(
  query: string,
): Promise<{ symbol: string; name: string; exchange?: string }[]> {
  if (!env.FMP_API_KEY || !query?.trim()) return [];
  const url = `${FMP_BASE}/search?query=${encodeURIComponent(
    query.trim(),
  )}&limit=8&apikey=${env.FMP_API_KEY}`;
  const data = await fetchJson<FmpSearchHit[]>(url);
  if (!Array.isArray(data)) return [];
  return data
    .filter((h) => h && h.symbol)
    .map((h) => ({
      symbol: h.symbol,
      name: h.name || h.symbol,
      exchange: h.exchange,
    }));
}

const INTL_SUFFIXES = ["", ".NS", ".BO"];

const _profileCache = new Map<string, CompanyProfile | null>();

const EXCHANGE_PREFIX_MAP: Record<string, string> = {
  NSE: ".NS",
  BSE: ".BO",
  BOM: ".BO",
  LSE: ".L",
  TSX: ".TO",
  EPA: ".PA",
  AMS: ".AS",
  SWX: ".SW",
};

function isTickerLike(query: string): boolean {
  const s = query.trim().toUpperCase();
  if (s.length < 1 || s.length > 5) return false;
  return /^[A-Z.]+$/.test(s);
}

async function tryProfileWithSuffixes(
  base: string,
): Promise<{ symbol: string; profile: CompanyProfile }[]> {
  const found: { symbol: string; profile: CompanyProfile }[] = [];
  const sym = base.toUpperCase().replace(/\.(NS|BO|L|TO|DE|PA|AS|SW)$/, "");
  for (const suffix of INTL_SUFFIXES) {
    const candidate = `${sym}${suffix}`;
    const p = await fmpProfile(candidate);
    if (p) found.push({ symbol: candidate, profile: p });
  }
  return found;
}

function scoreProfileAgainstContext(
  profile: CompanyProfile,
  contextText: string,
): number {
  const ctx = contextText.toLowerCase();
  const name = (profile.companyName || "").toLowerCase();
  let score = 0;
  const nameWords = name.split(/\s+/).filter((w) => w.length > 2);
  for (const w of nameWords) {
    const matches = ctx.split(w).length - 1;
    score += matches;
  }
  if (name && ctx.includes(name)) score += 5;
  const symbolPart = (profile.symbol || "").split(".")[0].toLowerCase();
  if (symbolPart && ctx.includes(symbolPart)) score += 1;
  return score;
}

export async function resolveTickerViaTavily(
  company: string,
): Promise<{ symbol: string; source: string } | null> {
  if (!env.TAVILY_API_KEY || !company?.trim()) return null;

  const results = await tavilySearch(`${company} stock ticker company`, {
    maxResults: 6,
    searchDepth: "basic",
  });
  if (results.length === 0) return null;

  const contextText = results
    .map((r) => `${r.title || ""} ${r.snippet || ""}`)
    .join(" ");

  const candidates = new Set<string>();
  const addCandidate = (sym: string) => {
    const s = sym.toUpperCase().replace(/[^A-Z.]/g, "");
    if (s.length < 1 || s.length > 8) return;
    const stop = new Set([
      "A", "I", "THE", "AND", "FOR", "INC", "CORP", "LTD", "OF", "OR",
    ]);
    if (stop.has(s)) return;
    candidates.add(s);
  };

  for (const r of results) {
    const hay = `${r.title || ""} ${r.snippet || ""}`;
    const exchangeMatches = hay.match(
      /\b(?:NASDAQ|NYSE|AMEX|LSE|NSE|BSE|BOM|TSX|EPA|AMS|SWX)\s*[:\s]\s*\(?([A-Z]{1,5})\)?/g,
    );
    if (exchangeMatches) {
      for (const m of exchangeMatches) {
        const tick = m.match(/([A-Z]{1,5})\)?\s*$/);
        if (tick) addCandidate(tick[1]);
      }
    }
    const parenMatches = hay.match(/\(([A-Z]{1,5})\)/g);
    if (parenMatches) {
      for (const m of parenMatches) {
        const tick = m.match(/[A-Z]{1,5}/);
        if (tick) addCandidate(tick[0]);
      }
    }
  }

  if (isTickerLike(company)) {
    candidates.add(company.trim().toUpperCase());
  }

  if (candidates.size === 0) return null;

  const allProfiles: { symbol: string; profile: CompanyProfile; score: number }[] = [];
  const rankedCandidates = [...candidates].slice(0, 3);
  for (const c of rankedCandidates) {
    const group = await tryProfileWithSuffixes(c);
    for (const { symbol, profile } of group) {
      const score = scoreProfileAgainstContext(profile, contextText);
      allProfiles.push({ symbol, profile, score });
    }
    if (allProfiles.length > 0 && allProfiles[0].score >= 3) break;
  }

  if (allProfiles.length === 0) {
    const ranked = [...candidates].slice(0, 3);
    if (ranked.length > 0) {
      return { symbol: ranked[0], source: "Tavily web search (FMP verification unavailable)" };
    }
    return null;
  }

  allProfiles.sort((a, b) => b.score - a.score);
  const best = allProfiles[0];
  return { symbol: best.symbol, source: "Tavily + FMP verification" };
}

interface FmpProfileResponse {
  symbol: string;
  companyName?: string;
  exchange?: string;
  industry?: string;
  sector?: string;
  description?: string;
  website?: string;
  ceo?: string;
  fullTimeEmployees?: string | number;
  country?: string;
  address?: string;
  mktCap?: number;
  price?: number;
  beta?: number;
  currency?: string;
  isEtf?: boolean;
  isFund?: boolean;
  ipoDate?: string;
}

export async function fmpProfile(symbol: string): Promise<CompanyProfile | null> {
  if (!env.FMP_API_KEY || !symbol) return null;
  const cacheKey = symbol.toUpperCase();
  if (_profileCache.has(cacheKey)) return _profileCache.get(cacheKey) ?? null;
  const url = `${FMP_BASE}/profile?symbol=${encodeURIComponent(
    symbol,
  )}&apikey=${env.FMP_API_KEY}`;
  const data = await fetchJson<FmpProfileResponse[]>(url);
  if (!Array.isArray(data) || data.length === 0) {
    _profileCache.set(cacheKey, null);
    return null;
  }
  const p = data[0];
  const profile: CompanyProfile = {
    symbol: p.symbol,
    companyName: p.companyName || p.symbol,
    exchange: p.exchange,
    industry: p.industry,
    sector: p.sector,
    description: p.description,
    website: p.website,
    ceo: p.ceo,
    employees:
      typeof p.fullTimeEmployees === "number"
        ? String(p.fullTimeEmployees)
        : p.fullTimeEmployees,
    country: p.country,
    address: p.address,
    marketCap: typeof p.mktCap === "number" ? p.mktCap : undefined,
    price: typeof p.price === "number" ? p.price : undefined,
    beta: typeof p.beta === "number" ? p.beta : undefined,
    currency: p.currency,
    isEtf: p.isEtf,
    isFund: p.isFund,
    ipoDate: p.ipoDate,
  };
  _profileCache.set(cacheKey, profile);
  return profile;
}

interface FmpRatio {
  date?: string;
  grossProfitMargin?: number;
  operatingProfitMargin?: number;
  ebitMargin?: number;
  netProfitMargin?: number;
  currentRatio?: number;
  quickRatio?: number;
  priceToEarningsRatio?: number;
  priceToEarningsGrowthRatio?: number;
  priceToBookRatio?: number;
  priceToSalesRatio?: number;
  debtToEquityRatio?: number;
  dividendYield?: number;
  dividendPayoutRatio?: number;
  netIncomePerShare?: number;
}

function toPct(v: number | undefined): number | undefined {
  if (v === undefined || v === null || !Number.isFinite(v)) return undefined;
  return Math.abs(v) <= 1 ? v * 100 : v;
}

export async function fmpRatios(symbol: string): Promise<FinancialSnapshot> {
  const empty: FinancialSnapshot = {};
  if (!env.FMP_API_KEY || !symbol) return empty;
  const url = `${FMP_BASE}/ratios?symbol=${encodeURIComponent(
    symbol,
  )}&apikey=${env.FMP_API_KEY}&limit=1`;
  const data = await fetchJson<FmpRatio[]>(url);
  if (!Array.isArray(data) || data.length === 0) return empty;
  const r = data[0];
  return {
    grossProfitMargin: toPct(r.grossProfitMargin),
    operatingMargin: toPct(r.operatingProfitMargin ?? r.ebitMargin),
    netProfitMargin: toPct(r.netProfitMargin),
    currentRatio: r.currentRatio,
    quickRatio: r.quickRatio,
    peRatio: r.priceToEarningsRatio,
    pegRatio: r.priceToEarningsGrowthRatio,
    pbRatio: r.priceToBookRatio,
    psRatio: r.priceToSalesRatio,
    debtToEquity: r.debtToEquityRatio,
    dividendYield: toPct(r.dividendYield),
    payoutRatio: toPct(r.dividendPayoutRatio),
    eps: r.netIncomePerShare,
    asOfDate: r.date,
  };
}

interface FmpIncomeRow {
  date?: string;
  revenue?: number;
  eps?: number;
  epsdiluted?: number;
  netIncome?: number;
}

export async function fmpIncomeStatement(
  symbol: string,
): Promise<FinancialSnapshot> {
  const empty: FinancialSnapshot = {};
  if (!env.FMP_API_KEY || !symbol) return empty;
  const url = `${FMP_BASE}/income-statement?symbol=${encodeURIComponent(
    symbol,
  )}&apikey=${env.FMP_API_KEY}&limit=2`;
  const data = await fetchJson<FmpIncomeRow[]>(url);
  if (!Array.isArray(data) || data.length === 0) return empty;
  const [latest, prev] = data;
  const revenue = typeof latest?.revenue === "number" ? latest.revenue : undefined;
  let revenueGrowth: number | undefined;
  if (
    typeof latest?.revenue === "number" &&
    typeof prev?.revenue === "number" &&
    prev.revenue !== 0
  ) {
    revenueGrowth = ((latest.revenue - prev.revenue) / Math.abs(prev.revenue)) * 100;
  }
  return { revenue, revenueGrowth, asOfDate: latest?.date };
}

interface FmpCashFlowRow {
  date?: string;
  freeCashFlow?: number;
  operatingCashFlow?: number;
}

export async function fmpCashFlowStatement(
  symbol: string,
): Promise<FinancialSnapshot> {
  const empty: FinancialSnapshot = {};
  if (!env.FMP_API_KEY || !symbol) return empty;
  const url = `${FMP_BASE}/cash-flow-statement?symbol=${encodeURIComponent(
    symbol,
  )}&apikey=${env.FMP_API_KEY}&limit=1`;
  const data = await fetchJson<FmpCashFlowRow[]>(url);
  if (!Array.isArray(data) || data.length === 0) return empty;
  const c = data[0];
  return {
    freeCashFlow: c.freeCashFlow,
    operatingCashFlow: c.operatingCashFlow,
    asOfDate: c.date,
  };
}

interface FmpBalanceRow {
  date?: string;
  cashAndCashEquivalents?: number;
  cashAndShortTermInvestments?: number;
  totalDebt?: number;
}

export async function fmpBalanceSheet(
  symbol: string,
): Promise<FinancialSnapshot> {
  const empty: FinancialSnapshot = {};
  if (!env.FMP_API_KEY || !symbol) return empty;
  const url = `${FMP_BASE}/balance-sheet-statement?symbol=${encodeURIComponent(
    symbol,
  )}&apikey=${env.FMP_API_KEY}&limit=1`;
  const data = await fetchJson<FmpBalanceRow[]>(url);
  if (!Array.isArray(data) || data.length === 0) return empty;
  const b = data[0];
  const totalCash =
    typeof b.cashAndShortTermInvestments === "number"
      ? b.cashAndShortTermInvestments
      : b.cashAndCashEquivalents;
  return {
    totalCash,
    totalDebt: b.totalDebt,
    asOfDate: b.date,
  };
}

interface FmpEodRow {
  date: string;
  close: number;
  volume?: number;
}

export async function fmpHistoricalPrices(
  symbol: string,
  from?: string,
  to?: string,
): Promise<HistoricalPricePoint[]> {
  if (!env.FMP_API_KEY || !symbol) return [];
  const toDate = to || new Date().toISOString().slice(0, 10);
  const fromDate =
    from ||
    new Date(Date.now() - 3 * 365 * 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 10);
  const url = `${FMP_BASE}/historical-price-eod/full?symbol=${encodeURIComponent(
    symbol,
  )}&from=${fromDate}&to=${toDate}&apikey=${env.FMP_API_KEY}`;
  const data = await fetchJson<FmpEodRow[]>(url);
  if (!Array.isArray(data) || data.length === 0) return [];

  const asc = [...data].sort((a, b) => a.date.localeCompare(b.date));

  const weekly: HistoricalPricePoint[] = [];
  let lastWeekKey = "";
  for (const row of asc) {
    const d = new Date(row.date + "T00:00:00Z");
    const day = d.getUTCDay();
    const monday = new Date(d);
    monday.setUTCDate(d.getUTCDate() - ((day + 6) % 7));
    const key = monday.toISOString().slice(0, 10);
    if (key !== lastWeekKey) {
      weekly.push({ date: row.date, close: row.close, volume: row.volume });
      lastWeekKey = key;
    } else {
      weekly[weekly.length - 1] = {
        date: row.date,
        close: row.close,
        volume: row.volume,
      };
    }
  }
  return weekly;
}

interface FmpKeyMetricsRow {
  date?: string;
  marketCap?: number;
  returnOnEquity?: number;
  returnOnAssets?: number;
  freeCashFlowYield?: number;
  freeCashFlow?: number;
}

export async function fmpKeyMetrics(
  symbol: string,
): Promise<FinancialSnapshot> {
  const empty: FinancialSnapshot = {};
  if (!env.FMP_API_KEY || !symbol) return empty;
  const url = `${FMP_BASE}/key-metrics?symbol=${encodeURIComponent(
    symbol,
  )}&apikey=${env.FMP_API_KEY}&limit=1`;
  const data = await fetchJson<FmpKeyMetricsRow[]>(url);
  if (!Array.isArray(data) || data.length === 0) return empty;
  const m = data[0];
  return {
    roe: toPct(m.returnOnEquity),
    roa: toPct(m.returnOnAssets),
    asOfDate: m.date,
  };
}

export function combineFinancials(
  ...parts: (FinancialSnapshot | null | undefined)[]
): FinancialSnapshot {
  const out: FinancialSnapshot = {};
  const keys: (keyof FinancialSnapshot)[] = [
    "revenue",
    "revenueGrowth",
    "grossProfitMargin",
    "operatingMargin",
    "netProfitMargin",
    "eps",
    "peRatio",
    "pegRatio",
    "pbRatio",
    "psRatio",
    "roe",
    "roa",
    "debtToEquity",
    "currentRatio",
    "quickRatio",
    "freeCashFlow",
    "operatingCashFlow",
    "totalCash",
    "totalDebt",
    "dividendYield",
    "payoutRatio",
    "asOfDate",
  ];
  for (const part of parts) {
    if (!part) continue;
    for (const k of keys) {
      const v = part[k];
      if (out[k] === undefined && v !== undefined && v !== null) {
        (out[k] as unknown) = v;
      }
    }
  }
  if (!out.asOfDate) {
    out.asOfDate = new Date().toISOString().slice(0, 10);
  }
  return out;
}

interface TavilyResult {
  title?: string;
  url?: string;
  content?: string;
  score?: number;
  published_date?: string;
}

interface TavilyResponse {
  results?: TavilyResult[];
  answer?: string;
}

export async function tavilySearch(
  query: string,
  opts?: { maxResults?: number; searchDepth?: "basic" | "advanced" },
): Promise<WebResult[]> {
  if (!env.TAVILY_API_KEY || !query?.trim()) return [];
  const body = {
    api_key: env.TAVILY_API_KEY,
    query,
    max_results: opts?.maxResults ?? 6,
    search_depth: opts?.searchDepth ?? "basic",
    include_answer: false,
  };
  const data = await fetchJson<TavilyResponse>(
    "https://api.tavily.com/search",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
    15_000,
  );
  if (!data || !Array.isArray(data.results)) return [];
  return data.results
    .filter((r) => r && r.url)
    .map((r) => ({
      title: r.title || r.url || "Untitled",
      url: r.url as string,
      snippet: r.content,
      score: typeof r.score === "number" ? r.score : undefined,
      publishedDate: r.published_date,
    }));
}

interface NewsApiArticle {
  title?: string;
  description?: string;
  url?: string;
  publishedAt?: string;
  source?: { name?: string };
}

interface NewsApiResponse {
  status?: string;
  articles?: NewsApiArticle[];
}

export async function newsApiEverything(
  query: string,
  opts?: { pageSize?: number; from?: string },
): Promise<NewsItem[]> {
  if (!env.NEWS_API_KEY || !query?.trim()) return [];
  const pageSize = Math.min(opts?.pageSize ?? 12, 30);
  const fromDate =
    opts?.from ||
    new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const params = new URLSearchParams({
    q: query,
    sortBy: "publishedAt",
    pageSize: String(pageSize),
    from: fromDate,
    language: "en",
    apiKey: env.NEWS_API_KEY,
  });
  const url = `https://newsapi.org/v2/everything?${params.toString()}`;
  const data = await fetchJson<NewsApiResponse>(url);
  if (!data || !Array.isArray(data.articles)) return [];
  return data.articles
    .filter((a) => a && (a.title || a.url))
    .map((a) => ({
      title: a.title || "Untitled",
      source: a.source?.name || "Unknown",
      url: a.url,
      publishedAt: a.publishedAt,
      description: a.description,
    }));
}

interface WikiResponse {
  query?: {
    pages?: Record<
      string,
      { title?: string; extract?: string; fullurl?: string }
    >;
  };
}

export async function fetchCompanyDescription(
  company: string,
): Promise<string | null> {
  if (!company?.trim()) return null;
  const queries = [
    `${company.trim()}`,
    `${company.trim()} Inc`,
    `${company.trim()} company`,
    `${company.trim()} Corporation`,
  ];
  for (const q of queries) {
    const params = new URLSearchParams({
      action: "query",
      format: "json",
      prop: "extracts",
      exintro: "1",
      explaintext: "1",
      redirects: "1",
      titles: q,
    });
    const url = `https://en.wikipedia.org/w/api.php?${params.toString()}`;
    let data: WikiResponse | null = null;
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10_000);
      const res = await fetch(url, {
        signal: controller.signal,
        headers: {
          Accept: "application/json",
          "User-Agent": "FinOpsAgent/1.0 (investment research; contact@finopsagent.ai)",
        },
      });
      clearTimeout(timer);
      if (res.ok) {
        data = (await res.json()) as WikiResponse;
      }
    } catch {
      data = null;
    }
    const pages = data?.query?.pages;
    if (!pages) continue;
    for (const key of Object.keys(pages)) {
      const p = pages[key];
      if (p?.extract && !p.extract.startsWith("may refer to") && p.extract.length > 100) {
        if (/fruit|tree|grow|orchard|cultivar/i.test(p.extract) && !/company|corporation|inc/i.test(company)) continue;
        return p.extract.slice(0, 1200);
      }
    }
  }
  return null;
}

export async function fetchCompanyProfileViaTavily(
  company: string,
  symbol?: string,
): Promise<Partial<CompanyProfile> | null> {
  if (!env.TAVILY_API_KEY || !company?.trim()) return null;
  const results = await tavilySearch(`${company} company profile about sector industry`, {
    maxResults: 5,
    searchDepth: "basic",
  });
  if (results.length === 0) return null;

  const combined = results
    .map((r) => `${r.title || ""}. ${r.snippet || ""}`)
    .join(" ");

  const profile: Partial<CompanyProfile> = {
    symbol: symbol,
    companyName: company,
  };

  const websiteMatch = combined.match(/https?:\/\/(?:www\.)?([a-z0-9.-]+\.[a-z]{2,})/i);
  if (websiteMatch) {
    const domain = websiteMatch[1].toLowerCase();
    const skip = new Set(["wikipedia.org", "reuters.com", "bloomberg.com", "marketwatch.com", "investing.com", "yahoo.com", "fool.com", "seekingalpha.com", "forbes.com", "cnbc.com"]);
    const parts = domain.split(".");
    const root = parts.length >= 2 ? parts[parts.length - 2] : domain;
    if (![...skip].some((s) => s.includes(root) || root.includes(s.split(".")[0]))) {
      profile.website = `https://${domain}`;
    }
  }

  const sectorMatch = combined.match(/\bsector\s*[:\-]?\s*([A-Z][a-z]+(?:\s+[A-Za-z]+){0,3})/);
  if (sectorMatch) profile.sector = sectorMatch[1].trim();

  const industryMatch = combined.match(/\bindustry\s*[:\-]?\s*([A-Z][a-z]+(?:\s+[A-Za-z]+){0,3})/);
  if (industryMatch) profile.industry = industryMatch[1].trim();

  const ceoMatch = combined.match(/\b(?:CEO|Chief Executive Officer)\s*[:\-]?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})/);
  if (ceoMatch) profile.ceo = ceoMatch[1].trim();

  const countryMatch = combined.match(/\b(?:headquartered|based|based in)\s+(?:in\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})/);
  if (countryMatch) profile.country = countryMatch[1].trim();

  const priceMatch = combined.match(/\$\s*(\d{1,5}(?:\.\d{1,2})?)/);
  if (priceMatch) {
    const p = parseFloat(priceMatch[1]);
    if (p > 0 && p < 100000) profile.price = p;
  }

  const mcapMatch = combined.match(/market\s*(?:cap|capitalization)\s*(?:of|:)?\s*\$?([\d.]+)\s*(billion|trillion|million|B|T|M)/i);
  if (mcapMatch) {
    const num = parseFloat(mcapMatch[1]);
    const unit = mcapMatch[2].toLowerCase();
    const mult = unit.startsWith("t") ? 1e12 : unit.startsWith("b") ? 1e9 : unit.startsWith("m") ? 1e6 : 1;
    profile.marketCap = num * mult;
  }

  const desc = await fetchCompanyDescription(company);
  if (desc) {
    profile.description = desc;
  } else if (results[0]?.snippet) {
    profile.description = results[0].snippet.slice(0, 800);
  }

  return profile;
}

export { sleep as delay };
