export interface AgentEnv {
  GEMINI_API_KEY: string;
  TAVILY_API_KEY?: string;
  FMP_API_KEY?: string;
  NEWS_API_KEY?: string;
  GEMINI_MODEL: string;
  GEMINI_TEMPERATURE: number;
  GEMINI_MAX_TOKENS: number;
  RUN_TIMEOUT_MS: number;
}

function readEnv(): AgentEnv {
  const gemini = process.env.GEMINI_API_KEY?.trim();
  const tavily = process.env.TAVILY_API_KEY?.trim();
  const fmp = process.env.FMP_API_KEY?.trim();
  const news = process.env.NEWS_API_KEY?.trim();

  if (!gemini) {
    throw new Error(
      "[agent/env] GEMINI_API_KEY is missing. Set it in .env before running the agent. " +
        "The LLM is the brain of the pipeline and cannot be substituted.",
    );
  }

  return {
    GEMINI_API_KEY: gemini,
    TAVILY_API_KEY: tavily || undefined,
    FMP_API_KEY: fmp || undefined,
    NEWS_API_KEY: news || undefined,
    GEMINI_MODEL: process.env.GEMINI_MODEL?.trim() || "gemini-2.0-flash",
    GEMINI_TEMPERATURE: Number(process.env.GEMINI_TEMPERATURE ?? 0.3),
    GEMINI_MAX_TOKENS: Number(process.env.GEMINI_MAX_TOKENS ?? 4096),
    RUN_TIMEOUT_MS: Number(process.env.AGENT_RUN_TIMEOUT_MS ?? 90_000),
  };
}

export const env: AgentEnv = readEnv();
