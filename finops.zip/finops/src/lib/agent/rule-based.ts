import type {
  AnalyzedFinancials,
  CompanyProfile,
  FinancialHighlight,
  FinancialSnapshot,
  InvestmentDecision,
  NewsAnalysis,
  NewsItem,
  OpportunitySignal,
  RiskAssessmentBundleLike,
  RiskItem,
  StrengthItem,
  WeakSignal,
  WebAnalysis,
  WebResult,
} from "@/lib/agent/types";

export function formatLargeNumber(n: number | undefined): string {
  if (n === undefined || n === null || !Number.isFinite(n)) return "N/A";
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1e12) return `${sign}$${(abs / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `${sign}$${(abs / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${sign}$${(abs / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `${sign}$${(abs / 1e3).toFixed(2)}K`;
  return `${sign}$${abs.toFixed(2)}`;
}

export function formatPct(n: number | undefined, digits = 1): string {
  if (n === undefined || n === null || !Number.isFinite(n)) return "N/A";
  return `${n.toFixed(digits)}%`;
}

export function formatRatio(n: number | undefined, digits = 2): string {
  if (n === undefined || n === null || !Number.isFinite(n)) return "N/A";
  return n.toFixed(digits);
}

export function formatPlain(n: number | undefined, digits = 2): string {
  if (n === undefined || n === null || !Number.isFinite(n)) return "N/A";
  return n.toFixed(digits);
}

type Tone = "positive" | "negative" | "neutral";

export function ruleBasedFinancialAnalysis(
  profile: CompanyProfile | undefined,
  snap: FinancialSnapshot,
): AnalyzedFinancials {
  const highlights: FinancialHighlight[] = [];

  const add = (
    label: string,
    value: string,
    tone: Tone,
    note?: string,
  ) => highlights.push({ label, value, tone, note });

  if (snap.revenue !== undefined) {
    add("Revenue (TTM)", formatLargeNumber(snap.revenue), "neutral");
  }

  if (snap.revenueGrowth !== undefined) {
    const tone: Tone = snap.revenueGrowth >= 10 ? "positive" : snap.revenueGrowth < 0 ? "negative" : "neutral";
    add("Revenue Growth (YoY)", formatPct(snap.revenueGrowth), tone,
      tone === "positive" ? "Double-digit growth" : tone === "negative" ? "Revenue declining" : "Modest growth");
  }

  if (snap.grossProfitMargin !== undefined) {
    const tone: Tone = snap.grossProfitMargin >= 40 ? "positive" : snap.grossProfitMargin < 20 ? "negative" : "neutral";
    add("Gross Margin", formatPct(snap.grossProfitMargin), tone);
  }

  if (snap.operatingMargin !== undefined) {
    const tone: Tone = snap.operatingMargin >= 15 ? "positive" : snap.operatingMargin < 5 ? "negative" : "neutral";
    add("Operating Margin", formatPct(snap.operatingMargin), tone);
  }

  if (snap.netProfitMargin !== undefined) {
    const tone: Tone = snap.netProfitMargin >= 10 ? "positive" : snap.netProfitMargin < 0 ? "negative" : "neutral";
    add("Net Margin", formatPct(snap.netProfitMargin), tone);
  }

  if (snap.eps !== undefined) {
    add("EPS", `$${formatPlain(snap.eps)}`, snap.eps > 0 ? "positive" : "negative");
  }

  if (snap.peRatio !== undefined && snap.peRatio > 0) {
    const tone: Tone = snap.peRatio < 20 ? "positive" : snap.peRatio > 35 ? "negative" : "neutral";
    add("P/E Ratio", formatRatio(snap.peRatio), tone,
      tone === "positive" ? "Reasonable valuation" : tone === "negative" ? "Premium valuation" : undefined);
  }

  if (snap.pegRatio !== undefined && snap.pegRatio > 0) {
    const tone: Tone = snap.pegRatio < 1.5 ? "positive" : snap.pegRatio > 2.5 ? "negative" : "neutral";
    add("PEG Ratio", formatRatio(snap.pegRatio), tone,
      tone === "positive" ? "Growth reasonably priced" : undefined);
  }

  if (snap.pbRatio !== undefined && snap.pbRatio > 0) {
    const tone: Tone = snap.pbRatio < 3 ? "positive" : snap.pbRatio > 8 ? "negative" : "neutral";
    add("P/B Ratio", formatRatio(snap.pbRatio), tone);
  }

  if (snap.roe !== undefined) {
    const tone: Tone = snap.roe >= 15 ? "positive" : snap.roe < 5 ? "negative" : "neutral";
    add("Return on Equity", formatPct(snap.roe), tone);
  }

  if (snap.roa !== undefined) {
    const tone: Tone = snap.roa >= 8 ? "positive" : snap.roa < 2 ? "negative" : "neutral";
    add("Return on Assets", formatPct(snap.roa), tone);
  }

  if (snap.debtToEquity !== undefined) {
    const tone: Tone = snap.debtToEquity < 0.5 ? "positive" : snap.debtToEquity > 2 ? "negative" : "neutral";
    add("Debt / Equity", formatRatio(snap.debtToEquity), tone,
      tone === "negative" ? "High leverage" : undefined);
  }

  if (snap.currentRatio !== undefined) {
    const tone: Tone = snap.currentRatio >= 1.5 ? "positive" : snap.currentRatio < 1 ? "negative" : "neutral";
    add("Current Ratio", formatRatio(snap.currentRatio), tone,
      tone === "negative" ? "Potential liquidity pressure" : undefined);
  }

  if (snap.freeCashFlow !== undefined) {
    const tone: Tone = snap.freeCashFlow > 0 ? "positive" : "negative";
    add("Free Cash Flow", formatLargeNumber(snap.freeCashFlow), tone);
  }

  if (snap.dividendYield !== undefined && snap.dividendYield > 0) {
    add("Dividend Yield", formatPct(snap.dividendYield), "neutral");
  }

  if (profile?.beta !== undefined) {
    const tone: Tone = profile.beta < 1 ? "positive" : profile.beta > 1.5 ? "negative" : "neutral";
    add("Beta", formatRatio(profile.beta), tone,
      tone === "negative" ? "Higher volatility than market" : undefined);
  }

  const present = highlights.length;
  const dataQuality: AnalyzedFinancials["dataQuality"] =
    present >= 9 ? "full" : present >= 5 ? "partial" : "limited";

  const name = profile?.companyName || "The company";
  const posCount = highlights.filter((h) => h.tone === "positive").length;
  const negCount = highlights.filter((h) => h.tone === "negative").length;
  let summary: string;
  if (present === 0) {
    summary = `${name} has no financial data available from the data provider. Analysis is limited to qualitative signals.`;
  } else {
    const lean = posCount > negCount + 1 ? "broadly healthy" : negCount > posCount + 1 ? "broadly weak" : "mixed";
    const growthBit =
      snap.revenueGrowth !== undefined
        ? ` Revenue is ${snap.revenueGrowth >= 0 ? "growing" : "contracting"} at ${formatPct(Math.abs(snap.revenueGrowth))} YoY.`
        : "";
    const valBit =
      snap.peRatio !== undefined && snap.peRatio > 0
        ? ` The stock trades at ${formatRatio(snap.peRatio)}x earnings (${snap.peRatio < 20 ? "reasonable" : snap.peRatio > 35 ? "premium" : "elevated"} valuation).`
        : "";
    const balanceBit =
      snap.debtToEquity !== undefined
        ? ` Balance-sheet leverage is ${snap.debtToEquity < 0.5 ? "low" : snap.debtToEquity > 2 ? "high" : "moderate"} (D/E ${formatRatio(snap.debtToEquity)}).`
        : "";
    summary = `${name}'s financial profile is ${lean} across ${present} metrics.${growthBit}${valBit}${balanceBit}`;
  }

  return { highlights, summary, dataQuality };
}

const POSITIVE_WORDS = new Set([
  "beat", "beats", "surge", "surging", "record", "growth", "grow", "growing",
  "profit", "profitable", "rise", "rises", "rising", "gain", "gains", "strong",
  "robust", "upgrade", "outperform", "bullish", "jump", "jumps", "soar", "soars",
  "win", "wins", "launch", "launches", "breakthrough", "approve", "approval",
  "partnership", "acquire", "acquisition", "dividend", "buyback", "raise",
  "rally", "rebound", "innovation", "innovative", "expand", "expansion",
  "boost", "beat expectations", "exceed", "exceeds", "milestone",
]);

const NEGATIVE_WORDS = new Set([
  "miss", "misses", "fall", "falls", "falling", "decline", "declines",
  "loss", "losses", "lawsuit", "sue", "sued", "fraud", "probe", "investigation",
  "downgrade", "underperform", "bearish", "drop", "drops", "plunge", "crash",
  "cut", "cuts", "layoff", "layoffs", "recall", "bankruptcy", "default",
  "weak", "warning", "warn", "warns", "delay", "delayed", "halt", "halted",
  "suspend", "resign", "resigns", "fired", "scandal", "setback", "slump",
  "tumble", "shrink", "shrinks", "missed", "weakness", "pressure", "pressured",
]);

function classifySentiment(text: string): Tone {
  const lower = text.toLowerCase();
  let pos = 0;
  let neg = 0;
  for (const w of POSITIVE_WORDS) {
    if (lower.includes(w)) pos++;
  }
  for (const w of NEGATIVE_WORDS) {
    if (lower.includes(w)) neg++;
  }
  if (pos > neg) return "positive";
  if (neg > pos) return "negative";
  return "neutral";
}

export function ruleBasedNewsAnalysis(
  companyName: string,
  news: NewsItem[],
): NewsAnalysis {
  if (news.length === 0) {
    return {
      highlights: [],
      summary: `No recent news was found for ${companyName} in the last 30 days.`,
      overallSentiment: "neutral",
    };
  }

  const highlights = news.slice(0, 8).map((item) => {
    const sentiment = classifySentiment(`${item.title} ${item.description || ""}`);
    return {
      title: item.title,
      sentiment,
      source: item.source,
      date: item.publishedAt?.slice(0, 10),
    };
  });

  const pos = highlights.filter((h) => h.sentiment === "positive").length;
  const neg = highlights.filter((h) => h.sentiment === "negative").length;
  const neu = highlights.filter((h) => h.sentiment === "neutral").length;

  let overallSentiment: NewsAnalysis["overallSentiment"];
  if (pos > neg + neu) overallSentiment = "positive";
  else if (neg > pos + neu) overallSentiment = "negative";
  else if (pos > 0 && neg > 0) overallSentiment = "mixed";
  else overallSentiment = "neutral";

  const summary =
    `Of ${highlights.length} recent headlines, ${pos} skew positive, ${neg} negative, and ${neu} neutral. ` +
    `Overall news sentiment for ${companyName} is ${overallSentiment}.`;

  return { highlights, summary, overallSentiment };
}

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of",
  "with", "by", "from", "is", "are", "was", "were", "be", "been", "being",
  "this", "that", "these", "those", "it", "its", "as", "has", "have", "had",
  "will", "would", "could", "should", "may", "might", "can", "about", "into",
  "over", "under", "after", "before", "between", "through", "during", "more",
  "most", "than", "then", "so", "such", "very", "just", "also", "only", "up",
  "down", "out", "not", "no", "yes", "you", "your", "they", "their", "we",
  "our", "he", "she", "his", "her", "company", "stock", "shares", "said",
  "says", "inc", "corp", "ltd", "co", "new", "one", "two", "percent", "per",
  "cent", "million", "billion", "trillion", "us", "via", "amid", "amidst",
  "while", "which", "who", "whom", "whose", "what", "when", "where", "why",
  "how", "all", "any", "both", "each", "few", "other", "some", "such",
]);

export function ruleBasedWebAnalysis(
  companyName: string,
  web: WebResult[],
): WebAnalysis {
  if (web.length === 0) {
    return {
      highlights: [],
      summary: `No web research results were available for ${companyName}.`,
      themes: [],
    };
  }

  const highlights = web.slice(0, 5).map((r) => ({
    title: r.title,
    snippet: (r.snippet || "").slice(0, 220),
    url: r.url,
  }));

  const freq = new Map<string, number>();
  const companyNameLower = companyName.toLowerCase();
  const companyFirstWord = companyNameLower.split(/\s+/)[0] ?? "";
  for (const r of web) {
    let text = `${r.title || ""} ${r.snippet || ""}`.toLowerCase();
    text = text.replace(/https?:\/\/\S+/g, " ").replace(/www\.\S+/g, " ");
    const tokens = text.match(/[a-z][a-z-]{3,}/g) || [];
    for (const t of tokens) {
      if (STOPWORDS.has(t)) continue;
      if (t.length < 4) continue;
      if (companyNameLower.includes(t) || (companyFirstWord && t.includes(companyFirstWord))) continue;
      if (["aapl", "msft", "googl", "amzn", "xnas", "xnys", "nyse", "nasdaq"].includes(t)) continue;
      freq.set(t, (freq.get(t) ?? 0) + 1);
    }
  }
  const themes = [...freq.entries()]
    .filter(([, c]) => c >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([w]) => w);

  const summary =
    `Web research surfaced ${web.length} results` +
    (themes.length > 0 ? ` with recurring themes: ${themes.join(", ")}.` : ".");

  return { highlights, summary, themes };
}

export function ruleBasedRiskAssessment(state: {
  profile?: CompanyProfile;
  financialsRaw?: FinancialSnapshot;
  financialsAnalyzed?: AnalyzedFinancials;
  newsAnalyzed?: NewsAnalysis;
  webAnalyzed?: WebAnalysis;
}): RiskAssessmentBundleLike {
  const fin = state.financialsRaw ?? {};
  const news = state.newsAnalyzed;
  const strengths: StrengthItem[] = [];
  const weaknesses: StrengthItem[] = [];
  const weakSignals: WeakSignal[] = [];
  const opportunities: OpportunitySignal[] = [];
  const risks: RiskItem[] = [];

  if (fin.netProfitMargin !== undefined && fin.netProfitMargin >= 15) {
    strengths.push({
      title: "High net profitability",
      detail: `Net margin of ${formatPct(fin.netProfitMargin)} indicates strong pricing power and cost control.`,
    });
  }
  if (fin.grossProfitMargin !== undefined && fin.grossProfitMargin >= 40) {
    strengths.push({
      title: "Strong gross margins",
      detail: `Gross margin of ${formatPct(fin.grossProfitMargin)} suggests a defensible, premium offering.`,
    });
  }
  if (fin.roe !== undefined && fin.roe >= 18) {
    strengths.push({
      title: "Excellent returns on equity",
      detail: `ROE of ${formatPct(fin.roe)} shows efficient reinvestment of shareholder capital.`,
    });
  }

  if (fin.revenueGrowth !== undefined && fin.revenueGrowth >= 10) {
    strengths.push({
      title: "Robust top-line growth",
      detail: `Revenue growing at ${formatPct(fin.revenueGrowth)} YoY outpaces most large-cap peers.`,
    });
  }

  if (fin.debtToEquity !== undefined && fin.debtToEquity < 0.5) {
    strengths.push({
      title: "Conservative balance sheet",
      detail: `Debt-to-equity of ${formatRatio(fin.debtToEquity)} leaves ample financial flexibility.`,
    });
  }
  if (fin.freeCashFlow !== undefined && fin.freeCashFlow > 0) {
    strengths.push({
      title: "Positive free cash flow",
      detail: `Generating ${formatLargeNumber(fin.freeCashFlow)} of free cash flow supports dividends, buybacks, and reinvestment.`,
    });
  }

  if (fin.netProfitMargin !== undefined && fin.netProfitMargin < 0) {
    weaknesses.push({
      title: "Net losses",
      detail: `Net margin of ${formatPct(fin.netProfitMargin)} means the company is currently unprofitable.`,
    });
  } else if (fin.netProfitMargin !== undefined && fin.netProfitMargin < 5) {
    weaknesses.push({
      title: "Thin profitability",
      detail: `Net margin of ${formatPct(fin.netProfitMargin)} leaves little room for error.`,
    });
  }

  if (fin.revenueGrowth !== undefined && fin.revenueGrowth < 0) {
    weaknesses.push({
      title: "Revenue contraction",
      detail: `Revenue declined ${formatPct(Math.abs(fin.revenueGrowth))} YoY — demand may be softening.`,
    });
  }

  if (fin.peRatio !== undefined && fin.peRatio > 40) {
    weaknesses.push({
      title: "Premium valuation",
      detail: `P/E of ${formatRatio(fin.peRatio)} prices in high expectations; any miss could trigger a re-rating.`,
    });
  }
  if (fin.pegRatio !== undefined && fin.pegRatio > 2.5) {
    weaknesses.push({
      title: "Growth priced richly",
      detail: `PEG of ${formatRatio(fin.pegRatio)} suggests growth is expensive at current levels.`,
    });
  }

  if (fin.debtToEquity !== undefined && fin.debtToEquity > 2) {
    weaknesses.push({
      title: "High leverage",
      detail: `Debt-to-equity of ${formatRatio(fin.debtToEquity)} elevates financial risk, especially in rising-rate environments.`,
    });
  }
  if (fin.currentRatio !== undefined && fin.currentRatio < 1) {
    weaknesses.push({
      title: "Liquidity pressure",
      detail: `Current ratio of ${formatRatio(fin.currentRatio)} below 1x signals potential short-term liquidity strain.`,
    });
  }

  if (fin.debtToEquity !== undefined && fin.debtToEquity > 3) {
    risks.push({
      title: "Elevated financial leverage",
      severity: "high",
      detail: `Debt-to-equity of ${formatRatio(fin.debtToEquity)} materially increases insolvency risk in a downturn.`,
    });
  }
  if (fin.netProfitMargin !== undefined && fin.netProfitMargin < 0) {
    risks.push({
      title: "Ongoing unprofitability",
      severity: "high",
      detail: `Negative net margin (${formatPct(fin.netProfitMargin)}) raises questions about the path to sustainable profits.`,
    });
  }
  if (fin.revenueGrowth !== undefined && fin.revenueGrowth < -5) {
    risks.push({
      title: "Sharp revenue decline",
      severity: "high",
      detail: `Revenue contracted ${formatPct(Math.abs(fin.revenueGrowth))} YoY — possible structural demand erosion.`,
    });
  }
  if (state.profile?.beta !== undefined && state.profile.beta > 1.6) {
    risks.push({
      title: "High share-price volatility",
      severity: "medium",
      detail: `Beta of ${formatRatio(state.profile.beta)} means the stock amplifies market swings.`,
    });
  }
  if (fin.payoutRatio !== undefined && fin.payoutRatio > 80) {
    risks.push({
      title: "Strained dividend coverage",
      severity: "medium",
      detail: `Payout ratio of ${formatPct(fin.payoutRatio)} leaves little cushion for the dividend if earnings dip.`,
    });
  }
  if (fin.peRatio !== undefined && fin.peRatio > 50) {
    risks.push({
      title: "Stretched valuation",
      severity: "medium",
      detail: `P/E of ${formatRatio(fin.peRatio)} leaves no margin for execution missteps.`,
    });
  }
  if (news?.overallSentiment === "negative") {
    risks.push({
      title: "Negative recent news flow",
      severity: "medium",
      detail: `Recent headlines skew negative (${news.summary.toLowerCase().split(".")[0]}).`,
    });
  }

  if (fin.pegRatio !== undefined && fin.pegRatio > 1.8 && fin.pegRatio <= 2.5) {
    weakSignals.push({
      title: "Growth becoming pricey",
      detail: `PEG of ${formatRatio(fin.pegRatio)} is creeping above the comfortable range.`,
    });
  }
  if (fin.revenueGrowth !== undefined && fin.revenueGrowth >= 0 && fin.revenueGrowth < 5) {
    weakSignals.push({
      title: "Slowing growth",
      detail: `Revenue growth of ${formatPct(fin.revenueGrowth)} is positive but decelerating.`,
    });
  }
  if (fin.payoutRatio !== undefined && fin.payoutRatio > 60 && fin.payoutRatio <= 80) {
    weakSignals.push({
      title: "Rising payout ratio",
      detail: `Payout ratio of ${formatPct(fin.payoutRatio)} is approaching levels that may constrain reinvestment.`,
    });
  }

  if (news?.overallSentiment === "positive") {
    opportunities.push({
      title: "Positive news momentum",
      detail: "Recent headlines suggest improving sentiment that could support a re-rating.",
    });
  }
  const themes = state.webAnalyzed?.themes ?? [];
  if (themes.includes("ai") || themes.includes("cloud") || themes.includes("innovation")) {
    opportunities.push({
      title: "Secular technology tailwinds",
      detail: "Web research references AI / cloud / innovation themes that could drive durable demand.",
    });
  }
  if (themes.includes("expansion") || themes.includes("launch") || themes.includes("growth")) {
    opportunities.push({
      title: "Expansion narrative",
      detail: "Web research references expansion / new launches that could open incremental revenue.",
    });
  }
  if (fin.revenueGrowth !== undefined && fin.revenueGrowth >= 15 && fin.freeCashFlow !== undefined && fin.freeCashFlow > 0) {
    opportunities.push({
      title: "Compounding growth + cash generation",
      detail: "Combining double-digit growth with positive free cash flow is a rare, attractive profile.",
    });
  }

  return { strengths, weaknesses, weakSignals, opportunities, risks };
}

export function ruleBasedDecision(state: {
  profile?: CompanyProfile;
  financialsRaw?: FinancialSnapshot;
  financialsAnalyzed?: AnalyzedFinancials;
  newsAnalyzed?: NewsAnalysis;
  riskData?: RiskAssessmentBundleLike;
}): InvestmentDecision {
  const fin = state.financialsRaw ?? {};
  const dataQuality = state.financialsAnalyzed?.dataQuality ?? "limited";
  const risks = state.riskData?.risks ?? [];
  const news = state.newsAnalyzed;

  let score = 50;
  const reasons: string[] = [];

  if (fin.netProfitMargin !== undefined) {
    if (fin.netProfitMargin >= 15) { score += 12; reasons.push(`Strong net margin (${formatPct(fin.netProfitMargin)}).`); }
    else if (fin.netProfitMargin >= 8) { score += 6; }
    else if (fin.netProfitMargin < 0) { score -= 15; reasons.push(`Unprofitable (net margin ${formatPct(fin.netProfitMargin)}).`); }
    else { score -= 4; }
  }
  if (fin.roe !== undefined) {
    if (fin.roe >= 18) { score += 8; reasons.push(`High ROE (${formatPct(fin.roe)}).`); }
    else if (fin.roe < 5) { score -= 5; }
  }

  if (fin.revenueGrowth !== undefined) {
    if (fin.revenueGrowth >= 15) { score += 12; reasons.push(`Robust revenue growth (${formatPct(fin.revenueGrowth)} YoY).`); }
    else if (fin.revenueGrowth >= 5) { score += 6; }
    else if (fin.revenueGrowth < 0) { score -= 12; reasons.push(`Revenue contracting (${formatPct(fin.revenueGrowth)} YoY).`); }
    else { score += 2; }
  }

  if (fin.peRatio !== undefined && fin.peRatio > 0) {
    if (fin.peRatio < 18) { score += 8; reasons.push(`Reasonable valuation (P/E ${formatRatio(fin.peRatio)}).`); }
    else if (fin.peRatio > 40) { score -= 10; reasons.push(`Premium valuation (P/E ${formatRatio(fin.peRatio)}).`); }
    else if (fin.peRatio > 30) { score -= 5; }
    else { score += 3; }
  }
  if (fin.pegRatio !== undefined && fin.pegRatio > 0) {
    if (fin.pegRatio < 1.5) { score += 6; }
    else if (fin.pegRatio > 2.5) { score -= 6; reasons.push(`Growth looks expensive (PEG ${formatRatio(fin.pegRatio)}).`); }
  }

  if (fin.debtToEquity !== undefined) {
    if (fin.debtToEquity < 0.5) { score += 7; }
    else if (fin.debtToEquity > 2) { score -= 8; reasons.push(`High leverage (D/E ${formatRatio(fin.debtToEquity)}).`); }
    else if (fin.debtToEquity > 1) { score -= 3; }
  }
  if (fin.currentRatio !== undefined) {
    if (fin.currentRatio >= 1.5) { score += 4; }
    else if (fin.currentRatio < 1) { score -= 5; reasons.push(`Liquidity pressure (current ratio ${formatRatio(fin.currentRatio)}).`); }
  }

  if (fin.freeCashFlow !== undefined) {
    if (fin.freeCashFlow > 0) { score += 8; reasons.push(`Positive free cash flow (${formatLargeNumber(fin.freeCashFlow)}).`); }
    else { score -= 6; reasons.push("Negative free cash flow."); }
  }

  if (news?.overallSentiment === "positive") { score += 8; reasons.push("Recent news sentiment is positive."); }
  else if (news?.overallSentiment === "negative") { score -= 8; reasons.push("Recent news sentiment is negative."); }
  else if (news?.overallSentiment === "mixed") { score -= 2; }

  score = Math.max(5, Math.min(95, Math.round(score)));

  const highRisks = risks.filter((r) => r.severity === "high");

  let recommendation: InvestmentDecision["recommendation"];
  if (highRisks.length >= 2) {
    recommendation = "PASS";
    reasons.unshift(`${highRisks.length} high-severity risks detected — overriding score-based recommendation.`);
  } else if (score >= 65) {
    recommendation = "INVEST";
  } else if (score < 40) {
    recommendation = "PASS";
  } else {
    recommendation = "HOLD";
  }

  const dataPoints = Object.values(fin).filter((v) => v !== undefined && v !== null).length;
  let confidence: number;
  if (dataQuality === "full" && dataPoints >= 12) confidence = 68;
  else if (dataQuality === "partial") confidence = 52;
  else confidence = 32;
  confidence = Math.max(20, confidence - highRisks.length * 8);

  const name = state.profile?.companyName || "This company";
  const hasNoData = dataQuality === "limited" && Object.values(fin).filter((v) => v !== undefined && v !== null).length === 0;

  const verdict = hasNoData
    ? `${name} could not be fully analysed — insufficient financial data was available. Treat this verdict as preliminary.`
    : recommendation === "INVEST"
      ? `${name} screens attractively: a ${score}/100 investment score supported by solid fundamentals and manageable risks.`
      : recommendation === "PASS"
        ? `${name} does not clear the investment bar: a ${score}/100 score${highRisks.length ? " and material high-severity risks" : ""} warrant caution.`
        : `${name} is borderline: a ${score}/100 score with mixed signals — hold pending clearer catalysts.`;

  const thesis = hasNoData
    ? `${name} has insufficient financial data for a reliable assessment (confidence ${confidence}%). The agent could not retrieve key financial metrics, so the verdict defaults to HOLD pending further research. News and web context may still provide useful qualitative signals.`
    : `${name} earns a rule-based investment score of ${score}/100 ` +
      `(confidence ${confidence}%). The verdict is ${recommendation}, driven by: ` +
      reasons.slice(0, 5).join(" ") +
      (reasons.length > 5 ? " Additional factors were considered." : "") +
      ` This assessment is grounded strictly in fetched data; an LLM was not available to add qualitative nuance.`;

  return {
    recommendation,
    investmentScore: score,
    confidence,
    verdict,
    reasoning: reasons.length > 0 ? reasons : ["Insufficient data to generate detailed reasoning; verdict based on available signals."],
    thesis,
  };
}
