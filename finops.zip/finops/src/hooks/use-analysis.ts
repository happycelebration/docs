"use client";

import { useCallback, useRef, useState } from "react";
import {
  PIPELINE_STAGES,
  type AgentEvent,
  type InvestmentReport,
  type PipelineStageId,
} from "@/lib/agent/types";

export type AnalysisStatus = "idle" | "running" | "complete" | "error";

export type StageStatus = "pending" | "running" | "complete" | "error";

export interface LogEntry {
  stage: PipelineStageId;
  message: string;
  ts: number;
}

export interface AnalysisState {
  status: AnalysisStatus;
  currentStage: PipelineStageId | null;
  stageStatuses: Record<PipelineStageId, StageStatus>;
  stageProgress: Record<PipelineStageId, number>;
  logs: LogEntry[];
  partial: Partial<InvestmentReport>;
  report: InvestmentReport | null;
  error: string | null;
  company: string | null;
}

function emptyStageStatuses(): Record<PipelineStageId, StageStatus> {
  const acc = {} as Record<PipelineStageId, StageStatus>;
  for (const s of PIPELINE_STAGES) acc[s.id] = "pending";
  return acc;
}

function emptyStageProgress(): Record<PipelineStageId, number> {
  const acc = {} as Record<PipelineStageId, number>;
  for (const s of PIPELINE_STAGES) acc[s.id] = 0;
  return acc;
}

function initialState(): AnalysisState {
  return {
    status: "idle",
    currentStage: null,
    stageStatuses: emptyStageStatuses(),
    stageProgress: emptyStageProgress(),
    logs: [],
    partial: {},
    report: null,
    error: null,
    company: null,
  };
}

export interface UseAnalysisApi {
  state: AnalysisState;
  analyze: (company: string) => Promise<void>;
  reset: () => void;
}

export function useAnalysis(): UseAnalysisApi {
  const [state, setState] = useState<AnalysisState>(initialState);
  const readerRef = useRef<ReadableStreamDefaultReader<Uint8Array> | null>(null);
  const decoderRef = useRef<TextDecoder>(new TextDecoder());
  const bufferRef = useRef<string>("");
  const cancelledRef = useRef<boolean>(false);

  const reset = useCallback(() => {
    cancelledRef.current = true;
    if (readerRef.current) {
      try {
        readerRef.current.cancel().catch(() => {});
      } catch {
      }
      readerRef.current = null;
    }
    bufferRef.current = "";
    setState(initialState());
  }, []);

  const analyze = useCallback(async (company: string) => {
    cancelledRef.current = false;
    if (readerRef.current) {
      try {
        await readerRef.current.cancel().catch(() => {});
      } catch {
      }
      readerRef.current = null;
    }
    bufferRef.current = "";

    setState({
      ...initialState(),
      status: "running",
      company: company.trim(),
    });

    let res: Response;
    try {
      res = await fetch("/api/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "text/event-stream",
        },
        body: JSON.stringify({ company: company.trim() }),
      });
    } catch (err) {
      if (cancelledRef.current) return;
      setState((s) => ({
        ...s,
        status: "error",
        error:
          err instanceof Error
            ? `Network error: ${err.message}`
            : "Network error — could not reach the analysis server.",
      }));
      return;
    }

    if (!res.ok || !res.body) {
      const text = await res.text().catch(() => "");
      setState((s) => ({
        ...s,
        status: "error",
        error:
          `Analysis request failed (HTTP ${res.status}). ` +
          (text.slice(0, 240) || "No additional detail returned by the server."),
      }));
      return;
    }

    const reader = res.body.getReader();
    readerRef.current = reader;

    const processBuffer = () => {
      const buf = bufferRef.current;
      const frames = buf.split(/\r?\n\r?\n/);
      bufferRef.current = frames.pop() ?? "";

      for (const frame of frames) {
        if (!frame.trim()) continue;
        const dataLines = frame
          .split(/\r?\n/)
          .filter((l) => l.startsWith("data:"))
          .map((l) => l.slice(5).trim());
        if (dataLines.length === 0) continue;
        const payloadStr = dataLines.join("\n");
        let event: AgentEvent;
        try {
          event = JSON.parse(payloadStr) as AgentEvent;
        } catch {
          continue;
        }
        handleEvent(event);
      }
    };

    const handleEvent = (event: AgentEvent) => {
      if (cancelledRef.current) return;
      switch (event.type) {
        case "stage_start": {
          setState((s) => ({
            ...s,
            currentStage: event.stage,
            stageStatuses: { ...s.stageStatuses, [event.stage]: "running" },
            stageProgress: { ...s.stageProgress, [event.stage]: 0 },
            logs: event.message
              ? [
                  ...s.logs,
                  {
                    stage: event.stage,
                    message: event.message,
                    ts: Date.now(),
                  },
                ]
              : s.logs,
          }));
          break;
        }
        case "stage_progress": {
          setState((s) => ({
            ...s,
            currentStage: event.stage,
            logs: [
              ...s.logs,
              { stage: event.stage, message: event.message, ts: Date.now() },
            ],
          }));
          break;
        }
        case "stage_complete": {
          setState((s) => ({
            ...s,
            stageStatuses: { ...s.stageStatuses, [event.stage]: "complete" },
            stageProgress: { ...s.stageProgress, [event.stage]: 100 },
            partial: event.payload
              ? { ...s.partial, ...event.payload }
              : s.partial,
          }));
          break;
        }
        case "error": {
          const message = event.message;
          if (event.recoverable) {
            setState((s) => ({
              ...s,
              logs: [
                ...s.logs,
                {
                  stage: event.stage ?? s.currentStage ?? "gather",
                  message: `⚠ ${message}`,
                  ts: Date.now(),
                },
              ],
              error: message,
            }));
          } else {
            setState((s) => ({
              ...s,
              status: "error",
              error: message,
              stageStatuses: event.stage
                ? { ...s.stageStatuses, [event.stage]: "error" }
                : s.stageStatuses,
            }));
          }
          break;
        }
        case "complete": {
          setState((s) => ({
            ...s,
            status: "complete",
            report: event.report,
            partial: event.report,
            error: null,
          }));
          break;
        }
      }
    };

    try {
      while (true) {
        if (cancelledRef.current) break;
        const { done, value } = await reader.read();
        if (done) break;
        if (!value) continue;
        const chunk = decoderRef.current.decode(value, { stream: true });
        bufferRef.current += chunk;
        processBuffer();
      }
      if (bufferRef.current.trim()) {
        processBuffer();
      }
    } catch (err) {
      if (cancelledRef.current) return;
      setState((s) => ({
        ...s,
        status: "error",
        error:
          err instanceof Error
            ? `Stream interrupted: ${err.message}`
            : "Stream interrupted unexpectedly.",
      }));
    } finally {
      readerRef.current = null;
      try {
        reader.releaseLock();
      } catch {
      }
    }
  }, []);

  return { state, analyze, reset };
}
