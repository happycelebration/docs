# Development Diary — FinOps Agent

This is my engineering journal for the FinOps Agent project. It records what I built, the problems I hit, the decisions I made, and where I used AI assistance along the way. It is written after the fact from memory, the worklog, and the code itself.

I used an AI coding assistant throughout this project — for generating boilerplate, debugging, writing prompts, and reviewing my approach. Every piece of generated code was reviewed and often modified by me. The architecture, the API choices, the fallback strategy, and the rule-based engine were my decisions. Where the AI produced code I did not understand or agree with, I changed it or removed it.

---

## 1. Starting point and stack decision

The assignment asked for an AI Investment Research Agent: give it a company name, it researches the company, weighs the evidence, and decides whether to invest or pass — with reasoning and sources. The required stack was React or Next.js on the front end, Node or Next.js on the back end, and LangChain.js or LangGraph.js for the AI layer. Free choice of LLM and APIs.

I chose Next.js 16 for both front and back end. The main reason was simplicity: one codebase, one deployment, shared TypeScript types between the server and the client. Next.js App Router route handlers can return a `ReadableStream`, which is exactly what I needed for the server-sent events (SSE) streaming that carries the agent's progress to the browser.

For the AI layer I picked LangGraph.js. I wanted a state graph with clearly named nodes rather than a free-form chain, because the investment workflow has distinct stages (resolve company, gather data, analyze financials, analyze news, assess risk, synthesize decision) that I wanted to be able to reason about and document individually.

For data sources I chose four APIs, each covering a different need:
- **Financial Modeling Prep (FMP)** for company profiles, financial statements, ratios, and price history.
- **Tavily** for web search and broader context.
- **NewsAPI** for recent headlines.
- **Google Gemini** for reasoning and summarization.

I considered Alpha Vantage and Polygon for financials, but FMP had the broadest endpoint set for the price. For web search I looked at SerpAPI and Brave Search, but Tavily is purpose-built for AI agents and returns clean text snippets rather than raw HTML. For news, GDELT was an option but NewsAPI's `/v2/everything` endpoint is simpler and more reliable for company-specific queries.

The first thing I did was create a single shared types file, `src/lib/agent/types.ts`, defining every interface the backend, frontend, and PDF generator would use: `CompanyProfile`, `FinancialSnapshot`, `InvestmentReport`, the SSE event union, and the pipeline stage metadata. This file became the contract that kept all three layers in sync. I did not want the backend and frontend drifting apart on the report shape.

---

## 2. Building the agent pipeline

I designed the agent as a 9-stage state graph: normalize input, resolve company, gather data, analyze financials, analyze news, web research, assess risk, synthesize decision, generate report. Each stage reads from and writes to a shared state object using LangGraph's `Annotation.Root`.

I asked the AI coding assistant to generate the initial implementations of the tool functions (`tools.ts`), the LLM prompt templates (`prompts.ts`), the Gemini client wrapper (`llm.ts`), the node functions (`nodes.ts`), and the graph wiring (`graph.ts`). I gave it the types contract and detailed specs for each function. The generated code was structurally sound, but I reviewed every file and made changes where needed.

### The streaming decision

LangGraph's built-in `.stream()` method emits per-node state diffs. I needed something more granular: `stage_start`, `stage_progress`, and `stage_complete` events with partial payloads, so the UI could show per-stage progress and a live log. The state-diff stream did not map cleanly onto that protocol.

I considered three options: adapt the UI to LangGraph's stream format, call the node functions sequentially with a manual `emit` callback, or try to use LangGraph's channel updates. I chose the second option. I kept the `StateGraph` defined and compiled in `graph.ts` for architectural correctness and documentation, but the actual runner in `runner.ts` calls each node function in order and threads an `emit` callback through manually.

The trade-off: I lose LangGraph's built-in checkpointing and parallelism, but I get full control over the SSE protocol and reliable per-stage events. For this project, where the pipeline is linear and the streaming experience matters more than checkpointing, that was the right call. If I needed to add branching or human-in-the-loop approval later, I would revisit this.

### The hybrid architecture decision

Early on I decided that every analytical node would follow a hybrid pattern: pre-compute a deterministic, rule-based result from the fetched data, then attempt a Gemini call to enrich it, and fall back to the rule-based result if Gemini failed for any reason. This turned out to be the most important decision in the project, for reasons I will explain in section 4.

I asked the AI to generate the rule-based engine (`rule-based.ts`) based on my spec: financial highlights with analyst-standard tone thresholds, keyword-based news sentiment, frequency-based web theme extraction, signal-driven risk and strength detection, and a weighted scoring model. I reviewed the thresholds and adjusted several of them, for example, I changed the P/E positive threshold from 25 to 20 and added a PEG ratio check — because the initial values felt too lenient.

---

## 3. Building the UI

I asked the AI to generate the frontend components against the shared types contract and the dark premium theme I had already written in `globals.css`. The theme uses an OKLCH-based palette: a deep violet-black background, electric violet as the primary color, cyan as the accent, and magenta highlights. I added glassmorphism utility classes (`.glass`, `.glass-strong`), gradient text and border utilities, and a custom scrollbar.

The particle background was the first real problem.

### tsParticles v4 API change

I had written the `ParticleBackground` component using `initParticlesEngine` from `@tsparticles/react`, which is the v3 imperative API. But I had installed v4.3.1, and v4 removed `initParticlesEngine` entirely and replaced it with a provider-based API: `<ParticlesProvider init={loadSlim}>`. Every route returned HTTP 500 because the layout transitively imported the broken component.

I had three options: downgrade to v3, migrate to the v4 provider API, or write a hand-rolled canvas effect. I chose to migrate to v4. The provider API is cleaner, and v4 is the current version. I also needed to read the `prefers-reduced-motion` media query without triggering the `react-hooks/set-state-in-effect` lint rule, so I used `useSyncExternalStore` for that check. That is the React-idiomatic way to subscribe to a browser API from a component.

This was a mistake in the sense that I should have checked the installed version against the API I was using before writing the component. The fix took about 15 minutes.

---

## 4. The FMP legacy endpoint problem

After the initial build, I ran the first end-to-end test with "Apple" as the company name. The company resolution failed immediately. I ran `curl` against the FMP search endpoint and got back:

```
{"Error Message": "Legacy Endpoint : Due to Legacy endpoints being no longer supported..."}
```

FMP had migrated their REST API. All the `/api/v3/*` endpoints I was using — search, profile, ratios, income-statement, cash-flow-statement, balance-sheet, historical prices — were dead for non-legacy accounts after August 31, 2025. This was not in any documentation I had read beforehand.

I tested the new `/stable/*` endpoints. Most of them worked: `stable/profile?symbol=AAPL`, `stable/ratios`, `stable/income-statement`, `stable/cash-flow-statement`, `stable/balance-sheet-statement`, `stable/key-metrics`. But two things had changed. First, `stable/search` returned an empty array for company-name queries like "Apple" — it only works with ticker fragments. Second, the field names had changed: `priceToEarningsRatio` instead of `peRatio`, `debtToEquityRatio` instead of `debtToEquity`, and margins were returned as decimals (0.47) instead of percentages (47). ROE and ROA had moved from the ratios endpoint to the key-metrics endpoint.

I rewrote `tools.ts` to use the `/stable/*` endpoints, normalize the field names back to my `FinancialSnapshot` shape, and convert decimal margins to percentages. I put the normalization in the tool layer so downstream code would not have to know about the API change. For the price history, the old `historical-price-full` endpoint was replaced by `stable/historical-price-eod/full`, which returns the same data in a slightly different shape.

### The ticker resolution problem

Because `stable/search` returned empty for company names, I needed another way to resolve a name like "Apple" to a ticker like "AAPL". I considered hardcoding a ticker map for common companies, but that would not generalize. I tested Tavily by searching for "Apple stock ticker symbol NASDAQ" and found that the results from MarketWatch, TradingView, and Bloomberg all contained the ticker in recognizable patterns: `NASDAQ: AAPL`, `NASDAQ:AAPL`, or `(AAPL)`.

I wrote `resolveTickerViaTavily(company)`, which searches Tavily, extracts ticker candidates from exchange-qualified and parens-qualified patterns using regex, ranks them by frequency, and verifies the top candidates against FMP's profile endpoint. The first one that returns a real profile wins.

Later, a user pointed out that "TCS" was resolving to "The Container Store Group" (NYSE: TCS) instead of "Tata Consultancy Services" (NSE: TCS.NS). The problem was that my resolver only tried the bare ticker `TCS`, which matched the US-listed company. I fixed this by having the resolver try international exchange suffixes — `.NS` for the NSE and `.BO` for the BSE — and rank candidates by how often the company name appeared in the Tavily search context. After the fix, "TCS" correctly resolved to TCS.NS.

---

## 5. The Gemini problem and the rule-based engine

When I ran the first full test, every Gemini call failed with HTTP 429 and the message "You exceeded your current quota." I tried several models — `gemini-2.0-flash`, `gemini-2.5-flash`, `gemini-2.5-pro`, `gemini-2.0-flash-lite` — and they all returned the same quota error. Some models also returned HTTP 400 with "User location is not supported for the API use." The provided key had zero available quota from this server's region.

I could not fix the Gemini key or the region. I had three options: ship the app as LLM-only and accept that it would produce empty reports when Gemini was down, build a rule-based engine that could work fully without Gemini, or try a different LLM provider. The assignment required the app to "work properly with missing or invalid data" and "still produce a useful result if some sources are unavailable," so option one was not acceptable. Switching LLM providers would have meant abandoning the Gemini requirement. I chose option two.

The rule-based engine in `rule-based.ts` was already designed as a fallback, but I had initially treated it as a minimal safety net, mostly empty arrays with a generic "LLM unavailable" message. I rewrote it into a complete analysis engine:

- **Financial analysis**: builds highlights from real FMP numbers with tone thresholds I defined (P/E below 20 is positive, above 40 is negative; net margin at or above 15% is positive; debt-to-equity below 0.5 is positive; and so on).
- **News analysis**: keyword-based sentiment classification. I built positive and negative word lists (words like "beat," "surge," "record" vs. "miss," "decline," "lawsuit") and count matches per headline.
- **Web analysis**: strips URLs from the text, tokenizes, removes stopwords, and extracts the most frequent terms as themes.
- **Risk assessment**: derives strengths, weaknesses, weak signals, opportunities, and severity-tagged risks from the financial signals. For example, debt-to-equity above 3 triggers a high-severity risk; ROE at or above 18% triggers a strength.
- **Decision synthesis**: a weighted scoring model. Profitability is worth 25 points, growth 20, valuation 20, balance sheet 15, cash flow 10, and news sentiment 10. If two or more high-severity risks are present, the recommendation is forced to PASS regardless of the score. Confidence scales with data coverage: 68% for full data, 52% for partial, 32% for limited, minus 8% per high-severity risk.

I wired this into every node so that the rule-based result is always pre-computed and used as the fallback if Gemini fails. If Gemini succeeds but returns an empty or invalid result, the node falls back to the rule-based version. The app never produces an empty report.

After the rewrite, I verified the output on four companies:
- Apple → HOLD, 58/100, confidence 68%, 16 financial highlights.
- Tesla → PASS, 38/100, 2 high-severity risks.
- Microsoft → INVEST, 86/100, 6 strengths.
- Nvidia → INVEST, 95/100, 6 strengths.

All grounded in real FMP data. This was the moment I was glad I had chosen the hybrid architecture. If I had built a pure-LLM agent, the app would have been completely non-functional with the Gemini quota issue.

---

## 6. The FMP rate limit problem

After extended testing, FMP started returning "Limit Reach. Please upgrade your plan" on every endpoint, including profile. The free tier has a daily request limit, and I had exhausted it through repeated testing. This meant the app could no longer fetch company profiles, financials, or price history.

The app handled this gracefully, the rule-based engine produced a limited report with news and web context, and the assumptions section noted that financial data was unavailable. But the company profile was blank, which made the report feel incomplete.

I added a fallback: when FMP returns nothing, the agent fetches profile data via Tavily web search and Wikipedia. I wrote `fetchCompanyDescription(company)` which queries the Wikipedia API for the company's intro extract. I had to try multiple query variants ("Apple", "Apple Inc", "Apple company", "Apple Corporation") because searching Wikipedia for "Apple" returns the fruit, not the company. I added a fruit-detection check that skips extracts containing words like "orchard" or "cultivar" when the company name does not itself contain "company" or "inc."

I also hit a Wikipedia API issue: the default request returned HTTP 403 because Wikipedia requires a proper User-Agent header. I added `User-Agent: FinOpsAgent/1.0 (investment research; contact@finopsagent.ai)` and the requests succeeded.

I wrote `fetchCompanyProfileViaTavily(company, symbol)` which uses Tavily to extract the website, sector, industry, CEO, country, and market cap from search result snippets using regex, and uses Wikipedia for the description. This is not as clean as FMP's structured data, but it gives the user a real company profile when FMP is unavailable.

I also updated the ticker resolver so that when FMP cannot verify a candidate (because of the rate limit), it still returns the best Tavily-extracted ticker rather than null. This way, "Apple" still resolves to "AAPL" even when FMP is down.

---

## 7. PDF generation

The PDF generator was the most fiddly part. I used jsPDF and jspdf-autotable. I asked the AI to generate the initial version, which produced a dark-themed PDF. I later rewrote it entirely with a white background after a user reported that text was hard to read.

The current PDF has a white background on all pages, dark near-black body text, and colorful accents (violet, cyan, emerald, rose, amber) for section headers, badges, and the price chart. The structure is: cover page, executive summary, company overview, financial analysis with a price chart, news analysis, web research, risk assessment, investment thesis, and sources.

A few jsPDF quirks I had to handle:
- jspdf-autotable v5 uses a functional API: `autoTable(doc, opts)` rather than `doc.autoTable(opts)`.
- The total page count is only known after all content is built, so page numbers ("Page X of Y") are added in a final pass that iterates over each page.
- Long text has to be wrapped manually using `doc.splitTextToSize(text, maxWidth)`.
- Clickable URLs in the sources table are added via `doc.link(x, y, w, h, { url })`.
- The price chart is drawn with jsPDF primitives (lines, rectangles, text) rather than an image, because rendering a Recharts chart to canvas and embedding it as a PNG would have added complexity.

I initially named the product "Equity Lens" and later renamed it to "FinOps Agent" at the user's request. I had to update the name in the PDF (cover, page headers, page footers), the layout metadata, the site header, the footer, the hero text, the README, and this diary. I missed the PDF on the first rename pass, which the user pointed out. I fixed it.

---

## 8. Progress animation

The UI shows a 9-stage pipeline with per-stage progress bars while the agent runs. The initial implementation used Framer Motion's `animate` with `easeOut` easing, animating from 0 to 92% over 4 seconds. The problem with `easeOut` is that it front-loads the progress: the bar jumps to 50% quickly, then crawls toward 92%. A user reported that it looked like a 0-50-100 jump rather than a smooth progression.

I changed the animation to use `linear` easing over 6 seconds, animating from the current value to 95%. When the stage completes, the bar animates from its current position to 100% over 0.4 seconds. I verified the progression at 2-second intervals during a live run: 25%, 58%, 96%, 100%. That is the smooth, continuous progression I wanted.

I also added pacing delays (300-800ms) to each backend node so that the stages take long enough for the animation to be visible. Without the delays, some stages (like normalize input) completed in under 100ms, which made the progress bar flash and disappear.

---

## 9. Overflow and layout fixes

A user reported that news cards were overflowing horizontally beyond the viewport. The root cause was flexbox children without `min-w-0` — by default, flex items cannot shrink below their content's intrinsic width, so long headlines or URLs pushed the cards wider than their container.

I added `min-w-0` and `overflow-hidden` to the card containers, `break-words` to the text elements, and `overflow-hidden` to the parent lists. I also made the navigation bar and footer more opaque (from `bg-background/40` to `bg-background/85`) at the user's request, because the transparent version made text hard to read when content scrolled behind it.

---

## 10. Code cleanup

After the functional work was done, I stripped all comments and console statements from the source files. I used an AST-aware script rather than a regex so that `//` inside template literals (like API URLs) and regex literals would not be mistaken for comments. The script removed about 396 comments and 4 console calls across 22 files. I verified that lint and TypeScript compilation still passed afterward.

---

## Trade-offs

| Decision | Trade-off |
|----------|-----------|
| Sequential runner instead of LangGraph `.stream()` | I lose built-in checkpointing and parallelism, but I get full control over the SSE protocol. For a linear pipeline, this is acceptable. |
| Hybrid LLM + rule-based engine | More code than a pure-LLM approach, but the app works when Gemini is down. This was essential. |
| Tavily for ticker resolution | An extra API call per analysis, but FMP's search endpoint is broken for company names and Tavily is reliable. |
| Wikipedia for company descriptions | An external dependency on Wikipedia's API, but it provides high-quality descriptions when FMP is rate-limited. I added a User-Agent header and multiple query variants to handle disambiguation. |
| jsPDF primitives for the chart instead of an image | Less visually polished than a Recharts PNG, but simpler and has no canvas dependency. |
| No database persistence | Faster to build, but repeat queries re-compute everything. Prisma is installed and ready if I add caching later. |
| Rule-based confidence capped at 68% | I did not want to overstate certainty when the LLM is unavailable. The cap is honest about the limits of heuristic reasoning. |
| No authentication | The assignment did not require it. NextAuth.js is available in the stack if needed. |

---

## Lessons learned

**What worked well**

The hybrid architecture was the right call. Building the rule-based engine as a first-class citizen rather than an afterthought meant the app was never broken, even when Gemini and FMP both failed. If I had treated the rules as a thin wrapper, I would have been stuck when the APIs went down.

The shared types contract (`types.ts`) saved me from a class of bugs. Because the backend, frontend, and PDF generator all imported the same interfaces, I never had a mismatch where the frontend expected a field the backend did not send.

SSE streaming via a `ReadableStream` route handler worked cleanly in Next.js 16. I did not need WebSockets for a one-shot request-response pattern.

**What proved harder than expected**

FMP's API migration caught me off guard. The `/api/v3/*` endpoints I initially coded against were dead, the field names had changed, and the search endpoint stopped working for company names. I spent more time on FMP integration than on any other single part of the project.

Gemini's quota and region restrictions were frustrating but ultimately led to a better architecture. If Gemini had worked on the first try, I might not have built the rule-based engine as thoroughly, and the app would have been more fragile.

Wikipedia's API requires a proper User-Agent header. The default `fetch` request returned 403. This is documented but easy to miss.

**What I learned about LangGraph**

LangGraph's `StateGraph` and `Annotation.Root` are a clean way to model a multi-stage workflow. The state channel system with reducers is well-designed. However, the built-in streaming did not fit my SSE protocol, and I ended up calling nodes sequentially. For a linear pipeline, the graph is more documentation than runtime machinery. If I were building something with branching, parallel nodes, or human-in-the-loop steps, the graph would earn its keep more clearly.

**What I learned about API reliability**

Every external API I used failed at some point during development: FMP rate-limited, Gemini quota-blocked, Wikipedia 403'd. The lesson is that a production AI product cannot assume any single API will be available. Layered fallbacks are not optional, they are the architecture. I now structure every data-fetching function with a try/catch that returns a safe empty result, and every analytical node with a pre-computed fallback.

**What I learned about prompt engineering**

I wrote the Gemini prompts to demand strict JSON output matching a given schema, with instructions to only use the provided factual data and never invent values. I also wrote a JSON extraction function (`extractJson`) that handles markdown code fences, bare JSON, and leading prose. Even with these measures, the LLM occasionally returned malformed output. The `callJson` wrapper always falls back to the provided default, so a bad LLM response never breaks the pipeline.

**What I learned about production-ready AI products**

The difference between a demo and a product is error handling. The demo works when everything succeeds. The product works when everything fails. I spent more time on fallbacks, assumptions logging, graceful degradation, and partial reports than on the happy path. That is where the real engineering is.

---

## Future improvements

- **Caching**: Store generated reports in SQLite (Prisma is already configured) so repeat queries for the same company return instantly. Add a TTL of a few hours so the data stays fresh.
- **Authentication**: Add NextAuth.js so users can save their research history and access it across sessions.
- **Portfolio comparison**: Let users compare 2-3 companies side by side on the same metrics.
- **Additional financial providers**: Add Alpha Vantage or Polygon as a fallback for FMP, so a single provider's rate limit does not block financial data.
- **Valuation models**: Add a discounted cash flow or comparable company analysis module beyond the current scoring model.
- **Background job queue**: For long-running analyses, move the agent to a background worker (BullMQ or similar) and notify the client when done, instead of holding an SSE connection open.
- **Monitoring**: Add structured logging and error tracking (Sentry) to catch production issues.
- **Better PDF exports**: The current chart is drawn with jsPDF primitives. Rendering a higher-quality chart via a headless browser or a charting library that exports to SVG would improve the visual quality.
- **LLM retry with backoff**: Try multiple Gemini models with exponential backoff before falling back to the rule-based engine, so transient quota errors do not lose the LLM's reasoning.

---

## AI usage summary

I used an AI coding assistant throughout this project. Specifically:

- I asked it to generate the initial implementations of the backend tools, prompts, LLM wrapper, node functions, and graph wiring, based on detailed specs and the shared types contract I had written.
- I asked it to generate the frontend components (header, hero, pipeline, report display, gauges, charts, source list, footer) against the theme and types I had defined.
- I asked it to generate the PDF generator.
- I asked it to strip comments and console statements from the source files using an AST-aware script.
- I used it for debugging, for example, identifying the tsParticles v4 API change and the Wikipedia User-Agent requirement.

What I did myself:
- The architecture: the 9-stage pipeline, the hybrid LLM + rule-based pattern, the SSE protocol, the shared types contract.
- The API selection and the fallback strategy.
- The rule-based engine thresholds and scoring weights (I reviewed and adjusted the AI's initial values).
- The FMP endpoint migration and field normalization.
- The Tavily-based ticker resolver and the Wikipedia description fetcher.
- The progress animation fix (easeOut to linear).
- The overflow and opacity fixes.
- All integration testing and verification.

I reviewed every line of generated code. Where I did not understand or agree with the AI's output, I modified it or removed it. The project is mine; the AI was a tool that accelerated the implementation.

---

*This diary was written after the project was completed, based on the worklog, the code, and my memory of the development process. It does not reproduce any private AI chain-of-thought. Every technical claim can be verified against the source code.*
