<div align="center">

# LeakScope

### Ultimate Browser Privacy & Fingerprint Analyzer

**Discover what websites can learn about you.**

Scan your browser for 130+ privacy leaks, fingerprinting vectors, and security exposures — all in real-time, right from your browser.

[![Next.js](https://img.shields.io/badge/Next.js-16-black?style=flat-square&logo=next.js)](https://nextjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?style=flat-square&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-06B6D4?style=flat-square&logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](./LICENSE)

</div>

---

## Preview

LeakScope runs a deep scan of your browser across **10 categories** and **130+ detection points**, then presents a detailed privacy score dashboard with animated visualizations, risk breakdowns, and actionable recommendations.

---

## Features

### Deep Browser Scanning
- **10 scan categories** with 130+ individual detection points
- Real-time progress tracking with animated radar visualization
- Terminal-style live scan output with color-coded risk indicators
- SHA-256 fingerprint hash generation from collected browser data

### Privacy Score Dashboard
- **Overall Privacy Score** (0-100) with animated circular gauge
- **5 sub-scores**: Browser Uniqueness, Tracking Protection, Security Risks, Browser Protection, Anonymity Level
- **Letter grade** (A+ to F) with risk assessment
- **Browser Fingerprint ID** — unique SHA-256 hash of your browser's identifying features

### Threat Analysis
- Risk overview with critical/high/medium/low/safe classification
- Threat statistics with animated counters
- Category-by-category deep dive into every detected leak
- Each item includes: description, impact, mitigation, and recommended tools

### Recommendations & Reports
- Top 8 prioritized recommendations sorted by risk severity
- Recommended privacy tools for each issue
- **Export report** as JSON or plain text
- **Copy to clipboard** for instant sharing

### Premium UI/UX
- Dark theme with purple/pink neon glow effects
- Framer Motion animations throughout
- Fully responsive — works on mobile, tablet, and desktop
- Custom scrollbar, aurora background effects, shimmer animations

---

## Scan Categories

| # | Category | What It Detects |
|---|----------|----------------|
| 1 | **Browser Information** | User agent, browser version, engine, platform, vendor, language, cookies, DNT, ad blocker detection, headless/automation detection |
| 2 | **Device Information** | Screen resolution, color depth, pixel ratio, touch support, GPU info, hardware concurrency, device memory, media capabilities |
| 3 | **Operating System** | OS detection, virtual machine detection, architecture, CPU cores, platform specifics |
| 4 | **Network & Connection** | Public IP, geolocation (city/country/ISP), WebRTC leak detection, connection type, VPN/Tor/proxy heuristics, timezone mismatch |
| 5 | **Storage & Tracking** | Cookies, localStorage, sessionStorage, IndexedDB, Web SQL, cache storage, service workers, third-party storage |
| 6 | **Security Analysis** | HTTPS status, mixed content, TLS details, security headers, HSTS, CSP, CORS policies, dangerous API exposure |
| 7 | **Browser Fingerprint** | Canvas fingerprint, WebGL fingerprint, audio fingerprint, font detection, timezone uniqueness, hardware uniqueness, entropy calculation, tracking probability |
| 8 | **Permissions & Sensors** | Camera, microphone, geolocation, notifications, clipboard, Bluetooth, USB, battery, gamepad, MIDI access |
| 9 | **Performance & Environment** | CPU benchmarks, memory pressure, animation frame rate, rendering performance, worker support |
| 10 | **Privacy Protections** | Do Not Track, tracking prevention, cookie policies, referrer policy, GPC signal, sandbox support |

---

## Fingerprinting Techniques Used

LeakScope uses the same techniques that tracking companies use — so you can see exactly what they see:

| Technique | Description |
|-----------|-------------|
| **Canvas Fingerprint** | Renders hidden text/graphics and hashes the pixel output — unique per GPU/driver/font engine |
| **WebGL Fingerprint** | Reads 20+ WebGL parameters (vendor, renderer, extensions, texture limits) — unique per graphics card |
| **Audio Fingerprint** | Processes audio via Web Audio API and hashes the output — unique per audio hardware |
| **Font Detection** | Measures rendered text widths against 36 test fonts — unique per OS + installed apps |
| **Hardware Fingerprint** | Combines CPU cores, RAM, screen, touch points, pixel ratio — unique per device |
| **Timezone Fingerprint** | Hashes timezone + locale + UTC offset — narrows geographic region |
| **WebRTC Leak** | Extracts local/private IP via STUN — can bypass VPNs |
| **Entropy Calculation** | Estimates total identifying bits — predicts tracking probability |

The **Browser Fingerprint ID** is a SHA-256 hash computed from all collected fingerprint data combined, representing your complete browser identity.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Framework** | [Next.js 16](https://nextjs.org/) (App Router) |
| **Language** | [TypeScript 5](https://www.typescriptlang.org/) |
| **Styling** | [Tailwind CSS 4](https://tailwindcss.com/) + [shadcn/ui](https://ui.shadcn.com/) |
| **Animations** | [Framer Motion](https://www.framer.com/motion/) |
| **Icons** | [Lucide React](https://lucide.dev/) |
| **Toasts** | [Sonner](https://sonner.emilkowal.dev/) |
| **Runtime** | [Bun](https://bun.sh/) |
| **IP Geolocation** | [ipapi.co](https://ipapi.co/) (free API, no key required) |

---

## Project Structure

```
leakscope/
├── src/
│   ├── app/
│   │   ├── page.tsx                  # Main page with scan flow & tabs
│   │   ├── layout.tsx                # Root layout with metadata
│   │   ├── globals.css               # Global styles, CSS variables, animations
│   │   └── api/
│   │       ├── route.ts              # Health check endpoint
│   │       └── ip/
│   │           └── route.ts          # IP geolocation API route
│   ├── components/
│   │   ├── leakscope/
│   │   │   ├── hero-section.tsx      # Landing page with scan button
│   │   │   ├── scan-radar.tsx        # Animated radar during scan
│   │   │   ├── cyber-terminal.tsx    # Terminal-style scan output
│   │   │   ├── privacy-score-panel.tsx # Score gauge + info cards grid
│   │   │   ├── score-gauge.tsx       # SVG circular progress gauge
│   │   │   ├── animated-counter.tsx  # Number counter animation
│   │   │   ├── threat-stats.tsx      # Threat statistics panel
│   │   │   ├── risk-overview.tsx     # Risk level breakdown
│   │   │   ├── category-section.tsx  # Category expandable sections
│   │   │   ├── leak-item-detail.tsx  # Individual leak item detail
│   │   │   ├── recommendation-panel.tsx # Fix Issues tab
│   │   │   ├── risk-badge.tsx        # Risk level badge component
│   │   │   ├── export-report.tsx     # JSON/TXT/Clipboard export
│   │   │   ├── disclaimer-section.tsx # Learn tab content
│   │   │   └── neon-card.tsx         # Glowing card wrapper
│   │   └── ui/
│   │       └── button.tsx            # shadcn/ui button
│   └── lib/
│       ├── utils.ts                  # Utility functions
│       └── scanner/
│           ├── index.ts              # Main scan orchestrator
│           ├── types.ts              # TypeScript types & constants
│           ├── score.ts              # Privacy score calculator
│           ├── browser.ts            # Browser info scanner
│           ├── device.ts             # Device info scanner
│           ├── os.ts                 # OS detection scanner
│           ├── network.ts            # Network/WebRTC scanner
│           ├── storage.ts            # Storage/tracking scanner
│           ├── security.ts           # Security analysis scanner
│           ├── fingerprint.ts        # Fingerprint generation (canvas, WebGL, audio, fonts)
│           ├── permissions.ts        # Permissions/sensors scanner
│           ├── performance.ts        # Performance benchmark scanner
│           └── privacy.ts            # Privacy protections scanner
├── public/
│   ├── logo.svg                      # App logo
│   └── robots.txt                    # SEO robots file
├── package.json
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── postcss.config.mjs
├── eslint.config.mjs
└── components.json                   # shadcn/ui config
```

---

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) 18+ or [Bun](https://bun.sh/) 1.0+
- npm, yarn, pnpm, or bun

### Installation

```bash
# Clone the repository
git clone https://github.com/cloudxplorer/LeakScope
cd LeakScope

# Install dependencies
npm install
# or with bun
bun install

# Start the development server
npm run dev
# or with bun
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser to start scanning.

### Build for Production

```bash
npm run build
npm run start
# or with bun
bun run build
bun run start
```

---

## How It Works

### Scan Flow

1. **User clicks "Start Scan"** — the scan orchestrator initializes
2. **10 scanner modules run sequentially** — each with a 15-second timeout
3. **Real-time progress updates** — animated radar, terminal output, progress bar
4. **SHA-256 fingerprint hash generated** — from all collected browser attributes
5. **Privacy scores calculated** — weighted scoring across 5 dimensions
6. **Results displayed** — dashboard with gauges, stats, categories, and recommendations

### Privacy Score Calculation

The overall privacy score (0-100) is calculated from 5 sub-scores:

| Sub-Score | Description | Direction |
|-----------|-------------|-----------|
| **Browser Uniqueness** | How uniquely identifiable your browser is | ↓ Lower is better |
| **Tracking Protection** | How well you're protected against trackers | ↑ Higher is better |
| **Security Risks** | Number and severity of security exposures | ↓ Lower is better |
| **Browser Protection** | Built-in browser privacy features | ↑ Higher is better |
| **Anonymity Level** | How anonymous your browsing session is | ↑ Higher is better |

Each detected item is assigned a risk weight (Critical=100, High=75, Medium=50, Low=25, Safe=0), and the scores are computed based on the distribution of risk levels across categories.

### Risk Levels

| Level | Color | Meaning |
|-------|-------|---------|
| 🔴 Critical | Red | Actively exploitable, immediate privacy risk |
| 🟠 High | Orange | Significant identifying information exposed |
| 🟡 Medium | Yellow | Moderate fingerprinting or tracking potential |
| 🟣 Low | Purple | Minor identifying detail, low risk |
| 🟢 Safe | Fuchsia | No significant privacy concern detected |

---

## API Routes

### `GET /api/ip`

Returns IP geolocation data for the requesting client.

**Response:**
```json
{
  "ip": "203.0.113.42",
  "city": "Mumbai",
  "country": "India",
  "region": "Maharashtra",
  "loc": "19.0760,72.8777",
  "org": "AS55441 C IPL Sify",
  "timezone": "Asia/Kolkata"
}
```

Uses [ipapi.co](https://ipapi.co/) for geolocation — no API key required for basic usage.

---

## Privacy & Security Notes

- **100% client-side scanning** — all fingerprinting runs in your browser
- **No data sent to external servers** — except IP geolocation lookup (ipapi.co)
- **No cookies or tracking** — LeakScope itself does not track you
- **No database required** — fully stateless application
- **WebRTC leak test** — performed locally using STUN servers with no external ICE servers
- **IP geolocation** — uses a server-side API route to proxy the ipapi.co request (keeps API key server-side if needed in future)

---

## Responsive Design

LeakScope is designed to work beautifully across all screen sizes:

| Screen | Layout |
|--------|--------|
| Mobile (<640px) | Stacked layout, fingerprint ID on top, 2-column info grid, scrollable categories |
| Tablet (640-1024px) | 3-column sub-scores, wider cards, side-by-side gauge + info |
| Desktop (>1024px) | Full dashboard, 5-column sub-scores, 3-column info row, expanded details |

---

## Customization

### Theme Colors

The color scheme is defined in `src/app/globals.css` using CSS custom properties:

```css
:root {
  --primary: #a855f7;        /* Purple */
  --primary-foreground: #ffffff;
  --background: #0a0612;     /* Dark background */
  --foreground: #f5f0ff;     /* Light text */
  /* ... more variables */
}
```

### Adding New Scanners

1. Create a new file in `src/lib/scanner/` (e.g., `webrtc.ts`)
2. Export an async function that returns `LeakItem[]`
3. Register it in `src/lib/scanner/index.ts` in the `SCANNERS` object
4. Add metadata in the `CATEGORY_META` object
5. Add the category ID to `CATEGORY_IDS` in `types.ts`

Each `LeakItem` requires:

```typescript
{
  id: string;           // Unique identifier (e.g., 'webrtc-stun')
  name: string;         // Display name
  value: string | boolean | number | null;  // Detected value
  riskLevel: RiskLevel; // 'critical' | 'high' | 'medium' | 'low' | 'safe'
  category: string;     // Category ID
  description: string;  // What was detected
  impact: string;       // Why it matters
  mitigation: string;   // How to fix it
  tools?: string[];     // Recommended tools
}
```

---

## Contributing

Contributions are welcome! Here's how you can help:

1. **Fork** the repository
2. **Create** a feature branch (`git checkout -b feature/amazing-feature`)
3. **Commit** your changes (`git commit -m 'Add amazing feature'`)
4. **Push** to the branch (`git push origin feature/amazing-feature`)
5. **Open** a Pull Request

### Ideas for Contributions

- Add new scan categories (e.g., Bluetooth, USB, Serial API detection)
- Improve fingerprinting techniques (e.g., Battery API, Speech Synthesis)
- Add historical scan comparison (compare scans over time)
- Implement browser extension detection improvements
- Add more export formats (PDF report, HTML report)
- Improve accessibility (ARIA labels, keyboard navigation)
- Add internationalization (i18n) support

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](./LICENSE) file for details.

---

<div align="center">

**LeakScope by Pallavi Thakur**

*Privacy & Fingerprint Analyzer*

</div>
