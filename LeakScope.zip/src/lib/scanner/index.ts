import { ScanResult, ScanProgress, ScanCategory, LeakItem } from './types';
import { scanBrowser } from './browser';
import { scanDevice } from './device';
import { scanOS } from './os';
import { scanNetwork } from './network';
import { scanStorage } from './storage';
import { scanSecurity } from './security';
import { scanFingerprint } from './fingerprint';
import { scanPermissions } from './permissions';
import { scanPerformance } from './performance';
import { scanPrivacy } from './privacy';
import { calculateScores } from './score';

type ProgressCallback = (progress: ScanProgress) => void;

const SCANNERS: Record<string, () => Promise<LeakItem[]>> = {
  browser: scanBrowser,
  device: scanDevice,
  os: scanOS,
  network: scanNetwork,
  storage: scanStorage,
  security: scanSecurity,
  fingerprint: scanFingerprint,
  permissions: scanPermissions,
  performance: scanPerformance,
  privacy: scanPrivacy,
};

const CATEGORY_META: Record<string, { name: string; icon: string; description: string }> = {
  browser: { name: 'Browser Information', icon: 'Globe', description: 'Your browser type, version, and settings' },
  device: { name: 'Device Information', icon: 'Monitor', description: 'Your hardware capabilities and device details' },
  os: { name: 'Operating System', icon: 'Laptop', description: 'Operating system detection and virtual machine checks' },
  network: { name: 'Network & Connection', icon: 'Wifi', description: 'Your network details and connection information' },
  storage: { name: 'Storage & Tracking', icon: 'Database', description: 'Browser storage methods and tracking risks' },
  security: { name: 'Security Analysis', icon: 'Shield', description: 'Security checks and potential weaknesses' },
  fingerprint: { name: 'Browser Fingerprint', icon: 'Fingerprint', description: 'How uniquely identifiable your browser is' },
  permissions: { name: 'Permissions & Sensors', icon: 'Key', description: 'Website permissions and sensor access checks' },
  performance: { name: 'Performance & Environment', icon: 'Gauge', description: 'Device performance and speed measurements' },
  privacy: { name: 'Privacy Protections', icon: 'Lock', description: 'How well your privacy protections are working' },
};

function truncateValue(val: string | boolean | number | null, maxLen = 40): string {
  if (val === null || val === undefined) return 'N/A';
  const s = String(val);
  return s.length > maxLen ? s.slice(0, maxLen) + '...' : s;
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error(`Scanner timed out after ${ms}ms`)), ms)
    ),
  ]);
}

export async function runScan(onProgress?: ProgressCallback): Promise<ScanResult> {
  const startTime = Date.now();
  const categories: ScanCategory[] = [];
  const categoryIds = Object.keys(SCANNERS);
  let fingerprintHash = '';

  for (let i = 0; i < categoryIds.length; i++) {
    const catId = categoryIds[i];
    const meta = CATEGORY_META[catId];

    onProgress?.({
      isScanning: true,
      currentCategory: meta.name,
      completedCategories: i,
      totalCategories: categoryIds.length,
      percentage: Math.round((i / categoryIds.length) * 100),
      terminalLines: [`[SCAN] Probing ${meta.name.toLowerCase()}...`],
    });

    try {
      const items = await withTimeout(SCANNERS[catId](), 15000);
      const riskSummary = { critical: 0, high: 0, medium: 0, low: 0, safe: 0 };
      items.forEach(item => { riskSummary[item.riskLevel]++; });

      const itemLines = items.map(item => {
        const tag = item.riskLevel.toUpperCase();
        const val = truncateValue(item.value);
        return `[${tag}] ${item.name}: ${val}`;
      });

      const critCount = riskSummary.critical;
      const highCount = riskSummary.high;
      const summary = critCount > 0 || highCount > 0
        ? `[WARN] ${meta.name}: ${critCount} critical, ${highCount} high risk findings`
        : `[OK] ${meta.name}: ${items.length} items analyzed`;

      onProgress?.({
        isScanning: true,
        currentCategory: meta.name,
        completedCategories: i + 1,
        totalCategories: categoryIds.length,
        percentage: Math.round(((i + 1) / categoryIds.length) * 100),
        terminalLines: [...itemLines, summary],
      });

      categories.push({
        id: catId,
        name: meta.name,
        icon: meta.icon,
        description: meta.description,
        items,
        riskSummary,
      });

      if (catId === 'fingerprint') {
        const hashItem = items.find(it => it.id === 'fp-hash');
        if (hashItem) fingerprintHash = String(hashItem.value);
      }
    } catch {
      onProgress?.({
        isScanning: true,
        currentCategory: meta.name,
        completedCategories: i + 1,
        totalCategories: categoryIds.length,
        percentage: Math.round(((i + 1) / categoryIds.length) * 100),
        terminalLines: [`[ERROR] ${meta.name}: scan skipped or timed out`],
      });

      categories.push({
        id: catId,
        name: meta.name,
        icon: meta.icon,
        description: meta.description,
        items: [],
        riskSummary: { critical: 0, high: 0, medium: 0, low: 0, safe: 0 },
      });
    }
  }

  const scores = calculateScores(categories);
  const scanDuration = Date.now() - startTime;

  onProgress?.({
    isScanning: false,
    currentCategory: 'Complete',
    completedCategories: categoryIds.length,
    totalCategories: categoryIds.length,
    percentage: 100,
    terminalLines: ['[DONE] Analysis complete.'],
  });

  return { scores, categories, timestamp: Date.now(), scanDuration, fingerprintHash };
}
