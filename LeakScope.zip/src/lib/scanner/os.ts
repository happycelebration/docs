import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'os', description, impact, mitigation, tools };
}

function detectOS(ua: string): string {
  if (/Windows NT 11/.test(ua)) return 'Windows 11';
  if (/Windows NT 10/.test(ua)) return 'Windows 10/11';
  if (/Windows NT 6\.3/.test(ua)) return 'Windows 8.1';
  if (/Windows NT 6\.2/.test(ua)) return 'Windows 8';
  if (/Windows NT 6\.1/.test(ua)) return 'Windows 7';
  if (/Mac OS X/.test(ua)) {
    const match = ua.match(/Mac OS X ([\d_]+)/);
    return match ? `macOS ${match[1].replace(/_/g, '.')}` : 'macOS';
  }
  if (/Android/.test(ua)) {
    const match = ua.match(/Android ([\d.]+)/);
    return match ? `Android ${match[1]}` : 'Android';
  }
  if (/iPhone|iPad/.test(ua)) {
    const match = ua.match(/OS ([\d_]+)/);
    return match ? `iOS ${match[1].replace(/_/g, '.')}` : 'iOS';
  }
  if (/Linux/.test(ua)) return 'Linux';
  if (/CrOS/.test(ua)) return 'ChromeOS';
  return 'Unknown';
}

function detectOSVersion(ua: string): string {
  if (/Windows NT ([\d.]+)/.test(ua)) {
    const match = ua.match(/Windows NT ([\d.]+)/);
    return match ? match[1] : 'Unknown';
  }
  if (/Mac OS X ([\d_]+)/.test(ua)) {
    const match = ua.match(/Mac OS X ([\d_]+)/);
    return match ? match[1].replace(/_/g, '.') : 'Unknown';
  }
  if (/Android ([\d.]+)/.test(ua)) {
    const match = ua.match(/Android ([\d.]+)/);
    return match ? match[1] : 'Unknown';
  }
  if (/OS ([\d_]+)/.test(ua) && /iPhone|iPad/.test(ua)) {
    const match = ua.match(/OS ([\d_]+)/);
    return match ? match[1].replace(/_/g, '.') : 'Unknown';
  }
  return 'Unknown';
}

function detectVMHints(): { isVM: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const ua = navigator.userAgent;

  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl');
    if (gl) {
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) as string;
        const vmRenderers = ['SwiftShader', 'VirtualBox', 'VMware', 'Parallels', 'llvmpipe', 'virgl', 'Mesa', 'Gallium'];
        for (const vm of vmRenderers) {
          if (renderer.includes(vm)) {
            reasons.push(`GPU renderer contains "${vm}"`);
            break;
          }
        }
      }
    }
  } catch {}

  const cores = navigator.hardwareConcurrency;
  if (cores && cores <= 2) {
    reasons.push(`Low CPU cores (${cores}) suggests virtualized environment`);
  }

  const deviceMemory = (navigator as Record<string, unknown>).deviceMemory as number | undefined;
  if (deviceMemory && deviceMemory <= 2) {
    reasons.push(`Low device memory (${deviceMemory}GB) suggests virtualized environment`);
  }

  return { isVM: reasons.length > 0, reasons };
}

function detectEmulatorHints(): { isEmulator: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const ua = navigator.userAgent;

  if (/Android/.test(ua) && !/Mobile/.test(ua) && navigator.maxTouchPoints === 0) {
    reasons.push('Android UA without mobile flag and no touch support');
  }

  if (/iPhone|iPad/.test(ua)) {
    try {
      const hasGyroscope = typeof (window as Record<string, unknown>).Gyroscope !== 'undefined';
      const hasAccelerometer = typeof (window as Record<string, unknown>).Accelerometer !== 'undefined';
      if (!hasGyroscope && !hasAccelerometer) {
        reasons.push('iOS UA detected but no motion sensors available');
      }
    } catch {}
  }

  if (navigator.hardwareConcurrency && navigator.hardwareConcurrency > 16 && /Mobi/.test(ua)) {
    reasons.push('Mobile UA with unusually high CPU core count');
  }

  const deviceMemory = (navigator as Record<string, unknown>).deviceMemory as number | undefined;
  if (deviceMemory && deviceMemory > 8 && /Mobi/.test(ua)) {
    reasons.push('Mobile UA with unusually high device memory');
  }

  return { isEmulator: reasons.length > 0, reasons };
}

function detectWSLHints(): { isWSL: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const ua = navigator.userAgent;

  if (/Linux/.test(ua) && !/Android/.test(ua)) {
    if (navigator.platform === 'Win32' || navigator.platform === 'Win64') {
      reasons.push('Linux UA with Windows platform string');
    }
    if (/Microsoft/.test(ua) || /WSL/.test(ua)) {
      reasons.push('WSL identifier in User Agent');
    }
  }

  return { isWSL: reasons.length > 0, reasons };
}

function detectSandboxHints(): { isSandboxed: boolean; reasons: string[] } {
  const reasons: string[] = [];

  try {
    if (window.self !== window.top) {
      reasons.push('Running inside an iframe');
    }
  } catch {
    reasons.push('Cross-origin iframe blocked access to window.top');
  }

  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) reasons.push('Canvas 2D context unavailable');
  } catch {
    reasons.push('Canvas feature blocked');
  }

  try {
    const pc = new RTCPeerConnection({ iceServers: [] });
    pc.close();
  } catch {
    reasons.push('WebRTC is blocked (common in restricted environments)');
  }

  return { isSandboxed: reasons.length > 0, reasons };
}

export async function scanOS(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];
  const ua = navigator.userAgent;

  const osName = detectOS(ua);
  items.push(createLeakItem(
    'os-name', 'Operating System', osName, 'high',
    'Your operating system can be identified from the User Agent and platform strings.',
    'OS identification is fundamental to creating a browser profile and enables operating system-specific security attacks.',
    'Use browsers that spoof or minimize OS information in the User Agent.',
    ['Tor Browser', 'Brave']
  ));

  const osVersion = detectOSVersion(ua);
  items.push(createLeakItem(
    'os-version', 'OS Version', osVersion, 'high',
    'The specific OS version can be estimated from the User Agent string.',
    'Knowing the exact OS version allows targeting of operating system-specific vulnerabilities and makes your profile more unique.',
    'Keep your OS updated. Use browsers that reduce version detail leakage.',
    ['Tor Browser']
  ));

  const isWindows = /Windows/.test(ua);
  items.push(createLeakItem(
    'os-windows', 'Windows Detection', isWindows, 'medium',
    'Windows can be detected from the User Agent string.',
    'Windows detection enables Windows-specific profiling techniques and security attacks.',
    'Use privacy-focused browsers that normalize OS signals.',
    ['Tor Browser']
  ));

  const isAndroid = /Android/.test(ua);
  items.push(createLeakItem(
    'os-android', 'Android Detection', isAndroid, 'medium',
    'Android can be detected from the User Agent string.',
    'Android detection enables mobile-specific tracking and reveals your device category.',
    'Use browsers that provide a generic mobile user agent.',
    ['Tor Browser']
  ));

  const isIOS = /iPhone|iPad|iPod/.test(ua) || (navigator.maxTouchPoints > 1 && /Macintosh/.test(ua));
  items.push(createLeakItem(
    'os-ios', 'iOS Detection', isIOS, 'medium',
    'iOS can be detected from the User Agent string or touch capabilities on macOS.',
    'iOS detection enables Apple-specific profiling and reveals a premium device user.',
    'Use browsers that normalize iOS-specific signals.',
    ['Tor Browser']
  ));

  const isLinux = /Linux/.test(ua) && !/Android/.test(ua);
  items.push(createLeakItem(
    'os-linux', 'Linux Detection', isLinux, 'medium',
    'Linux can be detected from the User Agent string (excluding Android).',
    'Linux users are a small minority, making this a more identifying detail for creating a unique profile of you.',
    'Use browsers that report a generic OS to reduce uniqueness.',
    ['Tor Browser']
  ));

  const isMacOS = /Mac OS X/.test(ua) && !/iPhone|iPad|iPod/.test(ua);
  items.push(createLeakItem(
    'os-macos', 'macOS Detection', isMacOS, 'medium',
    'macOS can be detected from the User Agent string.',
    'macOS detection reveals a premium device user and enables Apple-specific profiling techniques.',
    'Use browsers that normalize macOS-specific signals.',
    ['Tor Browser']
  ));

  const emulatorResult = detectEmulatorHints();
  items.push(createLeakItem(
    'os-emulator', 'Emulator Hints', emulatorResult.isEmulator ? `Possible emulator: ${emulatorResult.reasons.join('; ')}` : 'No emulator indicators detected', emulatorResult.isEmulator ? 'high' : 'safe',
    'Emulator environments can be detected by checking for missing sensors or unusual hardware combinations.',
    'Emulator detection can reveal that the browsing session is not from a real device, which may trigger additional security checks.',
    'Use real devices for privacy-sensitive browsing. Emulators provide weak anonymity.',
    []
  ));

  const vmResult = detectVMHints();
  items.push(createLeakItem(
    'os-vm', 'Virtual Machine Hints', vmResult.isVM ? `Possible VM: ${vmResult.reasons.join('; ')}` : 'No VM indicators detected', vmResult.isVM ? 'medium' : 'safe',
    'Virtual machines can be detected through GPU renderer analysis and hardware specifications.',
    'VM detection reveals that the browsing session is not from a physical computer, which may affect anonymity assumptions.',
    'Use VMs with GPU passthrough for better stealth. Be aware that VM characteristics are detectable.',
    []
  ));

  const wslResult = detectWSLHints();
  items.push(createLeakItem(
    'os-wsl', 'Windows Subsystem for Linux (WSL) Hints', wslResult.isWSL ? `Possible WSL: ${wslResult.reasons.join('; ')}` : 'No WSL indicators detected', wslResult.isWSL ? 'low' : 'safe',
    'Windows Subsystem for Linux can sometimes be detected through UA and platform inconsistencies.',
    'WSL detection is a minor signal that reveals a specific development environment setup.',
    'No specific mitigation needed as this is a low-impact signal.',
    []
  ));

  const sandboxResult = detectSandboxHints();
  items.push(createLeakItem(
    'os-sandbox', 'Sandbox Hints', sandboxResult.isSandboxed ? `Sandboxed: ${sandboxResult.reasons.join('; ')}` : 'No sandbox indicators detected', sandboxResult.isSandboxed ? 'medium' : 'safe',
    'Restricted browsing environments (embedded pages, limited features) can be detected through various feature availability checks.',
    'Detecting a restricted environment reveals that the browsing session has limited capabilities, which may affect security assumptions.',
    'Be aware of restricted environment limitations when relying on browser features for security.',
    []
  ));

  const virtualizationHints: string[] = [];
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl');
    if (gl) {
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) as string;
        const vmNames = ['VMware', 'VirtualBox', 'Parallels', 'QEMU', 'VBox'];
        for (const name of vmNames) {
          if (renderer.includes(name)) {
            virtualizationHints.push(`GPU renderer contains "${name}"`);
          }
        }
      }
    }
  } catch {}
  if (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 1) {
    virtualizationHints.push('Very low CPU core count');
  }
  items.push(createLeakItem(
    'os-virtualization', 'Virtualization Hints', virtualizationHints.length > 0 ? virtualizationHints.join('; ') : 'No virtualization indicators detected', virtualizationHints.length > 0 ? 'medium' : 'safe',
    'Virtualization can be detected through GPU renderer names, hardware specs, and timing measurements.',
    'Virtualization detection reveals that the browsing environment is running inside virtual software, which may compromise your privacy.',
    'Use hardware with GPU passthrough for better privacy in virtualized environments.',
    []
  ));

  items.push(createLeakItem(
    'os-platform', 'Operating System Platform', navigator.platform, 'high',
    'The navigator.platform property reveals your operating system platform.',
    'The platform string is a direct operating system identifier used for profiling. It cannot be easily changed without breaking compatibility.',
    'Use browsers that spoof the platform string to a common value.',
    ['Tor Browser']
  ));

  const is64Bit = /x86_64|Win64|x64|amd64|aarch64/.test(ua) || navigator.platform === 'Linux x86_64';
  items.push(createLeakItem(
    'os-architecture', 'Operating System Type (32-bit/64-bit)', is64Bit ? '64-bit' : '32-bit', 'low',
    'Whether your operating system is 32-bit or 64-bit can be guessed from the User Agent.',
    'This reveals little since most modern systems are 64-bit.',
    'No specific mitigation needed.',
    []
  ));

  return items;
}
