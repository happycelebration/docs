import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'browser', description, impact, mitigation, tools };
}

function parseBrowserFromUA(ua: string): { name: string; version: string } {
  if (ua.includes('Firefox/')) {
    const match = ua.match(/Firefox\/([\d.]+)/);
    return { name: 'Firefox', version: match?.[1] ?? 'Unknown' };
  }
  if (ua.includes('Edg/')) {
    const match = ua.match(/Edg\/([\d.]+)/);
    return { name: 'Edge', version: match?.[1] ?? 'Unknown' };
  }
  if (ua.includes('OPR/') || ua.includes('Opera/')) {
    const match = ua.match(/(?:OPR|Opera)\/([\d.]+)/);
    return { name: 'Opera', version: match?.[1] ?? 'Unknown' };
  }
  if (ua.includes('Chrome/')) {
    const match = ua.match(/Chrome\/([\d.]+)/);
    return { name: 'Chrome', version: match?.[1] ?? 'Unknown' };
  }
  if (ua.includes('Safari/') && ua.includes('Version/')) {
    const match = ua.match(/Version\/([\d.]+)/);
    return { name: 'Safari', version: match?.[1] ?? 'Unknown' };
  }
  return { name: 'Unknown', version: 'Unknown' };
}

function detectEngine(ua: string): string {
  if (ua.includes('Gecko/')) return 'Gecko';
  if (ua.includes('AppleWebKit/')) return 'WebKit';
  if (ua.includes('Trident/')) return 'Trident';
  return 'Unknown';
}

async function detectAdBlocker(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    const res = await fetch('https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js', {
      method: 'HEAD',
      mode: 'no-cors',
      signal: controller.signal,
    });
    clearTimeout(timeout);
    return false;
  } catch {
    return true;
  }
}

async function detectDevTools(): Promise<boolean> {
  try {
    const threshold = 160;
    const t1 = performance.now();
    debugger;
    const t2 = performance.now();
    return (t2 - t1) > threshold;
  } catch {
    return false;
  }
}

function detectHeadless(): { isHeadless: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const ua = navigator.userAgent;

  if (ua.includes('HeadlessChrome')) reasons.push('HeadlessChrome in User Agent');
  if (navigator.webdriver) reasons.push('navigator.webdriver is true');

  const hasChrome = 'chrome' in window;
  const hasPlugins = navigator.plugins && navigator.plugins.length > 0;
  const hasLanguages = navigator.languages && navigator.languages.length > 0;

  if (!hasChrome && ua.includes('Chrome')) reasons.push('Missing window.chrome object');
  if (!hasPlugins && !ua.includes('Firefox')) reasons.push('No browser plugins detected');
  if (!hasLanguages) reasons.push('No languages array');

  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl');
  if (gl) {
    const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
    if (debugInfo) {
      const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
      if (typeof renderer === 'string' && renderer.includes('SwiftShader')) {
        reasons.push('SwiftShader GPU renderer (software rendering)');
      }
    }
  }

  return { isHeadless: reasons.length > 0, reasons };
}

export async function scanBrowser(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];
  const ua = navigator.userAgent;

  items.push(createLeakItem(
    'browser-user-agent', 'Browser Identifier (User Agent)', ua, 'high',
    'Your browser identifier string reveals your browser, version, operating system, and device type.',
    'Websites use this to identify your browser and serve targeted content or track you across visits.',
    'Use a privacy-focused browser that randomizes or hides or changes the browser identifier. Consider using browser extensions like Browser Identifier Switcher.',
    ['Tor Browser', 'Brave', 'Browser Identifier Switcher Extensions']
  ));

  const browserInfo = parseBrowserFromUA(ua);
  items.push(createLeakItem(
    'browser-name-version', 'Browser Name & Version', `${browserInfo.name} ${browserInfo.version}`, 'high',
    'The specific browser and version can be identified from your browser identifier string.',
    'Knowing your exact browser version allows trackers to target known vulnerabilities or create a unique profile of your session.',
    'Keep your browser updated. Use browsers that minimize version detail in the browser identifier.',
    ['Tor Browser', 'Brave']
  ));

  const engine = detectEngine(ua);
  items.push(createLeakItem(
    'browser-engine', 'Browser Rendering Engine', engine, 'medium',
    'The rendering engine used by your browser can be detected.',
    'Engine identification narrows down the browser family and enables engine-specific methods of creating a unique browser profile.',
    'Use browsers that normalize engine-specific behaviors.',
    ['Tor Browser']
  ));

  items.push(createLeakItem(
    'browser-platform', 'Platform', navigator.platform, 'high',
    'Your browser reveals the type of operating system you are using.',
    'This provides operating system-level identification that can be combined with other details for creating a unique browser profile.',
    'Some browsers hide or change this value. Use browsers that randomize platform reporting.',
    ['Tor Browser', 'Brave']
  ));

  items.push(createLeakItem(
    'browser-vendor', 'Vendor', navigator.vendor, 'medium',
    'Your browser reveals which company made it.',
    'This helps identify which browser family you are using, contributing to how uniquely identifiable your browser is.',
    'This property is built into browsers and cannot easily be hidden without causing compatibility issues.',
    ['Tor Browser']
  ));

  items.push(createLeakItem(
    'browser-product', 'Product', navigator.product, 'low',
    'Your browser typically reports "Gecko" as its product name regardless of the actual engine.',
    'While mostly useless for identification, inconsistencies can reveal attempts to hide or change browser details.',
    'No specific mitigation needed as this property is outdated and not standard.',
    []
  ));

  const productSub = typeof navigator.productSub !== 'undefined' ? navigator.productSub : null;
  items.push(createLeakItem(
    'browser-productsub', 'Browser Build Sub-identifier', productSub, 'low',
    'This reveals the build number of the browser (Firefox only).',
    'Chrome does not report this while Firefox returns a build identifier, helping distinguish browser families.',
    'No specific mitigation needed as this is a minor identifier.',
    []
  ));

  const appCodeName = navigator.appCodeName;
  items.push(createLeakItem(
    'browser-appcodename', 'Browser Code Name', appCodeName, 'low',
    'Your browser always reports "Mozilla" as its code name in all modern browsers.',
    'Historically used for browser detection, now mostly useless but inconsistencies could reveal attempts to hide or change browser details.',
    'No specific mitigation needed.',
    []
  ));

  const appVersion = navigator.appVersion;
  items.push(createLeakItem(
    'browser-appversion', 'AppVersion', appVersion, 'medium',
    'Your browser reveals version and operating system information.',
    'Combined with other details, this adds to the information that can be used to identify your browser.',
    'Use browsers that minimize information shared about your system.',
    ['Tor Browser']
  ));

  const buildId = typeof (navigator as Record<string, unknown>).buildId !== 'undefined' ? (navigator as Record<string, unknown>).buildId as string : null;
  items.push(createLeakItem(
    'browser-buildid', 'Browser Build ID', buildId, 'medium',
    'This reveals the specific build identifier of your browser (Firefox only).',
    'This provides a very specific detail that can be used to create a unique profile of you by identifying your exact browser build.',
    'Use Firefox with privacy protection enabled, which returns a generic build ID instead of the real one.',
    ['Tor Browser', 'Firefox with Privacy Protection']
  ));

  const oscpu = typeof (navigator as Record<string, unknown>).oscpu !== 'undefined' ? (navigator as Record<string, unknown>).oscpu as string : null;
  items.push(createLeakItem(
    'browser-oscpu', 'Operating System & CPU Info', oscpu, 'high',
    'This reveals details about your operating system and CPU (Firefox only).',
    'This provides detailed operating system and CPU information that significantly contributes to creating a unique profile of your browser.',
    'Use Firefox with privacy protection enabled, which hides or changes this value.',
    ['Tor Browser', 'Firefox with Privacy Protection']
  ));

  const language = navigator.language;
  items.push(createLeakItem(
    'browser-language', 'Language', language, 'high',
    'Your browser language preference reveals your likely geographic region or nationality.',
    'Language preference is a very specific detail that can be used to create a unique profile of you and deliver targeted content.',
    'Set a common language like en-US. Use browsers that normalize language reporting.',
    ['Tor Browser']
  ));

  const languages = navigator.languages ? navigator.languages.join(', ') : null;
  items.push(createLeakItem(
    'browser-languages', 'Languages', languages, 'high',
    'The full list of language preferences provides even more specific identification than a single language.',
    'The combination and order of preferred languages is highly unique and a powerful detail that can help identify your browser.',
    'Limit your language list to a single common language. Use privacy-focused browsers that hide or change this.',
    ['Tor Browser', 'Brave']
  ));

  const dnt = navigator.doNotTrack;
  items.push(createLeakItem(
    'browser-dnt', 'Do Not Track', dnt, 'medium',
    'The Do Not Track header signals your tracking preference to websites.',
    'Ironically, having Do Not Track enabled can itself be a detail that can help identify your browser since few users enable it. Some trackers ignore Do Not Track entirely.',
    'Consider whether Do Not Track helps or hurts your privacy level. Privacy-focused browsers handle this automatically.',
    ['Brave', 'Tor Browser']
  ));

  const cookieEnabled = navigator.cookieEnabled;
  items.push(createLeakItem(
    'browser-cookies', 'Cookies Enabled', cookieEnabled, 'medium',
    'Whether cookies are enabled affects how websites can track you.',
    'Disabling cookies reduces tracking but can itself be a detail that can help identify your browser. Most trackers use cookie alternatives.',
    'Use browsers with intelligent cookie management rather than disabling cookies entirely.',
    ['Brave', 'Firefox with Enhanced Tracking Protection']
  ));

  let pdfViewerEnabled: boolean | null = null;
  try {
    pdfViewerEnabled = (navigator as Record<string, unknown>).pdfViewerEnabled as boolean | null ?? null;
  } catch {}
  items.push(createLeakItem(
    'browser-pdf-viewer', 'PDF Viewer Enabled', pdfViewerEnabled, 'low',
    'Indicates whether the browser has a built-in PDF viewer.',
    'This is a not very identifying detail that helps distinguish browser configurations.',
    'No specific mitigation needed as this is not a very identifying detail.',
    []
  ));

  let javaEnabled: boolean | null = null;
  try {
    javaEnabled = typeof (navigator as Record<string, unknown>).javaEnabled === 'function'
      ? (navigator as Record<string, unknown>).javaEnabled.call(navigator) as boolean
      : null;
  } catch {}
  items.push(createLeakItem(
    'browser-java', 'Java Enabled', javaEnabled, 'low',
    'Java applet support is outdated and removed from modern browsers.',
    'If still reported, this is a not very identifying detail on its own. However, older browsers with Java enabled are extremely unique and easy to identify.',
    'Use a modern browser that does not support Java applets.',
    []
  ));

  const isBrave = typeof (navigator as Record<string, unknown>).brave === 'object' && typeof (navigator as Record<string, unknown>).brave?.isBrave === 'function';
  items.push(createLeakItem(
    'browser-brave', 'Brave Browser Detected', isBrave, 'low',
    'Brave browser can be detected through its built-in identification feature.',
    'While Brave provides privacy features, being detectable as a Brave user is itself a detail that can help identify your browser.',
    'Brave is working on making this detection harder. Using Tor mode provides stronger anonymity.',
    ['Brave with Tor']
  ));

  const headlessResult = detectHeadless();
  items.push(createLeakItem(
    'browser-headless', 'Automated Browser Detection', headlessResult.isHeadless ? `Detected: ${headlessResult.reasons.join('; ')}` : 'Not detected', headlessResult.isHeadless ? 'critical' : 'safe',
    'Automated browsers without a visible window are often used for scripted browsing, data collection, and bot activity.',
    'If detected, it indicates your browser is running automatically rather than being used by a person. Some websites block automated browsers or show different content.',
    'Avoid using automated mode for privacy-sensitive browsing. Use a normal browser window instead.',
    []
  ));

  const webdriverEnabled = navigator.webdriver;
  items.push(createLeakItem(
    'browser-webdriver', 'Bot/Automation Detection', webdriverEnabled, webdriverEnabled ? 'critical' : 'safe',
    'This indicates if the browser is being controlled by automation tools rather than a real person.',
    'This detection reveals that the browser session is not operated by a real person, which can affect how websites respond to you.',
    'Do not use automated browsers for privacy-sensitive tasks. Some tools can hide or change this property.',
    []
  ));

  let devToolsOpen = false;
  try {
    devToolsOpen = await detectDevTools();
  } catch {}
  items.push(createLeakItem(
    'browser-devtools', 'Developer Tools Detection', devToolsOpen, 'low',
    'Developer tools can be detected using timing-based detection methods.',
    'Knowing Developer Tools are open is a minor clue, but some sites use it to detect debugging or reverse engineering.',
    'No specific mitigation needed for most users. Use browser extensions to hide or change Developer Tools detection if concerned.',
    []
  ));

  let adBlockerDetected = false;
  try {
    adBlockerDetected = await detectAdBlocker();
  } catch {}
  items.push(createLeakItem(
    'browser-adblocker', 'Ad Blocker Detection', adBlockerDetected, 'low',
    'Ad blockers can be detected by attempting to load known ad scripts.',
    'Having an ad blocker is a detail that can help identify your browser since not all users have one. However, ad blockers improve privacy.',
    'Using an ad blocker is recommended despite the small risk of being identified. The privacy benefits outweigh the minor detail.',
    ['uBlock Origin', 'Brave Shields', 'AdGuard']
  ));

  let extensionInterference = false;
  try {
    const testEl = document.createElement('div');
    testEl.id = 'adsense';
    testEl.className = 'ad-placement';
    document.body.appendChild(testEl);
    await new Promise(r => setTimeout(r, 100));
    const computed = window.getComputedStyle(testEl);
    extensionInterference = computed.display === 'none' || computed.visibility === 'hidden';
    document.body.removeChild(testEl);
  } catch {}
  items.push(createLeakItem(
    'browser-extension-interference', 'Extension Interference Detection', extensionInterference, 'low',
    'Browser extensions that change page content can be detected by checking for modifications to the page.',
    'Detectable extensions contribute to creating a unique browser profile. Hiding ad elements through styling reveals ad blocker presence.',
    'Use privacy extensions that are less detectable. Some modern blockers use less detectable methods.',
    ['uBlock Origin', 'Privacy Badger']
  ));

  return items;
}
