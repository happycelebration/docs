import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'security', description, impact, mitigation, tools };
}

export async function scanSecurity(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const isHTTPS = typeof location !== 'undefined' && location.protocol === 'https:';
  items.push(createLeakItem(
    'security-https', 'HTTPS Status', isHTTPS ? 'Secure (HTTPS)' : 'Insecure (HTTP)', isHTTPS ? 'safe' : 'critical',
    'HTTPS encryption protects data sent between your browser and the website.',
    'Without HTTPS, all data including passwords and session information can be intercepted by attackers on the network.',
    'Only visit sites that use HTTPS. Use browsers that automatically upgrade HTTP connections to HTTPS.',
    ['HTTPS Everywhere', 'Brave', 'Firefox']
  ));

  let mixedContentDetected = false;
  try {
    if (isHTTPS && typeof document !== 'undefined') {
      const resources = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
      for (const r of resources) {
        if (r.name && r.name.startsWith('http://')) {
          mixedContentDetected = true;
          break;
        }
      }
    }
  } catch {}
  items.push(createLeakItem(
    'security-mixed-content', 'Mixed Content Detection', mixedContentDetected ? 'Mixed content detected' : 'No mixed content detected', mixedContentDetected ? 'high' : 'safe',
    'Mixed content occurs when a secure (HTTPS) page loads some resources over an insecure (HTTP) connection, compromising security.',
    'Mixed content allows attackers to intercept or modify the insecure resources, potentially injecting malicious code.',
    'Use browsers that block mixed content automatically. Website operators should ensure all resources use HTTPS.',
    ['Brave', 'Chrome', 'Firefox']
  ));

  items.push(createLeakItem(
    'security-csp', 'Content Security Policy (CSP)', 'Cannot be directly inspected from client-side JavaScript. Content Security Policy headers protect against script injection and other attacks.', 'medium',
    'Content Security Policy (CSP) is a security feature that restricts which resources a page can load, preventing malicious script injection and data theft attacks.',
    'Without Content Security Policy, pages are more vulnerable to cross-site scripting attacks that can steal your login credentials and session information.',
    'Use browser extensions that report or enforce Content Security Policy. Website operators should implement strict policies.',
    ['CSP Evaluator', 'Report URI']
  ));

  let referrerPolicy = 'Not Available';
  try {
    const metaTags = document.querySelectorAll('meta[name="referrer"]');
    if (metaTags.length > 0) {
      referrerPolicy = metaTags[0].getAttribute('content') || 'Not Available';
    } else {
      referrerPolicy = 'Default (no explicit policy)';
    }
  } catch {}
  items.push(createLeakItem(
    'security-referrer-policy', 'Referrer Policy', referrerPolicy, 'medium',
    'Referrer Policy controls how much information about the current page is shared with other websites when you click a link.',
    'A permissive referrer policy can leak the full URL (including private path and search terms) to third-party sites, revealing your browsing behavior.',
    'Set referrer policy to "no-referrer" or "same-origin" to minimize information leakage.',
    ['Brave', 'Firefox']
  ));

  items.push(createLeakItem(
    'security-permissions-policy', 'Permissions Policy', 'Cannot be directly inspected from client-side JavaScript. Permissions Policy controls which browser features and capabilities can be used.', 'medium',
    'Permissions Policy (formerly Feature Policy) restricts which browser features websites are allowed to use.',
    'Without Permissions Policy, all features are available by default, increasing the chances of being profiled or exploited.',
    'Website operators should implement strict Permissions Policies to limit feature exposure.',
    []
  ));

  const isSecureContext = typeof window !== 'undefined' && window.isSecureContext;
  items.push(createLeakItem(
    'security-secure-context', 'Secure Context', isSecureContext, isSecureContext ? 'safe' : 'high',
    'A secure context is required for many sensitive browser features (like Geolocation and Background Scripts).',
    'A non-secure context means the page is loaded over HTTP, so sensitive features may be blocked, but data is still vulnerable to interception.',
    'Always use HTTPS to ensure a secure context and access to security-restricted browser features.',
    []
  ));

  const isCrossOriginIsolated = typeof window !== 'undefined' && (window as Record<string, unknown>).crossOriginIsolated === true;
  items.push(createLeakItem(
    'security-cross-origin-isolated', 'Cross-Origin Isolation', isCrossOriginIsolated, isCrossOriginIsolated ? 'safe' : 'medium',
    'Cross-origin isolation is a security boundary that enables advanced features like high-resolution timers, which were restricted after the Spectre vulnerability was discovered.',
    'Without cross-origin isolation, the page cannot use certain advanced features, but it also cannot be attacked via Spectre-style side-channel methods as easily.',
    'Website operators should implement Cross-Origin Opener Policy and Cross-Origin Embedder Policy headers to enable cross-origin isolation where needed.',
    []
  ));

  items.push(createLeakItem(
    'security-coop-coep', 'Cross-Origin Isolation Status', isCrossOriginIsolated ? 'Cross-origin isolated (policies enabled)' : 'Not cross-origin isolated (policies may not be set)', isCrossOriginIsolated ? 'safe' : 'medium',
    'Cross-Origin Opener Policy (COOP) and Cross-Origin Embedder Policy (COEP) are security headers that work together to create a cross-origin isolation boundary.',
    'Without COOP, other websites can access the page\'s window reference. Without COEP, resources from other websites can be loaded without verification, enabling Spectre-style attacks.',
    'Website operators should set both COOP and COEP headers for maximum security.',
    []
  ));

  items.push(createLeakItem(
    'security-xss', 'Cross-Site Scripting (XSS) Exposure', 'Explanation only', 'high',
    'Cross-Site Scripting (XSS) attacks inject malicious scripts into trusted websites.',
    'XSS can steal your login credentials and session information, redirect you to malicious sites, and perform actions on your behalf. Stored XSS (where the script is saved on the server) is particularly dangerous.',
    'Use browsers with built-in XSS filters. Keep browser extensions minimal. Use Content Security Policy.',
    ['Brave', 'NoScript']
  ));

  let isInIframe = false;
  try {
    isInIframe = window.self !== window.top;
  } catch {
    isInIframe = true;
  }
  items.push(createLeakItem(
    'security-clickjacking', 'Clickjacking Risk', isInIframe ? 'Running in iframe - clickjacking possible' : 'Not in iframe', isInIframe ? 'high' : 'safe',
    'Clickjacking embeds a page in an invisible frame to trick you into clicking hidden elements.',
    'If this page is in a frame, it could be subject to clickjacking attacks where invisible overlays trick you into unintended actions.',
    'Website operators should set X-Frame-Options or Content Security Policy frame-ancestors directive to prevent framing.',
    ['NoScript']
  ));

  items.push(createLeakItem(
    'security-mime-sniffing', 'Content Type Guessing (MIME Sniffing) Risk', 'Explanation only', 'medium',
    'Content type guessing (MIME sniffing) allows browsers to guess what kind of file a resource is, potentially executing uploaded files as scripts.',
    'Without the proper header to prevent guessing, browsers may interpret uploaded files (e.g., images) as scripts, enabling cross-site scripting attacks.',
    'Website operators should set the proper header to prevent content type guessing (X-Content-Type-Options: nosniff).',
    []
  ));

  items.push(createLeakItem(
    'security-cors', 'Cross-Origin Access (CORS) Observations', 'Cross-Origin Resource Sharing (CORS) policies control which other websites can access resources. Improper CORS configuration can expose sensitive data.', 'medium',
    'CORS headers control which other websites can access data and resources from this site.',
    'Misconfigured CORS (e.g., allowing access from any website) can expose sensitive data and features to any origin, enabling data theft.',
    'Website operators should restrict CORS to specific trusted websites. Never allow access from all websites for sensitive data.',
    []
  ));

  items.push(createLeakItem(
    'security-password-manager', 'Password Manager Detection', 'Browser password managers can be detected through autofill behavior analysis.', 'low',
    'Password manager autofill behavior can be detected by websites through timing and page analysis.',
    'Knowing a password manager is present reveals your security practices and can be used as a minor way to profile you.',
    'Use built-in browser password managers rather than detectable third-party extensions.',
    ['Bitwarden', '1Password', 'KeePassXC']
  ));

  const powerfulAPIs: string[] = [];
  try {
    if (navigator.geolocation) powerfulAPIs.push('Geolocation');
  } catch {}
  try {
    if (navigator.mediaDevices) powerfulAPIs.push('MediaDevices');
  } catch {}
  try {
    if (typeof (navigator as Record<string, unknown>).bluetooth === 'object') powerfulAPIs.push('Bluetooth');
  } catch {}
  try {
    if (typeof (navigator as Record<string, unknown>).usb === 'object') powerfulAPIs.push('USB');
  } catch {}
  try {
    if (typeof (navigator as Record<string, unknown>).serial === 'object') powerfulAPIs.push('Serial');
  } catch {}
  items.push(createLeakItem(
    'security-unsafe-api', 'Sensitive Feature Access', powerfulAPIs.length > 0 ? `Available: ${powerfulAPIs.join(', ')}` : 'No sensitive features detected', powerfulAPIs.length > 3 ? 'high' : 'medium',
    'Sensitive features (Geolocation, Bluetooth, USB, Serial) provide access to sensitive device capabilities.',
    'More available features means greater chances of being profiled or exploited, and more ways to profile you. Each feature can potentially leak sensitive information.',
    'Disable unused features through browser settings. Use browsers that require explicit permission for sensitive features.',
    ['Brave', 'Firefox']
  ));

  const deprecatedAPIs: string[] = [];
  try {
    if (typeof (navigator as Record<string, unknown>).javaEnabled === 'function') deprecatedAPIs.push('navigator.javaEnabled()');
  } catch {}
  try {
    if (document.registerElement) deprecatedAPIs.push('document.registerElement()');
  } catch {}
  try {
    if (typeof (window as Record<string, unknown>).webkitStorageInfo !== 'undefined') deprecatedAPIs.push('webkitStorageInfo');
  } catch {}
  items.push(createLeakItem(
    'security-deprecated-api', 'Outdated Feature Usage', deprecatedAPIs.length > 0 ? `Detected: ${deprecatedAPIs.join(', ')}` : 'No outdated features detected', deprecatedAPIs.length > 0 ? 'medium' : 'safe',
    'Outdated features indicate an older browser version or compatibility code that may have security vulnerabilities.',
    'Using outdated features increases the chances of being profiled or exploited and can indicate an outdated browser that lacks modern security protections.',
    'Keep your browser updated to the latest version. Avoid using outdated browser features.',
    []
  ));

  let clipboardAvailable = false;
  try {
    clipboardAvailable = typeof navigator.clipboard !== 'undefined';
  } catch {}
  items.push(createLeakItem(
    'security-clipboard', 'Clipboard Security', clipboardAvailable ? 'Clipboard feature available' : 'Clipboard feature not available', clipboardAvailable ? 'medium' : 'safe',
    'The Clipboard feature allows reading and writing to the system clipboard (copy/paste).',
    'Malicious websites could potentially read clipboard data containing passwords or other sensitive information if permission is granted.',
    'Deny clipboard access requests from untrusted sites. Use browsers that require a user action (like a click) for clipboard access.',
    ['Brave', 'Firefox']
  ));

  return items;
}
