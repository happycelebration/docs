import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'network', description, impact, mitigation, tools };
}

interface IPGeoData {
  ip: string;
  city: string;
  country: string;
  region: string;
  loc: string;
  org: string;
  timezone: string;
}

async function getPublicIP(): Promise<IPGeoData> {
  try {
    const res = await fetch('/api/ip', { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error('Failed');
    return await res.json();
  } catch {
    return { ip: 'unknown', city: 'Unknown', country: 'Unknown', region: 'Unknown', loc: '0,0', org: 'Unknown', timezone: 'Unknown' };
  }
}

async function getLocalIPViaWebRTC(): Promise<{ ip: string; leaked: boolean }> {
  return new Promise((resolve) => {
    let localIP = '';
    let leaked = false;
    try {
      const pc = new RTCPeerConnection({ iceServers: [] });
      pc.createDataChannel('');
      pc.createOffer().then(offer => pc.setLocalDescription(offer)).catch(() => {});
      pc.onicecandidate = (e) => {
        if (!e.candidate) return;
        const candidate = e.candidate.candidate;
        const ipRegex = /([0-9]{1,3}\.){3}[0-9]{1,3}/;
        const match = candidate.match(ipRegex);
        if (match) {
          const ip = match[0];
          if (!ip.startsWith('0.') && !ip.startsWith('127.')) {
            localIP = ip;
            leaked = true;
          }
        }
      };
      setTimeout(() => {
        pc.close();
        resolve({ ip: localIP || 'Not Available', leaked });
      }, 3000);
    } catch {
      resolve({ ip: 'Not Available', leaked: false });
    }
  });
}

export async function scanNetwork(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const ipGeo = await getPublicIP();
  items.push(createLeakItem(
    'network-public-ip', 'Public IP Address', ipGeo.ip, 'critical',
    'Your public IP address uniquely identifies your internet connection.',
    'Your IP address is the most direct identifier of your network connection. It can reveal your approximate location and ISP.',
    'Use a VPN, Tor, or proxy to hide your real IP address. Choose providers that do not log your activity.',
    ['Tor Browser', 'Mullvad VPN', 'ProtonVPN', 'IVPN']
  ));

  items.push(createLeakItem(
    'network-ip-city', 'IP Geolocation (City)', ipGeo.city, 'high',
    'Your approximate city can be determined from your IP address.',
    'City-level geolocation narrows your identity to a geographic area, useful for targeted advertising and tracking.',
    'Use a VPN to mask your real location. Choose a VPN server in a different city or country.',
    ['Mullvad VPN', 'ProtonVPN']
  ));

  items.push(createLeakItem(
    'network-ip-country', 'IP Geolocation (Country)', ipGeo.country, 'high',
    'Your country can be determined from your IP address.',
    'Country-level identification is used for content restrictions, targeted advertising, and regulatory compliance.',
    'Use a VPN to appear from a different country.',
    ['Mullvad VPN', 'ProtonVPN']
  ));

  items.push(createLeakItem(
    'network-ip-org', 'ISP / Organization', ipGeo.org, 'high',
    'Your Internet Service Provider can be identified from your IP address.',
    'ISP identification reveals who provides your internet and can be used for targeted attacks or legal requests.',
    'Use a VPN to hide your ISP information from websites.',
    ['Mullvad VPN', 'ProtonVPN']
  ));

  const webrtcResult = await getLocalIPViaWebRTC();
  items.push(createLeakItem(
    'network-local-ip', 'Local Network Address (WebRTC Leak)', webrtcResult.ip, webrtcResult.leaked ? 'critical' : 'safe',
    'A browser feature called WebRTC can reveal your local network address even through VPNs.',
    'A WebRTC leak can bypass VPN protection and reveal your real local network setup, including your router address.',
    'Disable WebRTC in your browser or use extensions that block WebRTC leaks. Many privacy browsers do this by default.',
    ['Brave', 'uBlock Origin', 'Privacy Badger']
  ));

  const conn = (navigator as Record<string, unknown>).connection as {
    type?: string;
    effectiveType?: string;
    downlink?: number;
    rtt?: number;
    saveData?: boolean;
  } | undefined;

  const connectionType = conn?.type ?? null;
  items.push(createLeakItem(
    'network-connection-type', 'Connection Type', connectionType, 'medium',
    'A browser capability called the Network Information feature reveals your connection type (wifi, cellular, etc.).',
    'Connection type information helps identify your network setup and can be used for tracking that adapts to you.',
    'This feature is not widely supported. Use browsers that do not implement it.',
    ['Firefox', 'Safari']
  ));

  const effectiveType = conn?.effectiveType ?? null;
  items.push(createLeakItem(
    'network-effective-type', 'Effective Connection Type', effectiveType, 'medium',
    'The effective connection type (4G, 3G, etc.) reveals your network quality.',
    'Effective connection type helps profile your network environment and can be used for creating a profile based on your connection speed.',
    'This feature is primarily available in Chromium-based browsers. Use Firefox or Safari to avoid exposure.',
    ['Firefox', 'Safari']
  ));

  const downlink = conn?.downlink ?? null;
  items.push(createLeakItem(
    'network-downlink', 'Downlink Speed', downlink !== null ? `${downlink} Mbps` : null, 'medium',
    'The estimated downlink speed of your connection.',
    'Downlink speed is a moderate identifying detail that varies by location and network conditions.',
    'This feature is primarily available in Chromium-based browsers.',
    ['Firefox', 'Safari']
  ));

  const rtt = conn?.rtt ?? null;
  items.push(createLeakItem(
    'network-rtt', 'Network Round-Trip Time (Latency)', rtt !== null ? `${rtt} ms` : null, 'medium',
    'The estimated round-trip time (how long data takes to travel to a server and back) of your connection.',
    'Network round-trip time reveals latency characteristics that can help estimate how far you are from servers.',
    'This feature is primarily available in Chromium-based browsers.',
    ['Firefox', 'Safari']
  ));

  const browserTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const ipTimezone = ipGeo.timezone;
  const timezoneMismatch = browserTimezone !== ipTimezone && ipTimezone !== 'Unknown' && browserTimezone !== 'Unknown';
  items.push(createLeakItem(
    'network-vpn-heuristic', 'VPN Detection (Timezone Mismatch)', timezoneMismatch ? `Mismatch: Browser=${browserTimezone}, IP=${ipTimezone}` : 'No timezone mismatch detected', timezoneMismatch ? 'medium' : 'safe',
    'A mismatch between your browser timezone and IP geolocation timezone may indicate VPN usage.',
    'Timezone mismatches are a common way to detect VPN usage. Some websites use this to serve different content or block access.',
    'If using a VPN, set your browser timezone to match the VPN exit location. Some VPN tools do this automatically.',
    ['Brave', 'VPN with timezone spoofing']
  ));

  const proxyHints: string[] = [];
  if (ipGeo.org && /proxy|vpn|tunnel|hosting|cloud|datacenter|server/i.test(ipGeo.org)) {
    proxyHints.push(`ISP name suggests proxy/hosting: ${ipGeo.org}`);
  }
  if (conn?.saveData) {
    proxyHints.push('Save-data mode detected (common in proxy environments)');
  }
  items.push(createLeakItem(
    'network-proxy-heuristic', 'Proxy Detection Clues', proxyHints.length > 0 ? proxyHints.join('; ') : 'No proxy indicators detected', proxyHints.length > 0 ? 'medium' : 'safe',
    'Various detection clues can suggest proxy usage, including ISP name and connection characteristics.',
    'Proxy detection can reveal that you are attempting to hide your real location, which may trigger additional verification.',
    'Use high-quality VPNs with residential IPs that are harder to detect as proxies.',
    ['Mullvad VPN', 'ProtonVPN']
  ));

  const torHints: string[] = [];
  if (ipGeo.org && /tor/i.test(ipGeo.org)) {
    torHints.push('ISP name contains Tor reference');
  }
  if (ipGeo.country && ipGeo.country !== 'Unknown') {
    const torCountries = ['Germany', 'Netherlands', 'France', 'Romania', 'Iceland'];
    if (torCountries.includes(ipGeo.country)) {
      torHints.push(`IP located in common Tor exit node country (${ipGeo.country})`);
    }
  }
  const isBrave = typeof (navigator as Record<string, unknown>).brave === 'object';
  if (isBrave && torHints.length > 0) {
    torHints.push('Brave browser detected (may be using Tor mode)');
  }
  items.push(createLeakItem(
    'network-tor-heuristic', 'Tor Detection Clues', torHints.length > 0 ? torHints.join('; ') : 'No Tor indicators detected', torHints.length > 0 ? 'low' : 'safe',
    'Various detection clues can suggest Tor usage, including ISP characteristics and IP geolocation.',
    'Tor detection is not inherently negative, but some websites block Tor exit nodes entirely.',
    'Use Tor Browser for maximum anonymity. Be aware that some sites may block Tor traffic.',
    ['Tor Browser']
  ));

  items.push(createLeakItem(
    'network-browser-timezone', 'Browser Timezone', browserTimezone, 'high',
    'Your browser timezone is visible to websites.',
    'Timezone is a specific detail that reveals your geographic region and can be combined with other details for creating a unique profile of you.',
    'Use browsers that spoof or randomize the timezone. Set timezone to UTC for maximum anonymity.',
    ['Tor Browser']
  ));

  const browserLocale = navigator.language;
  const ipCountry = ipGeo.country;
  const localeMismatch = browserLocale && ipCountry && ipCountry !== 'Unknown' && !browserLocale.includes(ipCountry.substring(0, 2).toLowerCase());
  items.push(createLeakItem(
    'network-locale-mismatch', 'Locale Mismatch', localeMismatch ? `Browser locale (${browserLocale}) may not match IP country (${ipCountry})` : 'No locale mismatch detected', localeMismatch ? 'medium' : 'safe',
    'A mismatch between your browser locale and IP geolocation may indicate location spoofing.',
    'Locale mismatches can reveal that you are using a VPN or have manually changed your language settings.',
    'Match your browser locale to your VPN exit location for consistency.',
    []
  ));

  items.push(createLeakItem(
    'network-webrtc-leak', 'WebRTC Information Leak Detection', webrtcResult.leaked ? 'WebRTC revealed local network address' : 'No WebRTC leak detected', webrtcResult.leaked ? 'critical' : 'safe',
    'A browser feature called WebRTC can leak your local network address even when using a VPN or proxy.',
    'A WebRTC information leak bypasses VPN protection and reveals your real local network setup to websites.',
    'Disable WebRTC in your browser settings or use extensions that prevent WebRTC IP leaks.',
    ['Brave', 'uBlock Origin', 'WebRTC Blocker Extensions']
  ));

  return items;
}
