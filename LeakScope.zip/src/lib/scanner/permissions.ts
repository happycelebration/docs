import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'permissions', description, impact, mitigation, tools };
}

async function queryPermission(name: PermissionName): Promise<string> {
  try {
    const result = await navigator.permissions.query({ name });
    return result.state;
  } catch {
    return 'unsupported';
  }
}

export async function scanPermissions(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const cameraState = await queryPermission('camera' as PermissionName);
  items.push(createLeakItem(
    'perm-camera', 'Camera Permission', cameraState, cameraState === 'granted' ? 'high' : cameraState === 'prompt' ? 'medium' : 'safe',
    'Camera permission shows whether websites are allowed to use your camera.',
    'If granted, websites can turn on your camera. Even the permission state itself gives away details that make your browser unique.',
    'Deny camera access to untrusted sites. Review and revoke camera permissions regularly.',
    ['Brave', 'Firefox']
  ));

  const micState = await queryPermission('microphone' as PermissionName);
  items.push(createLeakItem(
    'perm-microphone', 'Microphone Permission', micState, micState === 'granted' ? 'high' : micState === 'prompt' ? 'medium' : 'safe',
    'Microphone permission shows whether websites are allowed to use your microphone.',
    'If granted, websites can listen to your microphone. The permission state gives away details that make your browser unique.',
    'Deny microphone access to untrusted sites. Review and revoke permissions regularly.',
    ['Brave', 'Firefox']
  ));

  let notifState = 'unsupported';
  try {
    notifState = typeof Notification !== 'undefined' ? Notification.permission : 'unsupported';
  } catch {}
  items.push(createLeakItem(
    'perm-notifications', 'Notification Permission', notifState, notifState === 'granted' ? 'medium' : 'low',
    'Notification permission shows whether websites are allowed to send you push notifications.',
    'If granted, websites can send you push messages even when you are not on their site. The permission state gives away details that make your browser unique.',
    'Deny notification permissions to untrusted sites. Use browsers that auto-block notification requests.',
    ['Brave', 'Firefox']
  ));

  const geoState = await queryPermission('geolocation');
  items.push(createLeakItem(
    'perm-geolocation', 'Geolocation Permission', geoState, geoState === 'granted' ? 'high' : geoState === 'prompt' ? 'medium' : 'safe',
    'Geolocation permission shows whether websites are allowed to see your precise location.',
    'If granted, websites can track your physical location with high accuracy. Even having the prompt option available gives away details that make your browser unique.',
    'Deny geolocation access to untrusted sites. Use browsers that require explicit permission for location access.',
    ['Brave', 'Firefox']
  ));

  const clipboardState = await queryPermission('clipboard-read' as PermissionName);
  items.push(createLeakItem(
    'perm-clipboard', 'Clipboard Permission', clipboardState, clipboardState === 'granted' ? 'high' : 'medium',
    'Clipboard permission shows whether websites are allowed to read what you have copied.',
    'If granted, websites can read sensitive data from your clipboard including passwords and personal information.',
    'Deny clipboard access to all websites. Use browsers that require explicit user gesture for clipboard access.',
    ['Brave', 'Firefox']
  ));

  const midiState = await queryPermission('midi' as PermissionName);
  items.push(createLeakItem(
    'perm-midi', 'MIDI Permission', midiState, midiState === 'granted' ? 'medium' : 'safe',
    'MIDI permission allows websites to access MIDI (Musical Instrument Digital Interface) devices connected to your computer, such as electronic keyboards or music controllers.',
    'MIDI access is rarely needed and can reveal connected musical instruments or controllers, which adds details that make your browser unique.',
    'Deny MIDI access unless you specifically need it for music applications.',
    []
  ));

  const bluetoothState = await queryPermission('bluetooth' as PermissionName);
  items.push(createLeakItem(
    'perm-bluetooth', 'Bluetooth Permission', bluetoothState, bluetoothState === 'granted' ? 'high' : 'safe',
    'Bluetooth permission allows websites to discover and connect to nearby Bluetooth devices.',
    'Bluetooth access can reveal what devices are near you, which is a powerful way to create a unique profile of your browser.',
    'Deny Bluetooth access to all websites. Use browsers that restrict Web Bluetooth by default.',
    ['Brave', 'Firefox']
  ));

  const accelState = await queryPermission('accelerometer' as PermissionName);
  const gyroState = await queryPermission('gyroscope' as PermissionName);
  const magnetState = await queryPermission('magnetometer' as PermissionName);
  items.push(createLeakItem(
    'perm-motion-sensors', 'Motion Sensor Permissions', `Accelerometer: ${accelState}, Gyroscope: ${gyroState}, Magnetometer: ${magnetState}`, (accelState === 'granted' || gyroState === 'granted') ? 'high' : 'medium',
    'Motion sensor permissions allow websites to access your device\'s movement and orientation data.',
    'Motion sensors can reveal how you hold and use your device, and possibly even guess your keystrokes. Permission states add details that make your browser unique.',
    'Deny motion sensor access to untrusted sites. Use browsers that restrict sensor access.',
    ['Brave', 'Firefox']
  ));

  let backgroundSync = false;
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const reg = await Promise.race([
        navigator.serviceWorker.ready,
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 2000)),
      ]);
      backgroundSync = reg != null && 'sync' in reg;
    }
  } catch {}
  items.push(createLeakItem(
    'perm-background-sync', 'Background Sync Capability', backgroundSync, 'low',
    'Background Sync allows background scripts to wait until you have a stable internet connection before performing actions.',
    'While useful for offline apps, Background Sync can be misused to send tracking data once your internet connection is restored.',
    'No specific action needed as Background Sync requires a background script to be registered first.',
    []
  ));

  let persistentNotif = false;
  try {
    persistentNotif = typeof PushManager !== 'undefined';
  } catch {}
  items.push(createLeakItem(
    'perm-persistent-notification', 'Persistent Notification Support', persistentNotif, 'low',
    'Push notification support via PushManager enables websites to send notifications even when closed.',
    'Push notifications can be used to track user presence and engagement patterns.',
    'Deny notification permissions to untrusted sites to prevent push notification tracking.',
    []
  ));

  const screenWakeLock = await queryPermission('screen-wake-lock' as PermissionName);
  items.push(createLeakItem(
    'perm-wake-lock', 'Screen Wake Lock', screenWakeLock, 'low',
    'Screen Wake Lock allows websites to prevent the screen from turning off.',
    'While mostly harmless, the permission state adds details that make your browser unique.',
    'No specific mitigation needed as this is a low-impact permission.',
    []
  ));

  return items;
}
