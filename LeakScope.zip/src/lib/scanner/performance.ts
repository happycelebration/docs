import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'performance', description, impact, mitigation, tools };
}

async function runCPUBenchmark(): Promise<number> {
  return new Promise((resolve) => {
    const start = performance.now();
    let result = 0;
    for (let i = 0; i < 1000000; i++) {
      result += Math.sqrt(i) * Math.sin(i);
    }
    const duration = performance.now() - start;
    resolve(duration);
  });
}

async function measureFPS(): Promise<number> {
  return new Promise((resolve) => {
    let count = 0;
    let lastTime = performance.now();
    const intervals: number[] = [];
    const measure = (now: number) => {
      if (count > 0) {
        intervals.push(now - lastTime);
      }
      lastTime = now;
      count++;
      if (count >= 60) {
        const avg = intervals.reduce((a, b) => a + b, 0) / intervals.length;
        resolve(Math.round(1000 / avg));
        return;
      }
      requestAnimationFrame(measure);
    };
    requestAnimationFrame(measure);
  });
}

async function measureAnimationSmoothness(): Promise<number> {
  return new Promise((resolve) => {
    let count = 0;
    let lastTime = performance.now();
    const intervals: number[] = [];
    const measure = (now: number) => {
      if (count > 0) {
        intervals.push(now - lastTime);
      }
      lastTime = now;
      count++;
      if (count >= 120) {
        const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
        const variance = intervals.reduce((a, b) => a + (b - mean) ** 2, 0) / intervals.length;
        resolve(Math.sqrt(variance));
        return;
      }
      requestAnimationFrame(measure);
    };
    requestAnimationFrame(measure);
  });
}

async function measureEventLoopLag(): Promise<number> {
  return new Promise((resolve) => {
    const lags: number[] = [];
    let iterations = 0;
    const maxIterations = 20;
    const measure = () => {
      const start = performance.now();
      setTimeout(() => {
        const lag = performance.now() - start - 0;
        lags.push(lag);
        iterations++;
        if (iterations >= maxIterations) {
          const avgLag = lags.reduce((a, b) => a + b, 0) / lags.length;
          resolve(avgLag);
        } else {
          measure();
        }
      }, 0);
    };
    measure();
  });
}

export async function scanPerformance(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const cpuDuration = await runCPUBenchmark();
  items.push(createLeakItem(
    'perf-cpu-benchmark', 'Processor (CPU) Speed Test', `${cpuDuration.toFixed(2)} ms`, 'medium',
    'A computation-heavy test reveals your processor speed and performance characteristics.',
    'Processor speed results can identify your processor type and help create a unique profile of your device.',
    'Use browsers that add noise to timing features or use resistFingerprinting mode.',
    ['Tor Browser', 'Firefox with resistFingerprinting']
  ));

  let fpsEstimate = 0;
  try {
    fpsEstimate = await measureFPS();
  } catch {}
  items.push(createLeakItem(
    'perf-fps', 'FPS Estimation', fpsEstimate > 0 ? `${fpsEstimate} FPS` : null, 'low',
    'Frames per second estimation based on animation timing.',
    'FPS can reveal your display refresh rate and graphics performance, which helps create a unique profile of your device.',
    'Use browsers that normalize animation timing or reduce its precision.',
    ['Tor Browser']
  ));

  let smoothness = 0;
  try {
    smoothness = await measureAnimationSmoothness();
  } catch {}
  items.push(createLeakItem(
    'perf-animation-smoothness', 'Animation Smoothness', `${smoothness.toFixed(2)} ms jitter`, 'low',
    'Frame time variance indicates how smoothly animations render on your device.',
    'Animation smoothness reveals graphics card and display characteristics that help create a unique profile of your device.',
    'Use browsers that normalize animation timing.',
    ['Tor Browser']
  ));

  const perfData: string[] = [];
  try {
    const timing = performance.timing;
    perfData.push(`DNS Lookup: ${timing.domainLookupEnd - timing.domainLookupStart}ms`);
    perfData.push(`Connection: ${timing.connectEnd - timing.connectStart}ms`);
    perfData.push(`Request: ${timing.responseStart - timing.requestStart}ms`);
    perfData.push(`Response: ${timing.responseEnd - timing.responseStart}ms`);
    perfData.push(`Page Rendering: ${timing.domComplete - timing.domLoading}ms`);
    perfData.push(`Load: ${timing.loadEventEnd - timing.loadEventStart}ms`);
  } catch {}
  items.push(createLeakItem(
    'perf-timing', 'Browser Performance Profile', perfData.length > 0 ? perfData.join(', ') : null, 'low',
    'Performance timing data reveals details about your network speed and page rendering.',
    'Performance timing can be used to estimate your network conditions and how close you are to servers, which helps create a unique profile of your browser.',
    'Some browsers have reduced the precision of performance timing features to protect your privacy.',
    ['Tor Browser', 'Brave']
  ));

  const cpuDuration2 = await runCPUBenchmark();
  const thermalThrottle = cpuDuration2 > cpuDuration * 1.3;
  items.push(createLeakItem(
    'perf-thermal', 'Device Slowdown (Thermal Throttling) Hints', thermalThrottle ? 'Possible device slowdown detected' : 'No device slowdown detected', thermalThrottle ? 'low' : 'safe',
    'Comparing consecutive speed test results can reveal if your device is slowing down due to heat.',
    'Device slowdown patterns are a minor identifying signal and can indicate how hard your device is working and its environmental conditions.',
    'No specific action needed as this is a low-impact signal.',
    []
  ));

  let memoryPressure: string | null = null;
  try {
    const perfMemory = (performance as Record<string, unknown>).memory as {
      jsHeapSizeLimit?: number;
      totalJSHeapSize?: number;
      usedJSHeapSize?: number;
    } | undefined;
    if (perfMemory) {
      const usedMB = ((perfMemory.usedJSHeapSize || 0) / (1024 * 1024)).toFixed(1);
      const totalMB = ((perfMemory.totalJSHeapSize || 0) / (1024 * 1024)).toFixed(1);
      const limitMB = ((perfMemory.jsHeapSizeLimit || 0) / (1024 * 1024)).toFixed(1);
      memoryPressure = `${usedMB} MB used / ${totalMB} MB total / ${limitMB} MB limit`;
    }
  } catch {}
  items.push(createLeakItem(
    'perf-memory', 'Memory Pressure', memoryPressure, memoryPressure ? 'medium' : 'safe',
    'Memory usage information (Chromium browsers only) reveals how much memory your browser is using.',
    'Memory usage patterns can help create a unique profile of your browser and reveal information about your browsing habits.',
    'This feature is only available in Chromium-based browsers. Firefox and Safari do not expose it.',
    ['Firefox', 'Safari']
  ));

  let eventLoopLag = 0;
  try {
    eventLoopLag = await measureEventLoopLag();
  } catch {}
  items.push(createLeakItem(
    'perf-event-loop', 'Background Task Delay', `${eventLoopLag.toFixed(2)} ms`, 'low',
    'Background task delay measures how long your browser takes to respond to scheduled tasks.',
    'Background task delay reveals how busy your system is and how much processing power is available, a minor identifying signal.',
    'Use browsers that reduce timer precision to minimize creating unique profiles of your browser.',
    ['Tor Browser', 'Brave']
  ));

  items.push(createLeakItem(
    'perf-timing-attacks', 'Timing-Based Security Risks', 'Explanation only', 'medium',
    'Timing-based security risks exploit precise timing measurements to extract sensitive information.',
    'High-precision timers and advanced features that could be misused can be used for certain security attacks and creating unique profiles of your browser.',
    'Use browsers that reduce timer precision and disable advanced features that could be misused in non-isolated contexts.',
    ['Tor Browser', 'Firefox', 'Brave']
  ));

  let navigationEntry: string | null = null;
  try {
    const entries = performance.getEntriesByType('navigation') as PerformanceNavigationTiming[];
    if (entries.length > 0) {
      const entry = entries[0];
      navigationEntry = `DNS Lookup: ${(entry.domainLookupEnd - entry.domainLookupStart).toFixed(1)}ms, Connection: ${(entry.connectEnd - entry.connectStart).toFixed(1)}ms, Server Response Time: ${(entry.responseStart - entry.requestStart).toFixed(1)}ms, Load: ${(entry.loadEventEnd - entry.startTime).toFixed(1)}ms`;
    }
  } catch {}
  items.push(createLeakItem(
    'perf-navigation-timing', 'Navigation Timing', navigationEntry, 'low',
    'Navigation timing provides detailed speed measurements for page loading.',
    'Navigation timing data reveals network conditions and server characteristics that can help create a unique profile of your browser.',
    'Some browsers reduce the precision of navigation timing data to protect your privacy.',
    ['Tor Browser']
  ));

  return items;
}
