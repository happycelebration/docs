import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'storage', description, impact, mitigation, tools };
}

export async function scanStorage(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const cookieEnabled = navigator.cookieEnabled;
  items.push(createLeakItem(
    'storage-cookies', 'Cookies Enabled', cookieEnabled, 'medium',
    'Whether cookies are enabled affects how websites can store and retrieve tracking data about you.',
    'Cookies are the main way websites keep track of who you are across visits and page loads.',
    'Use browsers with smart cookie management. Consider blocking third-party cookies.',
    ['Brave', 'Firefox with Enhanced Tracking Protection']
  ));

  let thirdPartyCookieBlocked = false;
  try {
    const testCookie = 'leakscope_test=1; SameSite=None; Secure';
    document.cookie = testCookie;
    const hasCookie = document.cookie.includes('leakscope_test');
    document.cookie = 'leakscope_test=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    thirdPartyCookieBlocked = cookieEnabled && !hasCookie;
  } catch {
    thirdPartyCookieBlocked = true;
  }
  items.push(createLeakItem(
    'storage-third-party-cookies', 'Third-Party Cookie Behavior', thirdPartyCookieBlocked ? 'Third-party cookies appear blocked' : 'Third-party cookies may be allowed', thirdPartyCookieBlocked ? 'safe' : 'high',
    'Third-party cookies are a major tracking method used by ad networks and data brokers.',
    'Third-party cookies allow trackers to follow you across different websites, building a detailed profile of your browsing habits.',
    'Block third-party cookies in your browser settings. Use browsers that block them by default.',
    ['Brave', 'Firefox', 'Safari', 'Chrome with Third-Party Cookie Block']
  ));

  let localStorageAvailable = false;
  let localStorageUsed = '0';
  try {
    const testKey = '__leakscope_test__';
    localStorage.setItem(testKey, '1');
    localStorage.removeItem(testKey);
    localStorageAvailable = true;
    let totalSize = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        totalSize += (localStorage.getItem(key) || '').length + key.length;
      }
    }
    localStorageUsed = `${(totalSize / 1024).toFixed(2)} KB`;
  } catch {
    localStorageAvailable = false;
  }
  items.push(createLeakItem(
    'storage-localstorage', 'LocalStorage Available', localStorageAvailable ? `Available (${localStorageUsed} used)` : 'Not Available', localStorageAvailable ? 'medium' : 'safe',
    'LocalStorage provides persistent storage that survives browser restarts and can be used to track you.',
    'LocalStorage data stays until you manually clear it and is accessible to the same website, enabling long-term tracking.',
    'Clear localStorage regularly. Use browser modes that clear storage on exit.',
    ['Brave', 'Firefox Private Browsing']
  ));

  let sessionStorageAvailable = false;
  try {
    const testKey = '__leakscope_test__';
    sessionStorage.setItem(testKey, '1');
    sessionStorage.removeItem(testKey);
    sessionStorageAvailable = true;
  } catch {
    sessionStorageAvailable = false;
  }
  items.push(createLeakItem(
    'storage-sessionstorage', 'SessionStorage Available', sessionStorageAvailable, 'low',
    'SessionStorage provides temporary storage for the duration of a page session.',
    'SessionStorage is cleared when the tab closes, making it a lower-risk storage mechanism. However, it can still be used for session tracking.',
    'SessionStorage is automatically cleared when the tab is closed. No specific mitigation needed.',
    []
  ));

  let indexedDBAvailable = false;
  try {
    const testDB = indexedDB.open('__leakscope_test__');
    testDB.onerror = () => { indexedDBAvailable = false; };
    testDB.onsuccess = () => {
      const db = testDB.result;
      db.close();
      indexedDB.deleteDatabase('__leakscope_test__');
    };
    indexedDBAvailable = true;
  } catch {
    indexedDBAvailable = false;
  }
  items.push(createLeakItem(
    'storage-indexeddb', 'IndexedDB (Browser Database) Available', indexedDBAvailable, 'medium',
    'IndexedDB is a powerful browser database that can store large amounts of structured data on your device.',
    'IndexedDB can be used for persistent tracking by storing large amounts of data, including cached profile data about you.',
    'Clear IndexedDB data regularly. Use browser modes that clear storage on exit.',
    ['Brave', 'Firefox Private Browsing']
  ));

  let cacheAPIAvailable = false;
  try {
    cacheAPIAvailable = typeof caches !== 'undefined';
  } catch {
    cacheAPIAvailable = false;
  }
  items.push(createLeakItem(
    'storage-cache-api', 'Browser Cache Storage Available', cacheAPIAvailable, 'medium',
    'Browser Cache Storage provides a way for websites to save copies of files on your device.',
    'Cached files can be used to store tracking identifiers that persist across sessions.',
    'Clear browser cache regularly. Use browser modes that clear cache on exit.',
    []
  ));

  let serviceWorkerSupport = false;
  try {
    serviceWorkerSupport = 'serviceWorker' in navigator;
  } catch {
    serviceWorkerSupport = false;
  }
  items.push(createLeakItem(
    'storage-service-worker', 'Background Script (Service Worker) Support', serviceWorkerSupport, 'medium',
    'Background Scripts (Service Workers) can intercept and modify network requests, run in the background, and persist across sessions.',
    'Background Scripts can be used for persistent tracking by intercepting requests and storing identifiers. They survive browser restarts.',
    'Regularly check and remove unknown Background Scripts (Service Workers). Use browsers that limit their persistence.',
    ['Brave']
  ));

  let sharedWorkerAvailable = false;
  try {
    sharedWorkerAvailable = typeof SharedWorker !== 'undefined';
  } catch {
    sharedWorkerAvailable = false;
  }
  items.push(createLeakItem(
    'storage-shared-worker', 'Shared Workers', sharedWorkerAvailable, 'low',
    'Shared Workers allow multiple tabs to share a single background process.',
    'Shared Workers can be used to coordinate tracking across tabs and windows from the same website.',
    'No specific mitigation needed as Shared Workers only work within the same website.',
    []
  ));

  let broadcastChannelAvailable = false;
  try {
    broadcastChannelAvailable = typeof BroadcastChannel !== 'undefined';
  } catch {
    broadcastChannelAvailable = false;
  }
  items.push(createLeakItem(
    'storage-broadcast-channel', 'Broadcast Channel', broadcastChannelAvailable, 'low',
    'BroadcastChannel allows communication between tabs on the same website.',
    'Can be used to coordinate tracking across tabs and detect when you have multiple tabs open.',
    'No specific mitigation needed as BroadcastChannel only works within the same website.',
    []
  ));

  let persistentStorage = false;
  try {
    if (navigator.storage && navigator.storage.persist) {
      persistentStorage = await navigator.storage.persisted();
    }
  } catch {}
  items.push(createLeakItem(
    'storage-persistent', 'Persistent Storage', persistentStorage, 'medium',
    'Persistent storage is requested by websites to prevent the browser from clearing their data automatically.',
    'If granted, persistent storage ensures tracking data survives even when you try to clear your browser data.',
    'Deny persistent storage requests. Configure your browser to always clear data on exit.',
    ['Brave', 'Firefox']
  ));

  let storageQuota: string | null = null;
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      const usedMB = ((estimate.usage || 0) / (1024 * 1024)).toFixed(2);
      const quotaMB = ((estimate.quota || 0) / (1024 * 1024)).toFixed(2);
      storageQuota = `${usedMB} MB used / ${quotaMB} MB quota`;
    }
  } catch {}
  items.push(createLeakItem(
    'storage-quota', 'Storage Quota Estimation', storageQuota, 'low',
    'The Storage feature can estimate the amount of storage used and available quota.',
    'Storage quota varies by browser and device, contributing slightly to identifying you. Used storage reveals your browsing habits.',
    'Regularly clear site data to minimize storage-based tracking.',
    []
  ));

  items.push(createLeakItem(
    'storage-evercookie', 'Evercookie Tracking Methods', 'Explanation only', 'medium',
    'Evercookies use multiple storage methods to recreate cookies even after you delete them.',
    'Evercookies store identifiers in localStorage, sessionStorage, IndexedDB, Web SQL, Browser Cache, Background Scripts, and even hidden file markers (ETags) to ensure persistent tracking.',
    'Use a comprehensive cleanup tool that clears all storage methods at once. Private browsing mode helps.',
    ['CCleaner', 'BleachBit', 'Browser Private Mode']
  ));

  items.push(createLeakItem(
    'storage-etag-tracking', 'ETag (Hidden File Marker) Tracking', 'Explanation only', 'medium',
    'Hidden file markers (ETags) sent by websites can be used to assign unique identifiers to your browser.',
    'When your browser saves a file from a website, the website assigns it a hidden marker (ETag). On future visits, your browser sends that marker back, effectively creating a tracking identifier without using cookies.',
    'Clear your browser cache regularly. Use private browsing mode. Some browsers remove these hidden markers from cached files.',
    ['Brave', 'Firefox Private Browsing']
  ));

  items.push(createLeakItem(
    'storage-hsts-tracking', 'HSTS (Secure Connection Enforcement) Tracking', 'Explanation only', 'medium',
    'A security feature that forces secure connections (HSTS) can be misused as a tracking mechanism.',
    'A website can set unique secure connection rules for different subdomains. By checking which subdomains force secure connections, a tracker can identify a returning visitor without using cookies.',
    'Clear HSTS settings by clearing browser site data. Use browsers that limit the tracking potential of this feature.',
    ['Brave', 'Firefox']
  ));

  return items;
}
