import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'privacy', description, impact, mitigation, tools };
}

async function checkTrackerBlocked(url: string): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    await fetch(url, { method: 'HEAD', mode: 'no-cors', signal: controller.signal });
    clearTimeout(timeout);
    return false;
  } catch {
    return true;
  }
}

async function checkWebRTCBlocked(): Promise<boolean> {
  try {
    const pc = new RTCPeerConnection({ iceServers: [] });
    pc.createDataChannel('');
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    pc.close();
    return false;
  } catch {
    return true;
  }
}

function checkAntiFingerprintResistance(): { isResistant: boolean; signals: string[] } {
  const signals: string[] = [];

  try {
    if (navigator.hardwareConcurrency === 2 && /Windows|Mac|Linux/.test(navigator.userAgent)) {
      signals.push('CPU cores reported as 2 (possibly hidden)');
    }
  } catch {}

  try {
    const deviceMemory = (navigator as Record<string, unknown>).deviceMemory as number | undefined;
    if (deviceMemory === undefined) {
      signals.push('Device memory feature not exposed (good)');
    }
  } catch {}

  try {
    if (screen.width === 0 || screen.height === 0) {
      signals.push('Screen dimensions reported as 0 (possibly hidden)');
    }
  } catch {}

  try {
    if (navigator.languages && navigator.languages.length === 1 && navigator.languages[0] === 'en-US') {
      const browserLang = navigator.language;
      if (browserLang !== 'en-US') {
        signals.push('Language mismatch suggests details are being changed');
      }
    }
  } catch {}

  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillText('test', 0, 0);
      const dataURL = canvas.toDataURL();
      if (dataURL.length < 100) {
        signals.push('Canvas output unusually small (possibly blocked)');
      }
    }
  } catch {}

  return { isResistant: signals.length > 0, signals };
}

export async function scanPrivacy(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const trackerUrls = [
    { name: 'Google Analytics', url: 'https://www.google-analytics.com/analytics.js' },
    { name: 'Facebook Pixel', url: 'https://connect.facebook.net/en_US/fbevents.js' },
    { name: 'Doubleclick', url: 'https://stats.g.doubleclick.net/j/collect' },
  ];
  let trackersBlocked = 0;
  const blockedNames: string[] = [];
  for (const tracker of trackerUrls) {
    const blocked = await checkTrackerBlocked(tracker.url);
    if (blocked) {
      trackersBlocked++;
      blockedNames.push(tracker.name);
    }
  }
  const trackerBlockingRate = (trackersBlocked / trackerUrls.length) * 100;
  items.push(createLeakItem(
    'privacy-tracker-blocking', 'Tracker Blocking Effectiveness', `${trackerBlockingRate.toFixed(0)}% blocked (${blockedNames.join(', ') || 'none'})`, trackerBlockingRate >= 50 ? 'safe' : trackerBlockingRate > 0 ? 'medium' : 'high',
    'Tests whether common tracker scripts are blocked from loading.',
    'Without tracker blocking, third-party trackers can follow you across websites and build comprehensive browsing profiles.',
    'Use browsers with built-in tracker blocking or install privacy extensions that block known trackers.',
    ['Brave', 'uBlock Origin', 'Privacy Badger']
  ));

  const antiFpResult = checkAntiFingerprintResistance();
  items.push(createLeakItem(
    'privacy-anti-fingerprint', 'Anti-Profiling Protection', antiFpResult.isResistant ? `Protected: ${antiFpResult.signals.join('; ')}` : 'No anti-profiling protection detected', antiFpResult.isResistant ? 'safe' : 'high',
    'Checks whether the browser appears to be changing or hiding common identifying details.',
    'Without anti-profiling protection, your browser profile is unique and can be tracked across sessions.',
    'Use browsers with built-in protection that makes your browser look less unique, like Tor Browser or Brave with strict settings.',
    ['Tor Browser', 'Brave']
  ));

  const webrtcBlocked = await checkWebRTCBlocked();
  items.push(createLeakItem(
    'privacy-webrtc-protection', 'WebRTC Protection', webrtcBlocked ? 'WebRTC is blocked' : 'WebRTC is available', webrtcBlocked ? 'safe' : 'high',
    'WebRTC can leak local IP addresses even through VPNs.',
    'Without WebRTC protection, your real local IP address may be exposed to websites, bypassing VPN protection.',
    'Disable WebRTC in your browser settings or use extensions that prevent WebRTC leaks.',
    ['Brave', 'uBlock Origin', 'WebRTC Control Extension']
  ));

  let thirdPartyCookieBlocked = false;
  try {
    document.cookie = 'leakscope_3p_test=1; SameSite=None; Secure';
    const hasCookie = document.cookie.includes('leakscope_3p_test');
    document.cookie = 'leakscope_3p_test=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    thirdPartyCookieBlocked = navigator.cookieEnabled && !hasCookie;
  } catch {
    thirdPartyCookieBlocked = true;
  }
  items.push(createLeakItem(
    'privacy-cookie-isolation', 'Cookie Isolation', thirdPartyCookieBlocked ? 'Third-party cookies blocked' : 'Third-party cookies allowed', thirdPartyCookieBlocked ? 'safe' : 'high',
    'Cookie isolation prevents third-party trackers from using cookies to follow you across sites.',
    'Without cookie isolation, third-party cookies enable cross-site tracking by ad networks and data brokers.',
    'Block third-party cookies in your browser settings. Use browsers that block them by default.',
    ['Brave', 'Firefox', 'Safari']
  ));

  const blockedAPIs: string[] = [];
  try {
    if (typeof navigator.getBattery === 'undefined') blockedAPIs.push('Battery API');
  } catch {}
  try {
    const pc = new RTCPeerConnection({ iceServers: [] });
    pc.close();
  } catch {
    blockedAPIs.push('WebRTC');
  }
  try {
    if (typeof navigator.sendBeacon === 'undefined') blockedAPIs.push('Beacon API');
  } catch {}
  items.push(createLeakItem(
    'privacy-script-blocking', 'Script Blocking', blockedAPIs.length > 0 ? `Blocked features: ${blockedAPIs.join(', ')}` : 'No features appear to be blocked', blockedAPIs.length > 0 ? 'safe' : 'medium',
    'Checks whether privacy-sensitive features have been blocked or removed.',
    'Blocking tracking features reduces your exposure. No blocking means all features are available for tracking.',
    'Use privacy extensions or browsers that restrict access to tracking features.',
    ['Brave', 'NoScript']
  ));

  items.push(createLeakItem(
    'privacy-third-party-requests', 'Third-Party Request Exposure', 'Explanation only', 'medium',
    'Third-party requests to external domains can be observed and used for tracking.',
    'Every third-party request reveals your browsing activity to external servers. Embedded content, analytics, and social widgets all contribute to tracking.',
    'Use content blockers to prevent third-party requests. Use browsers that limit third-party resource loading.',
    ['uBlock Origin', 'Brave', 'Privacy Badger']
  ));

  let hardeningScore = 0;
  const maxHardening = 5;
  if (trackerBlockingRate >= 50) hardeningScore++;
  if (antiFpResult.isResistant) hardeningScore++;
  if (webrtcBlocked) hardeningScore++;
  if (thirdPartyCookieBlocked) hardeningScore++;
  if (blockedAPIs.length > 0) hardeningScore++;
  const hardeningPercent = (hardeningScore / maxHardening) * 100;
  items.push(createLeakItem(
    'privacy-hardening-score', 'Browser Hardening Quality', `${hardeningPercent.toFixed(0)}% (${hardeningScore}/${maxHardening} protections active)`, hardeningPercent >= 80 ? 'safe' : hardeningPercent >= 60 ? 'low' : hardeningPercent >= 40 ? 'medium' : 'high',
    'Aggregate score of browser privacy hardening based on active protections.',
    'A lower hardening score means more tracking methods are available and your browser is less protected against profiling.',
    'Improve your score by turning on built-in browser protections and installing privacy extensions.',
    ['Brave', 'Tor Browser', 'uBlock Origin']
  ));

  let privacyExtensions: string[] = [];
  try {
    const isBrave = typeof (navigator as Record<string, unknown>).brave === 'object';
    if (isBrave) privacyExtensions.push('Brave Shields');

    const testEl = document.createElement('div');
    testEl.id = 'ad-banner';
    testEl.className = 'ad-slot';
    document.body.appendChild(testEl);
    await new Promise(r => setTimeout(r, 100));
    const computed = window.getComputedStyle(testEl);
    if (computed.display === 'none' || computed.visibility === 'hidden') {
      privacyExtensions.push('Ad Blocker (detected via DOM)');
    }
    document.body.removeChild(testEl);
  } catch {}
  items.push(createLeakItem(
    'privacy-extensions', 'Privacy Extension Effectiveness', privacyExtensions.length > 0 ? `Detected: ${privacyExtensions.join(', ')}` : 'No privacy extensions detected', privacyExtensions.length > 0 ? 'safe' : 'medium',
    'Privacy extensions can be detected through their effects on page content and browser behavior.',
    'While detected privacy extensions are effective at blocking trackers, their detectability itself gives away details that make your browser unique.',
    'Use browsers with built-in privacy features rather than extensions when possible.',
    ['Brave', 'Firefox with ETP']
  ));

  items.push(createLeakItem(
    'privacy-dns', 'DNS (Domain Name System) Privacy', 'Explanation only', 'medium',
    'When you visit a website, your browser typically sends the website name unencrypted, allowing your internet provider and network operators to see which websites you visit.',
    'Without DNS privacy, your internet provider can see every website you visit even with HTTPS, as website name lookups are sent unencrypted.',
    'Use Encrypted DNS (DNS-over-HTTPS or DNS-over-TLS) to hide the website names you visit. You can set this up in your browser or system settings.',
    ['Cloudflare 1.1.1.1', 'NextDNS', 'Brave (built-in DoH)']
  ));

  items.push(createLeakItem(
    'privacy-secure-dns', 'Encrypted DNS (DoH/DoT)', 'Explanation only', 'medium',
    'Encrypted DNS hides the website names you visit by encrypting them, preventing others from snooping.',
    'Without encrypted DNS, your browsing history is visible to anyone monitoring your network, even with HTTPS encryption on the actual connections.',
    'Enable encrypted DNS in your browser settings. Use DNS providers that support encrypted DNS and do not keep logs of your visits.',
    ['Cloudflare 1.1.1.1', 'NextDNS', 'Quad9']
  ));

  return items;
}
