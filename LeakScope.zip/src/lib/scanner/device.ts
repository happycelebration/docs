import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'device', description, impact, mitigation, tools };
}

async function hashString(str: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function detectDeviceType(): string {
  const ua = navigator.userAgent;
  if (/Mobi|Android/i.test(ua)) {
    if (/Tablet|iPad/i.test(ua) || (navigator.maxTouchPoints > 1 && !/Mobile/i.test(ua))) return 'Tablet';
    return 'Mobile';
  }
  if (/iPad/i.test(ua) || (navigator.maxTouchPoints > 1 && /Macintosh/i.test(ua))) return 'Tablet';
  return 'Desktop';
}

function detectEndianness(): string {
  try {
    const buffer = new ArrayBuffer(4);
    const view = new DataView(buffer);
    view.setUint32(0, 0x01020304, true);
    const uint32 = view.getUint32(0, false);
    return uint32 === 0x01020304 ? 'Little Endian' : 'Big Endian';
  } catch {
    return 'Unknown';
  }
}

function getGPUInfo(): { vendor: string; renderer: string } {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (!gl) return { vendor: 'Not Available', renderer: 'Not Available' };
    const debugInfo = (gl as WebGLRenderingContext).getExtension('WEBGL_debug_renderer_info');
    if (!debugInfo) return { vendor: 'Not Available', renderer: 'Not Available' };
    return {
      vendor: (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || 'Not Available',
      renderer: (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'Not Available',
    };
  } catch {
    return { vendor: 'Not Available', renderer: 'Not Available' };
  }
}

async function getWebGLFingerprint(): Promise<string> {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl') as WebGLRenderingContext | null;
    if (!gl) return 'Not Available';
    const params: string[] = [];
    const glCtx = gl as WebGLRenderingContext;
    params.push(`VERSION:${glCtx.getParameter(glCtx.VERSION)}`);
    params.push(`SHADING_LANGUAGE_VERSION:${glCtx.getParameter(glCtx.SHADING_LANGUAGE_VERSION)}`);
    params.push(`VENDOR:${glCtx.getParameter(glCtx.VENDOR)}`);
    params.push(`RENDERER:${glCtx.getParameter(glCtx.RENDERER)}`);
    params.push(`MAX_TEXTURE_SIZE:${glCtx.getParameter(glCtx.MAX_TEXTURE_SIZE)}`);
    params.push(`MAX_RENDERBUFFER_SIZE:${glCtx.getParameter(glCtx.MAX_RENDERBUFFER_SIZE)}`);
    params.push(`MAX_VIEWPORT_DIMS:${glCtx.getParameter(glCtx.MAX_VIEWPORT_DIMS)}`);
    params.push(`MAX_VERTEX_ATTRIBS:${glCtx.getParameter(glCtx.MAX_VERTEX_ATTRIBS)}`);
    params.push(`MAX_VERTEX_UNIFORM_VECTORS:${glCtx.getParameter(glCtx.MAX_VERTEX_UNIFORM_VECTORS)}`);
    params.push(`MAX_VARYING_VECTORS:${glCtx.getParameter(glCtx.MAX_VARYING_VECTORS)}`);
    params.push(`MAX_COMBINED_TEXTURE_IMAGE_UNITS:${glCtx.getParameter(glCtx.MAX_COMBINED_TEXTURE_IMAGE_UNITS)}`);
    const extensions = glCtx.getSupportedExtensions()?.join(',') ?? '';
    params.push(`EXTENSIONS:${extensions}`);
    return await hashString(params.join('|'));
  } catch {
    return 'Not Available';
  }
}

async function getCanvasFingerprint(): Promise<string> {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 50;
    const ctx = canvas.getContext('2d');
    if (!ctx) return 'Not Available';
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillStyle = '#f60';
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = '#069';
    ctx.fillText('LeakScope 🔒', 2, 15);
    ctx.fillStyle = 'rgba(102,204,0,0.7)';
    ctx.fillText('LeakScope 🔒', 4, 17);
    const dataURL = canvas.toDataURL();
    return await hashString(dataURL);
  } catch {
    return 'Not Available';
  }
}

async function getAudioFingerprint(): Promise<string> {
  try {
    const AudioCtx = window.AudioContext || (window as Record<string, unknown>).webkitAudioContext as typeof AudioContext;
    if (!AudioCtx) return 'Not Available';
    const audioCtx = new AudioCtx();
    const oscillator = audioCtx.createOscillator();
    const analyser = audioCtx.createAnalyser();
    const gain = audioCtx.createGain();
    const scriptProcessor = audioCtx.createScriptProcessor(4096, 1, 1);
    gain.gain.value = 0;
    oscillator.type = 'triangle';
    oscillator.frequency.value = 10000;
    oscillator.connect(analyser);
    analyser.connect(scriptProcessor);
    scriptProcessor.connect(gain);
    gain.connect(audioCtx.destination);
    oscillator.start(0);
    const audioData: number[] = [];
    let resolved = false;
    return new Promise<string>((resolve) => {
      scriptProcessor.onaudioprocess = (event) => {
        if (resolved) return;
        resolved = true;
        const output = event.outputBuffer.getChannelData(0);
        for (let i = 0; i < output.length; i++) {
          audioData.push(output[i]);
        }
        oscillator.stop();
        oscillator.disconnect();
        scriptProcessor.disconnect();
        analyser.disconnect();
        gain.disconnect();
        try { audioCtx.close(); } catch {}
        hashString(JSON.stringify(audioData.slice(0, 100))).then(h => resolve(h)).catch(() => resolve('Not Available'));
      };
      setTimeout(() => {
        if (resolved) return;
        resolved = true;
        try { oscillator.stop(); } catch {}
        try { oscillator.disconnect(); } catch {}
        try { scriptProcessor.disconnect(); } catch {}
        try { analyser.disconnect(); } catch {}
        try { gain.disconnect(); } catch {}
        try { audioCtx.close(); } catch {}
        resolve('Not Available');
      }, 3000);
    });
  } catch {
    return 'Not Available';
  }
}

async function detectFonts(): Promise<string[]> {
  const baseFonts = ['monospace', 'sans-serif', 'serif'];
  const testFonts = [
    'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Georgia',
    'Impact', 'Lucida Console', 'Lucida Sans Unicode', 'Microsoft Sans Serif',
    'Palatino Linotype', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana',
    'Roboto', 'Open Sans', 'Calibri', 'Cambria', 'Consolas', 'Segoe UI',
    'Helvetica', 'SF Pro', 'Menlo', 'Monaco', 'Fira Code', 'Source Code Pro',
    'Ubuntu', 'Noto Sans', 'Droid Sans', 'DejaVu Sans', 'Liberation Sans',
  ];
  const detected: string[] = [];
  try {
    const span = document.createElement('span');
    span.style.position = 'absolute';
    span.style.left = '-9999px';
    span.style.fontSize = '72px';
    span.textContent = 'mmmmmmmmmmlli';
    document.body.appendChild(span);
    const baseWidths: Record<string, number> = {};
    for (const base of baseFonts) {
      span.style.fontFamily = base;
      baseWidths[base] = span.offsetWidth;
    }
    for (const font of testFonts) {
      for (const base of baseFonts) {
        span.style.fontFamily = `'${font}', ${base}`;
        if (span.offsetWidth !== baseWidths[base]) {
          detected.push(font);
          break;
        }
      }
    }
    document.body.removeChild(span);
  } catch {}
  return detected;
}

async function measureRefreshRate(): Promise<number> {
  return new Promise((resolve) => {
    let count = 0;
    let lastTime = performance.now();
    const intervals: number[] = [];
    const measure = (now: number) => {
      if (count > 0) {
        intervals.push(now - lastTime);
      }
      lastTime = now;
      count++;
      if (count >= 30) {
        const avg = intervals.reduce((a, b) => a + b, 0) / intervals.length;
        resolve(Math.round(1000 / avg));
        return;
      }
      requestAnimationFrame(measure);
    };
    requestAnimationFrame(measure);
  });
}

export async function scanDevice(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];

  const deviceType = detectDeviceType();
  items.push(createLeakItem(
    'device-type', 'Device Type', deviceType, 'medium',
    'Your device type (mobile, desktop, tablet) can be inferred from the User Agent and touch support.',
    'Device type is used for responsive design but also helps identify your browser by narrowing down who you are.',
    'Use browsers that normalize device signals. Tor Browser attempts to appear as a desktop browser.',
    ['Tor Browser']
  ));

  const touchSupport = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  items.push(createLeakItem(
    'device-touch-support', 'Touch Support', touchSupport, 'medium',
    'Touch support reveals whether your device has a touchscreen.',
    'Touch capability combined with other details helps identify what kind of device you are using.',
    'Some privacy browsers report generic touch capabilities.',
    ['Tor Browser']
  ));

  items.push(createLeakItem(
    'device-max-touch-points', 'Max Touch Points', navigator.maxTouchPoints, 'medium',
    'The maximum number of simultaneous touch contacts your screen supports.',
    'This value varies by device and contributes to identifying your hardware profile.',
    'Privacy-focused browsers may report 0 or a standard value to hide this detail.',
    ['Tor Browser']
  ));

  const deviceMemory = (navigator as Record<string, unknown>).deviceMemory as number | undefined;
  items.push(createLeakItem(
    'device-memory', 'Device Memory', deviceMemory ? `${deviceMemory} GB` : null, 'high',
    'Your browser can reveal approximately how much memory (RAM) your device has.',
    'Device memory is a very specific detail that significantly narrows down your hardware profile.',
    'Use browsers that hide or omit this value. Firefox does not provide this information.',
    ['Firefox', 'Tor Browser']
  ));

  const hardwareConcurrency = navigator.hardwareConcurrency;
  items.push(createLeakItem(
    'device-hardware-concurrency', 'Number of CPU Cores', hardwareConcurrency, 'high',
    'Your browser can reveal how many processor cores your device has.',
    'Processor core count is a strong detail for identifying your browser that varies significantly between devices.',
    'Use browsers that report a standard value. Firefox with privacy settings returns 2.',
    ['Firefox with resistFingerprinting', 'Tor Browser']
  ));

  const ua = navigator.userAgent;
  const platform = navigator.platform;
  let cpuArch = 'Unknown';
  if (/x86_64|Win64|x64|amd64/i.test(ua) || platform === 'Linux x86_64') cpuArch = 'x86_64';
  else if (/arm64|aarch64/i.test(ua) || /Macintosh/.test(ua) && navigator.maxTouchPoints > 1) cpuArch = 'ARM64';
  else if (/arm/i.test(ua)) cpuArch = 'ARM';
  else if (/x86|i[3-6]86/.test(ua)) cpuArch = 'x86';
  items.push(createLeakItem(
    'device-cpu-arch', 'Processor Type Estimate', cpuArch, 'medium',
    'Your processor type can be estimated from your browser\'s identifying information.',
    'Processor type helps narrow down your device profile and can reveal if you are on a virtual machine or emulator.',
    'This cannot easily be hidden without breaking browser functionality.',
    ['Tor Browser']
  ));

  const endianness = detectEndianness();
  items.push(createLeakItem(
    'device-endianness', 'Byte Order (Endianness)', endianness, 'low',
    'The byte order of your processor can be detected by websites.',
    'Almost all consumer hardware uses the same byte order, so this is not very identifying. A different byte order would be very unique.',
    'No specific action needed as this is nearly the same for everyone.',
    []
  ));

  items.push(createLeakItem(
    'device-screen-resolution', 'Screen Resolution', `${screen.width}x${screen.height}`, 'high',
    'Your screen resolution can be directly read by websites.',
    'Screen resolution is a strong detail for identifying your browser, especially when combined with pixel ratio.',
    'Use browsers that report a standard resolution. Avoid maximizing your browser window.',
    ['Tor Browser']
  ));

  items.push(createLeakItem(
    'device-available-screen', 'Available Screen Size', `${screen.availWidth}x${screen.availHeight}`, 'high',
    'The available screen size does not include taskbars and other system interface elements.',
    'Available screen size reveals information about your system setup, making your browser more unique and identifiable.',
    'This is difficult to hide without breaking how pages are displayed.',
    ['Tor Browser']
  ));

  const pixelRatio = window.devicePixelRatio;
  items.push(createLeakItem(
    'device-pixel-ratio', 'Pixel Ratio', pixelRatio, 'high',
    'Your browser reveals the ratio between physical and logical screen pixels.',
    'Pixel ratio identifies high-resolution displays and specific device models, contributing to identifying your browser.',
    'Some privacy browsers report a standard pixel ratio of 1.',
    ['Tor Browser']
  ));

  const colorDepth = screen.colorDepth;
  items.push(createLeakItem(
    'device-color-depth', 'Color Depth', `${colorDepth}-bit`, 'medium',
    'Screen color depth indicates how many colors your display can show.',
    'Most modern displays use the same color depth, but variations can contribute to identifying your browser.',
    'No specific action needed as this is not very identifying on modern hardware.',
    []
  ));

  let hdrSupport = false;
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const mediaQuery = window.matchMedia('(dynamic-range: high)');
      hdrSupport = mediaQuery.matches;
    }
  } catch {}
  items.push(createLeakItem(
    'device-hdr', 'HDR (High Dynamic Range) Display Support', hdrSupport, 'low',
    'Whether your display supports High Dynamic Range can be detected by websites.',
    'HDR support is a minor detail that helps identify your display capabilities.',
    'No specific action needed as this is not very identifying.',
    []
  ));

  let refreshRate = 0;
  try {
    refreshRate = await measureRefreshRate();
  } catch {}
  items.push(createLeakItem(
    'device-refresh-rate', 'Estimated Refresh Rate', refreshRate ? `${refreshRate} Hz` : null, 'medium',
    'Your screen refresh rate can be estimated by measuring how fast your display updates.',
    'Refresh rate varies between devices and is a moderate detail for identifying your browser, especially for gaming displays.',
    'This cannot be easily hidden as it reflects actual hardware timing.',
    []
  ));

  const orientation = screen.orientation?.type ?? 'Unknown';
  items.push(createLeakItem(
    'device-orientation', 'Screen Orientation', orientation, 'low',
    'The current screen orientation (portrait, landscape, etc.).',
    'Orientation is a dynamic value that changes, making it a weak detail for identifying your browser on its own.',
    'No specific action needed.',
    []
  ));

  const multiMonitorHint = screen.width !== screen.availWidth || screen.height !== screen.availHeight;
  items.push(createLeakItem(
    'device-multi-monitor', 'Multi-Monitor Hint', multiMonitorHint, 'low',
    'Differences between screen and available screen dimensions may indicate taskbars or multiple monitors.',
    'Multiple monitors provide additional ways to track you through available screen dimensions.',
    'This is a weak signal and difficult to hide without breaking display functionality.',
    []
  ));

  const gpuInfo = getGPUInfo();
  items.push(createLeakItem(
    'device-gpu-vendor', 'Graphics Card (GPU) Maker', gpuInfo.vendor, 'high',
    'Your graphics card maker is exposed through browser graphics features.',
    'Your graphics card maker is a strong detail for identifying your browser and can reveal if you are using software rendering or a virtual machine.',
    'Some browsers block this information. Use browsers that restrict graphics card details.',
    ['Tor Browser', 'Brave']
  ));

  items.push(createLeakItem(
    'device-gpu-renderer', 'Graphics Card (GPU) Model', gpuInfo.renderer, 'high',
    'Your specific graphics card model is exposed through browser graphics features.',
    'The exact graphics card model is one of the strongest ways to track you, uniquely identifying your hardware.',
    'Use browsers that block or randomize graphics card information.',
    ['Tor Browser', 'Brave']
  ));

  const webglFp = await getWebGLFingerprint();
  items.push(createLeakItem(
    'device-webgl-fingerprint', 'WebGL Graphics Fingerprint', webglFp, 'critical',
    'A unique profile of all WebGL graphics parameters creates a fingerprint of your graphics hardware and driver.',
    'WebGL graphics fingerprints are highly unique and stable, making them one of the most powerful tracking mechanisms.',
    'Use browsers that randomize or standardize WebGL parameters. Disable WebGL if possible.',
    ['Tor Browser']
  ));

  const canvasFp = await getCanvasFingerprint();
  items.push(createLeakItem(
    'device-canvas-fingerprint', 'Canvas Fingerprint', canvasFp, 'critical',
    'A unique profile of canvas-rendered content creates a fingerprint based on your graphics card and font rendering.',
    'Canvas fingerprinting is one of the most common and effective tracking techniques used by websites.',
    'Use browsers that add noise to canvas rendering. Some extensions can block canvas fingerprinting.',
    ['Tor Browser', 'Canvas Blocker Extension', 'Brave']
  ));

  const audioFp = await getAudioFingerprint();
  items.push(createLeakItem(
    'device-audio-fingerprint', 'Audio Fingerprint', audioFp, 'high',
    'A unique profile of audio processing results creates a fingerprint based on your audio hardware and drivers.',
    'Audio fingerprinting is less common than canvas but still effective for tracking you across websites.',
    'Use browsers that standardize audio processing output.',
    ['Tor Browser', 'Brave']
  ));

  const fonts = await detectFonts();
  items.push(createLeakItem(
    'device-font-fingerprint', 'Font Fingerprint', fonts.length > 0 ? `${fonts.length} fonts detected: ${fonts.join(', ')}` : 'No additional fonts detected', 'high',
    'The set of installed fonts can be detected by measuring how text is displayed.',
    'Installed fonts are highly unique to each system and a powerful detail for identifying your browser.',
    'Use browsers that limit font detection or report a standard font set.',
    ['Tor Browser', 'Font Fingerprint Defender']
  ));

  let speechVoices: string[] = [];
  try {
    speechVoices = speechSynthesis.getVoices().map(v => `${v.name} (${v.lang})`);
    if (speechVoices.length === 0) {
      await new Promise<void>((resolve) => {
        speechSynthesis.onvoiceschanged = () => {
          speechVoices = speechSynthesis.getVoices().map(v => `${v.name} (${v.lang})`);
          resolve();
        };
        setTimeout(resolve, 1000);
      });
    }
  } catch {}
  items.push(createLeakItem(
    'device-speech-voices', 'Text-to-Speech Voices', speechVoices.length > 0 ? `${speechVoices.length} voices: ${speechVoices.slice(0, 5).join(', ')}${speechVoices.length > 5 ? '...' : ''}` : null, 'medium',
    'The list of text-to-speech voices reveals installed text-to-speech software and operating system voices.',
    'The combination and order of text-to-speech voices is a moderate detail for identifying your browser.',
    'Use browsers that limit or randomize the text-to-speech voices list.',
    ['Tor Browser']
  ));

  let mediaDevices: string[] = [];
  let hasMicrophone = false;
  let hasCamera = false;
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    devices.forEach(d => {
      mediaDevices.push(`${d.kind}:${d.deviceId.substring(0, 8)}...`);
      if (d.kind === 'audioinput') hasMicrophone = true;
      if (d.kind === 'videoinput') hasCamera = true;
    });
  } catch {}
  items.push(createLeakItem(
    'device-media-devices', 'Media Devices', mediaDevices.length > 0 ? `${mediaDevices.length} devices` : null, 'medium',
    'The number and types of connected cameras and microphones can be detected by websites.',
    'Media device counts reveal your hardware setup. Device IDs (even without labels) contribute to identifying your browser.',
    'Use browsers that randomize device IDs across sessions.',
    ['Tor Browser', 'Brave']
  ));

  items.push(createLeakItem(
    'device-microphone', 'Microphone Present', hasMicrophone, 'low',
    'Whether a microphone is connected can be detected from your device information.',
    'Microphone presence is a minor detail that contributes to identifying your device profile.',
    'No specific action needed beyond general privacy protections.',
    []
  ));

  items.push(createLeakItem(
    'device-camera', 'Camera Present', hasCamera, 'low',
    'Whether a camera is connected can be detected from your device information.',
    'Camera presence is a minor detail that contributes to identifying your device profile.',
    'No specific action needed beyond general privacy protections.',
    []
  ));

  const bluetoothAvailable = typeof (navigator as Record<string, unknown>).bluetooth === 'object';
  items.push(createLeakItem(
    'device-bluetooth', 'Bluetooth Available', bluetoothAvailable, 'low',
    'Bluetooth feature availability indicates the browser supports connecting to Bluetooth devices.',
    'Bluetooth availability reveals device capability but is not very identifying.',
    'No specific action needed.',
    []
  ));

  const usbAvailable = typeof (navigator as Record<string, unknown>).usb === 'object';
  items.push(createLeakItem(
    'device-usb', 'USB Available', usbAvailable, 'low',
    'USB feature availability indicates the browser supports connecting to USB devices.',
    'USB feature availability is a minor detail about browser and device capabilities.',
    'Disable USB access in browser settings if not needed.',
    []
  ));

  const hidAvailable = typeof (navigator as Record<string, unknown>).hid === 'object';
  items.push(createLeakItem(
    'device-hid', 'Human Interface Device (HID) Support', hidAvailable, 'low',
    'Human Interface Device (HID) support allows the browser to access devices like keyboards and game controllers.',
    'HID support is a minor detail about browser capabilities.',
    'Disable HID access in browser settings if not needed.',
    []
  ));

  let nfcAvailable = false;
  try {
    nfcAvailable = typeof NDEFReader !== 'undefined';
  } catch {}
  items.push(createLeakItem(
    'device-nfc', 'NFC (Near-Field Communication) Support', nfcAvailable, 'low',
    'NFC (Near-Field Communication) support indicates the device can communicate with nearby devices by tapping.',
    'NFC is a minor detail primarily relevant to mobile devices.',
    'No specific action needed.',
    []
  ));

  const sensorChecks = {
    Gyroscope: typeof (window as Record<string, unknown>).Gyroscope !== 'undefined',
    Accelerometer: typeof (window as Record<string, unknown>).Accelerometer !== 'undefined',
    Magnetometer: typeof (window as Record<string, unknown>).Magnetometer !== 'undefined',
    AmbientLightSensor: typeof (window as Record<string, unknown>).AmbientLightSensor !== 'undefined',
  };
  items.push(createLeakItem(
    'device-sensors', 'Device Sensors', `Gyroscope: ${sensorChecks.Gyroscope}, Accelerometer: ${sensorChecks.Accelerometer}, Magnetometer: ${sensorChecks.Magnetometer}, AmbientLight: ${sensorChecks.AmbientLightSensor}`, 'medium',
    'Device sensor availability reveals what hardware capabilities your device has.',
    'Sensor availability helps identify device type and features, contributing to ways to track you.',
    'Use browsers that restrict sensor access or require explicit permission.',
    ['Brave', 'Firefox']
  ));

  let batteryInfo: Record<string, unknown> = {};
  try {
    if (typeof (navigator as Record<string, unknown>).getBattery === 'function') {
      const battery = await (navigator as Record<string, unknown>).getBattery.call(navigator) as {
        charging: boolean;
        chargingTime: number;
        dischargingTime: number;
        level: number;
      };
      batteryInfo = {
        level: Math.round(battery.level * 100),
        charging: battery.charging,
      };
    }
  } catch {}
  items.push(createLeakItem(
    'device-battery', 'Battery Status', Object.keys(batteryInfo).length > 0 ? `Level: ${batteryInfo.level}%, Charging: ${batteryInfo.charging}` : null, 'high',
    'The Battery feature reveals your battery level and charging status.',
    'Battery level changes over time, allowing sites to link your visits together. Combined with charging status, it can uniquely identify you.',
    'Firefox and Brave have removed or restricted battery information. Use browsers that protect this information.',
    ['Firefox', 'Brave', 'Tor Browser']
  ));

  let gamepadSupport = false;
  try {
    const gamepads = navigator.getGamepads();
    gamepadSupport = gamepads !== null;
  } catch {}
  items.push(createLeakItem(
    'device-gamepad', 'Gamepad Support', gamepadSupport, 'low',
    'Gamepad feature availability indicates support for game controllers.',
    'This is a minor detail that contributes to identifying your device profile.',
    'No specific action needed.',
    []
  ));

  const virtualKeyboard = typeof (navigator as Record<string, unknown>).virtualKeyboard !== 'undefined';
  items.push(createLeakItem(
    'device-virtual-keyboard', 'Virtual Keyboard Support', virtualKeyboard, 'low',
    'The Virtual Keyboard feature indicates support for on-screen virtual keyboards.',
    'This is a minor detail primarily relevant for tablet or mobile device identification.',
    'No specific action needed.',
    []
  ));

  return items;
}
