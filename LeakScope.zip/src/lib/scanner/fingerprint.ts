import { LeakItem, RiskLevel } from './types';

function createLeakItem(id: string, name: string, value: string | boolean | number | null, riskLevel: RiskLevel, description: string, impact: string, mitigation: string, tools?: string[]): LeakItem {
  return { id, name, value: value ?? 'Not Available', riskLevel, category: 'fingerprint', description, impact, mitigation, tools };
}

async function hashString(str: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function generateCanvasFingerprint(): Promise<{ hash: string; dataURL: string }> {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 50;
    const ctx = canvas.getContext('2d');
    if (!ctx) return { hash: 'Not Available', dataURL: '' };
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillStyle = '#f60';
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = '#069';
    ctx.fillText('LeakScope 🔒', 2, 15);
    ctx.fillStyle = 'rgba(102,204,0,0.7)';
    ctx.fillText('LeakScope 🔒', 4, 17);
    const dataURL = canvas.toDataURL();
    const hash = await hashString(dataURL);
    return { hash, dataURL };
  } catch {
    return { hash: 'Not Available', dataURL: '' };
  }
}

async function generateWebGLFingerprint(): Promise<string> {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl') as WebGLRenderingContext | null;
    if (!gl) return 'Not Available';
    const glCtx = gl as WebGLRenderingContext;
    const params: string[] = [];
    params.push(`VERSION:${glCtx.getParameter(glCtx.VERSION)}`);
    params.push(`SHADING_LANGUAGE_VERSION:${glCtx.getParameter(glCtx.SHADING_LANGUAGE_VERSION)}`);
    params.push(`VENDOR:${glCtx.getParameter(glCtx.VENDOR)}`);
    params.push(`RENDERER:${glCtx.getParameter(glCtx.RENDERER)}`);
    params.push(`MAX_TEXTURE_SIZE:${glCtx.getParameter(glCtx.MAX_TEXTURE_SIZE)}`);
    params.push(`MAX_RENDERBUFFER_SIZE:${glCtx.getParameter(glCtx.MAX_RENDERBUFFER_SIZE)}`);
    params.push(`MAX_VIEWPORT_DIMS:${glCtx.getParameter(glCtx.MAX_VIEWPORT_DIMS)}`);
    params.push(`MAX_VERTEX_ATTRIBS:${glCtx.getParameter(glCtx.MAX_VERTEX_ATTRIBS)}`);
    params.push(`MAX_VERTEX_UNIFORM_VECTORS:${glCtx.getParameter(glCtx.MAX_VERTEX_UNIFORM_VECTORS)}`);
    params.push(`MAX_VARYING_VECTORS:${glCtx.getParameter(glCtx.MAX_VARYING_VECTORS)}`);
    params.push(`MAX_COMBINED_TEXTURE_IMAGE_UNITS:${glCtx.getParameter(glCtx.MAX_COMBINED_TEXTURE_IMAGE_UNITS)}`);
    params.push(`MAX_TEXTURE_IMAGE_UNITS:${glCtx.getParameter(glCtx.MAX_TEXTURE_IMAGE_UNITS)}`);
    params.push(`MAX_VERTEX_TEXTURE_IMAGE_UNITS:${glCtx.getParameter(glCtx.MAX_VERTEX_TEXTURE_IMAGE_UNITS)}`);
    params.push(`ALIASED_LINE_WIDTH_RANGE:${glCtx.getParameter(glCtx.ALIASED_LINE_WIDTH_RANGE)}`);
    params.push(`ALIASED_POINT_SIZE_RANGE:${glCtx.getParameter(glCtx.ALIASED_POINT_SIZE_RANGE)}`);
    params.push(`RED_BITS:${glCtx.getParameter(glCtx.RED_BITS)}`);
    params.push(`GREEN_BITS:${glCtx.getParameter(glCtx.GREEN_BITS)}`);
    params.push(`BLUE_BITS:${glCtx.getParameter(glCtx.BLUE_BITS)}`);
    params.push(`ALPHA_BITS:${glCtx.getParameter(glCtx.ALPHA_BITS)}`);
    params.push(`DEPTH_BITS:${glCtx.getParameter(glCtx.DEPTH_BITS)}`);
    params.push(`STENCIL_BITS:${glCtx.getParameter(glCtx.STENCIL_BITS)}`);
    const debugInfo = glCtx.getExtension('WEBGL_debug_renderer_info');
    if (debugInfo) {
      params.push(`UNMASKED_VENDOR:${glCtx.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)}`);
      params.push(`UNMASKED_RENDERER:${glCtx.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)}`);
    }
    const extensions = glCtx.getSupportedExtensions()?.join(',') ?? '';
    params.push(`EXTENSIONS:${extensions}`);
    return await hashString(params.join('|'));
  } catch {
    return 'Not Available';
  }
}

async function generateAudioFingerprint(): Promise<string> {
  try {
    const AudioCtx = window.AudioContext || (window as Record<string, unknown>).webkitAudioContext as typeof AudioContext;
    if (!AudioCtx) return 'Not Available';
    const audioCtx = new AudioCtx();
    const oscillator = audioCtx.createOscillator();
    const analyser = audioCtx.createAnalyser();
    const gain = audioCtx.createGain();
    const scriptProcessor = audioCtx.createScriptProcessor(4096, 1, 1);
    gain.gain.value = 0;
    oscillator.type = 'triangle';
    oscillator.frequency.value = 10000;
    oscillator.connect(analyser);
    analyser.connect(scriptProcessor);
    scriptProcessor.connect(gain);
    gain.connect(audioCtx.destination);
    oscillator.start(0);
    const audioData: number[] = [];
    let resolved = false;
    return new Promise<string>((resolve) => {
      scriptProcessor.onaudioprocess = (event) => {
        if (resolved) return;
        resolved = true;
        const output = event.outputBuffer.getChannelData(0);
        for (let i = 0; i < output.length; i++) {
          audioData.push(output[i]);
        }
        oscillator.stop();
        oscillator.disconnect();
        scriptProcessor.disconnect();
        analyser.disconnect();
        gain.disconnect();
        try { audioCtx.close(); } catch {}
        hashString(JSON.stringify(audioData.slice(0, 100))).then(h => resolve(h)).catch(() => resolve('Not Available'));
      };
      setTimeout(() => {
        if (resolved) return;
        resolved = true;
        try { oscillator.stop(); } catch {}
        try { oscillator.disconnect(); } catch {}
        try { scriptProcessor.disconnect(); } catch {}
        try { analyser.disconnect(); } catch {}
        try { gain.disconnect(); } catch {}
        try { audioCtx.close(); } catch {}
        resolve('Not Available');
      }, 3000);
    });
  } catch {
    return 'Not Available';
  }
}

async function detectFontsForFingerprint(): Promise<string> {
  const baseFonts = ['monospace', 'sans-serif', 'serif'];
  const testFonts = [
    'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Georgia',
    'Impact', 'Lucida Console', 'Lucida Sans Unicode', 'Microsoft Sans Serif',
    'Palatino Linotype', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana',
    'Roboto', 'Open Sans', 'Calibri', 'Cambria', 'Consolas', 'Segoe UI',
    'Helvetica', 'SF Pro', 'Menlo', 'Monaco', 'Fira Code', 'Source Code Pro',
    'Ubuntu', 'Noto Sans', 'Droid Sans', 'DejaVu Sans', 'Liberation Sans',
    'Wingdings', 'Symbol', 'Webdings', 'MS Gothic', 'MS PGothic',
  ];
  const detected: string[] = [];
  try {
    const span = document.createElement('span');
    span.style.position = 'absolute';
    span.style.left = '-9999px';
    span.style.fontSize = '72px';
    span.textContent = 'mmmmmmmmmmlli';
    document.body.appendChild(span);
    const baseWidths: Record<string, number> = {};
    for (const base of baseFonts) {
      span.style.fontFamily = base;
      baseWidths[base] = span.offsetWidth;
    }
    for (const font of testFonts) {
      for (const base of baseFonts) {
        span.style.fontFamily = `'${font}', ${base}`;
        if (span.offsetWidth !== baseWidths[base]) {
          detected.push(font);
          break;
        }
      }
    }
    document.body.removeChild(span);
  } catch {}
  return detected.join(',');
}

function estimateEntropy(items: { value: string | boolean | number | null; uniqueness: number }[]): number {
  let totalBits = 0;
  for (const item of items) {
    totalBits += Math.log2(Math.max(item.uniqueness, 1));
  }
  return totalBits;
}

export async function scanFingerprint(): Promise<LeakItem[]> {
  const items: LeakItem[] = [];
  const collectedData: string[] = [];

  const canvasResult = await generateCanvasFingerprint();
  items.push(createLeakItem(
    'fp-canvas', 'Canvas Uniqueness', canvasResult.hash, 'critical',
    'Canvas rendering produces unique output based on your graphics card, drivers, and font rendering.',
    'Canvas profiles are highly stable and unique, making them one of the most effective ways to track you across different websites.',
    'Use browsers that add noise to canvas rendering to make it less unique. Canvas blocking extensions can help but may break some sites.',
    ['Tor Browser', 'Canvas Blocker', 'Brave']
  ));
  collectedData.push(`canvas:${canvasResult.hash}`);

  const webglFp = await generateWebGLFingerprint();
  items.push(createLeakItem(
    'fp-webgl', 'WebGL Graphics Uniqueness', webglFp, 'critical',
    'WebGL parameters create a unique profile based on your graphics card, drivers, and WebGL capabilities.',
    'WebGL profiles are extremely stable and can identify you across sessions and even different browsers on the same machine.',
    'Use browsers that block or randomize WebGL details. Disabling WebGL entirely is the most effective protection.',
    ['Tor Browser', 'Brave', 'WebGL Blocker']
  ));
  collectedData.push(`webgl:${webglFp}`);

  const audioFp = await generateAudioFingerprint();
  items.push(createLeakItem(
    'fp-audio', 'Audio Processing Uniqueness', audioFp, 'high',
    'Audio processing produces unique output based on your audio hardware and drivers.',
    'Audio profiles are less commonly used but highly effective, and harder to detect and block than canvas profiles.',
    'Use browsers that normalize audio processing output. Some privacy extensions block audio-based profiling.',
    ['Tor Browser', 'Brave', 'AudioContext Blocker']
  ));
  collectedData.push(`audio:${audioFp}`);

  const fontList = await detectFontsForFingerprint();
  const fontHash = await hashString(fontList);
  items.push(createLeakItem(
    'fp-fonts', 'Font Uniqueness', fontHash, 'high',
    'The set of installed fonts creates a unique profile that is difficult to hide or change.',
    'Font profiles are highly unique because installed fonts depend on your operating system, applications, and personal customization.',
    'Use browsers that limit font detection or report a standard font set. Font blocking extensions can help.',
    ['Tor Browser', 'Font Fingerprint Defender']
  ));
  collectedData.push(`fonts:${fontHash}`);

  const timezoneData = [
    Intl.DateTimeFormat().resolvedOptions().timeZone,
    Intl.DateTimeFormat().resolvedOptions().locale,
    new Date().getTimezoneOffset().toString(),
  ].join('|');
  const timezoneHash = await hashString(timezoneData);
  items.push(createLeakItem(
    'fp-timezone', 'Timezone Uniqueness', timezoneHash, 'high',
    'Timezone-related data creates a profile based on your geographic region settings.',
    'Timezone data combined with language and region information is a strong identifier that reveals your approximate location and language preferences.',
    'Use browsers that normalize timezone and locale information.',
    ['Tor Browser']
  ));
  collectedData.push(`timezone:${timezoneHash}`);

  const hardwareData = [
    navigator.hardwareConcurrency?.toString() ?? '',
    (navigator as Record<string, unknown>).deviceMemory?.toString() ?? '',
    screen.width.toString(),
    screen.height.toString(),
    screen.colorDepth.toString(),
    window.devicePixelRatio?.toString() ?? '',
    navigator.maxTouchPoints?.toString() ?? '',
    navigator.platform ?? '',
  ].join('|');
  const hardwareHash = await hashString(hardwareData);
  items.push(createLeakItem(
    'fp-hardware', 'Hardware Uniqueness', hardwareHash, 'high',
    'Combined hardware specifications create a unique profile of your device.',
    'Hardware profiles are very stable across sessions and can identify your device even if you clear your cookies.',
    'Use browsers that report generic hardware values instead of real ones. Firefox with resistFingerprinting normalizes many hardware details.',
    ['Tor Browser', 'Firefox with resistFingerprinting']
  ));
  collectedData.push(`hardware:${hardwareHash}`);

  const entropyItems = [
    { value: canvasResult.hash, uniqueness: 256 },
    { value: webglFp, uniqueness: 256 },
    { value: audioFp, uniqueness: 128 },
    { value: fontHash, uniqueness: 64 },
    { value: timezoneHash, uniqueness: 32 },
    { value: hardwareHash, uniqueness: 128 },
    { value: navigator.userAgent, uniqueness: 64 },
    { value: navigator.language, uniqueness: 16 },
    { value: screen.width.toString(), uniqueness: 16 },
    { value: screen.height.toString(), uniqueness: 16 },
  ];
  const totalEntropy = estimateEntropy(entropyItems);
  const entropyLevel: RiskLevel = totalEntropy > 40 ? 'critical' : totalEntropy > 25 ? 'high' : totalEntropy > 15 ? 'medium' : 'low';
  items.push(createLeakItem(
    'fp-entropy', 'Overall Uniqueness Score', `${totalEntropy.toFixed(1)} bits`, entropyLevel,
    'The total uniqueness of all identifying signals combined, measured in bits.',
    `With a uniqueness score of ${totalEntropy.toFixed(1)} bits, your browser could be identified among approximately ${Math.pow(2, totalEntropy).toExponential(2)} other users.`,
    'Reduce your uniqueness by using privacy-focused browsers that make your browser look like everyone else\'s.',
    ['Tor Browser', 'Brave']
  ));

  const combinedHash = await hashString(collectedData.join('|'));
  items.push(createLeakItem(
    'fp-hash', 'Browser Fingerprint ID', combinedHash, 'critical',
    'A unique ID calculated from all collected browser details creates a unique identifier for your browser.',
    'This ID represents your complete browser profile. If it stays the same across visits, you can be tracked without any cookies.',
    'Use browsers that randomize identifying details across sessions to prevent a stable profile from being built.',
    ['Tor Browser']
  ));

  items.push(createLeakItem(
    'fp-cross-browser', 'Cross-Browser Comparison', 'Same device, different browsers may produce different profiles, but hardware details (graphics card, screen) remain consistent.', 'medium',
    'Cross-browser profiling uses hardware details that persist across different browsers on the same device.',
    'Hardware-based profiles (WebGL, screen resolution, audio) can link your identity across different browsers on the same machine.',
    'Use a single privacy-focused browser for all browsing to minimize cross-browser tracking.',
    ['Tor Browser']
  ));

  const uniquenessRatio = totalEntropy > 30 ? 'Very High' : totalEntropy > 20 ? 'High' : totalEntropy > 10 ? 'Moderate' : 'Low';
  const trackingProbability = totalEntropy > 30 ? '>99.9%' : totalEntropy > 20 ? '>99%' : totalEntropy > 10 ? '>90%' : '<90%';
  items.push(createLeakItem(
    'fp-tracking-probability', 'Tracking Probability', `${uniquenessRatio} (est. ${trackingProbability})`, totalEntropy > 20 ? 'critical' : totalEntropy > 10 ? 'high' : 'medium',
    'Estimated probability of being tracked based on how unique your browser profile is.',
    `Based on a uniqueness score of ${totalEntropy.toFixed(1)} bits, there is an estimated ${trackingProbability} chance of being uniquely identified and tracked across websites.`,
    'Use comprehensive privacy tools that address multiple tracking methods at the same time.',
    ['Tor Browser', 'Brave']
  ));

  return items;
}
