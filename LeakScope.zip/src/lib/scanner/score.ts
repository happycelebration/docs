import { ScanCategory, PrivacyScores, RISK_WEIGHTS, RiskLevel } from './types';

export function calculateScores(categories: ScanCategory[]): PrivacyScores {
  const getCategoryScore = (category: ScanCategory): number => {
    const items = category.items;
    if (items.length === 0) return 50;
    const totalWeight = items.reduce((sum, item) => sum + RISK_WEIGHTS[item.riskLevel], 0);
    const maxWeight = items.length * RISK_WEIGHTS.critical;
    const rawScore = 100 - ((totalWeight / maxWeight) * 100);
    return Math.max(0, Math.min(100, rawScore));
  };

  const categoryMap: Record<string, ScanCategory> = {};
  for (const cat of categories) {
    categoryMap[cat.id] = cat;
  }

  const browserScore = categoryMap['browser'] ? getCategoryScore(categoryMap['browser']) : 50;
  const deviceScore = categoryMap['device'] ? getCategoryScore(categoryMap['device']) : 50;
  const osScore = categoryMap['os'] ? getCategoryScore(categoryMap['os']) : 50;
  const networkScore = categoryMap['network'] ? getCategoryScore(categoryMap['network']) : 50;
  const storageScore = categoryMap['storage'] ? getCategoryScore(categoryMap['storage']) : 50;
  const securityScore = categoryMap['security'] ? getCategoryScore(categoryMap['security']) : 50;
  const fingerprintScore = categoryMap['fingerprint'] ? getCategoryScore(categoryMap['fingerprint']) : 50;
  const permissionsScore = categoryMap['permissions'] ? getCategoryScore(categoryMap['permissions']) : 50;
  const performanceScore = categoryMap['performance'] ? getCategoryScore(categoryMap['performance']) : 50;
  const privacyScore = categoryMap['privacy'] ? getCategoryScore(categoryMap['privacy']) : 50;

  const overall = (
    browserScore * 0.10 +
    deviceScore * 0.15 +
    osScore * 0.05 +
    networkScore * 0.15 +
    storageScore * 0.10 +
    securityScore * 0.10 +
    fingerprintScore * 0.15 +
    permissionsScore * 0.05 +
    performanceScore * 0.05 +
    privacyScore * 0.10
  );

  const fingerprintUniqueness = 100 - fingerprintScore;

  const trackingResistance = (
    privacyScore * 0.30 +
    storageScore * 0.20 +
    networkScore * 0.20 +
    browserScore * 0.15 +
    deviceScore * 0.15
  );

  const securityExposure = 100 - (
    securityScore * 0.40 +
    permissionsScore * 0.25 +
    networkScore * 0.20 +
    storageScore * 0.15
  );

  const browserHardening = (
    privacyScore * 0.35 +
    browserScore * 0.20 +
    securityScore * 0.20 +
    storageScore * 0.15 +
    permissionsScore * 0.10
  );

  const anonymityScore = (
    networkScore * 0.30 +
    fingerprintScore * 0.25 +
    privacyScore * 0.20 +
    browserScore * 0.15 +
    deviceScore * 0.10
  );

  const clamp = (v: number) => Math.max(0, Math.min(100, Math.round(v)));

  return {
    overall: clamp(overall),
    fingerprintUniqueness: clamp(fingerprintUniqueness),
    trackingResistance: clamp(trackingResistance),
    securityExposure: clamp(securityExposure),
    browserHardening: clamp(browserHardening),
    anonymityScore: clamp(anonymityScore),
  };
}
