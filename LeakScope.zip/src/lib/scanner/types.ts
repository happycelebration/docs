export type RiskLevel = 'critical' | 'high' | 'medium' | 'low' | 'safe';

export interface LeakItem {
  id: string;
  name: string;
  value: string | boolean | number | null;
  riskLevel: RiskLevel;
  category: string;
  description: string;
  impact: string;
  mitigation: string;
  tools?: string[];
}

export interface ScanCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
  items: LeakItem[];
  riskSummary: Record<RiskLevel, number>;
}

export interface PrivacyScores {
  overall: number;
  fingerprintUniqueness: number;
  trackingResistance: number;
  securityExposure: number;
  browserHardening: number;
  anonymityScore: number;
}

export interface ScanResult {
  scores: PrivacyScores;
  categories: ScanCategory[];
  timestamp: number;
  scanDuration: number;
  fingerprintHash: string;
}

export interface ScanProgress {
  isScanning: boolean;
  currentCategory: string;
  completedCategories: number;
  totalCategories: number;
  percentage: number;
  terminalLines: string[];
}

export const RISK_COLORS: Record<RiskLevel, string> = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#a855f7',
  safe: '#d946ef',
};

export const RISK_LABELS: Record<RiskLevel, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
  safe: 'Safe',
};

export const RISK_WEIGHTS: Record<RiskLevel, number> = {
  critical: 100,
  high: 75,
  medium: 50,
  low: 25,
  safe: 0,
};

export const CATEGORY_IDS = [
  'browser',
  'device',
  'os',
  'network',
  'storage',
  'security',
  'fingerprint',
  'permissions',
  'performance',
  'privacy',
] as const;

export type CategoryId = (typeof CATEGORY_IDS)[number];
