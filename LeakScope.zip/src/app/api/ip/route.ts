import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const forwarded = request.headers.get('x-forwarded-for');
    const ip = forwarded ? forwarded.split(',')[0].trim() : 'unknown';

    const geoRes = await fetch(`https://ipapi.co/${ip}/json/`, {
      signal: AbortSignal.timeout(5000),
    });
    const geoData = await geoRes.json();

    return NextResponse.json({
      ip: geoData.ip || ip,
      city: geoData.city || 'Unknown',
      country: geoData.country_name || 'Unknown',
      region: geoData.region || 'Unknown',
      loc: `${geoData.latitude || 0},${geoData.longitude || 0}`,
      org: geoData.org || 'Unknown',
      timezone: geoData.timezone || 'Unknown',
    });
  } catch {
    return NextResponse.json({
      ip: 'unknown',
      city: 'Unknown',
      country: 'Unknown',
      region: 'Unknown',
      loc: '0,0',
      org: 'Unknown',
      timezone: 'Unknown',
    });
  }
}
