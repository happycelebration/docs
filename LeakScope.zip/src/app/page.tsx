'use client';

import { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { runScan } from '@/lib/scanner';
import { ScanResult, ScanProgress } from '@/lib/scanner/types';

import { HeroSection } from '@/components/leakscope/hero-section';
import { ScanRadar } from '@/components/leakscope/scan-radar';
import { CyberTerminal } from '@/components/leakscope/cyber-terminal';
import { PrivacyScorePanel } from '@/components/leakscope/privacy-score-panel';
import { ThreatStats } from '@/components/leakscope/threat-stats';
import { RiskOverview } from '@/components/leakscope/risk-overview';
import { CategorySection } from '@/components/leakscope/category-section';
import { RecommendationPanel } from '@/components/leakscope/recommendation-panel';
import { ExportReport } from '@/components/leakscope/export-report';
import { DisclaimerSection } from '@/components/leakscope/disclaimer-section';
import { Shield, LayoutDashboard, AlertTriangle, BookOpen } from 'lucide-react';

type ViewTab = 'dashboard' | 'categories' | 'recommendations' | 'learn';
type TerminalLine = { text: string; type: 'info' | 'success' | 'warning' | 'error' | 'system' };

function classifyLine(line: string): TerminalLine {
  if (line.includes('[CRITICAL]')) return { text: line, type: 'error' };
  if (line.includes('[HIGH]')) return { text: line, type: 'warning' };
  if (line.includes('[MEDIUM]')) return { text: line, type: 'info' };
  if (line.includes('[LOW]')) return { text: line, type: 'success' };
  if (line.includes('[SAFE]')) return { text: line, type: 'success' };
  if (line.includes('[SCAN]')) return { text: line, type: 'info' };
  if (line.includes('[OK]')) return { text: line, type: 'success' };
  if (line.includes('[WARN]')) return { text: line, type: 'warning' };
  if (line.includes('[ERROR]')) return { text: line, type: 'error' };
  if (line.includes('[DONE]')) return { text: line, type: 'success' };
  return { text: line, type: 'info' };
}

export default function Home() {
  const [result, setResult] = useState<ScanResult | null>(null);
  const [progress, setProgress] = useState<ScanProgress>({
    isScanning: false,
    currentCategory: '',
    completedCategories: 0,
    totalCategories: 10,
    percentage: 0,
    terminalLines: [],
  });
  const [activeTab, setActiveTab] = useState<ViewTab>('dashboard');
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([]);
  const abortRef = useRef(false);

  const handleScan = useCallback(async () => {
    if (progress.isScanning) return;
    abortRef.current = false;

    setProgress({
      isScanning: true,
      currentCategory: 'Initializing',
      completedCategories: 0,
      totalCategories: 10,
      percentage: 0,
      terminalLines: [],
    });
    setTerminalLines([{ text: '[INIT] LeakScope v2.0 — browser privacy scanner', type: 'system' }]);
    setResult(null);

    const scanResult = await runScan((p) => {
      if (abortRef.current) return;
      setProgress(p);
      setTerminalLines((prev) => [...prev, ...p.terminalLines.map(classifyLine)]);
    });

    if (!abortRef.current) {
      setTerminalLines((prev) => [
        ...prev,
        { text: `[DONE] Scan completed in ${(scanResult.scanDuration / 1000).toFixed(1)}s`, type: 'success' },
        { text: `[HASH] Fingerprint: ${scanResult.fingerprintHash.slice(0, 32)}...`, type: 'info' },
        { text: `[SCORE] Overall Privacy Score: ${scanResult.scores.overall}/100`, type: scanResult.scores.overall >= 60 ? 'success' : 'warning' },
      ]);
      setResult(scanResult);
      setActiveTab('dashboard');
    }
  }, [progress.isScanning]);

  const tabs: { id: ViewTab; label: string; icon: React.ComponentType<any> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'categories', label: 'Categories', icon: AlertTriangle },
    { id: 'recommendations', label: 'Fix Issues', icon: Shield },
    { id: 'learn', label: 'Learn', icon: BookOpen },
  ];

  const isScanning = progress.isScanning;

  return (
    <div className="relative min-h-screen flex flex-col overflow-hidden bg-[#0a0612]">
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a0a2e] via-[#0a0612] to-[#12051f]" />
        <div
          className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] rounded-full opacity-[0.15] blur-[120px]"
          style={{ background: 'radial-gradient(circle, #9333ea 0%, #581c87 50%, transparent 70%)', animation: 'aurora-shift 20s ease-in-out infinite' }}
        />
        <div
          className="absolute bottom-[-15%] right-[-5%] w-[500px] h-[500px] rounded-full opacity-[0.12] blur-[100px]"
          style={{ background: 'radial-gradient(circle, #ec4899 0%, #9d174d 50%, transparent 70%)', animation: 'aurora-shift 25s ease-in-out infinite reverse' }}
        />
        <div
          className="absolute top-[30%] right-[20%] w-[350px] h-[350px] rounded-full opacity-[0.08] blur-[80px]"
          style={{ background: 'radial-gradient(circle, #8b5cf6 0%, transparent 60%)', animation: 'aurora-shift 18s ease-in-out infinite 3s' }}
        />
      </div>

      <div className="relative z-10 flex-1 flex flex-col">
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
          <AnimatePresence mode="wait">
            {isScanning ? (
              <motion.div
                key="scanning"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="flex flex-col items-center justify-center min-h-[80vh] sm:min-h-[85vh] gap-6 sm:gap-8"
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                  className="flex flex-col items-center gap-2"
                >
                  <span className="text-5xl sm:text-6xl md:text-7xl font-extrabold bg-gradient-to-r from-purple-400 via-fuchsia-400 to-pink-400 bg-clip-text text-transparent tabular-nums tracking-tight">
                    {Math.round(progress.percentage)}
                    <span className="text-2xl sm:text-3xl text-purple-400/60 ml-1">%</span>
                  </span>
                  <span className="text-sm text-purple-300/70 font-medium tracking-wide capitalize">
                    Scanning {progress.currentCategory}
                  </span>
                </motion.div>

                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.15 }}
                >
                  <ScanRadar
                    isScanning={progress.isScanning}
                    progress={progress.percentage}
                    currentCategory={progress.currentCategory}
                  />
                </motion.div>

                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.25 }}
                  className="w-full max-w-2xl"
                >
                  <CyberTerminal lines={terminalLines} maxHeight="280px" />
                </motion.div>

                <div className="w-full max-w-sm mt-2">
                  <div className="h-2 rounded-full bg-purple-950/50 overflow-hidden">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-r from-purple-600 via-fuchsia-500 to-pink-500"
                      initial={{ width: '0%' }}
                      animate={{ width: `${progress.percentage}%` }}
                      transition={{ duration: 0.4, ease: 'easeOut' }}
                    />
                  </div>
                  <p className="text-center text-xs text-purple-400/60 mt-2 font-medium">
                    {progress.completedCategories} of {progress.totalCategories} categories complete
                  </p>
                </div>
              </motion.div>
            ) : result ? (
              <motion.div
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="pb-20"
              >
                <HeroSection onScan={handleScan} isScanning={progress.isScanning} hasResults={!!result} />

                <div className="flex flex-col items-center gap-4 mb-6 sm:mb-8 mt-6 sm:mt-8">
                  <div className="flex items-center gap-1 p-1 rounded-2xl bg-purple-950/40 border border-purple-500/10">
                    {tabs.map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${
                          activeTab === tab.id
                            ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white shadow-lg shadow-purple-500/25'
                            : 'text-purple-300/60 hover:text-purple-300/90 hover:bg-purple-900/30'
                        }`}
                      >
                        <tab.icon className="w-4 h-4" />
                        <span className="hidden sm:inline">{tab.label}</span>
                        <span className="sm:hidden">{tab.label === 'Dashboard' ? 'Dash' : tab.label === 'Categories' ? 'Cats' : tab.label === 'recommendations' ? 'Fix' : tab.label}</span>
                      </button>
                    ))}
                  </div>
                  <ExportReport result={result} />
                </div>

                <AnimatePresence mode="wait">
                  {activeTab === 'dashboard' && (
                    <motion.div
                      key="dashboard"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.35 }}
                      className="space-y-8"
                    >
                      <PrivacyScorePanel
                        scores={result.scores}
                        scanDuration={result.scanDuration}
                        fingerprintHash={result.fingerprintHash}
                      />
                      <ThreatStats result={result} />
                      <RiskOverview result={result} />
                    </motion.div>
                  )}

                  {activeTab === 'categories' && (
                    <motion.div
                      key="categories"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.35 }}
                      className="space-y-4"
                    >
                      {result.categories.map((category, index) => (
                        <CategorySection key={category.id} category={category} delay={index * 0.05} />
                      ))}
                    </motion.div>
                  )}

                  {activeTab === 'recommendations' && (
                    <motion.div
                      key="recommendations"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.35 }}
                    >
                      <RecommendationPanel result={result} />
                    </motion.div>
                  )}

                  {activeTab === 'learn' && (
                    <motion.div
                      key="learn"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.35 }}
                    >
                      <DisclaimerSection />
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ) : (
              <motion.div
                key="hero"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
              >
                <HeroSection onScan={handleScan} isScanning={progress.isScanning} hasResults={false} />

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.5 }}
                  className="pb-20"
                >
                  <DisclaimerSection />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <footer className="relative z-10 mt-auto border-t border-purple-500/10 bg-purple-950/20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
            <div className="flex flex-col items-center gap-1.5">
              <p className="text-sm font-semibold bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
                LeakScope by Pallavi Thakur
              </p>
              <p className="text-purple-400/40 text-[10px] font-medium">
                All Rights Reserved
              </p>
              <p className="text-purple-400/35 text-[9px] font-medium tracking-wider uppercase mt-0.5">
                Privacy & Fingerprint Analyzer
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
