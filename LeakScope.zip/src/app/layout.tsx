import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "LeakScope - Ultimate Browser Privacy & Fingerprint Analyzer",
  description: "Discover what websites can learn about you. Analyze browser fingerprints, privacy leaks, security exposures, and tracking vectors in real-time.",
  keywords: ["privacy", "fingerprint", "browser", "security", "tracking", "WebRTC", "canvas", "LeakScope"],
  authors: [{ name: "LeakScope" }],
  icons: {
    icon: "logo.svg",
  },
  openGraph: {
    title: "LeakScope - Browser Privacy Analyzer",
    description: "Discover what websites can learn about you through browser fingerprinting and tracking.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "LeakScope - Browser Privacy Analyzer",
    description: "Discover what websites can learn about you through browser fingerprinting and tracking.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster theme="dark" position="bottom-right" />
      </body>
    </html>
  );
}
