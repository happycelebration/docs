'use client';

import { motion } from 'framer-motion';
import { ScanResult, RiskLevel } from '@/lib/scanner/types';
import { NeonCard } from './neon-card';
import { AnimatedCounter } from './animated-counter';
import { Eye, Fingerprint, Wifi, Shield, AlertTriangle, Activity } from 'lucide-react';

interface ThreatStatsProps {
  result: ScanResult;
}

interface StatCard {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  suffix?: string;
  color: string;
  glowColor: 'purple' | 'pink' | 'amber' | 'red';
  iconBg: string;
}

export function ThreatStats({ result }: ThreatStatsProps) {
  const allItems = result.categories.flatMap((cat) => cat.items);
  const leakCount = allItems.filter((item) => item.riskLevel !== 'safe').length;
  const criticalCount = result.categories.reduce((sum, cat) => sum + (cat.riskSummary.critical || 0), 0);

  const fingerprintCat = result.categories.find((cat) => cat.id === 'fingerprint');
  const entropyItem = fingerprintCat?.items.find(
    (item) => item.name.toLowerCase().includes('entropy') || item.id.includes('entropy')
  );
  const entropyValue = entropyItem && typeof entropyItem.value === 'number' ? entropyItem.value : 0;

  const stats: StatCard[] = [
    { icon: Eye, label: 'Total Leaks', value: leakCount, color: 'text-rose-400', glowColor: 'red', iconBg: 'bg-rose-500/15' },
    { icon: AlertTriangle, label: 'Critical Issues', value: criticalCount, color: 'text-orange-400', glowColor: 'red', iconBg: 'bg-orange-500/15' },
    { icon: Fingerprint, label: 'Browser Uniqueness', value: Math.round(entropyValue), suffix: ' bits', color: 'text-amber-400', glowColor: 'amber', iconBg: 'bg-amber-500/15' },
    { icon: Shield, label: 'Privacy Score', value: result.scores.overall, suffix: '/100', color: result.scores.overall >= 60 ? 'text-purple-400' : 'text-rose-400', glowColor: result.scores.overall >= 60 ? 'purple' : 'red', iconBg: result.scores.overall >= 60 ? 'bg-purple-500/15' : 'bg-rose-500/15' },
    { icon: Activity, label: 'Scan Time', value: result.scanDuration, suffix: 'ms', color: 'text-fuchsia-400', glowColor: 'purple', iconBg: 'bg-fuchsia-500/15' },
    { icon: Wifi, label: 'Areas Checked', value: result.categories.length, color: 'text-pink-400', glowColor: 'pink', iconBg: 'bg-pink-500/15' },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-4">
      {stats.map((stat, index) => (
        <motion.div key={stat.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.06, duration: 0.4 }} className="min-w-0">
          <NeonCard glowColor={stat.glowColor} delay={index * 0.06}>
            <div className="p-4 sm:p-5 flex flex-col items-center text-center group hover:scale-[1.02] transition-transform duration-300 min-w-0">
              <div className={`w-10 h-10 rounded-xl ${stat.iconBg} flex items-center justify-center mb-3`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div className={`text-2xl sm:text-3xl font-bold ${stat.color} mb-1`}>
                <AnimatedCounter value={stat.value} duration={800} suffix={stat.suffix || ''} />
              </div>
              <span className="text-purple-300/65 text-[11px] font-medium uppercase tracking-wider">
                {stat.label}
              </span>
            </div>
          </NeonCard>
        </motion.div>
      ))}
    </div>
  );
}
