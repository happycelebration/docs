'use client';

import { motion } from 'framer-motion';
import { PrivacyScores } from '@/lib/scanner/types';
import { ScoreGauge } from './score-gauge';
import { NeonCard } from './neon-card';
import { AnimatedCounter } from './animated-counter';
import { Clock, Hash, Award, TrendingUp, Fingerprint } from 'lucide-react';

interface PrivacyScorePanelProps {
  scores: PrivacyScores;
  scanDuration: number;
  fingerprintHash: string;
}

const subScores = [
  { key: 'fingerprintUniqueness' as const, label: 'Browser Uniqueness', inverted: true },
  { key: 'trackingResistance' as const, label: 'Tracking Protection', inverted: false },
  { key: 'securityExposure' as const, label: 'Security Risks', inverted: true },
  { key: 'browserHardening' as const, label: 'Browser Protection', inverted: false },
  { key: 'anonymityScore' as const, label: 'Anonymity Level', inverted: false },
];

function getScoreColor(score: number, inverted: boolean): string {
  const effectiveScore = inverted ? 100 - score : score;
  if (effectiveScore >= 80) return '#c084fc';
  if (effectiveScore >= 60) return '#e879f9';
  if (effectiveScore >= 40) return '#fbbf24';
  if (effectiveScore >= 20) return '#fb923c';
  return '#f87171';
}

function getOverallColor(score: number): string {
  if (score >= 80) return '#a855f7';
  if (score >= 60) return '#c084fc';
  if (score >= 40) return '#fbbf24';
  if (score >= 20) return '#fb923c';
  return '#f87171';
}

export function PrivacyScorePanel({ scores, scanDuration, fingerprintHash }: PrivacyScorePanelProps) {
  const overallColor = getOverallColor(scores.overall);
  const grade = scores.overall >= 90 ? 'A+' : scores.overall >= 80 ? 'A' : scores.overall >= 70 ? 'B+' : scores.overall >= 60 ? 'B' : scores.overall >= 50 ? 'C+' : scores.overall >= 40 ? 'C' : scores.overall >= 30 ? 'D' : 'F';
  const assessment = scores.overall >= 80 ? 'Well Protected' : scores.overall >= 60 ? 'Moderate Risk' : scores.overall >= 40 ? 'High Risk' : 'Critical Risk';

  return (
    <div className="w-full space-y-6">
      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 items-center">
        <NeonCard glowColor="purple" delay={0} className="shrink-0 order-2 lg:order-1">
          <div className="p-5 flex items-center justify-center">
            <ScoreGauge
              score={scores.overall}
              size={150}
              strokeWidth={12}
              label="Overall Score"
              color={overallColor}
              delay={0.2}
            />
          </div>
        </NeonCard>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 w-full order-1 lg:order-2">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.4 }}
            className="col-span-2 lg:col-span-3 order-1 lg:order-4"
          >
            <div
              className="rounded-2xl border border-purple-500/20"
              style={{
                background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.08) 0%, rgba(88, 28, 135, 0.04) 50%, transparent 100%)',
                boxShadow: '0 4px 24px rgba(147, 51, 234, 0.1)',
              }}
            >
              <div className="bg-[#110a20]/80 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-fuchsia-500/15 flex items-center justify-center shrink-0">
                  <Fingerprint className="w-4 h-4 text-fuchsia-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] text-purple-300/65 uppercase tracking-wider font-medium mb-1">Browser Fingerprint ID</p>
                  <p className="text-white font-semibold text-xs font-mono break-all leading-relaxed select-all">
                    {fingerprintHash || 'Generating...'}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.4 }}
            className="order-2 lg:order-1"
          >
            <div
              className="rounded-2xl border border-purple-500/20 h-full"
              style={{
                background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.08) 0%, rgba(88, 28, 135, 0.04) 50%, transparent 100%)',
                boxShadow: '0 4px 24px rgba(147, 51, 234, 0.1)',
              }}
            >
              <div className="bg-[#110a20]/80 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-500/15 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-purple-400" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-[10px] text-purple-300/65 uppercase tracking-wider font-medium">Scan Time</p>
                  <p className="text-white font-semibold text-sm">
                    <AnimatedCounter value={scanDuration} duration={800} suffix="ms" />
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.4 }}
            className="order-3 lg:order-2"
          >
            <div
              className="rounded-2xl border border-purple-500/20 h-full"
              style={{
                background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.08) 0%, rgba(88, 28, 135, 0.04) 50%, transparent 100%)',
                boxShadow: '0 4px 24px rgba(147, 51, 234, 0.1)',
              }}
            >
              <div className="bg-[#110a20]/80 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-pink-500/15 flex items-center justify-center shrink-0">
                  <Award className="w-4 h-4 text-pink-400" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-[10px] text-purple-300/65 uppercase tracking-wider font-medium">Grade</p>
                  <p className="text-white font-bold text-sm">{grade}</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.4 }}
            className="col-span-2 lg:col-span-1 order-4 lg:order-3"
          >
            <div
              className="rounded-2xl border border-purple-500/20 h-full"
              style={{
                background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.08) 0%, rgba(88, 28, 135, 0.04) 50%, transparent 100%)',
                boxShadow: '0 4px 24px rgba(147, 51, 234, 0.1)',
              }}
            >
              <div className="bg-[#110a20]/80 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-fuchsia-500/15 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-4 h-4 text-fuchsia-400" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-[10px] text-purple-300/65 uppercase tracking-wider font-medium">Assessment</p>
                  <p className="text-white font-semibold text-sm">{assessment}</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {subScores.map((sub, index) => {
          const score = scores[sub.key];
          const color = getScoreColor(score, sub.inverted);
          const glowColor =
            sub.key === 'fingerprintUniqueness' || sub.key === 'securityExposure'
              ? 'amber'
              : score >= 60 ? 'purple' : 'red';

          return (
            <motion.div key={sub.key} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 + index * 0.08, duration: 0.4 }} className="min-w-0">
              <NeonCard glowColor={glowColor} delay={0.4 + index * 0.08}>
                <div className="flex flex-col items-center py-3 px-2">
                  <ScoreGauge score={score} size={72} strokeWidth={5} label={sub.label} color={color} delay={0.5 + index * 0.08} />
                  {sub.inverted && (
                    <span className="text-[9px] text-amber-400/50 mt-1 font-medium">↓ lower is better</span>
                  )}
                </div>
              </NeonCard>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
