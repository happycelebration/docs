'use client';
import { useEffect, useRef } from 'react';
import { AnimatePresence } from 'framer-motion';

interface TerminalLine {
  text: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'system';
}

interface CyberTerminalProps {
  lines: TerminalLine[];
  maxHeight?: string;
}

const TYPE_COLORS: Record<TerminalLine['type'], string> = {
  info: 'text-purple-400',
  success: 'text-emerald-400',
  warning: 'text-amber-400',
  error: 'text-rose-400',
  system: 'text-fuchsia-400',
};

const TYPE_PREFIX: Record<TerminalLine['type'], string> = {
  info: '→',
  success: '✓',
  warning: '⚠',
  error: '✕',
  system: '◆',
};

export function CyberTerminal({ lines, maxHeight = '280px' }: CyberTerminalProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines]);

  return (
    <div className="rounded-2xl border border-purple-500/15 overflow-hidden bg-purple-950/30 backdrop-blur-md">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-purple-500/10 bg-purple-950/40">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-rose-500/70" />
          <span className="h-2 w-2 rounded-full bg-amber-500/70" />
          <span className="h-2 w-2 rounded-full bg-emerald-500/70" />
        </div>
        <span className="ml-3 text-[10px] text-purple-300/55 uppercase tracking-[0.2em] font-medium">
          Scanner Output
        </span>
      </div>

      <div
        ref={scrollRef}
        className="overflow-y-auto p-3"
        style={{ maxHeight }}
      >
        <AnimatePresence initial={false}>
          {lines.map((line, i) => (
            <div
              key={`${i}-${line.text.slice(0, 30)}`}
              className={`flex items-start gap-2 font-mono text-[11px] leading-relaxed ${TYPE_COLORS[line.type]}`}
            >
              <span className="shrink-0 mt-px opacity-40 text-[10px]">{TYPE_PREFIX[line.type]}</span>
              <span className="break-all">{line.text}</span>
            </div>
          ))}
        </AnimatePresence>
        <span className="inline-block w-1.5 h-3.5 bg-purple-400 animate-pulse ml-0.5 mt-0.5 rounded-sm" />
      </div>
    </div>
  );
}
