'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LeakItem } from '@/lib/scanner/types';
import { RiskBadge } from './risk-badge';
import { ChevronDown, Shield, AlertTriangle, Info, Wrench } from 'lucide-react';

interface LeakItemDetailProps {
  item: LeakItem;
  index: number;
}

const RISK_BG: Record<string, string> = {
  critical: 'bg-rose-500/[0.04]',
  high: 'bg-orange-500/[0.04]',
  medium: 'bg-amber-500/[0.04]',
  low: 'bg-purple-500/[0.04]',
  safe: 'bg-fuchsia-500/[0.04]',
};

const RISK_BORDER: Record<string, string> = {
  critical: 'border-rose-500/10',
  high: 'border-orange-500/10',
  medium: 'border-amber-500/10',
  low: 'border-purple-500/10',
  safe: 'border-fuchsia-500/10',
};

function truncateValue(val: string | boolean | number | null, maxLen = 50): string {
  if (val === null || val === undefined) return '—';
  const str = String(val);
  if (str.length <= maxLen) return str;
  return str.slice(0, maxLen) + '…';
}

export function LeakItemDetail({ item, index }: LeakItemDetailProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03, duration: 0.25 }}
      className={`rounded-xl border ${RISK_BORDER[item.riskLevel]} ${RISK_BG[item.riskLevel]} overflow-hidden`}
    >
      <button onClick={() => setExpanded((v) => !v)} className="w-full flex items-center gap-2 px-3 sm:px-4 py-2.5 sm:py-3 text-left hover:bg-purple-900/10 transition-colors">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5 min-w-0">
            <span className="text-xs sm:text-sm font-medium text-purple-100 truncate">{item.name}</span>
            <span className="shrink-0"><RiskBadge level={item.riskLevel} className="text-[8px] sm:text-[9px] px-1.5 py-px" /></span>
          </div>
          <p className="text-[10px] sm:text-[11px] text-purple-300/55 truncate">{truncateValue(item.value)}</p>
        </div>
        <motion.div animate={{ rotate: expanded ? 180 : 0 }} transition={{ duration: 0.2 }} className="shrink-0">
          <ChevronDown className="h-4 w-4 text-purple-400/50" />
        </motion.div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }} className="overflow-hidden"
          >
            <div className="px-3 sm:px-4 pb-3 sm:pb-4 pt-2 border-t border-purple-500/8 space-y-3">
              <p className="text-xs text-purple-200/75 break-words leading-relaxed">{String(item.value ?? '—')}</p>

              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-md bg-purple-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Info className="h-3 w-3 text-purple-400" />
                </div>
                <div>
                  <p className="text-[10px] text-purple-300/60 uppercase tracking-wider font-medium mb-0.5">Description</p>
                  <p className="text-xs text-purple-200/75 leading-relaxed break-words">{item.description}</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-md bg-amber-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <AlertTriangle className="h-3 w-3 text-amber-400" />
                </div>
                <div>
                  <p className="text-[10px] text-purple-300/60 uppercase tracking-wider font-medium mb-0.5">Impact</p>
                  <p className="text-xs text-purple-200/75 leading-relaxed break-words">{item.impact}</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-md bg-pink-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Shield className="h-3 w-3 text-pink-400" />
                </div>
                <div>
                  <p className="text-[10px] text-purple-300/60 uppercase tracking-wider font-medium mb-0.5">Mitigation</p>
                  <p className="text-xs text-purple-200/75 leading-relaxed break-words">{item.mitigation}</p>
                </div>
              </div>

              {item.tools && item.tools.length > 0 && (
                <div className="flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-md bg-fuchsia-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Wrench className="h-3 w-3 text-fuchsia-400" />
                  </div>
                  <div>
                    <p className="text-[10px] text-purple-300/60 uppercase tracking-wider font-medium mb-0.5">Recommended Tools</p>
                    <div className="flex flex-wrap gap-1.5">
                      {item.tools.map((tool) => (
                        <span key={tool} className="inline-block rounded-lg border border-fuchsia-500/15 bg-fuchsia-500/10 px-2.5 py-1 text-[10px] text-fuchsia-400 font-medium">{tool}</span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
