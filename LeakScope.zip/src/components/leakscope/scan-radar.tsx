'use client';
import { motion } from 'framer-motion';

interface ScanRadarProps {
  isScanning: boolean;
  progress: number;
  currentCategory: string;
}

const RING_COUNT = 4;
const DOT_COUNT = 8;
const SIZE = 220;
const CENTER = SIZE / 2;

const DOTS = Array.from({ length: DOT_COUNT }, (_, i) => ({
  angle: (Math.PI * 2 * i) / DOT_COUNT + Math.random() * 0.5,
  radius: 30 + Math.random() * 55,
  delay: i * 0.2,
  size: 2 + Math.random() * 2,
}));

export function ScanRadar({ isScanning }: ScanRadarProps) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative" style={{ width: SIZE, height: SIZE }}>
        <svg width={SIZE} height={SIZE} className="absolute inset-0">
          <defs>
            <radialGradient id="radarBg" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(147,51,234,0.08)" />
              <stop offset="100%" stopColor="transparent" />
            </radialGradient>
            <linearGradient id="sweepGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="rgba(147,51,234,0)" />
              <stop offset="100%" stopColor="rgba(168,85,247,0.3)" />
            </linearGradient>
          </defs>

          <circle cx={CENTER} cy={CENTER} r={CENTER} fill="url(#radarBg)" />

          {Array.from({ length: RING_COUNT }, (_, i) => {
            const r = ((i + 1) / RING_COUNT) * (CENTER - 10);
            return (
              <circle
                key={`ring-${i}`}
                cx={CENTER}
                cy={CENTER}
                r={r}
                fill="none"
                stroke="rgba(147,51,234,0.1)"
                strokeWidth={1}
              />
            );
          })}

          <line x1={CENTER} y1={10} x2={CENTER} y2={SIZE - 10} stroke="rgba(147,51,234,0.06)" strokeWidth={1} />
          <line x1={10} y1={CENTER} x2={SIZE - 10} y2={CENTER} stroke="rgba(147,51,234,0.06)" strokeWidth={1} />
          <line x1={30} y1={30} x2={SIZE - 30} y2={SIZE - 30} stroke="rgba(147,51,234,0.03)" strokeWidth={1} />
          <line x1={SIZE - 30} y1={30} x2={30} y2={SIZE - 30} stroke="rgba(147,51,234,0.03)" strokeWidth={1} />

          {isScanning && (
            <motion.g
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
              style={{ transformOrigin: `${CENTER}px ${CENTER}px`, transformBox: 'view-box' }}
            >
              <path
                d={`M ${CENTER} ${CENTER} L ${CENTER + CENTER * 0.9} ${CENTER} A ${CENTER * 0.9} ${CENTER * 0.9} 0 0 1 ${CENTER} ${CENTER - CENTER * 0.9} Z`}
                fill="url(#sweepGrad)"
                opacity={0.5}
              />
              <line
                x1={CENTER} y1={CENTER} x2={CENTER + CENTER * 0.9} y2={CENTER}
                stroke="#a855f7"
                strokeWidth={1.5}
                opacity={0.8}
              />
            </motion.g>
          )}

          {DOTS.map((dot, i) => {
            const x = CENTER + Math.cos(dot.angle) * dot.radius;
            const y = CENTER + Math.sin(dot.angle) * dot.radius;
            return (
              <motion.circle
                key={`dot-${i}`}
                cx={x} cy={y} r={dot.size}
                fill="#a855f7"
                initial={{ opacity: 0 }}
                animate={isScanning ? { opacity: [0, 0.8, 0.3] } : { opacity: 0.2 }}
                transition={isScanning ? { duration: 1.5, repeat: Infinity, delay: dot.delay } : { duration: 0.3 }}
              />
            );
          })}

          <motion.circle
            cx={CENTER} cy={CENTER} r={4}
            fill="#a855f7"
            animate={isScanning ? { scale: [1, 1.5, 1], opacity: [0.8, 1, 0.8] } : { scale: 1, opacity: 0.5 }}
            transition={isScanning ? { duration: 2, repeat: Infinity } : { duration: 0.3 }}
            style={{ transformOrigin: `${CENTER}px ${CENTER}px`, transformBox: 'view-box' }}
          />
        </svg>
      </div>
    </div>
  );
}
