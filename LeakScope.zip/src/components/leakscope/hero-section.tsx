'use client';

import { motion } from 'framer-motion';
import { Shield, Scan, Zap, Eye, Fingerprint, Lock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeroSectionProps {
  onScan: () => void;
  isScanning: boolean;
  hasResults: boolean;
}

const features = [
  {
    icon: Eye,
    title: 'Privacy Score',
    description: 'Comprehensive privacy assessment across 10 categories',
    iconBg: 'bg-purple-500/15',
    iconColor: 'text-purple-400',
  },
  {
    icon: Fingerprint,
    title: 'Fingerprint Analysis',
    description: 'Detect browser fingerprinting vectors and entropy',
    iconBg: 'bg-fuchsia-500/15',
    iconColor: 'text-fuchsia-400',
  },
  {
    icon: Lock,
    title: 'Security Audit',
    description: 'Identify security exposures and hardening gaps',
    iconBg: 'bg-pink-500/15',
    iconColor: 'text-pink-400',
  },
];

export function HeroSection({ onScan, isScanning, hasResults }: HeroSectionProps) {
  if (hasResults) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full"
      >
        <div className="flex items-center justify-between px-5 py-3.5 rounded-2xl border border-purple-500/20 bg-purple-950/30 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/25">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-bold bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
              LeakScope
            </span>
          </div>
          <Button
            onClick={onScan}
            disabled={isScanning}
            className="bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white hover:from-purple-500 hover:to-fuchsia-500 border-0 rounded-xl shadow-lg shadow-purple-500/25 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] px-5 py-2"
          >
            {isScanning ? (
              <span className="flex items-center gap-2">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
                  <Scan className="w-4 h-4" />
                </motion.div>
                Scanning...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Rescan
              </span>
            )}
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative w-full flex flex-col items-center pt-12 sm:pt-20 md:pt-28 pb-12 sm:pb-20 px-4"
    >
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
        className="relative z-10 text-center"
      >
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-8"
        >
          <div className="relative inline-flex items-center justify-center">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500 via-fuchsia-500 to-pink-500 flex items-center justify-center shadow-2xl shadow-purple-500/30">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <motion.div
              className="absolute inset-0 w-20 h-20 rounded-2xl"
              animate={{ boxShadow: ['0 0 30px rgba(147,51,234,0.3)', '0 0 60px rgba(236,72,153,0.2)', '0 0 30px rgba(147,51,234,0.3)'] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            />
          </div>
        </motion.div>

        <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold mb-4 tracking-tight">
          <span className="bg-gradient-to-r from-purple-400 via-fuchsia-400 to-pink-400 bg-clip-text text-transparent">
            LeakScope
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-purple-200/70 text-lg sm:text-xl mb-10 sm:mb-14 max-w-lg mx-auto px-4 font-medium leading-relaxed"
        >
          Discover what websites can learn about you
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="mb-14 sm:mb-20"
        >
          <Button
            onClick={onScan}
            disabled={isScanning}
            size="lg"
            className="relative group px-10 sm:px-12 py-7 sm:py-8 text-lg font-bold bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 text-white hover:from-purple-500 hover:via-fuchsia-500 hover:to-pink-500 border-0 rounded-2xl shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-500 hover:scale-[1.03] active:scale-[0.98]"
          >
            <motion.div
              className="absolute inset-0 rounded-2xl"
              animate={
                isScanning
                  ? {}
                  : {
                      boxShadow: [
                        '0 0 40px rgba(147,51,234,0.2)',
                        '0 0 80px rgba(236,72,153,0.15)',
                        '0 0 40px rgba(147,51,234,0.2)',
                      ],
                    }
              }
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            />
            {isScanning ? (
              <span className="relative flex items-center gap-3">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
                  <Scan className="w-6 h-6" />
                </motion.div>
                Initializing...
              </span>
            ) : (
              <span className="relative flex items-center gap-3">
                <Sparkles className="w-5 h-5" />
                Start Privacy Scan
              </span>
            )}
          </Button>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6 max-w-4xl w-full"
      >
        {features.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 + index * 0.12, duration: 0.5 }}
            className="group rounded-2xl border border-purple-500/15 bg-purple-950/20 backdrop-blur-sm p-7 hover:bg-purple-900/25 hover:border-purple-400/25 transition-all duration-500"
          >
            <div className={`w-11 h-11 rounded-xl ${feature.iconBg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
              <feature.icon className={`w-5 h-5 ${feature.iconColor}`} />
            </div>
            <h3 className="text-white font-semibold text-base mb-2">{feature.title}</h3>
            <p className="text-purple-300/65 text-sm leading-relaxed">{feature.description}</p>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}
