'use client';
import { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface NeonCardProps {
  children: ReactNode;
  className?: string;
  glowColor?: string;
  delay?: number;
}

const CARD_STYLES: Record<string, { border: string; shadow: string; gradient: string }> = {
  purple: {
    border: 'rgba(147, 51, 234, 0.25)',
    shadow: '0 4px 24px rgba(147, 51, 234, 0.1), 0 0 60px rgba(147, 51, 234, 0.05)',
    gradient: 'linear-gradient(135deg, rgba(147, 51, 234, 0.08) 0%, rgba(88, 28, 135, 0.04) 50%, transparent 100%)',
  },
  pink: {
    border: 'rgba(236, 72, 153, 0.25)',
    shadow: '0 4px 24px rgba(236, 72, 153, 0.1), 0 0 60px rgba(236, 72, 153, 0.05)',
    gradient: 'linear-gradient(135deg, rgba(236, 72, 153, 0.08) 0%, rgba(190, 24, 93, 0.04) 50%, transparent 100%)',
  },
  amber: {
    border: 'rgba(245, 158, 11, 0.25)',
    shadow: '0 4px 24px rgba(245, 158, 11, 0.08), 0 0 60px rgba(245, 158, 11, 0.04)',
    gradient: 'linear-gradient(135deg, rgba(245, 158, 11, 0.06) 0%, rgba(180, 83, 9, 0.03) 50%, transparent 100%)',
  },
  red: {
    border: 'rgba(239, 68, 68, 0.25)',
    shadow: '0 4px 24px rgba(239, 68, 68, 0.1), 0 0 60px rgba(239, 68, 68, 0.05)',
    gradient: 'linear-gradient(135deg, rgba(239, 68, 68, 0.08) 0%, rgba(185, 28, 28, 0.04) 50%, transparent 100%)',
  },
  cyan: {
    border: 'rgba(6, 182, 212, 0.25)',
    shadow: '0 4px 24px rgba(6, 182, 212, 0.1), 0 0 60px rgba(6, 182, 212, 0.05)',
    gradient: 'linear-gradient(135deg, rgba(6, 182, 212, 0.06) 0%, rgba(14, 116, 144, 0.03) 50%, transparent 100%)',
  },
};

export function NeonCard({ children, className = '', glowColor = 'purple', delay = 0 }: NeonCardProps) {
  const style = CARD_STYLES[glowColor] ?? CARD_STYLES.purple;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.25, 0.4, 0.25, 1] }}
      className={`relative rounded-2xl ${className}`}
      style={{
        border: `1px solid ${style.border}`,
        boxShadow: style.shadow,
        background: style.gradient,
      }}
    >
      <div className="relative bg-[#110a20]/80 backdrop-blur-md rounded-2xl">
        {children}
      </div>
    </motion.div>
  );
}
