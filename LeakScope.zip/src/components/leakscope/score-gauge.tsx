'use client';
import { motion } from 'framer-motion';
import { AnimatedCounter } from './animated-counter';

interface ScoreGaugeProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  label: string;
  color?: string;
  delay?: number;
}

function getScoreColor(score: number, override?: string): string {
  if (override) return override;
  if (score <= 30) return '#f87171';
  if (score <= 50) return '#fb923c';
  if (score <= 70) return '#fbbf24';
  if (score <= 90) return '#c084fc';
  return '#e879f9';
}

function getScoreGlow(score: number): string {
  if (score <= 30) return 'rgba(248,113,113,0.3)';
  if (score <= 50) return 'rgba(251,146,60,0.3)';
  if (score <= 70) return 'rgba(251,191,36,0.3)';
  if (score <= 90) return 'rgba(192,132,252,0.35)';
  return 'rgba(232,121,249,0.35)';
}

export function ScoreGauge({ score, size = 120, strokeWidth = 8, label, color, delay = 0 }: ScoreGaugeProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const mainColor = getScoreColor(score, color);
  const glowColor = getScoreGlow(score);
  const center = size / 2;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.5, ease: [0.25, 0.4, 0.25, 1] }}
      className="flex flex-col items-center gap-2"
    >
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={center} cy={center} r={radius}
            fill="none" stroke="rgba(147,51,234,0.1)" strokeWidth={strokeWidth}
          />
          <motion.circle
            cx={center} cy={center} r={radius}
            fill="none" stroke={mainColor} strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: circumference - (circumference * score) / 100 }}
            transition={{ delay: delay + 0.3, duration: 1.2, ease: 'easeOut' }}
            style={{ filter: `drop-shadow(0 0 8px ${glowColor})` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <AnimatedCounter
            value={score} suffix="" duration={1200}
            className="text-2xl font-bold" style={{ color: mainColor } as React.CSSProperties}
          />
        </div>
      </div>
      <span className="text-[10px] sm:text-[11px] font-medium text-purple-300/70 uppercase tracking-wider text-center leading-tight max-w-[100px]">
        {label}
      </span>
    </motion.div>
  );
}
