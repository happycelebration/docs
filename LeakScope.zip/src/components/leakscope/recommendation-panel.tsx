'use client';

import { motion } from 'framer-motion';
import { ScanResult, RiskLevel, LeakItem } from '@/lib/scanner/types';
import { NeonCard } from './neon-card';
import { RiskBadge } from './risk-badge';
import { Shield, AlertTriangle, ArrowRight, ExternalLink } from 'lucide-react';

interface RecommendationPanelProps {
  result: ScanResult;
}

const RISK_PRIORITY: Record<RiskLevel, number> = { critical: 0, high: 1, medium: 2, low: 3, safe: 4 };

function getRiskBorderColor(risk: RiskLevel): string {
  switch (risk) {
    case 'critical': return 'border-rose-500/20';
    case 'high': return 'border-orange-500/20';
    case 'medium': return 'border-amber-500/20';
    case 'low': return 'border-purple-500/20';
    case 'safe': return 'border-fuchsia-500/20';
  }
}

export function RecommendationPanel({ result }: RecommendationPanelProps) {
  const allItems: LeakItem[] = result.categories.flatMap((cat) => cat.items);
  const riskyItems = allItems.filter((item) => item.riskLevel !== 'safe').sort((a, b) => RISK_PRIORITY[a.riskLevel] - RISK_PRIORITY[b.riskLevel]).slice(0, 8);

  if (riskyItems.length === 0) {
    return (
      <NeonCard glowColor="purple" delay={0}>
        <div className="p-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-purple-500/15 flex items-center justify-center mx-auto mb-4">
            <Shield className="w-7 h-7 text-purple-400" />
          </div>
          <h3 className="text-purple-300 font-semibold text-lg mb-2">No Issues Found</h3>
          <p className="text-purple-300/65 text-sm">Your browser appears to be well-protected.</p>
        </div>
      </NeonCard>
    );
  }

  return (
    <NeonCard glowColor={riskyItems[0].riskLevel === 'critical' || riskyItems[0].riskLevel === 'high' ? 'red' : 'amber'} delay={0}>
      <div className="p-5 sm:p-6 min-w-0">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-white font-semibold text-lg">Top Recommendations</h3>
          <span className="ml-auto text-xs text-purple-300/60 font-medium">{riskyItems.length} issues</span>
        </div>

        <div className="space-y-3">
          {riskyItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className={`rounded-xl border ${getRiskBorderColor(item.riskLevel)} bg-purple-950/20 p-4 hover:bg-purple-900/20 transition-colors duration-200 min-w-0`}
            >
              <div className="flex items-start gap-3 min-w-0">
                <div className="flex-shrink-0 mt-0.5">
                  <RiskBadge level={item.riskLevel} showDot className="text-[9px] px-1.5 py-0.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-medium text-sm mb-1.5 break-words">{item.name}</h4>
                  <p className="text-purple-300/65 text-xs mb-3 break-words">{item.mitigation}</p>
                  {item.tools && item.tools.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap mb-2">
                      {item.tools.map((tool) => (
                        <span key={tool} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium bg-purple-500/10 text-purple-300 border border-purple-500/15">
                          <ArrowRight className="w-2.5 h-2.5" />{tool}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-purple-400/40 hover:text-purple-300 transition-colors flex-shrink-0 mt-1 cursor-pointer" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </NeonCard>
  );
}
