'use client';

import { motion } from 'framer-motion';
import { ScanResult, RiskLevel, RISK_LABELS, RISK_COLORS } from '@/lib/scanner/types';
import { NeonCard } from './neon-card';
import { AnimatedCounter } from './animated-counter';

interface RiskOverviewProps {
  result: ScanResult;
}

const RISK_ORDER: RiskLevel[] = ['critical', 'high', 'medium', 'low', 'safe'];

const BAR_COLORS: Record<RiskLevel, { bg: string; text: string }> = {
  critical: { bg: 'bg-gradient-to-r from-red-500 to-rose-500', text: 'text-rose-400' },
  high: { bg: 'bg-gradient-to-r from-orange-500 to-amber-500', text: 'text-orange-400' },
  medium: { bg: 'bg-gradient-to-r from-yellow-500 to-amber-500', text: 'text-amber-400' },
  low: { bg: 'bg-gradient-to-r from-purple-500 to-fuchsia-500', text: 'text-purple-400' },
  safe: { bg: 'bg-gradient-to-r from-fuchsia-500 to-pink-500', text: 'text-fuchsia-400' },
};

export function RiskOverview({ result }: RiskOverviewProps) {
  const totalCounts = RISK_ORDER.reduce((acc, level) => {
    acc[level] = result.categories.reduce((sum, cat) => sum + (cat.riskSummary[level] || 0), 0);
    return acc;
  }, {} as Record<RiskLevel, number>);

  const totalItems = RISK_ORDER.reduce((sum, level) => sum + totalCounts[level], 0);
  const maxCount = Math.max(...RISK_ORDER.map((level) => totalCounts[level]), 1);

  return (
    <NeonCard glowColor="purple" delay={0}>
      <div className="p-5 sm:p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-white font-semibold text-lg">Risk Distribution</h3>
          <span className="text-purple-300/65 text-xs font-medium">
            <AnimatedCounter value={totalItems} duration={600} /> items
          </span>
        </div>

        <div className="space-y-3">
          {RISK_ORDER.map((level, index) => {
            const count = totalCounts[level];
            const percentage = totalItems > 0 ? (count / totalItems) * 100 : 0;
            const barWidth = maxCount > 0 ? (count / maxCount) * 100 : 0;
            const colors = BAR_COLORS[level];

            return (
              <div key={level} className="flex items-center gap-3">
                <div className="w-16 sm:w-20 flex-shrink-0">
                  <span className={`text-[11px] sm:text-xs font-medium ${colors.text}`}>{RISK_LABELS[level]}</span>
                </div>

                <div className="flex-1 h-8 rounded-xl bg-purple-950/30 overflow-hidden relative min-w-0">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${barWidth}%` }}
                    transition={{ duration: 0.8, delay: 0.2 + index * 0.1, ease: 'easeOut' }}
                    className={`h-full ${colors.bg} rounded-xl relative`}
                    style={{ boxShadow: `0 0 16px ${RISK_COLORS[level]}20` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-white/10 rounded-xl" />
                  </motion.div>
                </div>

                <div className="w-14 sm:w-16 flex-shrink-0 text-right">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.6 + index * 0.1, duration: 0.3 }}
                    className="flex items-center justify-end gap-1"
                  >
                    <span className="text-white text-xs sm:text-sm font-semibold">
                      <AnimatedCounter value={count} duration={600} />
                    </span>
                    <span className="text-purple-400/60 text-[10px]">({percentage.toFixed(0)}%)</span>
                  </motion.div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </NeonCard>
  );
}
