'use client';

import { motion } from 'framer-motion';
import { NeonCard } from './neon-card';
import { Info, Shield, BookOpen } from 'lucide-react';

export function DisclaimerSection() {
  return (
    <NeonCard glowColor="purple" delay={0}>
      <div className="p-5 sm:p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-xl bg-purple-500/15 flex items-center justify-center">
            <Info className="w-4 h-4 text-purple-400" />
          </div>
          <h3 className="text-white font-semibold text-lg">About This Tool</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.4 }}
            className="rounded-xl border border-purple-500/10 bg-purple-950/20 p-5">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center">
                <Shield className="w-4 h-4 text-emerald-400" />
              </div>
              <h4 className="text-emerald-400 font-semibold text-sm">Privacy First</h4>
            </div>
            <ul className="space-y-2.5 text-purple-200/70 text-xs leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400/80 mt-0.5">•</span>
                <span>This tool runs entirely in your browser. No data is sent to external servers (except to look up your approximate location from your IP address).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400/80 mt-0.5">•</span>
                <span>All profiling techniques used here are the same ones websites use &mdash; we show you what they can see about you.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400/80 mt-0.5">•</span>
                <span>Your scan results are never stored, transmitted, or shared.</span>
              </li>
            </ul>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.4 }}
            className="rounded-xl border border-purple-500/10 bg-purple-950/20 p-5">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center">
                <BookOpen className="w-4 h-4 text-amber-400" />
              </div>
              <h4 className="text-amber-400 font-semibold text-sm">How Browser Profiling Works</h4>
            </div>
            <ul className="space-y-2.5 text-purple-200/70 text-xs leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-amber-400/80 mt-0.5">•</span>
                <span>Browser profiling collects details like your screen resolution, fonts, add-ons, and hardware to create a unique identifier for you.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400/80 mt-0.5">•</span>
                <span>Unlike cookies, profiling works without storing anything on your device &mdash; making it harder to detect and block.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400/80 mt-0.5">•</span>
                <span>Websites can legally use these techniques for fraud prevention, analytics, and advertising.</span>
              </li>
            </ul>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.4 }}
            className="rounded-xl border border-purple-500/10 bg-purple-950/20 p-5">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-fuchsia-500/15 flex items-center justify-center">
                <Info className="w-4 h-4 text-fuchsia-400" />
              </div>
              <h4 className="text-fuchsia-400 font-semibold text-sm">Privacy Tips</h4>
            </div>
            <ul className="space-y-2.5 text-purple-200/70 text-xs leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-fuchsia-400/80 mt-0.5">•</span>
                <span>Use privacy-focused browsers like Firefox or Brave with built-in tracking protection enabled.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-fuchsia-400/80 mt-0.5">•</span>
                <span>Consider using the Tor Browser for maximum anonymity when needed.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-fuchsia-400/80 mt-0.5">•</span>
                <span>Install extensions like uBlock Origin and Privacy Badger to reduce tracking methods.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-fuchsia-400/80 mt-0.5">•</span>
                <span>Keep your browser updated &mdash; newer versions often include better privacy protections.</span>
              </li>
            </ul>
          </motion.div>
        </div>

        <div className="mt-5 pt-4 border-t border-purple-500/10">
          <p className="text-purple-400/50 text-[11px] text-center">
            This tool is for educational purposes only. Results reflect your browser&apos;s current configuration and may vary across sessions and devices.
          </p>
        </div>
      </div>
    </NeonCard>
  );
}
