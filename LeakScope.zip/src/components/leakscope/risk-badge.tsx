'use client';
import { RiskLevel, RISK_LABELS } from '@/lib/scanner/types';

interface RiskBadgeProps {
  level: RiskLevel;
  showDot?: boolean;
  className?: string;
}

const RISK_STYLES: Record<RiskLevel, { bg: string; text: string; border: string; dot: string }> = {
  critical: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/15', dot: 'bg-rose-500' },
  high: { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-500/15', dot: 'bg-orange-500' },
  medium: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/15', dot: 'bg-amber-500' },
  low: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/15', dot: 'bg-purple-500' },
  safe: { bg: 'bg-fuchsia-500/10', text: 'text-fuchsia-400', border: 'border-fuchsia-500/15', dot: 'bg-fuchsia-500' },
};

export function RiskBadge({ level, showDot = true, className = '' }: RiskBadgeProps) {
  const style = RISK_STYLES[level];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-lg border px-2 py-0.5 text-[11px] font-medium uppercase tracking-wider ${style.bg} ${style.text} ${style.border} ${className}`}>
      {showDot && <span className={`inline-block h-1.5 w-1.5 rounded-full ${style.dot}`} />}
      {RISK_LABELS[level]}
    </span>
  );
}
