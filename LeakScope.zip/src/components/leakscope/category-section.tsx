'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ScanCategory, RiskLevel } from '@/lib/scanner/types';
import { NeonCard } from './neon-card';
import { RiskBadge } from './risk-badge';
import { LeakItemDetail } from './leak-item-detail';
import {
  Globe, Monitor, Laptop, Wifi, Database, Shield,
  Fingerprint, Key, Gauge, Lock, ChevronDown, ChevronRight,
} from 'lucide-react';

interface CategorySectionProps {
  category: ScanCategory;
  delay?: number;
}

const ICON_MAP: Record<string, React.ComponentType<any>> = {
  Globe, Monitor, Laptop, Wifi, Database, Shield, Fingerprint, Key, Gauge, Lock,
};

const RISK_PRIORITY: Record<RiskLevel, number> = { critical: 0, high: 1, medium: 2, low: 3, safe: 4 };

function getHighestRisk(summary: Record<RiskLevel, number>): RiskLevel {
  if (summary.critical > 0) return 'critical';
  if (summary.high > 0) return 'high';
  if (summary.medium > 0) return 'medium';
  if (summary.low > 0) return 'low';
  return 'safe';
}

function getGlowFromRisk(risk: RiskLevel): 'purple' | 'pink' | 'amber' | 'red' {
  switch (risk) {
    case 'critical': case 'high': return 'red';
    case 'medium': return 'amber';
    case 'low': return 'pink';
    case 'safe': return 'purple';
  }
}

function getIconStyle(risk: RiskLevel): { color: string; bg: string } {
  switch (risk) {
    case 'critical': return { color: 'text-rose-400', bg: 'bg-rose-500/15' };
    case 'high': return { color: 'text-orange-400', bg: 'bg-orange-500/15' };
    case 'medium': return { color: 'text-amber-400', bg: 'bg-amber-500/15' };
    case 'low': return { color: 'text-purple-400', bg: 'bg-purple-500/15' };
    case 'safe': return { color: 'text-fuchsia-400', bg: 'bg-fuchsia-500/15' };
  }
}

export function CategorySection({ category, delay = 0 }: CategorySectionProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const highestRisk = getHighestRisk(category.riskSummary);
  const glowColor = getGlowFromRisk(highestRisk);
  const IconComponent = ICON_MAP[category.icon] || Shield;
  const iconStyle = getIconStyle(highestRisk);
  const sortedItems = [...category.items].sort((a, b) => RISK_PRIORITY[a.riskLevel] - RISK_PRIORITY[b.riskLevel]);
  const riskEntries = (Object.entries(category.riskSummary) as [RiskLevel, number][]).filter(([, count]) => count > 0);

  return (
    <NeonCard glowColor={glowColor} delay={delay} className="w-full">
      <button onClick={() => setIsExpanded(!isExpanded)} className="w-full text-left p-4 sm:p-5 flex items-center gap-3 sm:gap-4 group">
        <div className={`w-10 h-10 rounded-xl ${iconStyle.bg} flex items-center justify-center flex-shrink-0`}>
          <IconComponent className={`w-5 h-5 ${iconStyle.color}`} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-white font-semibold text-sm sm:text-base truncate">{category.name}</h3>
          <p className="text-purple-300/60 text-xs truncate mt-0.5">{category.description}</p>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap justify-end max-w-[40%] sm:max-w-[50%]">
          {riskEntries.map(([level, count]) => (
            <span key={level} className="inline-flex items-center gap-1">
              <RiskBadge level={level} showDot className="text-[10px] px-1.5 py-0.5" />
              <span className="text-purple-300/60 text-[10px] font-medium">{count}</span>
            </span>
          ))}
        </div>
        <div className="flex-shrink-0 text-purple-400/50 group-hover:text-purple-300/80 transition-colors">
          {isExpanded ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
        </div>
      </button>
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }} className="overflow-hidden"
          >
            <div className="px-4 sm:px-5 pb-4 sm:pb-5 space-y-2">
              <div className="h-px bg-gradient-to-r from-transparent via-purple-500/15 to-transparent mb-4" />
              {sortedItems.map((item, index) => (
                <motion.div key={item.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.03, duration: 0.25 }}>
                  <LeakItemDetail item={item} index={index} />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </NeonCard>
  );
}
