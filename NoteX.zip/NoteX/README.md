# NoteX

**NoteX** is a lightweight, stylish, and customizable floating desktop note application for Android. Designed with a sleek **Water Glass / Glassmorphism UI**, NoteX allows you to write, paste, and keep persistent notes floating over any application without interrupting your workflow.

Built specifically with strict **Java 6/7 compatibility** for seamless building on **AIDE (Android IDE)** as well as standard Android Studio.

---

## Key Features

* **Glassmorphism Design**: Beautiful dark acrylic / frosted glass canvas with subtle highlights and soft rounded corners.
* **Always-on-Top Floating Note**: Stays accessible over any application or desktop view.
* **A4 Aspect Ratio Sheet**: Proportional note window shaped like a standard portrait A4 page for natural readability.
* **Dedicated Quick Action Buttons**: Integrated **Copy** and **Paste** header controls that instantly sync with the system clipboard (selected text or entire note).
* **Live Customizable Settings**:
  * **Floating Icon Opacity**: Adjust transparency of the minimized bubble (0% – 100%).
  * **Canvas Glass Transparency**: Dynamic alpha controls for background opacity.
  * **Canvas Size**: Toggle between 4 proportional A4 sheet sizes (Small, Medium, Large, Extra Large).
* **Real-time Auto-Save**: Powered by `SharedPreferences`, your note is auto-saved as you type—never lose a word on exit or minimize.
* **Seamless Drag & Touch**: Smooth dragging for both the expanded window header and the minimized bubble.

---

## Project Structure

```text
NoteX/
├── app/
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/
│           │   └── com/
│           │       └── floating/
│           │           └── notex/
│           │               ├── MainActivity.java
│           │               └── FloatingNoteService.java
│           └── res/
│               ├── drawable/
│               │   ├── bg_button_action.xml
│               │   ├── bg_button_close.xml
│               │   ├── bg_button_minimize.xml
│               │   ├── bg_glass_window.xml
│               │   ├── bg_minimized_bubble.xml
│               │   ├── ic_close.xml
│               │   ├── ic_copy.xml
│               │   ├── ic_launcher.xml
│               │   ├── ic_minimize.xml
│               │   └── ic_paste.xml
│               ├── layout/
│               │   ├── activity_main.xml
│               │   └── layout_floating_widget.xml
│               └── values/
│                   ├── colors.xml
│                   └── strings.xml

```
## Getting Started

### Prerequisites

 * **Android OS**: Android 7.0 (API Level 24) up to Android 15+ (API Level 35/36).
 * **IDE**: Compatible with **AIDE (Android IDE)** on mobile device or **Android Studio** on desktop.
 * **Java Version**: Java 6 / 7 compatible syntax.
 
### Installation

 1. **Clone the Repository**
   ```bash
   git clone [https://github.com/your-username/NoteX.git](https://github.com/your-username/NoteX.git)
   
   ```
 2. **Open in AIDE or Android Studio**
   * **AIDE**: Open the app folder in AIDE on your Android device.
   * **Android Studio**: Select Open an Existing Project and navigate to the cloned folder.
 3. **Build & Run**
   * Clean and rebuild the project (Menu -> Project -> Clean and Rebuild).
   * Compile and install the APK.
   
## Permissions

NoteX uses the **Display over other apps** permission to draw the floating window over other applications:
```xml
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

```
> **Note**: When launching the app for the first time, click **Grant Overlay Permission** to enable floating window functionality in device settings.
> 

## Tech Stack & Architecture

 * **Language**: Java 1.7 (Zero Kotlin dependencies, fully legacy/AIDE compatible).
 * **UI Window**: WindowManager with TYPE_APPLICATION_OVERLAY.
 * **Background Processing**: Unbound background Service (FloatingNoteService).
 * **Data Persistence**: SharedPreferences with real-time TextWatcher listeners.
 * **Graphics**: Dynamic GradientDrawable shape rendering for frosted glass effects and rounded top corners.
 
## How It Works

 1. **Launcher Activity (MainActivity)**: Manages overlay permission status and provides 3 live SeekBar controls to adjust icon transparency, canvas glass tint, and A4 canvas dimensions.
 2. **Floating Service (FloatingNoteService)**: Dynamically inflates layout_floating_widget.xml into the system overlay layer. Handles drag movements via OnTouchListener, auto-saves content, and interacts with ClipboardManager for single-tap copy/paste.
 
## Contributing

Contributions are welcome! If you have suggestions or improvements:
 1. Fork the Project.
 2. Create your Feature Branch (git checkout -b feature/NewFeature).
 3. Commit your Changes (git commit -m 'Add NewFeature').
 4. Push to the Branch (git push origin feature/NewFeature).
 5. Open a Pull Request.
 
## License

Distributed under the **MIT License**. See LICENSE for more details.
<p align="center">Made with ❤️ for Android developers and multitasking power users!</p>