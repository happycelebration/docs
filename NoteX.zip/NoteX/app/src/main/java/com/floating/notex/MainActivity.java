package com.floating.notex;

import com.floating.notex.R;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    public static final String PREFS_SETTINGS = "NoteXSettings";
    public static final String KEY_BUBBLE_OPACITY = "key_bubble_opacity";
    public static final String KEY_CANVAS_OPACITY = "key_canvas_opacity";
    public static final String KEY_CANVAS_SIZE = "key_canvas_size";

    public static final String ACTION_UPDATE_SETTINGS = "com.floating.notex.UPDATE_SETTINGS";

    private static final int CODE_DRAW_OVERLAY_PERMISSION = 1001;

    private Button btnAction;
    private SeekBar seekBubbleOpacity;
    private SeekBar seekCanvasOpacity;
    private SeekBar seekCanvasSize;

    private TextView tvLabelBubbleOpacity;
    private TextView tvLabelCanvasOpacity;
    private TextView tvLabelCanvasSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAction = (Button) findViewById(R.id.btn_action);
        seekBubbleOpacity = (SeekBar) findViewById(R.id.seek_bubble_opacity);
        seekCanvasOpacity = (SeekBar) findViewById(R.id.seek_canvas_opacity);
        seekCanvasSize = (SeekBar) findViewById(R.id.seek_canvas_size);

        tvLabelBubbleOpacity = (TextView) findViewById(R.id.tv_label_bubble_opacity);
        tvLabelCanvasOpacity = (TextView) findViewById(R.id.tv_label_canvas_opacity);
        tvLabelCanvasSize = (TextView) findViewById(R.id.tv_label_canvas_size);

        SharedPreferences prefs = getSharedPreferences(PREFS_SETTINGS, MODE_PRIVATE);
        int savedBubbleOpacity = prefs.getInt(KEY_BUBBLE_OPACITY, 80);
        int savedCanvasOpacity = prefs.getInt(KEY_CANVAS_OPACITY, 70);
        int savedCanvasSize = prefs.getInt(KEY_CANVAS_SIZE, 1);

        seekBubbleOpacity.setProgress(savedBubbleOpacity);
        seekCanvasOpacity.setProgress(savedCanvasOpacity);
        seekCanvasSize.setProgress(savedCanvasSize);

        updateLabels(savedBubbleOpacity, savedCanvasOpacity, savedCanvasSize);

        seekBubbleOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					saveSetting(KEY_BUBBLE_OPACITY, progress);
					updateLabels(progress, seekCanvasOpacity.getProgress(), seekCanvasSize.getProgress());
					notifyService();
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        seekCanvasOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					if (progress < 10) {
						progress = 10;
					}
					saveSetting(KEY_CANVAS_OPACITY, progress);
					updateLabels(seekBubbleOpacity.getProgress(), progress, seekCanvasSize.getProgress());
					notifyService();
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        seekCanvasSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					saveSetting(KEY_CANVAS_SIZE, progress);
					updateLabels(seekBubbleOpacity.getProgress(), seekCanvasOpacity.getProgress(), progress);
					notifyService();
				}

				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        btnAction.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (checkOverlayPermission()) {
						toggleService();
					} else {
						requestOverlayPermission();
					}
				}
			});
    }

    private void updateLabels(int bubbleOpacity, int canvasOpacity, int canvasSize) {
        tvLabelBubbleOpacity.setText("Floating Icon Opacity: " + bubbleOpacity + "%");
        tvLabelCanvasOpacity.setText("Canvas Transparency (Glass Tint): " + canvasOpacity + "%");

        String sizeText;
        switch (canvasSize) {
            case 0:
                sizeText = "Small A4 (200dp x 280dp)";
                break;
            case 2:
                sizeText = "Large A4 (280dp x 395dp)";
                break;
            case 3:
                sizeText = "Extra Large A4 (320dp x 450dp)";
                break;
            default:
                sizeText = "Medium A4 (240dp x 340dp)";
                break;
        }
        tvLabelCanvasSize.setText("Canvas Size: " + sizeText);
    }

    private void saveSetting(String key, int value) {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_SETTINGS, MODE_PRIVATE).edit();
        editor.putInt(key, value);
        editor.apply();
    }

    private void notifyService() {
        if (FloatingNoteService.isServiceRunning) {
            Intent intent = new Intent(this, FloatingNoteService.class);
            intent.setAction(ACTION_UPDATE_SETTINGS);
            startService(intent);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateButtonState();
    }

    private boolean checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(intent, CODE_DRAW_OVERLAY_PERMISSION);
        }
    }

    private void toggleService() {
        Intent intent = new Intent(MainActivity.this, FloatingNoteService.class);
        if (FloatingNoteService.isServiceRunning) {
            stopService(intent);
            Toast.makeText(this, "Floating Note Stopped", Toast.LENGTH_SHORT).show();
        } else {
            startService(intent);
            Toast.makeText(this, "Floating Note Started", Toast.LENGTH_SHORT).show();
        }
        updateButtonState();
    }

    private void updateButtonState() {
        if (!checkOverlayPermission()) {
            btnAction.setText(R.string.grant_permission);
        } else if (FloatingNoteService.isServiceRunning) {
            btnAction.setText(R.string.stop_service);
        } else {
            btnAction.setText(R.string.start_service);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CODE_DRAW_OVERLAY_PERMISSION) {
            if (checkOverlayPermission()) {
                toggleService();
            } else {
                Toast.makeText(this, R.string.permission_required, Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}

