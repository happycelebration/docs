package com.floating.notex;

import com.floating.notex.R;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class FloatingNoteService extends Service {

    public static boolean isServiceRunning = false;

    private static final String PREFS_NAME = "NoteXPrefs";
    private static final String KEY_NOTE_TEXT = "saved_note_text";

    private WindowManager windowManager;
    private View floatingView;
    private View expandedView;
    private View headerBar;
    private ImageView minimizedView;
    private EditText etNote;

    private WindowManager.LayoutParams params;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        isServiceRunning = true;

        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null);

        expandedView = floatingView.findViewById(R.id.expanded_view);
        minimizedView = (ImageView) floatingView.findViewById(R.id.minimized_view);
        etNote = (EditText) floatingView.findViewById(R.id.et_note);
        headerBar = floatingView.findViewById(R.id.header_bar);

        ImageView btnCopy = (ImageView) floatingView.findViewById(R.id.btn_copy);
        ImageView btnPaste = (ImageView) floatingView.findViewById(R.id.btn_paste);
        ImageView btnMinimize = (ImageView) floatingView.findViewById(R.id.btn_minimize);
        ImageView btnClose = (ImageView) floatingView.findViewById(R.id.btn_close);

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;

        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        if (windowManager != null) {
            windowManager.addView(floatingView, params);
        }

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedText = prefs.getString(KEY_NOTE_TEXT, "");
        etNote.setText(savedText);

        etNote.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
					editor.putString(KEY_NOTE_TEXT, s.toString());
					editor.apply();
				}

				@Override
				public void afterTextChanged(Editable s) {}
			});

        btnCopy.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					int start = etNote.getSelectionStart();
					int end = etNote.getSelectionEnd();
					String textToCopy = "";

					if (start >= 0 && end > start) {
						textToCopy = etNote.getText().toString().substring(start, end);
					} else {
						textToCopy = etNote.getText().toString();
					}

					if (!textToCopy.isEmpty() && clipboard != null) {
						ClipData clip = ClipData.newPlainText("NoteX", textToCopy);
						clipboard.setPrimaryClip(clip);
						Toast.makeText(FloatingNoteService.this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
					}
				}
			});

        btnPaste.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClipDescription() != null) {
						ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
						if (item != null && item.getText() != null) {
							String pasteText = item.getText().toString();
							int start = etNote.getSelectionStart();
							int end = etNote.getSelectionEnd();

							if (start >= 0 && end >= start) {
								etNote.getText().replace(start, end, pasteText);
							} else {
								etNote.append(pasteText);
							}
							Toast.makeText(FloatingNoteService.this, "Pasted from clipboard", Toast.LENGTH_SHORT).show();
						}
					}
				}
			});

        btnMinimize.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					switchToMinimized();
				}
			});

        btnClose.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopSelf();
				}
			});

        minimizedView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					switchToExpanded();
				}
			});

        setupDragTouchListener(headerBar, false);
        setupDragTouchListener(minimizedView, true);

        applySettings();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && MainActivity.ACTION_UPDATE_SETTINGS.equals(intent.getAction())) {
            applySettings();
        }
        return START_STICKY;
    }

    private void applySettings() {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_SETTINGS, MODE_PRIVATE);
        int bubbleOpacity = prefs.getInt(MainActivity.KEY_BUBBLE_OPACITY, 80);
        int canvasOpacity = prefs.getInt(MainActivity.KEY_CANVAS_OPACITY, 70);
        int canvasSizeIndex = prefs.getInt(MainActivity.KEY_CANVAS_SIZE, 1);

        float bubbleAlpha = bubbleOpacity / 100.0f;
        minimizedView.setAlpha(bubbleAlpha);

        int alphaValue = Math.round((canvasOpacity / 100.0f) * 255);
        int strokeAlpha = Math.round((canvasOpacity / 100.0f) * 120);

        GradientDrawable glassDrawable = new GradientDrawable();
        glassDrawable.setShape(GradientDrawable.RECTANGLE);
        glassDrawable.setColor(Color.argb(alphaValue, 25, 33, 44));
        glassDrawable.setCornerRadius(dpToPx(18));
        glassDrawable.setStroke(dpToPx(1), Color.argb(strokeAlpha, 255, 255, 255));

        float radiusPx = dpToPx(18);
        float[] headerRadii = new float[] {
            radiusPx, radiusPx,
            radiusPx, radiusPx,
            0, 0,
            0, 0
        };

        GradientDrawable headerDrawable = new GradientDrawable();
        headerDrawable.setShape(GradientDrawable.RECTANGLE);
        headerDrawable.setColor(Color.argb(34, 255, 255, 255));
        headerDrawable.setCornerRadii(headerRadii);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            expandedView.setBackground(glassDrawable);
            headerBar.setBackground(headerDrawable);
        } else {
            expandedView.setBackgroundDrawable(glassDrawable);
            headerBar.setBackgroundDrawable(headerDrawable);
        }

        int widthDp;
        int heightDp;
        switch (canvasSizeIndex) {
            case 0:
                widthDp = 200;
                heightDp = 280;
                break;
            case 2:
                widthDp = 280;
                heightDp = 395;
                break;
            case 3:
                widthDp = 320;
                heightDp = 450;
                break;
            default:
                widthDp = 240;
                heightDp = 340;
                break;
        }

        ViewGroup.LayoutParams layoutParams = expandedView.getLayoutParams();
        layoutParams.width = dpToPx(widthDp);
        layoutParams.height = dpToPx(heightDp);
        expandedView.setLayoutParams(layoutParams);
    }

    private int dpToPx(int dp) {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        return Math.round(dp * (metrics.densityDpi / 160.0f));
    }

    private void switchToMinimized() {
        expandedView.setVisibility(View.GONE);
        minimizedView.setVisibility(View.VISIBLE);
        params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        windowManager.updateViewLayout(floatingView, params);
    }

    private void switchToExpanded() {
        minimizedView.setVisibility(View.GONE);
        expandedView.setVisibility(View.VISIBLE);
        params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        windowManager.updateViewLayout(floatingView, params);
        etNote.requestFocus();
    }

    private void setupDragTouchListener(View dragView, final boolean isBubble) {
        dragView.setOnTouchListener(new View.OnTouchListener() {
				private int initialX;
				private int initialY;
				private float initialTouchX;
				private float initialTouchY;

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							return !isBubble;

						case MotionEvent.ACTION_MOVE:
							int deltaX = (int) (event.getRawX() - initialTouchX);
							int deltaY = (int) (event.getRawY() - initialTouchY);

							params.x = initialX + deltaX;
							params.y = initialY + deltaY;
							windowManager.updateViewLayout(floatingView, params);
							return true;

						case MotionEvent.ACTION_UP:
							int diffX = (int) (event.getRawX() - initialTouchX);
							int diffY = (int) (event.getRawY() - initialTouchY);

							if (isBubble && Math.abs(diffX) < 10 && Math.abs(diffY) < 10) {
								v.performClick();
							}
							return true;
					}
					return false;
				}
			});
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isServiceRunning = false;
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }
}

