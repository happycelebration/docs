'use client';

import { useState, useEffect, useCallback } from 'react';
import Navbar from './navbar';
import Banner from './banner';
import { Row } from './row';
import MovieDetailModal from './modal';
import SearchOverlay from './search-overlay';
import Footer from './footer';
import SkeletonRow from './skeleton-row';
import { TMDBMovie } from '@/lib/tmdb';

interface MovieRow {
  title: string;
  movies: TMDBMovie[];
  isOriginal?: boolean;
}

const ROW_CONFIGS = [
  { title: 'Flixnet Originals', endpoint: '/api/tmdb/originals', isOriginal: true },
  { title: 'Trending Now', endpoint: '/api/tmdb/trending' },
  { title: 'Top Rated', endpoint: '/api/tmdb/top-rated' },
  { title: 'Action Movies', endpoint: '/api/tmdb/genre?id=28' },
  { title: 'Comedy Movies', endpoint: '/api/tmdb/genre?id=35' },
  { title: 'Horror Movies', endpoint: '/api/tmdb/genre?id=27' },
  { title: 'Romance Movies', endpoint: '/api/tmdb/genre?id=10749' },
  { title: 'Documentaries', endpoint: '/api/tmdb/genre?id=99' },
];

export interface FlixnetMovie {
  id: number;
  title: string;
  name?: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  release_date?: string;
  first_air_date?: string;
  media_type?: 'movie' | 'tv';
}

function toFlixnetMovie(m: TMDBMovie, mediaType: 'movie' | 'tv' = 'movie'): FlixnetMovie {
  return {
    id: m.id,
    title: m.title || m.name || '',
    name: m.name,
    overview: m.overview,
    poster_path: m.poster_path,
    backdrop_path: m.backdrop_path,
    vote_average: m.vote_average,
    release_date: m.release_date,
    first_air_date: m.first_air_date,
    media_type: mediaType,
  };
}

export default function FlixnetApp() {
  const [rows, setRows] = useState<MovieRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [bannerMovie, setBannerMovie] = useState<FlixnetMovie | null>(null);
  const [selectedMovie, setSelectedMovie] = useState<FlixnetMovie | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    async function fetchAllRows() {
      try {
        const results = await Promise.all(
          ROW_CONFIGS.map(async (config) => {
            const res = await fetch(config.endpoint);
            if (!res.ok) return { title: config.title, movies: [], isOriginal: config.isOriginal };
            const data = await res.json();
            return { title: config.title, movies: (data.results || []) as TMDBMovie[], isOriginal: config.isOriginal };
          })
        );
        setRows(results);
        const trending = results.find((r) => r.title === 'Trending Now');
        if (trending && trending.movies.length > 0) {
          const topMovies = trending.movies.slice(0, 5);
          const randomMovie = topMovies[Math.floor(Math.random() * topMovies.length)];
          setBannerMovie(toFlixnetMovie(randomMovie, 'movie'));
        }
      } catch {
      } finally {
        setLoading(false);
      }
    }
    fetchAllRows();
  }, []);

  const handleMovieClick = useCallback((movie: FlixnetMovie) => {
    setSelectedMovie(movie);
    setIsModalOpen(true);
  }, []);

  const handleSearchMovieClick = useCallback((movie: TMDBMovie) => {
    setSelectedMovie(toFlixnetMovie(movie, 'movie'));
    setIsModalOpen(true);
    setIsSearchOpen(false);
  }, []);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedMovie(null);
  }, []);

  const handleSearchToggle = useCallback(() => {
    setIsSearchOpen((prev) => !prev);
  }, []);

  const handlePlay = useCallback((movieId: number) => {
    for (const row of rows) {
      const movie = row.movies.find((m) => m.id === movieId);
      if (movie) {
        setSelectedMovie(toFlixnetMovie(movie, row.isOriginal ? 'tv' : 'movie'));
        setIsModalOpen(true);
        break;
      }
    }
  }, [rows]);

  return (
    <div className="min-h-screen flex flex-col bg-[#111]">
      <Navbar onSearchToggle={handleSearchToggle} isSearchOpen={isSearchOpen} />
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} onMovieClick={handleSearchMovieClick} />
      <main className="flex-1 pt-0">
        {!loading && bannerMovie && <Banner movie={bannerMovie} onPlay={handlePlay} />}
        {loading && <div className="w-full h-[80vh] bg-gray-900 animate-pulse" />}
        <div className="-mt-16 relative z-10 pb-12">
          {loading ? (
            <div className="space-y-8 px-4 md:px-12 pt-8">
              {ROW_CONFIGS.map((config) => (
                <SkeletonRow key={config.title} title={config.title} isOriginal={config.isOriginal} />
              ))}
            </div>
          ) : (
            rows.map((row) => (
              <Row
                key={row.title} title={row.title}
                movies={row.movies.map((m) => toFlixnetMovie(m, row.isOriginal ? 'tv' : 'movie'))}
                isOriginal={row.isOriginal} onMovieClick={handleMovieClick}
              />
            ))
          )}
        </div>
      </main>
      <Footer />
      <MovieDetailModal movie={selectedMovie} isOpen={isModalOpen} onClose={handleCloseModal} />
    </div>
  );
}
