'use client';

import { useState, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { MovieCard } from './movie-card';

interface RowProps {
  title: string;
  movies: Array<{
    id: number;
    title: string;
    name?: string;
    overview: string;
    poster_path: string | null;
    backdrop_path: string | null;
    vote_average: number;
    release_date?: string;
    first_air_date?: string;
    media_type?: 'movie' | 'tv';
  }>;
  isOriginal?: boolean;
  onMovieClick: (movie: RowProps['movies'][0]) => void;
}

export function Row({ title, movies, isOriginal = false, onMovieClick }: RowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeCardId, setActiveCardId] = useState<number | null>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const [isRowHovered, setIsRowHovered] = useState(false);

  const checkArrows = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    setShowLeftArrow(el.scrollLeft > 10);
    setShowRightArrow(el.scrollLeft < el.scrollWidth - el.clientWidth - 10);
  }, []);

  const handleScroll = useCallback(() => { checkArrows(); }, [checkArrows]);

  const scroll = useCallback((direction: 'left' | 'right') => {
    const el = scrollRef.current;
    if (!el) return;
    const cardWidth = isOriginal ? 300 : 185;
    const scrollAmount = cardWidth * 3;
    const target = direction === 'left' ? el.scrollLeft - scrollAmount : el.scrollLeft + scrollAmount;
    el.scrollTo({ left: target, behavior: 'smooth' });
  }, [isOriginal]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    const el = scrollRef.current;
    if (!el) return;
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      e.preventDefault();
      el.scrollTo({ left: el.scrollLeft + e.deltaY * 2, behavior: 'auto' });
    }
  }, []);

  const handleRowEnter = useCallback(() => { setIsRowHovered(true); checkArrows(); }, [checkArrows]);
  const handleRowLeave = useCallback(() => { setIsRowHovered(false); setActiveCardId(null); }, []);
  const handleCardHover = useCallback((id: number | null) => { setActiveCardId(id); }, []);

  if (!movies || movies.length === 0) return null;

  return (
    <div className="group/row relative mb-8">
      <h2 className="mb-2 ml-4 text-base font-bold text-white sm:text-lg md:ml-12">{title}</h2>
      <div className="relative" onMouseEnter={handleRowEnter} onMouseLeave={handleRowLeave}>
        {showLeftArrow && isRowHovered && (
          <motion.button
            initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute left-0 top-0 z-40 flex h-full w-12 items-center justify-center bg-black/60 opacity-0 transition-opacity group-hover/row:opacity-100 md:w-14"
            onClick={() => scroll('left')} aria-label="Scroll left"
          >
            <ChevronLeft className="h-8 w-8 text-white" />
          </motion.button>
        )}
        {showRightArrow && isRowHovered && (
          <motion.button
            initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 top-0 z-40 flex h-full w-12 items-center justify-center bg-black/60 opacity-0 transition-opacity group-hover/row:opacity-100 md:w-14"
            onClick={() => scroll('right')} aria-label="Scroll right"
          >
            <ChevronRight className="h-8 w-8 text-white" />
          </motion.button>
        )}
        <div
          ref={scrollRef} onScroll={handleScroll} onWheel={handleWheel}
          className="scrollbar-hide flex gap-1.5 overflow-x-auto px-4 py-6 md:px-12"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {movies.map((movie) => {
            const isCardActive = activeCardId === movie.id;
            const isSomeOtherCardActive = activeCardId !== null && !isCardActive;
            return (
              <motion.div
                key={movie.id}
                animate={{
                  opacity: isSomeOtherCardActive ? 0.4 : 1,
                  filter: isSomeOtherCardActive ? 'brightness(0.5)' : 'brightness(1)',
                }}
                transition={{ duration: 0.3 }}
                className="flex-shrink-0"
              >
                <MovieCard
                  movie={movie} isActive={isCardActive} onHover={handleCardHover}
                  onClick={onMovieClick} isOriginal={isOriginal}
                />
              </motion.div>
            );
          })}
        </div>
      </div>
      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}
