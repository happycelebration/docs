'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Play, Plus, ThumbsUp } from 'lucide-react';

interface ModalProps {
  movie: {
    id: number;
    title: string;
    name?: string;
    overview: string;
    backdrop_path: string | null;
    vote_average: number;
    release_date?: string;
    first_air_date?: string;
    media_type?: 'movie' | 'tv';
  } | null;
  isOpen: boolean;
  onClose: () => void;
}

interface MovieDetail {
  id: number;
  title: string;
  overview: string;
  backdrop_path: string;
  vote_average: number;
  release_date: string;
  runtime: number;
  genres: { id: number; name: string }[];
  videos: { results: Array<{ key: string; type: string; site: string; name: string }> };
}

const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p';

function getBackdropUrl(path: string | null): string {
  return path ? `${TMDB_IMAGE_BASE}/original${path}` : '';
}

function formatRuntime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return h === 0 ? `${m}m` : `${h}h ${m}m`;
}

function getMatchPercentage(voteAverage: number): number {
  return Math.min(Math.round(voteAverage * 10), 99);
}

function getTrailerKey(videos: MovieDetail['videos']): string | null {
  if (!videos?.results?.length) return null;
  return videos.results.find((v) => v.type === 'Trailer' && v.site === 'YouTube')?.key ?? null;
}

interface ModalContentProps {
  movie: NonNullable<ModalProps['movie']>;
  onClose: () => void;
}

function ModalContent({ movie, onClose }: ModalContentProps) {
  const [details, setDetails] = useState<MovieDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [isTrailerPlaying, setIsTrailerPlaying] = useState(false);
  const [trailerKey, setTrailerKey] = useState<string | null>(null);
  const trailerKeyRef = useRef<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const mediaType = movie.media_type || 'movie';
    fetch(`/api/tmdb/movie?id=${movie.id}&type=${mediaType}`)
      .then((res) => res.json())
      .then((data: MovieDetail) => {
        if (!cancelled) {
          setDetails(data);
          const key = getTrailerKey(data.videos);
          setTrailerKey(key);
          trailerKeyRef.current = key;
          setLoading(false);
        }
      })
      .catch(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [movie.id, movie.media_type]);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  const handleEscape = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      if (isTrailerPlaying) {
        setIsTrailerPlaying(false);
      } else {
        onClose();
      }
    }
  }, [onClose, isTrailerPlaying]);

  useEffect(() => {
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [handleEscape]);

  const displayTitle = movie.title || movie.name || '';
  const releaseYear = movie.release_date
    ? new Date(movie.release_date).getFullYear()
    : movie.first_air_date ? new Date(movie.first_air_date).getFullYear() : null;
  const matchPercent = getMatchPercentage(movie.vote_average);
  const rating = movie.vote_average ? movie.vote_average.toFixed(1) : null;
  const backdropImage = details?.backdrop_path ? getBackdropUrl(details.backdrop_path) : movie.backdrop_path ? getBackdropUrl(movie.backdrop_path) : '';

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-start justify-center"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <motion.div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        transition={{ duration: 0.25 }}
      />
      <motion.div
        className="relative w-full max-w-3xl mx-4 mt-8 sm:mt-12 md:mt-16 rounded-lg overflow-hidden shadow-2xl"
        style={{ backgroundColor: '#181818' }}
        initial={{ opacity: 0, y: 80, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 80, scale: 0.95 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-3 right-3 z-20 flex items-center justify-center w-9 h-9 rounded-full bg-black/60 hover:bg-black/80 transition-colors cursor-pointer" aria-label="Close modal">
          <X className="w-5 h-5 text-white" />
        </button>
        <div className="relative w-full aspect-video overflow-hidden bg-black">
          {isTrailerPlaying && trailerKey ? (
            <iframe
              src={`https://www.youtube.com/embed/${trailerKey}?autoplay=1&mute=1&controls=1&modestbranding=1&rel=0`}
              className="absolute inset-0 w-full h-full"
              allow="autoplay; encrypted-media" allowFullScreen
              title={`${displayTitle} trailer`}
            />
          ) : (
            <>
              {backdropImage && <img src={backdropImage} alt={displayTitle} className="w-full h-full object-cover" />}
              <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#181818]/60 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4 drop-shadow-lg leading-tight">{displayTitle}</h2>
                <div className="flex items-center gap-3">
                  <button onClick={() => { if (trailerKeyRef.current) setIsTrailerPlaying(true); }} className="flex items-center gap-2 px-6 py-2 bg-white text-black rounded-md font-semibold text-sm hover:bg-white/80 transition-colors cursor-pointer">
                    <Play className="w-5 h-5 fill-black" /> Play
                  </button>
                  <button className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-400 bg-black/40 hover:border-white transition-colors cursor-pointer" aria-label="Add to My List">
                    <Plus className="w-5 h-5 text-white" />
                  </button>
                  <button className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-400 bg-black/40 hover:border-white transition-colors cursor-pointer" aria-label="Like">
                    <ThumbsUp className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
        <div className="p-6 sm:p-8 pt-4 sm:pt-6">
          {loading ? (
            <div className="space-y-4 animate-pulse">
              <div className="flex items-center gap-4">
                <div className="h-5 w-20 bg-gray-700 rounded" />
                <div className="h-5 w-12 bg-gray-700 rounded" />
                <div className="h-5 w-16 bg-gray-700 rounded" />
              </div>
              <div className="h-4 w-full bg-gray-700 rounded" />
              <div className="h-4 w-3/4 bg-gray-700 rounded" />
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-sm mb-4">
                <span className="font-semibold" style={{ color: '#46d369' }}>{matchPercent}% Match</span>
                {releaseYear && <span className="text-gray-400">{releaseYear}</span>}
                {rating && (
                  <span className="flex items-center gap-1 text-gray-400">
                    <svg className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" /></svg>
                    {rating}
                  </span>
                )}
                {details?.runtime && <span className="text-gray-400">{formatRuntime(details.runtime)}</span>}
              </div>
              <p className="text-gray-300 text-sm sm:text-base leading-relaxed mb-5">{details?.overview || movie.overview}</p>
              {details?.genres && details.genres.length > 0 && (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-gray-500 text-sm">Genres:</span>
                  {details.genres.map((genre, index) => (
                    <span key={genre.id} className="inline-flex items-center">
                      <span className="text-white text-sm hover:text-gray-300 transition-colors cursor-default">{genre.name}</span>
                      {index < details.genres.length - 1 && <span className="text-gray-600 text-sm ml-2">&bull;</span>}
                    </span>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function MovieDetailModal({ movie, isOpen, onClose }: ModalProps) {
  return (
    <AnimatePresence>
      {isOpen && movie && <ModalContent key={movie.id} movie={movie} onClose={onClose} />}
    </AnimatePresence>
  );
}
