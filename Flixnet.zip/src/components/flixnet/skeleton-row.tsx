'use client';

interface SkeletonRowProps {
  title?: string;
  isOriginal?: boolean;
}

function ShimmerBlock({ className = '' }: { className?: string }) {
  return (
    <div className={`relative overflow-hidden rounded-md bg-white/10 ${className}`}>
      <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/8 to-transparent" />
    </div>
  );
}

export default function SkeletonRow({ title, isOriginal = false }: SkeletonRowProps) {
  const cardCount = isOriginal ? 7 : 6;

  return (
    <div className="w-full py-4">
      {title ? (
        <h2 className="text-white text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4">
          {title}
        </h2>
      ) : (
        <ShimmerBlock className="h-6 sm:h-7 w-40 sm:w-52 mb-3 sm:mb-4" />
      )}

      <div className="flex gap-2 sm:gap-3 overflow-hidden">
        {Array.from({ length: cardCount }).map((_, i) => (
          <div
            key={i}
            className={`shrink-0 ${
              isOriginal
                ? 'w-[130px] sm:w-[170px] md:w-[200px]'
                : 'w-[130px] sm:w-[160px] md:w-[185px]'
            }`}
          >
            <ShimmerBlock
              className={isOriginal ? 'aspect-video' : 'aspect-[2/3]'}
            />

            {!isOriginal && (
              <div className="mt-2 space-y-1.5">
                <ShimmerBlock className="h-3 w-4/5" />
                <ShimmerBlock className="h-3 w-1/2" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
