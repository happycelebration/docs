'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Menu, X, ChevronDown } from 'lucide-react';

interface NavbarProps {
  onSearchToggle: () => void;
  isSearchOpen: boolean;
}

const NAV_ITEMS = ['Home', 'TV Shows', 'Movies', 'New & Popular', 'My List'];

export default function Navbar({ onSearchToggle, isSearchOpen }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeItem, setActiveItem] = useState('Home');
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setIsScrolled(window.scrollY > 50);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) searchInputRef.current.focus();
  }, [isSearchOpen]);

  useEffect(() => {
    const handleResize = () => { if (window.innerWidth >= 768) setIsMobileMenuOpen(false); };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isMobileMenuOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isMobileMenuOpen]);

  const handleNavClick = useCallback((label: string) => {
    setActiveItem(label);
    setIsMobileMenuOpen(false);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-500 ease-in-out ${
          isScrolled ? 'bg-[#111]' : 'bg-transparent'
        }`}
        style={{ backgroundColor: isScrolled ? 'rgba(17,17,17,0.97)' : 'rgba(0,0,0,0)' }}
      >
        <div
          className={`absolute bottom-0 left-0 right-0 h-px transition-opacity duration-500 ${
            isScrolled ? 'opacity-100 bg-gradient-to-r from-transparent via-red-600/20 to-transparent' : 'opacity-0'
          }`}
        />
        <div className="flex items-center justify-between px-4 md:px-12 py-3 md:py-4">
          <div className="flex items-center gap-2 md:gap-8">
            <button
              className="md:hidden relative z-50 p-1 text-white hover:text-white/80 transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <a
              href="#"
              className="text-[#e50914] font-black text-xl sm:text-2xl md:text-3xl tracking-[0.08em] leading-none select-none"
              style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif', textShadow: '2px 2px 4px rgba(229,9,20,0.3)' }}
            >
              FLIXNET
            </a>
            <ul className="hidden md:flex items-center gap-1 lg:gap-5">
              {NAV_ITEMS.map((label) => (
                <li key={label}>
                  <button
                    onClick={() => handleNavClick(label)}
                    className={`relative px-1 py-1 text-sm transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                      activeItem === label ? 'text-white font-medium' : 'text-gray-300 hover:text-white/90'
                    }`}
                  >
                    {label}
                    {activeItem === label && (
                      <motion.div
                        layoutId="nav-active-indicator"
                        className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#e50914]"
                        transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                      />
                    )}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <div className="flex items-center">
              <AnimatePresence>
                {isSearchOpen && (
                  <motion.div
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 180, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
                    className="overflow-hidden"
                  >
                    <input
                      ref={searchInputRef}
                      type="text"
                      placeholder="Titles, people, genres"
                      className="w-full bg-black/80 border border-white/30 text-white text-sm px-3 py-1.5 placeholder-gray-400 focus:outline-none focus:border-white/60 transition-colors"
                    />
                  </motion.div>
                )}
              </AnimatePresence>
              <button
                onClick={onSearchToggle}
                className="p-2 text-white hover:text-white/80 transition-colors cursor-pointer"
                aria-label={isSearchOpen ? 'Close search' : 'Open search'}
              >
                <Search className="w-5 h-5" />
              </button>
            </div>
            <div className="group relative flex items-center gap-1 cursor-pointer">
              <div
                className="w-8 h-8 rounded overflow-hidden flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #e50914 0%, #b20710 50%, #8c0610 100%)' }}
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-white/90">
                  <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z" />
                </svg>
              </div>
              <ChevronDown className="w-3 h-3 text-white transition-transform duration-200 group-hover:rotate-180" />
            </div>
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
              onClick={() => setIsMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed top-0 left-0 bottom-0 z-40 w-64 bg-black/95 border-r border-white/5 md:hidden"
            >
              <div className="flex items-center justify-between p-4 border-b border-white/10">
                <span className="text-[#e50914] font-black text-xl tracking-[0.08em]">FLIXNET</span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-1 text-white/60 hover:text-white transition-colors" aria-label="Close menu">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="py-4">
                {NAV_ITEMS.map((label, index) => (
                  <motion.button
                    key={label}
                    initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * index, duration: 0.25 }}
                    onClick={() => handleNavClick(label)}
                    className={`flex items-center w-full px-6 py-3 text-base transition-colors cursor-pointer ${
                      activeItem === label ? 'text-white bg-white/5 border-l-2 border-[#e50914]' : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {label}
                  </motion.button>
                ))}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
