'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Plus, ThumbsUp, ChevronDown } from 'lucide-react';

export interface MovieCardProps {
  movie: {
    id: number;
    title: string;
    name?: string;
    overview: string;
    poster_path: string | null;
    backdrop_path: string | null;
    vote_average: number;
    release_date?: string;
    first_air_date?: string;
    media_type?: 'movie' | 'tv';
  };
  isActive: boolean;
  onHover: (id: number | null) => void;
  onClick: (movie: MovieCardProps['movie']) => void;
  isOriginal?: boolean;
}

function getRatingColor(vote: number): string {
  if (vote >= 7) return '#46d369';
  if (vote >= 5) return '#ffc107';
  return '#e50914';
}

function getRatingLabel(vote: number): string {
  if (vote >= 7) return 'Popular';
  if (vote >= 5) return 'Mixed';
  return 'Low';
}

export function MovieCard({ movie, isActive, onHover, onClick, isOriginal = false }: MovieCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const displayTitle = movie.title || movie.name || 'Untitled';
  const imagePath = isOriginal
    ? movie.backdrop_path ? `https://image.tmdb.org/t/p/w780${movie.backdrop_path}` : null
    : movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : null;
  const ratingColor = getRatingColor(movie.vote_average);
  const ratingPercent = Math.round(movie.vote_average * 10);

  const handleMouseEnter = useCallback(() => { onHover(movie.id); }, [movie.id, onHover]);
  const handleMouseLeave = useCallback(() => { onHover(null); }, [onHover]);

  return (
    <motion.div
      className="relative flex-shrink-0 cursor-pointer"
      onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}
      onClick={() => onClick(movie)}
      animate={{ scale: isActive ? 1.2 : 1, zIndex: isActive ? 50 : 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20, delay: isActive ? 0.2 : 0 }}
      style={{ width: isOriginal ? 300 : 185, marginLeft: isActive ? 30 : 0, marginRight: isActive ? 30 : 0 }}
    >
      <motion.div
        className="relative overflow-hidden rounded-md"
        animate={{ boxShadow: isActive ? '0 8px 40px rgba(0,0,0,0.8), 0 0 20px rgba(229,9,20,0.3)' : '0 2px 8px rgba(0,0,0,0.3)' }}
        transition={{ type: 'spring', stiffness: 300, damping: 20, delay: isActive ? 0.2 : 0 }}
      >
        <div className="relative w-full overflow-hidden bg-gray-900" style={{ aspectRatio: isOriginal ? '16/9' : '2/3' }}>
          {imagePath ? (
            <img
              src={imagePath} alt={displayTitle} loading="lazy"
              className={`h-full w-full object-cover transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
              onLoad={() => setImageLoaded(true)}
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gray-800">
              <span className="text-sm text-gray-500">No Image</span>
            </div>
          )}
          {!imageLoaded && imagePath && <div className="absolute inset-0 animate-pulse bg-gray-800" />}
        </div>

        <AnimatePresence>
          {isActive && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.2, delay: 0.15 }}
              className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/95 to-black/60 px-3 pb-3 pt-8"
            >
              <h3 className="mb-1.5 text-sm font-bold leading-tight text-white line-clamp-2">{displayTitle}</h3>
              <div className="mb-2 flex items-center gap-2">
                <span
                  className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-xs font-bold"
                  style={{ backgroundColor: `${ratingColor}22`, color: ratingColor, border: `1px solid ${ratingColor}55` }}
                >
                  <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ backgroundColor: ratingColor }} />
                  {ratingPercent}%
                </span>
                <span className="text-xs text-gray-400">{getRatingLabel(movie.vote_average)}</span>
              </div>
              <p className="mb-3 text-xs leading-relaxed text-gray-400 line-clamp-2">{movie.overview || 'No description available.'}</p>
              <div className="flex items-center gap-1.5">
                <button className="flex h-7 w-7 items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-110" onClick={(e) => { e.stopPropagation(); onClick(movie); }} aria-label="Play">
                  <Play className="h-3.5 w-3.5 fill-black" />
                </button>
                <button className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-gray-400 text-white transition-colors hover:border-white" onClick={(e) => e.stopPropagation()} aria-label="Add to list">
                  <Plus className="h-3.5 w-3.5" />
                </button>
                <button className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-gray-400 text-white transition-colors hover:border-white" onClick={(e) => e.stopPropagation()} aria-label="Like">
                  <ThumbsUp className="h-3 w-3" />
                </button>
                <button className="ml-auto flex h-7 w-7 items-center justify-center rounded-full border-2 border-gray-400 text-white transition-colors hover:border-white" onClick={(e) => { e.stopPropagation(); onClick(movie); }} aria-label="More info">
                  <ChevronDown className="h-3.5 w-3.5" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}
