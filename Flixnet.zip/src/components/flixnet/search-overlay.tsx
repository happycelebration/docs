'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Star } from 'lucide-react';
import { TMDBMovie, getImageUrl } from '@/lib/tmdb';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onMovieClick: (movie: TMDBMovie) => void;
}

export default function SearchOverlay({ isOpen, onClose, onMovieClick }: SearchOverlayProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<TMDBMovie[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 150);
    } else {
      setQuery('');
      setResults([]);
      setHasSearched(false);
      setLoading(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const performSearch = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      setHasSearched(false);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/tmdb/search?q=${encodeURIComponent(searchQuery.trim())}`);
      if (res.ok) {
        const data = await res.json();
        setResults(data.results || []);
      } else {
        setResults([]);
      }
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
      setHasSearched(true);
    }
  }, []);

  const handleInputChange = (value: string) => {
    setQuery(value);
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    if (!value.trim()) {
      setResults([]);
      setHasSearched(false);
      setLoading(false);
      return;
    }
    setLoading(true);
    debounceTimerRef.current = setTimeout(() => performSearch(value), 300);
  };

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="fixed inset-0 z-50 bg-[#141414] overflow-y-auto"
        >
          <div className="sticky top-0 z-20 bg-[#141414]">
            <div className="flex items-center gap-3 px-4 sm:px-8 lg:px-12 py-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-[18px] h-[18px] text-gray-400 pointer-events-none" />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => handleInputChange(e.target.value)}
                  placeholder="Titles, people, genres"
                  className="w-full h-10 sm:h-11 pl-10 pr-9 bg-[#2a2a2a] border-none rounded text-white text-sm sm:text-base placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500 transition-colors"
                />
                {query && (
                  <button
                    onClick={() => handleInputChange('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
                    aria-label="Clear search"
                  >
                    <X className="w-4 h-4 text-gray-400" />
                  </button>
                )}
              </div>
              <button
                onClick={onClose}
                className="flex-shrink-0 h-10 sm:h-11 px-3 text-white text-sm sm:text-base font-medium hover:text-white/80 transition-colors cursor-pointer whitespace-nowrap"
                aria-label="Close search"
              >
                Cancel
              </button>
            </div>
          </div>

          <div className="px-4 sm:px-8 lg:px-12 py-4 sm:py-6">
            {loading && (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-[2/3] bg-[#2a2a2a] rounded-sm mb-2" />
                    <div className="h-3 bg-[#2a2a2a] rounded w-3/4 mb-1.5" />
                    <div className="h-2.5 bg-[#2a2a2a] rounded w-1/2" />
                  </div>
                ))}
              </div>
            )}

            {!loading && hasSearched && results.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-24"
              >
                <Search className="w-12 h-12 text-gray-600 mb-3" />
                <h3 className="text-lg sm:text-xl text-white font-medium mb-1">No results found</h3>
                <p className="text-gray-500 text-sm text-center max-w-xs">
                  We couldn&apos;t find any movies matching &ldquo;{query}&rdquo;. Try a different search.
                </p>
              </motion.div>
            )}

            {!loading && results.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <p className="text-gray-500 text-xs mb-4">
                  {results.length} result{results.length !== 1 ? 's' : ''} for &ldquo;{query}&rdquo;
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
                  {results.map((movie, index) => (
                    <motion.button
                      key={movie.id}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.25, delay: Math.min(index * 0.04, 0.25) }}
                      onClick={() => onMovieClick(movie)}
                      className="group text-left cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-gray-400 rounded-sm"
                    >
                      <div className="relative aspect-[2/3] rounded-sm overflow-hidden mb-2 bg-[#2a2a2a]">
                        <img
                          src={getImageUrl(movie.poster_path, 'w500')}
                          alt={movie.title || movie.name || 'Movie poster'}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-200 flex items-center justify-center">
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                            <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M8 5v14l11-7z" />
                            </svg>
                          </div>
                        </div>
                        {movie.vote_average > 0 && (
                          <div className="absolute top-1.5 right-1.5 flex items-center gap-0.5 bg-black/80 rounded px-1 py-0.5">
                            <Star className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400" />
                            <span className="text-[10px] text-white font-medium">{movie.vote_average.toFixed(1)}</span>
                          </div>
                        )}
                      </div>
                      <h3 className="text-white text-xs sm:text-sm font-normal truncate group-hover:text-gray-300 transition-colors">
                        {movie.title || movie.name}
                      </h3>
                      {(movie.release_date || movie.first_air_date) && (
                        <p className="text-gray-600 text-[11px] sm:text-xs mt-0.5">
                          {(movie.release_date || movie.first_air_date)?.split('-')[0]}
                        </p>
                      )}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            {!loading && !hasSearched && (
              <div className="flex flex-col items-center justify-center py-24">
                <Search className="w-12 h-12 text-gray-600 mb-3" />
                <h3 className="text-lg sm:text-xl text-white font-medium mb-1">Search for movies</h3>
                <p className="text-gray-500 text-sm text-center max-w-xs">
                  Type a title, genre, or keyword to find your next watch.
                </p>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
