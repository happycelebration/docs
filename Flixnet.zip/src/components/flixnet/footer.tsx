'use client';

import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Youtube, href: '#', label: 'YouTube' },
];

const footerLinks = [
  ['Audio Description', 'Help Center', 'Gift Cards', 'Media Center'],
  ['Investor Relations', 'Jobs', 'Terms of Use', 'Privacy'],
  ['Legal Notices', 'Cookie Preferences', 'Corporate Information', 'Contact Us'],
  ['Account', 'Ways to Watch', 'Speed Test', 'Only on Flixnet'],
];

export default function Footer() {
  return (
    <footer className="bg-[#111] text-gray-400 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="flex items-center gap-5 mb-6">
          {socialLinks.map(({ icon: Icon, href, label }) => (
            <a key={label} href={href} aria-label={label} className="text-gray-400 hover:text-white transition-colors duration-200">
              <Icon className="w-5 h-5 sm:w-6 sm:h-6" />
            </a>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {footerLinks.map((column, colIndex) => (
            <ul key={colIndex} className="space-y-2 sm:space-y-3">
              {column.map((link) => (
                <li key={link}>
                  <a href="#" className="text-xs sm:text-sm text-gray-400 hover:text-white hover:underline transition-colors duration-200 underline-offset-2">{link}</a>
                </li>
              ))}
            </ul>
          ))}
        </div>
        <div className="mb-6">
          <button className="border border-gray-500 text-gray-400 text-xs px-3 py-1.5 hover:text-white hover:border-white transition-colors duration-200">Service Code</button>
        </div>
        <div className="mb-4 flex items-start gap-3">
          <svg className="w-8 h-8 shrink-0 mt-0.5" viewBox="0 0 185.3 134.8" fill="currentColor" aria-hidden="true">
            <path d="M0 0h185.3v134.8H0z" fill="none" />
            <path d="M29.5 17.2h18.4v52.3c0 12.5 4.7 18.2 14.2 18.2s14.3-5.7 14.3-18.2V17.2h18.4v54.4c0 21.7-13.6 34.4-32.7 34.4S29.5 93.3 29.5 71.6V17.2zM102.8 17.2h27.7c16.3 0 27 8.3 27 21.8 0 8.8-4.3 15.6-12.3 19.1v.3c9.6 2.5 15.4 10 15.4 20.2 0 15.7-12.3 25.8-30.5 25.8h-27.3V17.2zm18.3 33.9h5.3c6.4 0 11.5-3.1 11.5-9.7 0-6.2-4.5-9.3-11.2-9.3h-5.6v19zm0 36h6.8c7.8 0 12.5-3.7 12.5-10.5 0-6.5-4.8-10.2-12.7-10.2H121v20.7z" />
          </svg>
          <p className="text-xs text-gray-500 leading-relaxed">This product uses the TMDB API but is not endorsed or certified by TMDB.</p>
        </div>
        <p className="text-xs text-gray-600">&copy; {new Date().getFullYear()} Flixnet by Pallavi Thakur. All rights reserved. This is a demo project and is not affiliated with Netflix, Inc.</p>
      </div>
    </footer>
  );
}
