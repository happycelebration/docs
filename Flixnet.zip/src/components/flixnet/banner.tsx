'use client';

import { motion } from 'framer-motion';
import { Play, Plus, Info } from 'lucide-react';

interface BannerProps {
  movie: {
    id: number;
    title: string;
    name?: string;
    overview: string;
    backdrop_path: string | null;
    media_type?: 'movie' | 'tv';
  } | null;
  onPlay: (movieId: number) => void;
}

export default function Banner({ movie, onPlay }: BannerProps) {
  if (!movie) return null;

  const displayTitle = movie.title || movie.name || 'Untitled';
  const imageUrl = movie.backdrop_path
    ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}`
    : null;

  return (
    <div className="relative w-full h-[80vh] overflow-hidden bg-black">
      {imageUrl && (
        <motion.div
          className="absolute inset-0 w-full h-full"
          initial={{ scale: 1.0 }}
          animate={{ scale: 1.1 }}
          transition={{ duration: 20, ease: 'linear', repeat: Infinity, repeatType: 'reverse' }}
        >
          <img src={imageUrl} alt={displayTitle} className="w-full h-full object-cover object-center" />
        </motion.div>
      )}
      <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, transparent 40%)' }} />
      <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to top, #111 0%, transparent 50%)' }} />
      <div className="absolute bottom-[15%] left-0 right-0 z-10 px-4 md:px-12 lg:px-16">
        <motion.div className="max-w-2xl space-y-4" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}>
          <motion.h1 className="text-white font-bold text-3xl md:text-5xl drop-shadow-lg leading-tight" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: 'easeOut', delay: 0.3 }}>
            {displayTitle}
          </motion.h1>
          <motion.p className="text-gray-200 text-sm md:text-base leading-relaxed line-clamp-3 drop-shadow-md max-w-xl" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: 'easeOut', delay: 0.5 }}>
            {movie.overview}
          </motion.p>
          <motion.div className="flex items-center gap-3" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: 'easeOut', delay: 0.7 }}>
            <button onClick={() => onPlay(movie.id)} className="flex items-center gap-2 bg-white text-black font-semibold px-5 md:px-8 py-2 md:py-2.5 rounded-md hover:bg-white/80 transition-colors duration-200 text-sm md:text-base cursor-pointer">
              <Play className="w-5 h-5 fill-current" /> Play
            </button>
            <button className="flex items-center gap-2 bg-gray-500/50 text-white font-semibold px-5 md:px-8 py-2 md:py-2.5 rounded-md hover:bg-gray-500/70 transition-colors duration-200 text-sm md:text-base cursor-pointer">
              <Plus className="w-5 h-5" /> My List
            </button>
            <button className="flex items-center justify-center w-9 h-9 md:w-10 md:h-10 rounded-full bg-gray-500/50 text-white hover:bg-gray-500/70 transition-colors duration-200 cursor-pointer">
              <Info className="w-5 h-5" />
            </button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
