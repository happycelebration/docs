import { getTopRated } from "@/lib/tmdb";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await getTopRated();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to fetch top rated" }, { status: 500 });
  }
}
