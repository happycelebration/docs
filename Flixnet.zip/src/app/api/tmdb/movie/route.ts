import { getDetailsById } from "@/lib/tmdb";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    const type = searchParams.get("type") || "movie";
    if (!id) return NextResponse.json({ error: "Movie id is required" }, { status: 400 });
    const validType = type === "tv" ? "tv" : "movie";
    const data = await getDetailsById(Number(id), validType);
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to fetch details" }, { status: 500 });
  }
}
