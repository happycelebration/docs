import { getMoviesByGenre } from "@/lib/tmdb";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Genre id is required" }, { status: 400 });
    const data = await getMoviesByGenre(Number(id));
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to fetch genre movies" }, { status: 500 });
  }
}
