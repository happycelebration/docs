import { searchMovies } from "@/lib/tmdb";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get("q");
    if (!query) return NextResponse.json({ error: "Search query is required" }, { status: 400 });
    const data = await searchMovies(query);
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to search movies" }, { status: 500 });
  }
}
