import { getNetflixOriginals } from "@/lib/tmdb";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await getNetflixOriginals();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to fetch originals" }, { status: 500 });
  }
}
