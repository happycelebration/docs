import { getTrending } from "@/lib/tmdb";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const data = await getTrending();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to fetch trending" }, { status: 500 });
  }
}
