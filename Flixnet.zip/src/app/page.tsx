import FlixnetApp from '@/components/flixnet/flixnet-app';

export default function Home() {
  return <FlixnetApp />;
}
