const TMDB_API_KEY = process.env.TMDB_API_KEY || "9af439041dd4382b3b71b3bcc95d79bc";
const TMDB_BASE_URL = "https://api.themoviedb.org/3";
export const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";

export interface TMDBMovie {
  id: number;
  title: string;
  name?: string;
  original_title?: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  vote_count: number;
  release_date?: string;
  first_air_date?: string;
  genre_ids?: number[];
  popularity: number;
  media_type?: string;
}

export interface TMDBVideo {
  id: string;
  key: string;
  name: string;
  site: string;
  type: string;
  official: boolean;
}

export interface TMDBMovieDetail extends TMDBMovie {
  runtime?: number;
  genres: { id: number; name: string }[];
  tagline?: string;
  status?: string;
  videos?: { results: TMDBVideo[] };
}

async function tmdbFetch<T>(endpoint: string, params: Record<string, string> = {}): Promise<T> {
  const url = new URL(`${TMDB_BASE_URL}${endpoint}`);
  url.searchParams.set("api_key", TMDB_API_KEY);
  url.searchParams.set("language", "en-US");
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });
  const res = await fetch(url.toString(), { next: { revalidate: 3600 } });
  if (!res.ok) throw new Error(`TMDB API error: ${res.status}`);
  return res.json();
}

export async function getTrending(mediaType = "movie", timeWindow = "week") {
  return tmdbFetch<{ results: TMDBMovie[] }>(`/trending/${mediaType}/${timeWindow}`);
}

export async function getTopRated() {
  return tmdbFetch<{ results: TMDBMovie[] }>("/movie/top_rated");
}

export async function getMoviesByGenre(genreId: number, page = 1) {
  return tmdbFetch<{ results: TMDBMovie[] }>("/discover/movie", {
    with_genres: String(genreId),
    sort_by: "popularity.desc",
    page: String(page),
  });
}

export async function getNetflixOriginals() {
  return tmdbFetch<{ results: TMDBMovie[] }>("/discover/tv", {
    with_networks: "213",
    sort_by: "popularity.desc",
  });
}

export async function getMovieDetails(movieId: number) {
  return tmdbFetch<TMDBMovieDetail>(`/movie/${movieId}`, { append_to_response: "videos" });
}

export async function getTVDetails(tvId: number) {
  return tmdbFetch<TMDBMovieDetail>(`/tv/${tvId}`, { append_to_response: "videos" });
}

export async function getDetailsById(id: number, type: "movie" | "tv" = "movie") {
  return type === "tv" ? getTVDetails(id) : getMovieDetails(id);
}

export async function searchMovies(query: string, page = 1) {
  return tmdbFetch<{ results: TMDBMovie[]; total_results: number }>("/search/movie", {
    query,
    page: String(page),
  });
}

export function getImageUrl(path: string | null, size: "w300" | "w500" | "w780" | "original" = "w500") {
  if (!path) return "/placeholder-movie.svg";
  return `${TMDB_IMAGE_BASE}/${size}${path}`;
}

export function getBackdropUrl(path: string | null) {
  if (!path) return null;
  return `${TMDB_IMAGE_BASE}/original${path}`;
}
