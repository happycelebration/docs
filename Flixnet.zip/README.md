# Flixnet

A Netflix-inspired movie streaming UI built with **Next.js 16**, **TypeScript**, **Tailwind CSS**, and **Framer Motion** — powered by [The Movie Database (TMDB)](https://www.themoviedb.org/) API.

![Next.js](https://img.shields.io/badge/Next.js-16-black?logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-06B6D4?logo=tailwindcss)
![Framer Motion](https://img.shields.io/badge/Framer_Motion-12-purple?logo=framer)
![TMDB](https://img.shields.io/badge/TMDB-API-01D277?logo=themoviedb)

---

## Preview

A full-featured Netflix clone with:

- Cinematic hero banner with animated backdrop
- Horizontally scrollable content rows
- Hover-expanding movie cards with spring animations
- Movie detail modal with YouTube trailer playback
- Full-screen search with live TMDB results
- Fully responsive design (mobile → desktop)
- Smooth Framer Motion animations throughout
- Skeleton loading states

---

## Features

### Core UI

| Feature | Description |
|---|---|
| **Navbar** | Fixed header that transitions from transparent to solid black on scroll, with FLIXNET branding, navigation links, search toggle, and profile avatar |
| **Hero Banner** | Full-width cinematic backdrop (80vh) with slow zoom animation, gradient overlays, movie title, description, and Play / My List / More Info buttons |
| **Content Rows** | Horizontally scrollable rows with chevron navigation and mouse-wheel-to-horizontal-scroll support. 8 curated categories |
| **Movie Cards** | Poster cards with spring-animated hover scale (1.2×), red glow shadow, rating badge, and quick action buttons |
| **Detail Modal** | Fullscreen overlay with backdrop blur, YouTube trailer embed, movie metadata (title, description, release date, rating), and escape-key support |
| **Search Overlay** | Full-screen search with debounced input (300ms), live TMDB results in a responsive grid with star ratings |
| **Footer** | Netflix-style footer with social links, navigation columns, and mandatory TMDB attribution |

### Design System

- **Background**: `#111111` (Netflix dark)
- **Accent**: `#E50914` (Netflix red)
- **Typography**: Geist Sans (via Next.js)
- **Animations**: Spring physics via Framer Motion
- **Theme**: Dark mode with cinematic gradients

### Content Categories

| Row | Source | Type |
|---|---|---|
| Flixnet Originals | TMDB Discover TV (Network 213) | TV Shows |
| Trending Now | TMDB Trending (Weekly) | Movies |
| Top Rated | TMDB Top Rated | Movies |
| Action Movies | TMDB Discover (Genre 28) | Movies |
| Comedy Movies | TMDB Discover (Genre 35) | Movies |
| Horror Movies | TMDB Discover (Genre 27) | Movies |
| Romance Movies | TMDB Discover (Genre 10749) | Movies |
| Documentaries | TMDB Discover (Genre 99) | Movies |

---

## Tech Stack

| Technology | Purpose |
|---|---|
| **Next.js 16** | React framework with App Router |
| **TypeScript 5** | Type safety |
| **Tailwind CSS 4** | Utility-first styling |
| **Framer Motion 12** | Spring-based animations & transitions |
| **TMDB API v3** | Movie & TV show data source |
| **Lucide React** | Icon library |
| **shadcn/ui** | UI component foundation |

---

## Project Structure

```
src/
├── app/
│   ├── api/tmdb/
│   │   ├── genre/route.ts          # GET /api/tmdb/genre?id=
│   │   ├── movie/route.ts          # GET /api/tmdb/movie?id=&type=
│   │   ├── originals/route.ts      # GET /api/tmdb/originals
│   │   ├── search/route.ts         # GET /api/tmdb/search?q=
│   │   ├── top-rated/route.ts      # GET /api/tmdb/top-rated
│   │   └── trending/route.ts       # GET /api/tmdb/trending
│   ├── globals.css                 # Global styles + custom utilities
│   ├── layout.tsx                  # Root layout (dark theme, Geist font)
│   └── page.tsx                    # Home page
├── components/flixnet/
│   ├── banner.tsx                  # Hero banner with animated backdrop
│   ├── flixnet-app.tsx             # Main app orchestrator component
│   ├── footer.tsx                  # Netflix-style footer
│   ├── modal.tsx                   # Movie detail modal with trailer
│   ├── movie-card.tsx              # Movie card with hover effects
│   ├── navbar.tsx                  # Fixed navbar with scroll effect
│   ├── row.tsx                     # Horizontal scrollable movie row
│   ├── search-overlay.tsx          # Full-screen search overlay
│   └── skeleton-row.tsx            # Loading skeleton rows
└── lib/
    └── tmdb.ts                     # TMDB API client & TypeScript types
```

---

## Getting Started

### Prerequisites

- **Node.js** ≥ 18 or **Bun** ≥ 1.0
- **TMDB API Key** — [Get yours here](https://www.themoviedb.org/settings/api)

### Installation

```bash
# Clone the repository
git clone https://github.com/cloudxplorer/Flixnet
cd Flixnet

# Install dependencies
bun install
# or
npm install
```

### Environment Setup

Create a `.env` file in the project root:

```env
TMDB_API_KEY=your_tmdb_api_key_here
```

> Get your free TMDB API key at [themoviedb.org/settings/api](https://www.themoviedb.org/settings/api)

### Run the Development Server

```bash
bun run dev
# or
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
bun run build
# or
npm run build
```

---

## API Routes

All API routes proxy requests to TMDB, keeping your API key server-side.

| Method | Endpoint | Description | Parameters |
|---|---|---|---|
| `GET` | `/api/tmdb/trending` | Fetch trending movies of the week | — |
| `GET` | `/api/tmdb/top-rated` | Fetch top-rated movies | — |
| `GET` | `/api/tmdb/originals` | Fetch Netflix original TV shows | — |
| `GET` | `/api/tmdb/genre` | Fetch movies by genre | `id` (genre ID) |
| `GET` | `/api/tmdb/search` | Search movies | `q` (query string) |
| `GET` | `/api/tmdb/movie` | Fetch movie/TV details + trailer | `id` (TMDB ID), `type` (`movie` or `tv`) |

### Example Requests

```bash
# Trending movies
curl http://localhost:3000/api/tmdb/trending

# Search for "Inception"
curl http://localhost:3000/api/tmdb/search?q=Inception

# Get movie details with trailer
curl http://localhost:3000/api/tmdb/movie?id=550&type=movie

# Get TV show details
curl http://localhost:3000/api/tmdb/movie?id=1399&type=tv
```

---

## Component Architecture

```
FlixnetApp (Orchestrator)
├── Navbar
│   ├── Logo & Navigation
│   ├── Search Toggle → SearchOverlay
│   └── Profile Avatar
├── Banner (Hero)
│   ├── Backdrop Image (animated zoom)
│   ├── Gradient Overlays
│   └── Action Buttons (Play, My List, More Info)
├── Row × 8
│   ├── Row Title
│   ├── Chevron Navigation (← →)
│   └── MovieCard × N
│       ├── Poster Image
│       ├── Hover Expansion (spring animation)
│       ├── Rating Badge
│       └── Click → Modal
├── Modal
│   ├── Backdrop Blur Overlay
│   ├── YouTube Trailer (React Player)
│   ├── Movie Metadata
│   └── Close Button (Escape key)
├── SearchOverlay
│   ├── Search Input (debounced)
│   ├── Results Grid
│   └── Result Cards (click → Modal)
├── SkeletonRow (Loading State)
└── Footer
    ├── Social Links
    ├── Navigation Columns
    └── TMDB Attribution
```

---

## Key Interactions

### Movie Card Hover

Cards expand with a **spring animation** (`stiffness: 300, damping: 20`) on hover, revealing:
- Movie title and rating
- Brief description
- Quick action buttons (Play, Add to List, More Info)

### Modal Trailer Playback

Clicking "More Info" or a movie card opens a **fullscreen modal** that:
1. Fetches movie/TV details from TMDB
2. Searches for an official YouTube trailer
3. Autoplays the trailer with React Player
4. Displays full metadata below the video

### Search

The search overlay:
1. Opens with a smooth Framer Motion animation
2. Debounces input by 300ms
3. Queries TMDB search API
4. Displays results in a responsive grid
5. Clicking a result opens the detail modal

---

## Responsive Breakpoints

| Breakpoint | Layout |
|---|---|
| `< 640px` (Mobile) | Single column, smaller cards, simplified navbar |
| `640–768px` (Tablet) | 2–3 cards visible per row |
| `768–1024px` (Small Desktop) | 4–5 cards per row, full navbar |
| `> 1024px` (Desktop) | 6+ cards per row, full cinematic experience |

---

## License

This project is for **educational and demonstration purposes only**.

- This product uses the TMDB API but is not endorsed or certified by TMDB.
- All movie data and images are property of their respective owners.
- Netflix is a trademark of Netflix, Inc. This project is not affiliated with Netflix.

---

## Acknowledgments

- [The Movie Database (TMDB)](https://www.themoviedb.org/) — For the amazing free API
- [Netflix](https://www.netflix.com/) — Design inspiration
- [Next.js](https://nextjs.org/) — The React framework
- [Framer Motion](https://www.framer.com/motion/) — Animation library
- [Tailwind CSS](https://tailwindcss.com/) — Utility-first CSS framework
- [shadcn/ui](https://ui.shadcn.com/) — UI component library
